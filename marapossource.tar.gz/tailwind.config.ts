import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          DEFAULT: 'rgb(var(--brand-primary-rgb) / <alpha-value>)',
          dark: '#8E0B20',
          light: '#E8354F',
        },
        ink: {
          DEFAULT: 'rgb(var(--brand-secondary-rgb) / <alpha-value>)',
          soft: '#2A2A2A',
        },
        surface: {
          DEFAULT: '#FFFFFF',
          muted: '#F5F6F8',
          border: '#E4E7EC',
        },
        state: {
          available: '#16A34A',
          occupied: '#DC2626',
          awaiting: '#F59E0B',
          reserved: '#2563EB',
          cleaning: '#6B7280',
        },
      },
      fontFamily: {
        sans: ['var(--font-arabic)', 'Tahoma', 'Arial', 'sans-serif'],
      },
      boxShadow: {
        card: '0 1px 3px rgba(16,24,40,0.08), 0 1px 2px rgba(16,24,40,0.04)',
        pop: '0 12px 32px rgba(16,24,40,0.16)',
      },
    },
  },
  plugins: [],
};

export default config;
