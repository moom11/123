import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { CashMovementType } from '@prisma/client';
import { cleanupBranch, createTestContext, prisma, type TestContext } from './helpers';
import {
  approveShiftDifference,
  closeShift,
  getShiftSummary,
  movementSign,
  openShift,
  recordCashMovement,
  recordDrawerOpen,
} from '@/lib/pos/shift-service';
import { createOrder } from '@/lib/pos/order-service';
import { checkoutOrder } from '@/lib/pos/checkout-service';
import { toNumber } from '@/lib/money';

let ctx: TestContext;

beforeAll(async () => {
  ctx = await createTestContext();
});

afterAll(async () => {
  await cleanupBranch(ctx.branchId);
  await prisma.$disconnect();
});

/** يفتح وردية جديدة لمستخدم مؤقت حتى لا تتعارض الورديات */
async function freshShift(openingFloat = 500) {
  const user = await prisma.user.create({
    data: {
      branchId: ctx.branchId,
      employeeNo: `S${Date.now()}${Math.random().toString(36).slice(2, 6)}`,
      fullName: 'كاشير اختبار',
      passwordHash: 'x',
    },
  });
  const shift = await openShift({
    branchId: ctx.branchId,
    userId: user.id,
    openingFloat,
  });
  return { shift, userId: user.id };
}

describe('فتح الوردية', () => {
  it('يفتح وردية برصيد افتتاحي ويسجل حركة الافتتاح', async () => {
    const { shift } = await freshShift(500);
    expect(shift.status).toBe('OPEN');
    expect(toNumber(shift.openingFloat)).toBe(500);
    expect(shift.shiftNumber).toMatch(/^SH-\d{5}$/);

    const movement = await prisma.cashMovement.findFirst({
      where: { shiftId: shift.id, type: CashMovementType.OPENING_FLOAT },
    });
    expect(toNumber(movement!.amount)).toBe(500);
  });

  it('يمنع فتح وردية ثانية لنفس المستخدم', async () => {
    const { userId } = await freshShift(100);
    await expect(
      openShift({ branchId: ctx.branchId, userId, openingFloat: 100 }),
    ).rejects.toThrow(/وردية مفتوحة بالفعل/);
  });

  it('يرفض رصيدًا افتتاحيًا سالبًا', async () => {
    const user = await prisma.user.create({
      data: {
        branchId: ctx.branchId,
        employeeNo: `N${Date.now()}`,
        fullName: 'اختبار',
        passwordHash: 'x',
      },
    });
    await expect(
      openShift({ branchId: ctx.branchId, userId: user.id, openingFloat: -50 }),
    ).rejects.toThrow(/سالبًا/);
  });
});

describe('احتساب النقد المتوقع', () => {
  it('الافتتاحي + المبيعات النقدية − المصروفات − المسحوبات − الإيداعات', async () => {
    const { shift, userId } = await freshShift(500);

    // مبيعات نقدية 230
    const order = await createOrder({
      branchId: ctx.branchId,
      userId,
      type: 'TAKEAWAY',
      shiftId: shift.id,
      items: [{ productId: ctx.plainProductId, quantity: 2 }],
    });
    await checkoutOrder({
      orderId: order.id,
      userId,
      shiftId: shift.id,
      payments: [{ paymentMethodId: ctx.cashMethodId, amount: 230 }],
    });

    // مبيعات شبكة 115 — لا تؤثر على النقد
    const cardOrder = await createOrder({
      branchId: ctx.branchId,
      userId,
      type: 'TAKEAWAY',
      shiftId: shift.id,
      items: [{ productId: ctx.plainProductId, quantity: 1 }],
    });
    await checkoutOrder({
      orderId: cardOrder.id,
      userId,
      shiftId: shift.id,
      payments: [{ paymentMethodId: ctx.cardMethodId, amount: 115 }],
    });

    await recordCashMovement({
      branchId: ctx.branchId,
      shiftId: shift.id,
      userId,
      type: CashMovementType.EXPENSE,
      amount: 80,
      note: 'مشتريات يومية',
    });
    await recordCashMovement({
      branchId: ctx.branchId,
      shiftId: shift.id,
      userId,
      type: CashMovementType.WITHDRAWAL,
      amount: 50,
    });
    await recordCashMovement({
      branchId: ctx.branchId,
      shiftId: shift.id,
      userId,
      type: CashMovementType.DEPOSIT_TO_MAIN_SAFE,
      amount: 100,
    });

    const summary = await getShiftSummary(shift.id);

    expect(summary.cashSales).toBe(230);
    expect(summary.cardSales).toBe(115);
    expect(summary.expenses).toBe(80);
    expect(summary.withdrawals).toBe(50);
    expect(summary.deposits).toBe(100);
    // 500 + 230 − 80 − 50 − 100 = 500
    expect(summary.expectedCash).toBe(500);
    expect(summary.invoiceCount).toBe(2);
    // إجمالي المبيعات يشمل الشبكة
    expect(summary.totalSales).toBe(345);
  });

  it('الإيداع في الصندوق الرئيسي لا يُحتسب مصروفًا', async () => {
    const { shift, userId } = await freshShift(200);
    await recordCashMovement({
      branchId: ctx.branchId,
      shiftId: shift.id,
      userId,
      type: CashMovementType.DEPOSIT_TO_MAIN_SAFE,
      amount: 150,
    });
    const summary = await getShiftSummary(shift.id);
    expect(summary.deposits).toBe(150);
    expect(summary.expenses).toBe(0);
  });

  it('العهدة واستردادها يؤثران في الاتجاهين', async () => {
    expect(movementSign(CashMovementType.EMPLOYEE_ADVANCE)).toBe(-1);
    expect(movementSign(CashMovementType.ADVANCE_SETTLEMENT)).toBe(1);

    const { shift, userId } = await freshShift(300);
    await recordCashMovement({
      branchId: ctx.branchId,
      shiftId: shift.id,
      userId,
      type: CashMovementType.EMPLOYEE_ADVANCE,
      amount: 100,
    });
    await recordCashMovement({
      branchId: ctx.branchId,
      shiftId: shift.id,
      userId,
      type: CashMovementType.ADVANCE_SETTLEMENT,
      amount: 40,
    });
    const summary = await getShiftSummary(shift.id);
    expect(summary.expectedCash).toBe(240); // 300 − 100 + 40
  });

  it('يسجل مرات فتح درج النقد دون التأثير على الرصيد', async () => {
    const { shift, userId } = await freshShift(100);
    await recordDrawerOpen(ctx.branchId, shift.id, userId, 'صرف عملة');
    await recordDrawerOpen(ctx.branchId, shift.id, userId, 'مراجعة');
    const summary = await getShiftSummary(shift.id);
    expect(summary.drawerOpenCount).toBe(2);
    expect(summary.expectedCash).toBe(100);
  });

  it('المصروف يُنشئ مستند مصروف قابلًا للاعتماد', async () => {
    const { shift, userId } = await freshShift(100);
    const { expense } = await recordCashMovement({
      branchId: ctx.branchId,
      shiftId: shift.id,
      userId,
      type: CashMovementType.EXPENSE,
      amount: 25,
      note: 'مياه',
    });
    expect(expense).not.toBeNull();
    expect(expense!.status).toBe('PENDING');
    expect(toNumber(expense!.amount)).toBe(25);
  });
});

describe('إغلاق الوردية وفرق الصندوق', () => {
  it('يغلق الوردية بدون فرق', async () => {
    const { shift } = await freshShift(500);
    const result = await closeShift({ shiftId: shift.id, countedCash: 500 });
    expect(result.shift.status).toBe('CLOSED');
    expect(toNumber(result.shift.cashDifference!)).toBe(0);
  });

  it('يحتسب العجز ويطلب اعتماد المدير', async () => {
    const { shift } = await freshShift(500);
    const result = await closeShift({
      shiftId: shift.id,
      countedCash: 450,
      differenceReason: 'عجز غير مبرر',
    });
    expect(toNumber(result.shift.cashDifference!)).toBe(-50);
    expect(result.shift.status).toBe('PENDING_APPROVAL');
  });

  it('يحتسب الزيادة كذلك', async () => {
    const { shift } = await freshShift(500);
    const result = await closeShift({
      shiftId: shift.id,
      countedCash: 530,
      differenceReason: 'زيادة',
    });
    expect(toNumber(result.shift.cashDifference!)).toBe(30);
  });

  it('يرفض الإغلاق بفرق دون ذكر السبب', async () => {
    const { shift } = await freshShift(500);
    await expect(
      closeShift({ shiftId: shift.id, countedCash: 400 }),
    ).rejects.toThrow(/سبب الفرق/);
  });

  it('يغلق مباشرة عند اعتماد المدير أثناء الإغلاق', async () => {
    const { shift } = await freshShift(500);
    const result = await closeShift({
      shiftId: shift.id,
      countedCash: 480,
      differenceReason: 'فكة ناقصة',
      approvedById: ctx.managerId,
    });
    expect(result.shift.status).toBe('CLOSED');
    expect(result.shift.approvedById).toBe(ctx.managerId);
  });

  it('يعتمد المدير الفرق لاحقًا', async () => {
    const { shift } = await freshShift(500);
    await closeShift({
      shiftId: shift.id,
      countedCash: 470,
      differenceReason: 'نقص',
    });
    const approved = await approveShiftDifference(shift.id, ctx.managerId, 'تمت المراجعة');
    expect(approved.status).toBe('CLOSED');
    expect(approved.approvedById).toBe(ctx.managerId);
  });

  it('يمنع الإغلاق مع وجود طلبات مفتوحة', async () => {
    const { shift, userId } = await freshShift(500);
    await createOrder({
      branchId: ctx.branchId,
      userId,
      type: 'TAKEAWAY',
      shiftId: shift.id,
      items: [{ productId: ctx.plainProductId, quantity: 1 }],
    });
    await expect(
      closeShift({ shiftId: shift.id, countedCash: 500 }),
    ).rejects.toThrow(/طلب مفتوح/);
  });

  it('يمنع إغلاق وردية مغلقة مسبقًا', async () => {
    const { shift } = await freshShift(100);
    await closeShift({ shiftId: shift.id, countedCash: 100 });
    await expect(
      closeShift({ shiftId: shift.id, countedCash: 100 }),
    ).rejects.toThrow(/مغلقة مسبقًا/);
  });

  it('يمنع تسجيل حركات على وردية مغلقة', async () => {
    const { shift, userId } = await freshShift(100);
    await closeShift({ shiftId: shift.id, countedCash: 100 });
    await expect(
      recordCashMovement({
        branchId: ctx.branchId,
        shiftId: shift.id,
        userId,
        type: CashMovementType.EXPENSE,
        amount: 10,
      }),
    ).rejects.toThrow(/وردية مغلقة/);
  });
});
