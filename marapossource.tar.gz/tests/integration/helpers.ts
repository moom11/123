import {
  PaymentMethodType,
  PrepStation,
  PrismaClient,
  RoleCode,
  TaxType,
  TobaccoTaxBase,
} from '@prisma/client';
import bcrypt from 'bcryptjs';
import { PERMISSIONS, ROLE_LABELS, ROLE_PERMISSIONS } from '@/lib/auth/permissions';

export const prisma = new PrismaClient();

export interface TestContext {
  branchId: string;
  adminId: string;
  managerId: string;
  cashierId: string;
  vatTaxId: string;
  tobaccoTaxId: string;
  categoryId: string;
  /** منتج عادي بسعر 115 شامل ض.ق.م 15% ⇒ صافي 100 */
  plainProductId: string;
  /** منتج تبغ بسعر 100 غير شامل */
  tobaccoProductId: string;
  cashMethodId: string;
  cardMethodId: string;
  tableId: string;
}

let counter = 0;
const unique = () => `${Date.now()}-${(counter += 1)}`;

/**
 * يبني بيئة اختبار معزولة: فرع جديد بمنتجاته ومستخدميه.
 * الضرائب وطرق الدفع عامة على مستوى النظام فتُنشأ مرة واحدة.
 */
export async function createTestContext(): Promise<TestContext> {
  const suffix = unique();

  // الصلاحيات والأدوار (مشتركة)
  for (const [code, meta] of Object.entries(PERMISSIONS)) {
    await prisma.permission.upsert({
      where: { code },
      create: { code, nameAr: meta.nameAr, group: meta.group },
      update: {},
    });
  }
  const permissions = await prisma.permission.findMany();
  const byCode = new Map(permissions.map((p) => [p.code, p.id]));

  for (const roleCode of Object.keys(ROLE_PERMISSIONS) as RoleCode[]) {
    const role = await prisma.role.upsert({
      where: { code: roleCode },
      create: { code: roleCode, nameAr: ROLE_LABELS[roleCode] },
      update: {},
    });
    await prisma.rolePermission.deleteMany({ where: { roleId: role.id } });
    await prisma.rolePermission.createMany({
      data: ROLE_PERMISSIONS[roleCode]
        .map((code) => byCode.get(code))
        .filter((id): id is string => Boolean(id))
        .map((permissionId) => ({ roleId: role.id, permissionId })),
      skipDuplicates: true,
    });
  }

  const company = await prisma.company.create({
    data: { nameAr: `شركة اختبار ${suffix}`, vatNumber: '300000000000003' },
  });
  const branch = await prisma.branch.create({
    data: { companyId: company.id, code: `T-${suffix}`, nameAr: `فرع اختبار ${suffix}` },
  });
  await prisma.branchSetting.create({
    data: {
      branchId: branch.id,
      businessDayStartHour: 5,
      paymentRoundingTolerance: 0.05,
      cashDiffTolerance: 0,
      maxDiscountPercent: 50,
      requireManagerForDiscount: false,
    },
  });

  const roles = await prisma.role.findMany();
  const roleId = (code: RoleCode) => roles.find((r) => r.code === code)!.id;

  const makeUser = async (employeeNo: string, name: string, role: RoleCode, pin?: string) =>
    prisma.user.create({
      data: {
        branchId: branch.id,
        employeeNo,
        fullName: name,
        passwordHash: bcrypt.hashSync('Test@1234', 4),
        managerPinHash: pin ? bcrypt.hashSync(pin, 4) : null,
        roles: { create: { roleId: roleId(role) } },
      },
    });

  const admin = await makeUser(`A${suffix}`, 'مدير النظام', RoleCode.SYSTEM_ADMIN, '1111');
  const manager = await makeUser(`M${suffix}`, 'مدير الفرع', RoleCode.BRANCH_MANAGER, '2222');
  const cashier = await makeUser(`C${suffix}`, 'كاشير', RoleCode.CASHIER);

  const vat = await prisma.tax.upsert({
    where: { code: 'TEST-VAT15' },
    create: { code: 'TEST-VAT15', nameAr: 'ض.ق.م (اختبار)', type: TaxType.VAT, rate: 15, isDefault: false },
    update: { rate: 15 },
  });
  const tobacco = await prisma.tax.upsert({
    where: { code: 'TEST-TOB100' },
    create: {
      code: 'TEST-TOB100',
      nameAr: 'ضريبة التبغ (اختبار)',
      type: TaxType.TOBACCO,
      rate: 100,
      tobaccoBase: TobaccoTaxBase.PERCENT_OF_PRICE,
    },
    update: { rate: 100 },
  });

  const category = await prisma.category.create({
    data: { branchId: branch.id, nameAr: 'اختبار' },
  });

  const plain = await prisma.product.create({
    data: {
      branchId: branch.id,
      categoryId: category.id,
      nameAr: 'منتج عادي',
      sku: `P-${suffix}`,
      price: 115,
      priceIncludesVat: true,
      vatTaxId: vat.id,
      prepStation: PrepStation.KITCHEN,
    },
  });

  const tobaccoProduct = await prisma.product.create({
    data: {
      branchId: branch.id,
      categoryId: category.id,
      nameAr: 'شيشة اختبار',
      sku: `S-${suffix}`,
      price: 100,
      priceIncludesVat: false,
      vatTaxId: vat.id,
      isTobacco: true,
      tobaccoTaxId: tobacco.id,
      prepStation: PrepStation.SHISHA,
    },
  });

  const cashMethod = await prisma.paymentMethod.upsert({
    where: { code: 'TEST-CASH' },
    create: {
      code: 'TEST-CASH',
      nameAr: 'نقدي (اختبار)',
      type: PaymentMethodType.CASH,
      affectsCashDrawer: true,
    },
    update: { isActive: true },
  });
  const cardMethod = await prisma.paymentMethod.upsert({
    where: { code: 'TEST-MADA' },
    create: { code: 'TEST-MADA', nameAr: 'مدى (اختبار)', type: PaymentMethodType.MADA },
    update: { isActive: true },
  });

  const floor = await prisma.floor.create({
    data: { branchId: branch.id, nameAr: 'الدور الأرضي' },
  });
  const table = await prisma.restaurantTable.create({
    data: { branchId: branch.id, floorId: floor.id, number: `T${suffix}`, seats: 4 },
  });

  return {
    branchId: branch.id,
    adminId: admin.id,
    managerId: manager.id,
    cashierId: cashier.id,
    vatTaxId: vat.id,
    tobaccoTaxId: tobacco.id,
    categoryId: category.id,
    plainProductId: plain.id,
    tobaccoProductId: tobaccoProduct.id,
    cashMethodId: cashMethod.id,
    cardMethodId: cardMethod.id,
    tableId: table.id,
  };
}

/** يحذف بيانات الفرع الاختباري بالترتيب الصحيح للعلاقات */
export async function cleanupBranch(branchId: string) {
  const invoices = await prisma.invoice.findMany({
    where: { branchId },
    select: { id: true },
  });
  const invoiceIds = invoices.map((i) => i.id);

  await prisma.refundItem.deleteMany({ where: { refund: { branchId } } });
  await prisma.refund.deleteMany({ where: { branchId } });
  await prisma.payment.deleteMany({ where: { invoiceId: { in: invoiceIds } } });
  await prisma.invoiceChangeLog.deleteMany({ where: { invoiceId: { in: invoiceIds } } });
  await prisma.invoiceItem.deleteMany({ where: { invoiceId: { in: invoiceIds } } });
  await prisma.invoice.deleteMany({ where: { branchId } });

  await prisma.syncLog.deleteMany({ where: { syncJob: { branchId } } });
  await prisma.syncJob.deleteMany({ where: { branchId } });
  await prisma.expense.deleteMany({ where: { branchId } });
  await prisma.cashMovement.deleteMany({ where: { branchId } });
  await prisma.discount.deleteMany({ where: { order: { branchId } } });
  await prisma.kitchenTicket.deleteMany({ where: { order: { branchId } } });
  await prisma.orderItem.deleteMany({ where: { order: { branchId } } });
  await prisma.order.updateMany({ where: { branchId }, data: { mergedIntoId: null } });
  await prisma.order.deleteMany({ where: { branchId } });
  await prisma.shift.deleteMany({ where: { branchId } });
  await prisma.dailyClosing.deleteMany({ where: { branchId } });
  await prisma.productModifier.deleteMany({
    where: { group: { product: { branchId } } },
  });
  await prisma.productModifierGroup.deleteMany({ where: { product: { branchId } } });
  await prisma.productVariant.deleteMany({ where: { product: { branchId } } });
  await prisma.product.deleteMany({ where: { branchId } });
  await prisma.category.deleteMany({ where: { branchId } });
  await prisma.restaurantTable.deleteMany({ where: { branchId } });
  await prisma.area.deleteMany({ where: { floor: { branchId } } });
  await prisma.floor.deleteMany({ where: { branchId } });
  await prisma.printer.deleteMany({ where: { branchId } });
  await prisma.device.deleteMany({ where: { branchId } });
  await prisma.odooSetting.deleteMany({ where: { branchId } });
  await prisma.sequence.deleteMany({ where: { branchId } });
  await prisma.auditLog.deleteMany({ where: { branchId } });

  const users = await prisma.user.findMany({ where: { branchId }, select: { id: true } });
  const userIds = users.map((u) => u.id);
  await prisma.auditLog.deleteMany({ where: { userId: { in: userIds } } });
  await prisma.refreshToken.deleteMany({ where: { userId: { in: userIds } } });
  await prisma.userRole.deleteMany({ where: { userId: { in: userIds } } });
  await prisma.user.deleteMany({ where: { branchId } });

  // طرق الدفع والضرائب عامة على مستوى النظام — نعطّلها بدل حذفها
  // حتى لا تظهر في واجهة التطبيق ولا تكسر السجلات المرتبطة بها.
  await prisma.paymentMethod.updateMany({
    where: { code: { startsWith: 'TEST-' } },
    data: { isActive: false },
  });
  await prisma.tax.updateMany({
    where: { code: { startsWith: 'TEST-' } },
    data: { isActive: false, isDefault: false },
  });

  await prisma.branchSetting.deleteMany({ where: { branchId } });
  const branch = await prisma.branch.findUnique({ where: { id: branchId } });
  await prisma.branch.deleteMany({ where: { id: branchId } });
  if (branch) await prisma.company.deleteMany({ where: { id: branch.companyId } });
}
