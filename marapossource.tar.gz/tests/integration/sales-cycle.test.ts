import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { cleanupBranch, createTestContext, prisma, type TestContext } from './helpers';
import { addItemToOrder, cancelOrder, createOrder, holdOrder, resumeOrder, sendOrderToPreparation, splitOrder, transferOrderTable, mergeOrders } from '@/lib/pos/order-service';
import { checkoutOrder, cancelInvoice } from '@/lib/pos/checkout-service';
import { createRefund } from '@/lib/pos/refund-service';
import { applyDiscount } from '@/lib/pos/discount-service';
import { openShift } from '@/lib/pos/shift-service';
import { toNumber } from '@/lib/money';
import { ApiError } from '@/lib/api/errors';
import { DiscountType } from '@prisma/client';

let ctx: TestContext;
let shiftId: string;

beforeAll(async () => {
  ctx = await createTestContext();
  const shift = await openShift({
    branchId: ctx.branchId,
    userId: ctx.cashierId,
    openingFloat: 500,
  });
  shiftId = shift.id;
});

afterAll(async () => {
  await cleanupBranch(ctx.branchId);
  await prisma.$disconnect();
});

async function newOrder(items: { productId: string; quantity: number }[]) {
  return createOrder({
    branchId: ctx.branchId,
    userId: ctx.cashierId,
    type: 'TAKEAWAY',
    shiftId,
    items,
  });
}

describe('دورة البيع الكاملة', () => {
  it('يفتح طلبًا ويحسب الضرائب ثم يغلق الفاتورة', async () => {
    const order = await newOrder([{ productId: ctx.plainProductId, quantity: 2 }]);

    // 115 شامل × 2 ⇒ صافي 200، ض.ق.م 30، إجمالي 230
    expect(toNumber(order.subtotal)).toBe(200);
    expect(toNumber(order.vatTotal)).toBe(30);
    expect(toNumber(order.grandTotal)).toBe(230);

    const invoice = await checkoutOrder({
      orderId: order.id,
      userId: ctx.cashierId,
      shiftId,
      payments: [{ paymentMethodId: ctx.cashMethodId, amount: 230 }],
    });

    expect(invoice.status).toBe('PAID');
    expect(toNumber(invoice.paidTotal)).toBe(230);
    expect(invoice.invoiceNumber).toMatch(/^INV-\d{6}$/);
    expect(invoice.qrPayload).toBeTruthy();

    const updated = await prisma.order.findUniqueOrThrow({ where: { id: order.id } });
    expect(updated.status).toBe('PAID');
  });

  it('يحسب ضريبة التبغ مستقلة عن ضريبة القيمة المضافة', async () => {
    const order = await newOrder([{ productId: ctx.tobaccoProductId, quantity: 1 }]);
    // صافي 100، ضريبة تبغ 100، ض.ق.م = (100+100) × 15% = 30
    expect(toNumber(order.tobaccoTaxTotal)).toBe(100);
    expect(toNumber(order.vatTotal)).toBe(30);
    expect(toNumber(order.grandTotal)).toBe(230);

    const invoice = await checkoutOrder({
      orderId: order.id,
      userId: ctx.cashierId,
      shiftId,
      payments: [{ paymentMethodId: ctx.cashMethodId, amount: 230 }],
    });
    expect(toNumber(invoice.tobaccoTaxTotal)).toBe(100);
    expect(toNumber(invoice.vatTotal)).toBe(30);

    // نسخة الضرائب محفوظة داخل الفاتورة
    const snapshot = invoice.taxSnapshot as { tobacco: { amount: number } };
    expect(snapshot.tobacco.amount).toBe(100);
  });

  it('يقبل الدفع المختلط بين أكثر من طريقة', async () => {
    const order = await newOrder([{ productId: ctx.plainProductId, quantity: 1 }]);
    const invoice = await checkoutOrder({
      orderId: order.id,
      userId: ctx.cashierId,
      shiftId,
      payments: [
        { paymentMethodId: ctx.cardMethodId, amount: 100 },
        { paymentMethodId: ctx.cashMethodId, amount: 15 },
      ],
    });
    expect(invoice.payments).toHaveLength(2);
    expect(toNumber(invoice.paidTotal)).toBe(115);
  });

  it('يمنع إغلاق الفاتورة إذا لم تتساوَ المدفوعات مع الإجمالي', async () => {
    const order = await newOrder([{ productId: ctx.plainProductId, quantity: 1 }]);
    await expect(
      checkoutOrder({
        orderId: order.id,
        userId: ctx.cashierId,
        shiftId,
        payments: [{ paymentMethodId: ctx.cashMethodId, amount: 50 }],
      }),
    ).rejects.toThrow(/لا يساوي إجمالي الفاتورة/);
  });

  it('يسمح بفرق ضمن سماحية التقريب المسموح بها', async () => {
    const order = await newOrder([{ productId: ctx.plainProductId, quantity: 1 }]);
    const invoice = await checkoutOrder({
      orderId: order.id,
      userId: ctx.cashierId,
      shiftId,
      // 115 مقابل 114.96 — الفرق 0.04 ضمن السماحية 0.05
      payments: [{ paymentMethodId: ctx.cashMethodId, amount: 114.96 }],
    });
    expect(invoice.status).toBe('PAID');
  });

  it('يحسب الباقي للعميل عند الدفع النقدي', async () => {
    const order = await newOrder([{ productId: ctx.plainProductId, quantity: 1 }]);
    const invoice = await checkoutOrder({
      orderId: order.id,
      userId: ctx.cashierId,
      shiftId,
      payments: [
        { paymentMethodId: ctx.cashMethodId, amount: 115, receivedAmount: 200 },
      ],
    });
    expect(toNumber(invoice.changeDue)).toBe(85);
  });

  it('يمنع إغلاق نفس الطلب مرتين عبر مفتاح منع التكرار', async () => {
    const order = await newOrder([{ productId: ctx.plainProductId, quantity: 1 }]);
    const key = `test-idem-${order.id}`;

    const first = await checkoutOrder({
      orderId: order.id,
      userId: ctx.cashierId,
      shiftId,
      payments: [{ paymentMethodId: ctx.cashMethodId, amount: 115 }],
      idempotencyKey: key,
    });
    const second = await checkoutOrder({
      orderId: order.id,
      userId: ctx.cashierId,
      shiftId,
      payments: [{ paymentMethodId: ctx.cashMethodId, amount: 115 }],
      idempotencyKey: key,
    });

    expect(second.id).toBe(first.id);
    expect(second.invoiceNumber).toBe(first.invoiceNumber);

    const count = await prisma.invoice.count({ where: { orderId: order.id } });
    expect(count).toBe(1);
  });

  it('يمنع تكرار الطلب عند إعادة الإرسال من وضع العمل دون اتصال', async () => {
    const clientUuid = crypto.randomUUID();
    const first = await createOrder({
      branchId: ctx.branchId,
      userId: ctx.cashierId,
      type: 'TAKEAWAY',
      shiftId,
      clientUuid,
      items: [{ productId: ctx.plainProductId, quantity: 1 }],
    });
    const second = await createOrder({
      branchId: ctx.branchId,
      userId: ctx.cashierId,
      type: 'TAKEAWAY',
      shiftId,
      clientUuid,
      items: [{ productId: ctx.plainProductId, quantity: 1 }],
    });
    expect(second.id).toBe(first.id);
    expect(second.items).toHaveLength(1);
  });
});

describe('تعليق الطلبات وإلغاؤها', () => {
  it('يعلق الطلب ثم يسترجعه', async () => {
    const order = await newOrder([{ productId: ctx.plainProductId, quantity: 1 }]);
    expect((await holdOrder(order.id)).status).toBe('HELD');
    expect((await resumeOrder(order.id)).status).toBe('DRAFT');
  });

  it('يلغي الطلب قبل الدفع مع تسجيل السبب', async () => {
    const order = await newOrder([{ productId: ctx.plainProductId, quantity: 1 }]);
    const cancelled = await cancelOrder(order.id, 'العميل انصرف');
    expect(cancelled.status).toBe('CANCELLED');
    expect(cancelled.cancelReason).toBe('العميل انصرف');
  });

  it('يمنع إلغاء طلب مرتبط بفاتورة مدفوعة', async () => {
    const order = await newOrder([{ productId: ctx.plainProductId, quantity: 1 }]);
    await checkoutOrder({
      orderId: order.id,
      userId: ctx.cashierId,
      shiftId,
      payments: [{ paymentMethodId: ctx.cashMethodId, amount: 115 }],
    });
    await expect(cancelOrder(order.id, 'محاولة')).rejects.toThrow(/مدفوعة/);
  });

  it('لا يمكن تعديل طلب مدفوع', async () => {
    const order = await newOrder([{ productId: ctx.plainProductId, quantity: 1 }]);
    await checkoutOrder({
      orderId: order.id,
      userId: ctx.cashierId,
      shiftId,
      payments: [{ paymentMethodId: ctx.cashMethodId, amount: 115 }],
    });
    await expect(
      addItemToOrder(order.id, { productId: ctx.plainProductId, quantity: 1 }),
    ).rejects.toThrow(/لا يمكن تعديل/);
  });
});

describe('الطاولات والتقسيم والدمج', () => {
  it('ينقل الطلب إلى طاولة أخرى', async () => {
    const floor = await prisma.floor.findFirstOrThrow({ where: { branchId: ctx.branchId } });
    const target = await prisma.restaurantTable.create({
      data: { branchId: ctx.branchId, floorId: floor.id, number: `X${Date.now()}` },
    });
    const order = await createOrder({
      branchId: ctx.branchId,
      userId: ctx.cashierId,
      type: 'DINE_IN',
      tableId: ctx.tableId,
      shiftId,
      items: [{ productId: ctx.plainProductId, quantity: 1 }],
    });
    const moved = await transferOrderTable(order.id, target.id);
    expect(moved.tableId).toBe(target.id);

    const targetTable = await prisma.restaurantTable.findUniqueOrThrow({
      where: { id: target.id },
    });
    expect(targetTable.status).toBe('OCCUPIED');
    await cancelOrder(order.id, 'تنظيف بيانات الاختبار');
  });

  it('يقسم الفاتورة بنقل أصناف إلى طلب جديد', async () => {
    const order = await newOrder([
      { productId: ctx.plainProductId, quantity: 1 },
      { productId: ctx.tobaccoProductId, quantity: 1 },
    ]);
    const target = order.items.find((i) => i.productId === ctx.tobaccoProductId)!;
    const result = await splitOrder(order.id, [target.id], ctx.cashierId);

    expect(result.source.items).toHaveLength(1);
    expect(result.target.items).toHaveLength(1);
    expect(toNumber(result.source.grandTotal)).toBe(115);
    expect(toNumber(result.target.grandTotal)).toBe(230);
  });

  it('يدمج طلبين في طلب واحد', async () => {
    const a = await newOrder([{ productId: ctx.plainProductId, quantity: 1 }]);
    const b = await newOrder([{ productId: ctx.plainProductId, quantity: 2 }]);

    const merged = await mergeOrders(b.id, a.id);
    expect(merged.items).toHaveLength(2);
    expect(toNumber(merged.grandTotal)).toBe(345);

    const source = await prisma.order.findUniqueOrThrow({ where: { id: b.id } });
    expect(source.status).toBe('CANCELLED');
    expect(source.mergedIntoId).toBe(a.id);
  });

  it('يمنع نقل جميع الأصناف عبر التقسيم', async () => {
    const order = await newOrder([{ productId: ctx.plainProductId, quantity: 1 }]);
    await expect(
      splitOrder(order.id, [order.items[0].id], ctx.cashierId),
    ).rejects.toThrow(/جميع الأصناف/);
  });
});

describe('محطات التحضير', () => {
  it('يوجه الأصناف تلقائيًا إلى المطبخ والشيشة', async () => {
    const order = await newOrder([
      { productId: ctx.plainProductId, quantity: 1 },
      { productId: ctx.tobaccoProductId, quantity: 1 },
    ]);
    const { tickets } = await sendOrderToPreparation(order.id);

    const stations = tickets.map((t) => t.station).sort();
    expect(stations).toEqual(['KITCHEN', 'SHISHA']);

    const updated = await prisma.order.findUniqueOrThrow({ where: { id: order.id } });
    expect(updated.status).toBe('SENT_TO_PREP');
    expect(updated.sentToPrepAt).toBeTruthy();
  });

  it('لا يُنشئ تذاكر مكررة عند إعادة الإرسال', async () => {
    const order = await newOrder([{ productId: ctx.plainProductId, quantity: 1 }]);
    await sendOrderToPreparation(order.id);
    await sendOrderToPreparation(order.id);
    const count = await prisma.kitchenTicket.count({ where: { orderId: order.id } });
    expect(count).toBe(1);
  });
});

describe('الخصومات', () => {
  it('يطبق خصمًا بنسبة على كامل الفاتورة', async () => {
    const order = await newOrder([{ productId: ctx.plainProductId, quantity: 1 }]);
    const { order: updated } = await applyDiscount({
      orderId: order.id,
      type: DiscountType.PERCENT,
      value: 10,
      userId: ctx.managerId,
      userPermissions: ['discounts.apply', 'discounts.approve'],
      reason: 'عميل دائم',
    });
    expect(toNumber(updated.discountTotal)).toBe(10);
    expect(toNumber(updated.vatTotal)).toBe(13.5);
    expect(toNumber(updated.grandTotal)).toBe(103.5);
  });

  it('يرفض الخصم الذي يتجاوز الحد الأعلى المسموح', async () => {
    const order = await newOrder([{ productId: ctx.plainProductId, quantity: 1 }]);
    await expect(
      applyDiscount({
        orderId: order.id,
        type: DiscountType.PERCENT,
        value: 80, // الحد الأعلى في الإعدادات 50%
        userId: ctx.managerId,
        userPermissions: ['discounts.apply', 'discounts.approve'],
      }),
    ).rejects.toThrow(/الحد الأعلى/);
  });

  it('يرفض الخصم من مستخدم بلا صلاحية', async () => {
    const order = await newOrder([{ productId: ctx.plainProductId, quantity: 1 }]);
    await expect(
      applyDiscount({
        orderId: order.id,
        type: DiscountType.PERCENT,
        value: 5,
        userId: ctx.cashierId,
        userPermissions: ['pos.use'],
      }),
    ).rejects.toThrow(ApiError);
  });
});

describe('المرتجعات والإلغاءات', () => {
  it('ينفذ إرجاعًا كاملًا ويحفظ الفاتورة الأصلية', async () => {
    const order = await newOrder([{ productId: ctx.plainProductId, quantity: 2 }]);
    const invoice = await checkoutOrder({
      orderId: order.id,
      userId: ctx.cashierId,
      shiftId,
      payments: [{ paymentMethodId: ctx.cashMethodId, amount: 230 }],
    });

    const refund = await createRefund({
      invoiceId: invoice.id,
      userId: ctx.managerId,
      shiftId,
      reason: 'جودة غير مرضية',
    });

    expect(refund.type).toBe('FULL');
    expect(toNumber(refund.grandTotal)).toBe(230);
    expect(refund.refundNumber).toMatch(/^RET-\d{6}$/);

    const after = await prisma.invoice.findUniqueOrThrow({ where: { id: invoice.id } });
    expect(after.status).toBe('REFUNDED');
    expect(after.id).toBe(invoice.id); // الفاتورة لم تُحذف
  });

  it('ينفذ إرجاعًا جزئيًا ويحدث حالة الفاتورة', async () => {
    const order = await newOrder([{ productId: ctx.plainProductId, quantity: 4 }]);
    const invoice = await checkoutOrder({
      orderId: order.id,
      userId: ctx.cashierId,
      shiftId,
      payments: [{ paymentMethodId: ctx.cashMethodId, amount: 460 }],
    });

    const refund = await createRefund({
      invoiceId: invoice.id,
      userId: ctx.managerId,
      shiftId,
      reason: 'إرجاع صنفين',
      items: [{ invoiceItemId: invoice.items[0].id, quantity: 2 }],
    });

    expect(refund.type).toBe('PARTIAL');
    expect(toNumber(refund.grandTotal)).toBe(230);

    const after = await prisma.invoice.findUniqueOrThrow({ where: { id: invoice.id } });
    expect(after.status).toBe('PARTIALLY_REFUNDED');
  });

  it('يرفض إرجاع كمية أكبر من المتاح', async () => {
    const order = await newOrder([{ productId: ctx.plainProductId, quantity: 1 }]);
    const invoice = await checkoutOrder({
      orderId: order.id,
      userId: ctx.cashierId,
      shiftId,
      payments: [{ paymentMethodId: ctx.cashMethodId, amount: 115 }],
    });
    await expect(
      createRefund({
        invoiceId: invoice.id,
        userId: ctx.managerId,
        reason: 'محاولة تجاوز',
        items: [{ invoiceItemId: invoice.items[0].id, quantity: 5 }],
      }),
    ).rejects.toThrow(/تتجاوز المتاح/);
  });

  it('يوزع المبلغ المرتجع على طرق الدفع الأصلية', async () => {
    const order = await newOrder([{ productId: ctx.plainProductId, quantity: 2 }]);
    const invoice = await checkoutOrder({
      orderId: order.id,
      userId: ctx.cashierId,
      shiftId,
      payments: [
        { paymentMethodId: ctx.cashMethodId, amount: 115 },
        { paymentMethodId: ctx.cardMethodId, amount: 115 },
      ],
    });

    const refund = await createRefund({
      invoiceId: invoice.id,
      userId: ctx.managerId,
      shiftId,
      reason: 'إرجاع كامل',
    });

    const payments = refund.refundPayments as { amount: number }[];
    expect(payments).toHaveLength(2);
    expect(payments[0].amount).toBe(115);
    expect(payments[1].amount).toBe(115);
  });

  it('يلغي فاتورة مكتملة دون حذفها ويعكس الحركة النقدية', async () => {
    const order = await newOrder([{ productId: ctx.plainProductId, quantity: 1 }]);
    const invoice = await checkoutOrder({
      orderId: order.id,
      userId: ctx.cashierId,
      shiftId,
      payments: [{ paymentMethodId: ctx.cashMethodId, amount: 115 }],
    });

    const cancelled = await cancelInvoice(invoice.id, ctx.managerId, 'خطأ في الإدخال');
    expect(cancelled.status).toBe('CANCELLED');
    expect(cancelled.cancelReason).toBe('خطأ في الإدخال');

    const stillExists = await prisma.invoice.findUnique({ where: { id: invoice.id } });
    expect(stillExists).not.toBeNull();

    const reversal = await prisma.cashMovement.findFirst({
      where: { referenceId: invoice.id, type: 'REFUND_CASH_OUT' },
    });
    expect(reversal).not.toBeNull();
    expect(toNumber(reversal!.amount)).toBe(-115);

    // سجل التعديلات يوثق العملية
    const logs = await prisma.invoiceChangeLog.findMany({ where: { invoiceId: invoice.id } });
    expect(logs.some((l) => l.action === 'INVOICE_CANCELLED')).toBe(true);
  });
});
