import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { cleanupBranch, createTestContext, prisma, type TestContext } from './helpers';
import { createOrder, addItemToOrder, recalculateOrder } from '@/lib/pos/order-service';
import { checkoutOrder } from '@/lib/pos/checkout-service';
import { dismissOffer, getOrderOfferSummary, restoreOffer } from '@/lib/pos/offer-service';
import { openShift } from '@/lib/pos/shift-service';
import { toNumber } from '@/lib/money';

let ctx: TestContext;
let shiftId: string;
let offerId: string;
let cheapDrinkId: string;
let pricyDrinkId: string;
let expensiveDrinkId: string;

beforeAll(async () => {
  ctx = await createTestContext();
  const shift = await openShift({
    branchId: ctx.branchId,
    userId: ctx.cashierId,
    openingFloat: 0,
  });
  shiftId = shift.id;

  const suffix = Date.now();
  const drinkCategory = await prisma.category.create({
    data: { branchId: ctx.branchId, nameAr: 'مشروبات الاختبار' },
  });
  const vatTaxId = ctx.vatTaxId;

  const makeDrink = async (name: string, price: number) =>
    (
      await prisma.product.create({
        data: {
          branchId: ctx.branchId,
          categoryId: drinkCategory.id,
          nameAr: name,
          sku: `D-${name}-${suffix}`,
          price,
          priceIncludesVat: true,
          vatTaxId,
        },
      })
    ).id;

  cheapDrinkId = await makeDrink('مياه', 5);
  pricyDrinkId = await makeDrink('كابتشينو', 20);
  expensiveDrinkId = await makeDrink('عصير', 22);

  const shishaCategory = await prisma.product.findUniqueOrThrow({
    where: { id: ctx.tobaccoProductId },
    select: { categoryId: true },
  });

  const offer = await prisma.offer.create({
    data: {
      branchId: ctx.branchId,
      nameAr: 'مشروب + معسل بـ 55',
      fixedPrice: 55,
      priority: 10,
      daysOfWeek: [],
      components: {
        create: [
          {
            nameAr: 'أي مشروب أقل من 22',
            quantity: 1,
            categoryIds: [drinkCategory.id],
            productIds: [],
            maxUnitPrice: 21.99,
            tobaccoOnly: false,
            sortOrder: 0,
          },
          {
            nameAr: 'أي معسل',
            quantity: 1,
            categoryIds: [shishaCategory.categoryId],
            productIds: [],
            tobaccoOnly: true,
            sortOrder: 1,
          },
        ],
      },
    },
  });
  offerId = offer.id;
});

afterAll(async () => {
  await prisma.offerComponent.deleteMany({ where: { offer: { branchId: ctx.branchId } } });
  await prisma.discount.deleteMany({ where: { order: { branchId: ctx.branchId } } });
  await prisma.offer.deleteMany({ where: { branchId: ctx.branchId } });
  await cleanupBranch(ctx.branchId);
  await prisma.$disconnect();
});

async function orderWith(items: { productId: string; quantity: number }[]) {
  return createOrder({
    branchId: ctx.branchId,
    userId: ctx.cashierId,
    type: 'TAKEAWAY',
    shiftId,
    items,
  });
}

describe('التطبيق التلقائي للعروض', () => {
  it('يطبق العرض فور اكتمال شروطه ويصل بالإجمالي إلى سعر العرض', async () => {
    const order = await orderWith([
      { productId: pricyDrinkId, quantity: 1 },
      { productId: ctx.tobaccoProductId, quantity: 1 },
    ]);
    // الشيشة الاختبارية 100 غير شامل ⇒ 230 شاملة، مع المشروب 250 ⇒ العرض 55
    expect(toNumber(order.grandTotal)).toBeCloseTo(55, 1);

    const summary = await getOrderOfferSummary(prisma, order.id);
    expect(summary).toHaveLength(1);
    expect(summary[0].offerId).toBe(offerId);
    expect(summary[0].savings).toBeGreaterThan(0);
  });

  it('يبقي ضريبة التبغ منفصلة بعد تطبيق العرض', async () => {
    const order = await orderWith([
      { productId: pricyDrinkId, quantity: 1 },
      { productId: ctx.tobaccoProductId, quantity: 1 },
    ]);
    expect(toNumber(order.tobaccoTaxTotal)).toBeGreaterThan(0);
    expect(toNumber(order.vatTotal)).toBeGreaterThan(0);
    expect(toNumber(order.tobaccoTaxTotal)).not.toBe(toNumber(order.vatTotal));
  });

  it('لا يطبق العرض على مشروب لا يحقق شرط السعر', async () => {
    const order = await orderWith([
      { productId: expensiveDrinkId, quantity: 1 },
      { productId: ctx.tobaccoProductId, quantity: 1 },
    ]);
    const summary = await getOrderOfferSummary(prisma, order.id);
    expect(summary).toHaveLength(0);
    expect(toNumber(order.grandTotal)).toBeGreaterThan(55);
  });

  it('لا يطبق العرض بدون معسل', async () => {
    const order = await orderWith([{ productId: pricyDrinkId, quantity: 1 }]);
    expect(await getOrderOfferSummary(prisma, order.id)).toHaveLength(0);
  });

  it('يطبق العرض تلقائيًا عند إضافة الصنف المكمّل لاحقًا', async () => {
    const order = await orderWith([{ productId: pricyDrinkId, quantity: 1 }]);
    expect(await getOrderOfferSummary(prisma, order.id)).toHaveLength(0);

    const updated = await addItemToOrder(order.id, {
      productId: ctx.tobaccoProductId,
      quantity: 1,
    });
    expect(await getOrderOfferSummary(prisma, updated.id)).toHaveLength(1);
    expect(toNumber(updated.grandTotal)).toBeCloseTo(55, 1);
  });

  it('يستهلك المشروب الأغلى لصالح العميل', async () => {
    const order = await orderWith([
      { productId: cheapDrinkId, quantity: 1 },
      { productId: pricyDrinkId, quantity: 1 },
      { productId: ctx.tobaccoProductId, quantity: 1 },
    ]);
    // الباقة تأخذ الكابتشينو (20) ويبقى الماء (5) بسعره ⇒ 60
    expect(toNumber(order.grandTotal)).toBeCloseTo(60, 1);
  });

  it('يطبق باقتين عند مضاعفة المكونات', async () => {
    const order = await orderWith([
      { productId: pricyDrinkId, quantity: 2 },
      { productId: ctx.tobaccoProductId, quantity: 2 },
    ]);
    expect(toNumber(order.grandTotal)).toBeCloseTo(110, 1);
  });

  it('لا تتراكم خصومات العرض عند إعادة الاحتساب مرارًا', async () => {
    const order = await orderWith([
      { productId: pricyDrinkId, quantity: 1 },
      { productId: ctx.tobaccoProductId, quantity: 1 },
    ]);
    const firstTotal = toNumber(order.grandTotal);

    for (let i = 0; i < 3; i += 1) {
      await prisma.$transaction((tx) => recalculateOrder(tx, order.id));
    }
    const after = await prisma.order.findUniqueOrThrow({ where: { id: order.id } });
    expect(toNumber(after.grandTotal)).toBeCloseTo(firstTotal, 2);

    const offerDiscounts = await prisma.discount.count({
      where: { orderId: order.id, type: 'OFFER' },
    });
    expect(offerDiscounts).toBe(2); // خصم واحد لكل سطر مشارك
  });
});

describe('إلغاء العرض يدويًا', () => {
  it('الكاشير يستطيع إلغاء العرض فيعود السعر الأصلي', async () => {
    const order = await orderWith([
      { productId: pricyDrinkId, quantity: 1 },
      { productId: ctx.tobaccoProductId, quantity: 1 },
    ]);
    expect(toNumber(order.grandTotal)).toBeCloseTo(55, 1);

    const afterDismiss = await prisma.$transaction(async (tx) => {
      await dismissOffer(tx, order.id, offerId);
      return recalculateOrder(tx, order.id);
    });

    expect(toNumber(afterDismiss.grandTotal)).toBeGreaterThan(55);
    expect(await getOrderOfferSummary(prisma, order.id)).toHaveLength(0);
  });

  it('العرض الملغى لا يعود عند تعديل الطلب', async () => {
    const order = await orderWith([
      { productId: pricyDrinkId, quantity: 1 },
      { productId: ctx.tobaccoProductId, quantity: 1 },
    ]);
    await prisma.$transaction(async (tx) => {
      await dismissOffer(tx, order.id, offerId);
      return recalculateOrder(tx, order.id);
    });

    const updated = await addItemToOrder(order.id, {
      productId: cheapDrinkId,
      quantity: 1,
    });
    expect(await getOrderOfferSummary(prisma, updated.id)).toHaveLength(0);
  });

  it('يمكن إعادة تفعيل العرض بعد إلغائه', async () => {
    const order = await orderWith([
      { productId: pricyDrinkId, quantity: 1 },
      { productId: ctx.tobaccoProductId, quantity: 1 },
    ]);
    await prisma.$transaction(async (tx) => {
      await dismissOffer(tx, order.id, offerId);
      return recalculateOrder(tx, order.id);
    });
    const restored = await prisma.$transaction(async (tx) => {
      await restoreOffer(tx, order.id, offerId);
      return recalculateOrder(tx, order.id);
    });
    expect(toNumber(restored.grandTotal)).toBeCloseTo(55, 1);
  });

  it('العرض المعطّل لا يُطبق على الطلبات الجديدة', async () => {
    await prisma.offer.update({ where: { id: offerId }, data: { isActive: false } });
    const order = await orderWith([
      { productId: pricyDrinkId, quantity: 1 },
      { productId: ctx.tobaccoProductId, quantity: 1 },
    ]);
    expect(await getOrderOfferSummary(prisma, order.id)).toHaveLength(0);
    await prisma.offer.update({ where: { id: offerId }, data: { isActive: true } });
  });
});

describe('العرض داخل الفاتورة', () => {
  it('تُغلق الفاتورة بسعر العرض ويُحفظ الخصم في أسطرها', async () => {
    const order = await orderWith([
      { productId: pricyDrinkId, quantity: 1 },
      { productId: ctx.tobaccoProductId, quantity: 1 },
    ]);
    const total = toNumber(order.grandTotal);

    const invoice = await checkoutOrder({
      orderId: order.id,
      userId: ctx.cashierId,
      shiftId,
      payments: [{ paymentMethodId: ctx.cashMethodId, amount: total }],
    });

    expect(invoice.status).toBe('PAID');
    expect(toNumber(invoice.grandTotal)).toBeCloseTo(55, 1);
    expect(toNumber(invoice.discountTotal)).toBeGreaterThan(0);
    // الضريبتان محفوظتان منفصلتين في الفاتورة
    expect(toNumber(invoice.tobaccoTaxTotal)).toBeGreaterThan(0);
    expect(toNumber(invoice.vatTotal)).toBeGreaterThan(0);

    // أسطر الفاتورة تحمل الخصم المشتق من العرض
    const discounted = invoice.items.filter((i) => toNumber(i.discountAmount) > 0);
    expect(discounted.length).toBe(2);
  });
});
