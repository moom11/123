import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { SyncEntity, SyncStatus } from '@prisma/client';
import { cleanupBranch, createTestContext, prisma, type TestContext } from './helpers';
import {
  claimPendingJobs,
  completeJob,
  enqueueSyncJob,
  retryAllFailed,
  retryJob,
} from '@/lib/odoo/sync-queue';
import { createOrder } from '@/lib/pos/order-service';
import { checkoutOrder } from '@/lib/pos/checkout-service';
import { openShift } from '@/lib/pos/shift-service';
import { processSyncJob, runSyncCycle } from '@/lib/odoo/integration-service';
import { encryptSecret, decryptSecret } from '@/lib/crypto';
import { buildDailyClosing } from '@/lib/reports/report-service';
import { currentBusinessDay } from '@/lib/settings';
import { toNumber } from '@/lib/money';

let ctx: TestContext;
let shiftId: string;

beforeAll(async () => {
  ctx = await createTestContext();
  const shift = await openShift({
    branchId: ctx.branchId,
    userId: ctx.cashierId,
    openingFloat: 0,
  });
  shiftId = shift.id;
});

afterAll(async () => {
  await cleanupBranch(ctx.branchId);
  await prisma.$disconnect();
});

async function paidInvoice() {
  const order = await createOrder({
    branchId: ctx.branchId,
    userId: ctx.cashierId,
    type: 'TAKEAWAY',
    shiftId,
    items: [{ productId: ctx.plainProductId, quantity: 1 }],
  });
  return checkoutOrder({
    orderId: order.id,
    userId: ctx.cashierId,
    shiftId,
    payments: [{ paymentMethodId: ctx.cashMethodId, amount: 115 }],
  });
}

describe('إدراج مهام المزامنة', () => {
  it('يُنشئ مهمة تلقائيًا عند إغلاق الفاتورة', async () => {
    const invoice = await paidInvoice();
    const job = await prisma.syncJob.findFirst({
      where: { entity: SyncEntity.INVOICE, entityId: invoice.id },
    });
    expect(job).not.toBeNull();
    expect(job!.status).toBe(SyncStatus.PENDING);
    expect(job!.idempotencyKey).toBe(`invoice:${invoice.id}`);
  });

  it('لا يُنشئ مهمة مكررة لنفس المفتاح', async () => {
    const key = `dup-test-${Date.now()}`;
    const first = await enqueueSyncJob(prisma, {
      branchId: ctx.branchId,
      entity: SyncEntity.INVOICE,
      entityId: 'entity-1',
      idempotencyKey: key,
    });
    const second = await enqueueSyncJob(prisma, {
      branchId: ctx.branchId,
      entity: SyncEntity.INVOICE,
      entityId: 'entity-1',
      idempotencyKey: key,
    });
    expect(second.id).toBe(first.id);
    expect(await prisma.syncJob.count({ where: { idempotencyKey: key } })).toBe(1);
  });

  it('يُنشئ مهمة مرتجع عند تنفيذ الإرجاع', async () => {
    const { createRefund } = await import('@/lib/pos/refund-service');
    const invoice = await paidInvoice();
    const refund = await createRefund({
      invoiceId: invoice.id,
      userId: ctx.managerId,
      shiftId,
      reason: 'اختبار',
    });
    const job = await prisma.syncJob.findFirst({
      where: { entity: SyncEntity.REFUND, entityId: refund.id },
    });
    expect(job).not.toBeNull();
  });
});

describe('قفل المهام ومعالجتها', () => {
  it('يمنع عاملين من التقاط نفس المهمة', async () => {
    await prisma.syncJob.deleteMany({ where: { branchId: ctx.branchId } });
    const invoice = await paidInvoice();
    void invoice;

    const first = await claimPendingJobs('worker-1', 10);
    const second = await claimPendingJobs('worker-2', 10);

    expect(first.length).toBeGreaterThan(0);
    // المهام المقفولة لا تُلتقط مرة أخرى
    expect(second.filter((id) => first.includes(id))).toHaveLength(0);
  });

  it('يعيد جدولة المهمة عند خطأ قابل لإعادة المحاولة', async () => {
    const jobs = await prisma.syncJob.findMany({
      where: { branchId: ctx.branchId },
      take: 1,
    });
    const job = jobs[0];

    await completeJob(job.id, {
      success: false,
      error: 'تعذر الاتصال بخادم Odoo',
      retryable: true,
    });

    const after = await prisma.syncJob.findUniqueOrThrow({ where: { id: job.id } });
    expect(after.status).toBe(SyncStatus.FAILED);
    expect(after.attempts).toBe(job.attempts + 1);
    expect(after.nextRetryAt).not.toBeNull();
    expect(after.lockedAt).toBeNull();
  });

  it('يضع المهمة في «تحتاج مراجعة» عند خطأ غير قابل لإعادة المحاولة', async () => {
    const job = await enqueueSyncJob(prisma, {
      branchId: ctx.branchId,
      entity: SyncEntity.INVOICE,
      entityId: 'bad-entity',
      idempotencyKey: `fatal-${Date.now()}`,
    });
    await completeJob(job.id, {
      success: false,
      error: 'بيانات غير صالحة',
      retryable: false,
    });
    const after = await prisma.syncJob.findUniqueOrThrow({ where: { id: job.id } });
    expect(after.status).toBe(SyncStatus.NEEDS_REVIEW);
    expect(after.nextRetryAt).toBeNull();
  });

  it('يستنفد المحاولات وينقل المهمة إلى المراجعة', async () => {
    const job = await enqueueSyncJob(prisma, {
      branchId: ctx.branchId,
      entity: SyncEntity.INVOICE,
      entityId: 'exhaust-entity',
      idempotencyKey: `exhaust-${Date.now()}`,
      maxAttempts: 2,
    });
    await completeJob(job.id, { success: false, error: 'شبكة', retryable: true });
    await completeJob(job.id, { success: false, error: 'شبكة', retryable: true });

    const after = await prisma.syncJob.findUniqueOrThrow({ where: { id: job.id } });
    expect(after.attempts).toBe(2);
    expect(after.status).toBe(SyncStatus.NEEDS_REVIEW);
  });

  it('يحدّث حالة الفاتورة عند نجاح المزامنة', async () => {
    const invoice = await paidInvoice();
    const job = await prisma.syncJob.findFirstOrThrow({
      where: { entity: SyncEntity.INVOICE, entityId: invoice.id },
    });

    await completeJob(job.id, { success: true, odooRecordId: 4242 });

    const after = await prisma.invoice.findUniqueOrThrow({ where: { id: invoice.id } });
    expect(after.syncStatus).toBe(SyncStatus.SYNCED);
    expect(after.odooRecordId).toBe(4242);
    expect(after.lastSyncAt).not.toBeNull();
  });

  it('لا يعيد إرسال فاتورة مرحّلة مسبقًا', async () => {
    const invoice = await paidInvoice();
    await prisma.invoice.update({
      where: { id: invoice.id },
      data: { odooRecordId: 999 },
    });
    const job = await prisma.syncJob.findFirstOrThrow({
      where: { entity: SyncEntity.INVOICE, entityId: invoice.id },
    });

    const outcome = await processSyncJob(job.id);
    expect(outcome.success).toBe(true);
    expect(outcome.odooRecordId).toBe(999);
  });

  it('يسجل كل محاولة في سجل المزامنة', async () => {
    const job = await enqueueSyncJob(prisma, {
      branchId: ctx.branchId,
      entity: SyncEntity.INVOICE,
      entityId: 'log-entity',
      idempotencyKey: `log-${Date.now()}`,
    });
    await completeJob(job.id, { success: false, error: 'خطأ اختباري', retryable: true });
    const logs = await prisma.syncLog.findMany({ where: { syncJobId: job.id } });
    expect(logs.length).toBe(1);
    expect(logs[0].errorMessage).toBe('خطأ اختباري');
  });
});

describe('إعادة المحاولة اليدوية', () => {
  it('يعيد جدولة مهمة فاشلة', async () => {
    const job = await enqueueSyncJob(prisma, {
      branchId: ctx.branchId,
      entity: SyncEntity.INVOICE,
      entityId: 'retry-entity',
      idempotencyKey: `retry-${Date.now()}`,
    });
    await completeJob(job.id, { success: false, error: 'فشل', retryable: false });

    const retried = await retryJob(job.id);
    expect(retried!.status).toBe(SyncStatus.PENDING);
    expect(retried!.attempts).toBe(0);
    expect(retried!.lastError).toBeNull();
  });

  it('يعيد جدولة كل المهام الفاشلة في الفرع', async () => {
    await prisma.syncJob.updateMany({
      where: { branchId: ctx.branchId },
      data: { status: SyncStatus.FAILED },
    });
    const count = await retryAllFailed(ctx.branchId);
    expect(count).toBeGreaterThan(0);

    const remaining = await prisma.syncJob.count({
      where: { branchId: ctx.branchId, status: SyncStatus.FAILED },
    });
    expect(remaining).toBe(0);
  });
});

describe('فشل Odoo لا يوقف البيع', () => {
  it('يستمر إصدار الفواتير مع تعطل خادم Odoo', async () => {
    await prisma.odooSetting.upsert({
      where: { branchId: ctx.branchId },
      create: {
        branchId: ctx.branchId,
        isEnabled: true,
        url: 'http://127.0.0.1:9',
        database: 'nope',
        username: 'admin',
        apiKeyEncrypted: encryptSecret('secret'),
      },
      update: { isEnabled: true, url: 'http://127.0.0.1:9' },
    });

    const invoice = await paidInvoice();
    expect(invoice.status).toBe('PAID');

    const result = await runSyncCycle('test-worker', 20);
    expect(result.processed).toBeGreaterThan(0);
    // مهمة هذه الفاتورة تحديدًا يجب أن تفشل لتعذر الاتصال
    const job = await prisma.syncJob.findFirstOrThrow({
      where: { entity: SyncEntity.INVOICE, entityId: invoice.id },
    });
    expect(job.status).not.toBe(SyncStatus.SYNCED);
    expect(job.lastError).toMatch(/تعذر الاتصال/);

    // الفاتورة تبقى صالحة رغم فشل الترحيل
    const after = await prisma.invoice.findUniqueOrThrow({ where: { id: invoice.id } });
    expect(after.status).toBe('PAID');
    expect([SyncStatus.FAILED, SyncStatus.NEEDS_REVIEW]).toContain(after.syncStatus);
    expect(after.syncErrorMessage).toBeTruthy();
  });

  it('لا يخزّن مفتاح API في سجلات المزامنة', async () => {
    const logs = await prisma.syncLog.findMany({ take: 50 });
    const serialized = JSON.stringify(logs);
    expect(serialized).not.toContain('secret');
  });

  it('يخزن مفتاح API مشفرًا وقابلًا للاسترجاع', async () => {
    const settings = await prisma.odooSetting.findUniqueOrThrow({
      where: { branchId: ctx.branchId },
    });
    expect(settings.apiKeyEncrypted).not.toBe('secret');
    expect(decryptSecret(settings.apiKeyEncrypted)).toBe('secret');
  });
});

describe('الملخص اليومي', () => {
  it('يبني ملخصًا يفصل ضريبة التبغ عن ض.ق.م', async () => {
    const order = await createOrder({
      branchId: ctx.branchId,
      userId: ctx.cashierId,
      type: 'TAKEAWAY',
      shiftId,
      items: [{ productId: ctx.tobaccoProductId, quantity: 1 }],
    });
    await checkoutOrder({
      orderId: order.id,
      userId: ctx.cashierId,
      shiftId,
      payments: [{ paymentMethodId: ctx.cashMethodId, amount: 230 }],
    });

    const businessDay = await currentBusinessDay(ctx.branchId);
    const closing = await buildDailyClosing(ctx.branchId, businessDay);

    expect(toNumber(closing.tobaccoTaxTotal)).toBeGreaterThan(0);
    expect(toNumber(closing.vatTotal)).toBeGreaterThan(0);
    expect(toNumber(closing.vatTotal)).not.toBe(toNumber(closing.tobaccoTaxTotal));
    expect(closing.invoiceCount).toBeGreaterThan(0);
    expect(closing.idempotencyKey).toContain(ctx.branchId);
  });

  it('إعادة البناء لنفس اليوم تحدّث السجل ولا تكرره', async () => {
    const businessDay = await currentBusinessDay(ctx.branchId);
    const first = await buildDailyClosing(ctx.branchId, businessDay);
    const second = await buildDailyClosing(ctx.branchId, businessDay);
    expect(second.id).toBe(first.id);

    const count = await prisma.dailyClosing.count({
      where: { branchId: ctx.branchId, businessDay },
    });
    expect(count).toBe(1);
  });
});
