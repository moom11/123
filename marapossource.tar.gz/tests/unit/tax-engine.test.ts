import { describe, expect, it } from 'vitest';
import {
  calculateOrderTaxes,
  computeNetUnitPrice,
  computeOrderDiscountAmount,
  computeTobaccoTax,
  type TaxLineInput,
} from '@/lib/pos/tax-engine';
import { distributeProportionally, round2 } from '@/lib/money';

function line(overrides: Partial<TaxLineInput> = {}): TaxLineInput {
  return {
    id: 'line-1',
    quantity: 1,
    unitPrice: 100,
    priceIncludesVat: false,
    vatRate: 15,
    ...overrides,
  };
}

describe('احتساب ضريبة القيمة المضافة', () => {
  it('يحسب الضريبة على سعر غير شامل', () => {
    const { lines, totals } = calculateOrderTaxes([line({ unitPrice: 100 })]);
    expect(lines[0].netBeforeTax).toBe(100);
    expect(lines[0].vatAmount).toBe(15);
    expect(totals.grandTotal).toBe(115);
  });

  it('يستخرج الضريبة من سعر شامل', () => {
    const { lines, totals } = calculateOrderTaxes([
      line({ unitPrice: 115, priceIncludesVat: true }),
    ]);
    expect(lines[0].netBeforeTax).toBe(100);
    expect(lines[0].vatAmount).toBe(15);
    expect(totals.grandTotal).toBe(115);
  });

  it('يضرب في الكمية بشكل صحيح', () => {
    const { totals } = calculateOrderTaxes([
      line({ unitPrice: 45, quantity: 3, priceIncludesVat: true }),
    ]);
    expect(totals.grandTotal).toBe(135);
    expect(totals.netBeforeTax).toBe(117.39);
    expect(totals.vatTotal).toBe(17.61);
  });

  it('يضيف سعر الإضافات إلى وعاء الضريبة', () => {
    const { lines } = calculateOrderTaxes([
      line({ unitPrice: 20, modifiersPrice: 3, priceIncludesVat: true }),
    ]);
    // 23 شامل الضريبة ⇒ الصافي 20.00
    expect(lines[0].netBeforeTax).toBe(20);
    expect(lines[0].vatAmount).toBe(3);
  });

  it('يتعامل مع نسبة ضريبة صفرية', () => {
    const { totals } = calculateOrderTaxes([line({ unitPrice: 50, vatRate: 0 })]);
    expect(totals.vatTotal).toBe(0);
    expect(totals.grandTotal).toBe(50);
  });

  it('يتجاهل الأسطر ذات الكمية الصفرية', () => {
    const { lines } = calculateOrderTaxes([
      line({ id: 'a', quantity: 0 }),
      line({ id: 'b', quantity: 1 }),
    ]);
    expect(lines).toHaveLength(1);
    expect(lines[0].id).toBe('b');
  });
});

describe('احتساب ضريبة التبغ', () => {
  it('يحتسبها كنسبة من الصافي ويبقيها منفصلة عن ض.ق.م', () => {
    const { lines, totals } = calculateOrderTaxes([
      line({
        unitPrice: 100,
        isTobacco: true,
        tobaccoBase: 'PERCENT_OF_PRICE',
        tobaccoRate: 100,
      }),
    ]);
    expect(lines[0].netBeforeTax).toBe(100);
    expect(lines[0].tobaccoTaxAmount).toBe(100);
    // ض.ق.م تُحسب على (الصافي + ضريبة التبغ)
    expect(lines[0].vatAmount).toBe(30);
    expect(totals.grandTotal).toBe(230);
    // القيمتان لا تُدمجان أبدًا
    expect(totals.vatTotal).not.toBe(totals.tobaccoTaxTotal);
  });

  it('يعكس السعر الشامل لضريبتين معًا', () => {
    // سعر بيع 60 شامل ⇒ الصافي = 60 / (2 × 1.15) = 26.0870
    const { lines } = calculateOrderTaxes([
      line({
        unitPrice: 60,
        priceIncludesVat: true,
        isTobacco: true,
        tobaccoBase: 'PERCENT_OF_PRICE',
        tobaccoRate: 100,
      }),
    ]);
    expect(lines[0].netBeforeTax).toBeCloseTo(26.09, 2);
    expect(lines[0].tobaccoTaxAmount).toBeCloseTo(26.09, 2);
    expect(lines[0].vatAmount).toBeCloseTo(7.83, 2);
    expect(lines[0].lineTotal).toBeCloseTo(60, 1);
  });

  it('يدعم المبلغ الثابت لكل وحدة', () => {
    const { lines } = calculateOrderTaxes([
      line({
        unitPrice: 50,
        quantity: 2,
        isTobacco: true,
        tobaccoBase: 'FIXED_PER_UNIT',
        tobaccoFixedAmount: 10,
      }),
    ]);
    expect(lines[0].tobaccoTaxAmount).toBe(20);
    expect(lines[0].vatAmount).toBe(18); // (100 + 20) × 15%
  });

  it('يطبق الحد الأدنى للضريبة لكل وحدة', () => {
    const amount = computeTobaccoTax(
      line({
        isTobacco: true,
        tobaccoBase: 'PERCENT_OF_PRICE',
        tobaccoRate: 10,
        tobaccoMinPerUnit: 25,
        quantity: 2,
      }),
      100,
      2,
    );
    // النسبة تعطي 10 لكن الحد الأدنى 25 × 2 = 50
    expect(amount).toBe(50);
  });

  it('لا يطبق ضريبة تبغ على المنتجات العادية', () => {
    const { totals } = calculateOrderTaxes([line({ unitPrice: 100, isTobacco: false })]);
    expect(totals.tobaccoTaxTotal).toBe(0);
  });

  it('يفصل التبغ عن غيره داخل نفس الفاتورة', () => {
    const { totals } = calculateOrderTaxes([
      line({ id: 'food', unitPrice: 100 }),
      line({
        id: 'shisha',
        unitPrice: 100,
        isTobacco: true,
        tobaccoBase: 'PERCENT_OF_PRICE',
        tobaccoRate: 100,
      }),
    ]);
    expect(totals.tobaccoTaxTotal).toBe(100);
    expect(totals.vatTotal).toBe(45); // 15 + 30
    expect(totals.grandTotal).toBe(345);
  });
});

describe('الخصومات', () => {
  it('يطبق خصم نسبة قبل الضريبة', () => {
    const { totals } = calculateOrderTaxes([line({ unitPrice: 100 })], {
      type: 'PERCENT',
      value: 10,
    });
    expect(totals.discountTotal).toBe(10);
    expect(totals.netBeforeTax).toBe(90);
    expect(totals.vatTotal).toBe(13.5);
    expect(totals.grandTotal).toBe(103.5);
  });

  it('يطبق خصمًا بمبلغ ثابت', () => {
    const { totals } = calculateOrderTaxes([line({ unitPrice: 200 })], {
      type: 'AMOUNT',
      value: 50,
    });
    expect(totals.netBeforeTax).toBe(150);
    expect(totals.grandTotal).toBe(172.5);
  });

  it('يوزع خصم الفاتورة على الأسطر بالتناسب', () => {
    const { lines, totals } = calculateOrderTaxes(
      [
        line({ id: 'a', unitPrice: 100 }),
        line({ id: 'b', unitPrice: 300 }),
      ],
      { type: 'AMOUNT', value: 40 },
    );
    expect(lines[0].discountAmount).toBe(10);
    expect(lines[1].discountAmount).toBe(30);
    expect(totals.discountTotal).toBe(40);
  });

  it('يطبق خصم السطر مع خصم الفاتورة معًا', () => {
    const { lines, totals } = calculateOrderTaxes(
      [line({ unitPrice: 100, lineDiscount: 20 })],
      { type: 'PERCENT', value: 10 },
    );
    // خصم السطر 20، ثم 10% من الصافي المتبقي (80) = 8
    expect(lines[0].discountAmount).toBe(28);
    expect(totals.netBeforeTax).toBe(72);
  });

  it('لا يتجاوز الخصم قيمة الفاتورة', () => {
    expect(computeOrderDiscountAmount({ type: 'AMOUNT', value: 500 }, 100)).toBe(100);
  });

  it('يحترم الحد الأعلى للخصم', () => {
    expect(
      computeOrderDiscountAmount({ type: 'PERCENT', value: 50, maxAmount: 30 }, 200),
    ).toBe(30);
  });
});

describe('دقة المبالغ', () => {
  it('يوزع المبالغ دون فقدان هللات', () => {
    const shares = distributeProportionally(10, [1, 1, 1]);
    expect(round2(shares.reduce((a, b) => a + b, 0))).toBe(10);
  });

  it('يقرّب بشكل صحيح عند 0.005', () => {
    expect(round2(1.005)).toBe(1.01);
    expect(round2(2.675)).toBe(2.68);
  });

  it('يعيد صفرًا للقيم غير الصالحة', () => {
    expect(round2(Number.NaN)).toBe(0);
  });
});

describe('استخراج الصافي من السعر', () => {
  it('السعر غير الشامل يبقى كما هو', () => {
    expect(computeNetUnitPrice(line({ unitPrice: 100, priceIncludesVat: false }))).toBe(100);
  });

  it('السعر الشامل مع مبلغ ثابت للتبغ', () => {
    // G = (n + 10) × 1.15 = 115 ⇒ n = 90
    const net = computeNetUnitPrice(
      line({
        unitPrice: 115,
        priceIncludesVat: true,
        isTobacco: true,
        tobaccoBase: 'FIXED_PER_UNIT',
        tobaccoFixedAmount: 10,
      }),
    );
    expect(net).toBeCloseTo(90, 2);
  });
});
