import { afterAll, describe, expect, it } from 'vitest';
import { rm } from 'node:fs/promises';
import { join } from 'node:path';
import { readFileSync } from 'node:fs';
import { detectImageType, MAX_UPLOAD_BYTES, storeUpload } from '@/lib/uploads';

const PNG = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 0]);
const JPEG = new Uint8Array([0xff, 0xd8, 0xff, 0xe0, 0, 0, 0, 0]);
const GIF = new Uint8Array([0x47, 0x49, 0x46, 0x38, 0x39, 0x61, 0, 0]);
const WEBP = new Uint8Array([
  0x52, 0x49, 0x46, 0x46, 0x10, 0x00, 0x00, 0x00, 0x57, 0x45, 0x42, 0x50, 0, 0, 0, 0,
]);

const written: string[] = [];

function file(bytes: Uint8Array, name: string, type: string) {
  return new File([bytes as unknown as BlobPart], name, { type });
}

afterAll(async () => {
  for (const url of written) {
    await rm(join(process.cwd(), 'public', url), { force: true });
  }
});

describe('كشف نوع الصورة من التوقيع الثنائي', () => {
  it('يتعرف على الأنواع المسموحة', () => {
    expect(detectImageType(PNG)?.extension).toBe('png');
    expect(detectImageType(JPEG)?.extension).toBe('jpg');
    expect(detectImageType(GIF)?.extension).toBe('gif');
    expect(detectImageType(WEBP)?.extension).toBe('webp');
  });

  it('يرفض ما ليس صورة', () => {
    expect(detectImageType(new TextEncoder().encode('<?php system($_GET[0]); ?>'))).toBeNull();
    expect(detectImageType(new TextEncoder().encode('<svg onload=alert(1)>'))).toBeNull();
    expect(detectImageType(new Uint8Array([0, 1, 2, 3]))).toBeNull();
  });

  it('يرفض WebP مزيفًا يحمل RIFF بلا توقيع WEBP', () => {
    const fake = new Uint8Array(16);
    fake.set([0x52, 0x49, 0x46, 0x46], 0); // RIFF فقط (ملف WAV مثلًا)
    expect(detectImageType(fake)).toBeNull();
  });
});

describe('حفظ الملف المرفوع', () => {
  it('يحفظ الصورة ويعيد رابطًا عامًا', async () => {
    const stored = await storeUpload(file(PNG, 'x.png', 'image/png'), 'products');
    written.push(stored.url);
    expect(stored.url).toMatch(/^\/uploads\/products\/[0-9a-f-]{36}\.png$/);
    expect(stored.mime).toBe('image/png');
    // الملف موجود فعلًا على القرص بنفس المحتوى
    expect(readFileSync(join(process.cwd(), 'public', stored.url))).toEqual(Buffer.from(PNG));
  });

  it('لا يشتق اسم الملف من اسم المستخدم — لا مجال لاجتياز المسارات', async () => {
    const stored = await storeUpload(
      file(PNG, '../../../etc/passwd.png', 'image/png'),
      'products',
    );
    written.push(stored.url);
    expect(stored.url).not.toContain('..');
    expect(stored.url).not.toContain('passwd');
  });

  it('يرفض الامتداد المزيف: ترويسة تقول صورة والمحتوى نص', async () => {
    const script = new TextEncoder().encode('#!/bin/sh\nrm -rf /\n');
    await expect(storeUpload(file(script, 'evil.png', 'image/png'), 'products')).rejects.toThrow(
      /نوع الملف غير مسموح/,
    );
  });

  it('يرفض SVG لأنه قد يحمل سكربتًا', async () => {
    const svg = new TextEncoder().encode('<svg xmlns="http://www.w3.org/2000/svg"></svg>');
    await expect(storeUpload(file(svg, 'a.svg', 'image/svg+xml'), 'products')).rejects.toThrow(
      /نوع الملف غير مسموح/,
    );
  });

  it('يرفض الملف الفارغ', async () => {
    await expect(
      storeUpload(file(new Uint8Array(0), 'a.png', 'image/png'), 'products'),
    ).rejects.toThrow(/فارغ/);
  });

  it('يرفض ما يتجاوز الحد الأقصى للحجم', async () => {
    const big = new Uint8Array(MAX_UPLOAD_BYTES + 1);
    big.set(PNG, 0);
    await expect(storeUpload(file(big, 'big.png', 'image/png'), 'products')).rejects.toThrow(
      /الحد المسموح/,
    );
  });

  it('يفصل مجلد المصروفات عن مجلد المنتجات', async () => {
    const stored = await storeUpload(file(JPEG, 'r.jpg', 'image/jpeg'), 'expenses');
    written.push(stored.url);
    expect(stored.url).toMatch(/^\/uploads\/expenses\//);
  });

  it('يولّد اسمًا مختلفًا لكل رفع فلا يُستبدل ملف قائم', async () => {
    const a = await storeUpload(file(PNG, 'same.png', 'image/png'), 'products');
    const b = await storeUpload(file(PNG, 'same.png', 'image/png'), 'products');
    written.push(a.url, b.url);
    expect(a.url).not.toBe(b.url);
  });
});
