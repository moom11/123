import { describe, expect, it } from 'vitest';
import {
  formatBusinessDay,
  getBusinessDay,
  getBusinessDayRange,
  isWithinBusinessDay,
  parseBusinessDay,
} from '@/lib/business-day';

const TZ = 'Asia/Riyadh'; // UTC+3 بدون توقيت صيفي

/** يبني لحظة UTC من وقت محلي بالرياض */
function riyadh(y: number, m: number, d: number, hour: number, minute = 0): Date {
  return new Date(Date.UTC(y, m - 1, d, hour - 3, minute));
}

describe('اليوم التشغيلي من 5 صباحًا إلى 5 صباحًا', () => {
  it('الساعة 6 صباحًا تنتمي لنفس اليوم', () => {
    expect(formatBusinessDay(getBusinessDay(riyadh(2026, 8, 2, 6), 5, TZ))).toBe('2026-08-02');
  });

  it('الظهر ينتمي لنفس اليوم', () => {
    expect(formatBusinessDay(getBusinessDay(riyadh(2026, 8, 2, 12), 5, TZ))).toBe('2026-08-02');
  });

  it('الساعة 11 مساءً تنتمي لنفس اليوم', () => {
    expect(formatBusinessDay(getBusinessDay(riyadh(2026, 8, 2, 23), 5, TZ))).toBe('2026-08-02');
  });

  it('الساعة 2 بعد منتصف الليل تنتمي لليوم السابق', () => {
    expect(formatBusinessDay(getBusinessDay(riyadh(2026, 8, 3, 2), 5, TZ))).toBe('2026-08-02');
  });

  it('الساعة 4:59 صباحًا لا تزال في اليوم السابق', () => {
    expect(formatBusinessDay(getBusinessDay(riyadh(2026, 8, 3, 4, 59), 5, TZ))).toBe('2026-08-02');
  });

  it('الساعة 5:00 صباحًا بالضبط تبدأ اليوم الجديد', () => {
    expect(formatBusinessDay(getBusinessDay(riyadh(2026, 8, 3, 5), 5, TZ))).toBe('2026-08-03');
  });

  it('منتصف الليل تمامًا ينتمي لليوم السابق', () => {
    expect(formatBusinessDay(getBusinessDay(riyadh(2026, 8, 3, 0), 5, TZ))).toBe('2026-08-02');
  });

  it('يتعامل مع نهاية الشهر', () => {
    expect(formatBusinessDay(getBusinessDay(riyadh(2026, 9, 1, 3), 5, TZ))).toBe('2026-08-31');
  });

  it('يتعامل مع نهاية السنة', () => {
    expect(formatBusinessDay(getBusinessDay(riyadh(2027, 1, 1, 2), 5, TZ))).toBe('2026-12-31');
  });
});

describe('ساعة بداية قابلة للتعديل', () => {
  it('بداية 0 تعني اليوم التقويمي العادي', () => {
    expect(formatBusinessDay(getBusinessDay(riyadh(2026, 8, 3, 2), 0, TZ))).toBe('2026-08-03');
  });

  it('بداية 8 صباحًا تنقل الساعة 7 إلى اليوم السابق', () => {
    expect(formatBusinessDay(getBusinessDay(riyadh(2026, 8, 3, 7), 8, TZ))).toBe('2026-08-02');
  });
});

describe('نطاق اليوم التشغيلي', () => {
  it('يمتد 24 ساعة من ساعة البداية', () => {
    const day = parseBusinessDay('2026-08-02');
    const { start, end } = getBusinessDayRange(day, 5, TZ);
    expect(end.getTime() - start.getTime()).toBe(24 * 60 * 60 * 1000);
    // 5 صباحًا بالرياض = 2 صباحًا UTC
    expect(start.toISOString()).toBe('2026-08-02T02:00:00.000Z');
  });

  it('يحدد الانتماء للنطاق بشكل صحيح', () => {
    const day = parseBusinessDay('2026-08-02');
    expect(isWithinBusinessDay(riyadh(2026, 8, 2, 23), day, 5, TZ)).toBe(true);
    expect(isWithinBusinessDay(riyadh(2026, 8, 3, 3), day, 5, TZ)).toBe(true);
    expect(isWithinBusinessDay(riyadh(2026, 8, 3, 6), day, 5, TZ)).toBe(false);
    expect(isWithinBusinessDay(riyadh(2026, 8, 2, 4), day, 5, TZ)).toBe(false);
  });
});
