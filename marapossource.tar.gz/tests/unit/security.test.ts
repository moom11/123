import { describe, expect, it, beforeEach } from 'vitest';
import { decryptSecret, encryptSecret, maskSecret } from '@/lib/crypto';
import { hashPassword, isStrongPassword, verifyPassword } from '@/lib/auth/password';
import {
  ALL_PERMISSIONS,
  ROLE_PERMISSIONS,
  hasAnyPermission,
  hasPermission,
} from '@/lib/auth/permissions';
import { signAccessToken, verifyAccessToken, createRefreshToken, hashRefreshToken } from '@/lib/auth/tokens';
import { checkRateLimit, resetRateLimit } from '@/lib/api/rate-limit';
import { sanitize } from '@/lib/audit';
import { backoffDelayMs } from '@/lib/odoo/sync-queue';

describe('تشفير بيانات الاتصال بـ Odoo', () => {
  it('يشفر ويفك التشفير بشكل صحيح', () => {
    const secret = 'odoo-api-key-123456';
    const encrypted = encryptSecret(secret);
    expect(encrypted).not.toContain(secret);
    expect(decryptSecret(encrypted)).toBe(secret);
  });

  it('ينتج نصًا مشفرًا مختلفًا في كل مرة (IV عشوائي)', () => {
    expect(encryptSecret('same')).not.toBe(encryptSecret('same'));
  });

  it('يرفض البيانات المشفرة التالفة', () => {
    expect(() => decryptSecret('not-valid')).toThrow();
  });

  it('يتعامل مع القيم الفارغة', () => {
    expect(encryptSecret('')).toBe('');
    expect(decryptSecret(null)).toBe('');
  });

  it('يخفي القيمة عند العرض', () => {
    expect(maskSecret('abcdefghij')).toContain('ghij');
    expect(maskSecret('abcdefghij')).not.toBe('abcdefghij');
  });
});

describe('كلمات المرور', () => {
  it('يشفر ويتحقق بشكل صحيح', async () => {
    const hash = await hashPassword('Cashier@1234');
    expect(hash).not.toBe('Cashier@1234');
    expect(await verifyPassword('Cashier@1234', hash)).toBe(true);
    expect(await verifyPassword('wrong', hash)).toBe(false);
  });

  it('يرفض التحقق ضد بصمة فارغة', async () => {
    expect(await verifyPassword('any', '')).toBe(false);
  });

  it('يتحقق من قوة كلمة المرور', () => {
    expect(isStrongPassword('Admin@1234')).toBe(true);
    expect(isStrongPassword('short1')).toBe(false);
    expect(isStrongPassword('nodigitshere')).toBe(false);
  });
});

describe('صلاحيات المستخدمين', () => {
  it('مدير النظام يملك جميع الصلاحيات', () => {
    expect(ROLE_PERMISSIONS.SYSTEM_ADMIN).toHaveLength(ALL_PERMISSIONS.length);
  });

  it('الكاشير لا يستطيع تعديل الأسعار أو إلغاء فاتورة مكتملة', () => {
    const cashier = ROLE_PERMISSIONS.CASHIER as string[];
    expect(cashier).not.toContain('products.change_price');
    expect(cashier).not.toContain('invoices.cancel');
    expect(cashier).not.toContain('refunds.create');
  });

  it('الكاشير يستطيع البيع وفتح وإغلاق ورديته', () => {
    const cashier = ROLE_PERMISSIONS.CASHIER as string[];
    expect(cashier).toContain('payments.collect');
    expect(cashier).toContain('shifts.open');
    expect(cashier).toContain('shifts.close');
  });

  it('مقدم الطلب لا يستطيع تحصيل المدفوعات', () => {
    const waiter = ROLE_PERMISSIONS.WAITER as string[];
    expect(waiter).not.toContain('payments.collect');
    expect(waiter).toContain('orders.create');
    expect(waiter).toContain('orders.send_to_prep');
  });

  it('مدير الفرع يعتمد الخصومات وفروقات الصندوق', () => {
    const manager = ROLE_PERMISSIONS.BRANCH_MANAGER as string[];
    expect(manager).toContain('discounts.approve');
    expect(manager).toContain('shifts.approve_difference');
    expect(manager).toContain('refunds.create');
  });

  it('مدير الفرع لا يستطيع إعداد الربط مع Odoo', () => {
    expect(ROLE_PERMISSIONS.BRANCH_MANAGER as string[]).not.toContain('odoo.configure');
  });

  it('دوال التحقق تعمل بشكل صحيح', () => {
    const permissions = ['pos.use', 'orders.create'];
    expect(hasPermission(permissions, 'pos.use')).toBe(true);
    expect(hasPermission(permissions, ['pos.use', 'orders.create'])).toBe(true);
    expect(hasPermission(permissions, ['pos.use', 'invoices.cancel'])).toBe(false);
    expect(hasAnyPermission(permissions, ['invoices.cancel', 'pos.use'])).toBe(true);
  });
});

describe('رموز الجلسة', () => {
  it('يوقّع ويتحقق من رمز الدخول', async () => {
    const token = await signAccessToken({
      sub: 'user-1',
      employeeNo: '1003',
      fullName: 'خالد',
      branchId: 'branch-1',
      roles: ['CASHIER'],
      permissions: ['pos.use'],
    });
    const payload = await verifyAccessToken(token);
    expect(payload?.sub).toBe('user-1');
    expect(payload?.permissions).toContain('pos.use');
  });

  it('يرفض الرمز المزيّف', async () => {
    expect(await verifyAccessToken('invalid.token.here')).toBeNull();
  });

  it('يخزن بصمة رمز التحديث وليس الرمز نفسه', () => {
    const bundle = createRefreshToken();
    expect(bundle.tokenHash).not.toBe(bundle.token);
    expect(bundle.tokenHash).toBe(hashRefreshToken(bundle.token));
    expect(bundle.expiresAt.getTime()).toBeGreaterThan(Date.now());
  });
});

describe('تحديد معدل الطلبات', () => {
  beforeEach(() => resetRateLimit());

  it('يسمح بالطلبات ضمن الحد ويمنع ما بعده', () => {
    for (let i = 0; i < 3; i += 1) {
      expect(checkRateLimit('test-key', 3).allowed).toBe(true);
    }
    expect(checkRateLimit('test-key', 3).allowed).toBe(false);
  });

  it('يفصل بين المفاتيح المختلفة', () => {
    checkRateLimit('key-a', 1);
    expect(checkRateLimit('key-b', 1).allowed).toBe(true);
  });
});

describe('سجل التدقيق', () => {
  it('يخفي البيانات الحساسة', () => {
    const clean = sanitize({
      username: 'admin',
      password: 'secret',
      apiKey: 'odoo-key',
      nested: { managerPin: '1111', amount: 50 },
    });
    expect(clean.username).toBe('admin');
    expect(clean.password).toBe('***');
    expect(clean.apiKey).toBe('***');
    expect(clean.nested.managerPin).toBe('***');
    expect(clean.nested.amount).toBe(50);
  });
});

describe('إعادة المحاولة عند فشل الاتصال', () => {
  it('التأخير يتصاعد مع كل محاولة', () => {
    expect(backoffDelayMs(1)).toBe(30_000);
    expect(backoffDelayMs(2)).toBe(120_000);
    expect(backoffDelayMs(3)).toBe(480_000);
    expect(backoffDelayMs(2)).toBeGreaterThan(backoffDelayMs(1));
  });

  it('التأخير لا يتجاوز ساعتين', () => {
    expect(backoffDelayMs(20)).toBe(2 * 60 * 60 * 1000);
  });
});
