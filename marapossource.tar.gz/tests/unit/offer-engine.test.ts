import { describe, expect, it } from 'vitest';
import {
  applyOffers,
  isOfferActiveNow,
  unitMatchesComponent,
  type OfferLine,
  type OfferSpec,
} from '@/lib/pos/offer-engine';
import { calculateOrderTaxes } from '@/lib/pos/tax-engine';

const DRINKS = 'cat-drinks';
const SHISHA = 'cat-shisha';

function drink(id: string, price: number): OfferLine {
  return {
    id,
    productId: `p-${id}`,
    categoryId: DRINKS,
    displayUnitPrice: price,
    quantity: 1,
    unitPrice: price,
    priceIncludesVat: true,
    vatRate: 15,
    isTobacco: false,
  };
}

function shisha(id: string, price: number, quantity = 1): OfferLine {
  return {
    id,
    productId: `p-${id}`,
    categoryId: SHISHA,
    displayUnitPrice: price,
    quantity,
    unitPrice: price,
    priceIncludesVat: true,
    vatRate: 15,
    isTobacco: true,
    tobaccoBase: 'PERCENT_OF_PRICE',
    tobaccoRate: 100,
  };
}

/** عرض: أي مشروب أقل من 22 + أي معسل = 55 */
const OFFER: OfferSpec = {
  id: 'offer-1',
  nameAr: 'مشروب + معسل بـ 55',
  fixedPrice: 55,
  priority: 10,
  maxPerOrder: 0,
  components: [
    {
      id: 'c1',
      nameAr: 'مشروب',
      quantity: 1,
      categoryIds: [DRINKS],
      productIds: [],
      maxUnitPrice: 21.99,
      minUnitPrice: null,
      tobaccoOnly: false,
    },
    {
      id: 'c2',
      nameAr: 'معسل',
      quantity: 1,
      categoryIds: [SHISHA],
      productIds: [],
      maxUnitPrice: null,
      minUnitPrice: null,
      tobaccoOnly: true,
    },
  ],
};

/** يحسب الإجمالي النهائي بعد تطبيق خصومات العرض */
function totalAfterOffers(lines: OfferLine[], offers: OfferSpec[] = [OFFER]) {
  const baseline = calculateOrderTaxes(lines);
  const netByLine = new Map(baseline.lines.map((l) => [l.id, l.netBeforeTax]));
  const applied = applyOffers(lines, offers, netByLine);

  const discountByLine = new Map<string, number>();
  for (const offer of applied) {
    for (const d of offer.lineDiscounts) {
      discountByLine.set(d.lineId, (discountByLine.get(d.lineId) ?? 0) + d.amount);
    }
  }
  const final = calculateOrderTaxes(
    lines.map((l) => ({ ...l, lineDiscount: discountByLine.get(l.id) ?? 0 })),
  );
  return { applied, totals: final.totals };
}

describe('مطابقة شروط مكوّنات العرض', () => {
  const unit = {
    lineId: 'l1',
    productId: 'p1',
    categoryId: DRINKS,
    displayUnitPrice: 20,
    netUnitPrice: 17.39,
    isTobacco: false,
    name: 'كابتشينو',
  };

  it('يطابق المنتج ضمن التصنيف وتحت السقف السعري', () => {
    expect(unitMatchesComponent(unit, OFFER.components[0])).toBe(true);
  });

  it('يرفض المنتج الأغلى من السقف', () => {
    expect(
      unitMatchesComponent({ ...unit, displayUnitPrice: 22 }, OFFER.components[0]),
    ).toBe(false);
  });

  it('يرفض المنتج من تصنيف آخر', () => {
    expect(unitMatchesComponent({ ...unit, categoryId: SHISHA }, OFFER.components[0])).toBe(
      false,
    );
  });

  it('يفرّق بين منتجات التبغ وغيرها', () => {
    expect(unitMatchesComponent({ ...unit, isTobacco: true }, OFFER.components[0])).toBe(
      false,
    );
    expect(
      unitMatchesComponent(
        { ...unit, categoryId: SHISHA, isTobacco: true },
        OFFER.components[1],
      ),
    ).toBe(true);
  });

  it('يحترم قيد المنتجات المحددة', () => {
    const component = { ...OFFER.components[0], productIds: ['p-other'] };
    expect(unitMatchesComponent(unit, component)).toBe(false);
    expect(unitMatchesComponent({ ...unit, productId: 'p-other' }, component)).toBe(true);
  });
});

describe('تسعير الباقة', () => {
  it('يصل بالإجمالي إلى سعر العرض بالضبط', () => {
    const { applied, totals } = totalAfterOffers([drink('d', 20), shisha('s', 60)]);
    expect(applied).toHaveLength(1);
    expect(totals.grandTotal).toBe(55);
  });

  it('يبقي ضريبة التبغ منفصلة عن ضريبة القيمة المضافة', () => {
    const { totals } = totalAfterOffers([drink('d', 20), shisha('s', 60)]);
    expect(totals.tobaccoTaxTotal).toBeGreaterThan(0);
    expect(totals.vatTotal).toBeGreaterThan(0);
    expect(totals.tobaccoTaxTotal).not.toBe(totals.vatTotal);
    // مجموع المكونات يساوي الإجمالي
    expect(
      Math.abs(
        totals.netBeforeTax + totals.tobaccoTaxTotal + totals.vatTotal - totals.grandTotal,
      ),
    ).toBeLessThan(0.005);
  });

  it('لا يطبق العرض إذا لم يكتمل شرط المشروب', () => {
    const { applied, totals } = totalAfterOffers([drink('d', 22), shisha('s', 60)]);
    expect(applied).toHaveLength(0);
    expect(totals.grandTotal).toBeGreaterThan(55);
  });

  it('لا يطبق العرض إذا لم يوجد معسل', () => {
    const { applied } = totalAfterOffers([drink('d', 20), drink('d2', 15)]);
    expect(applied).toHaveLength(0);
  });

  it('لا يرفع السعر عندما تكون الباقة أرخص أصلًا', () => {
    // 12 + 35 = 47 < 55 ⇒ لا خصم ولا زيادة
    const { applied, totals } = totalAfterOffers([drink('d', 12), shisha('s', 35)]);
    expect(applied).toHaveLength(0);
    expect(totals.grandTotal).toBeLessThan(55);
  });

  it('يستهلك الصنف الأغلى لصالح العميل', () => {
    // مياه 5 + كابتشينو 20 + شيشة 60 ⇒ الباقة تأخذ الكابتشينو، وتبقى المياه بسعرها
    const { totals } = totalAfterOffers([
      drink('cheap', 5),
      drink('pricey', 20),
      shisha('s', 60),
    ]);
    expect(totals.grandTotal).toBe(60); // 55 + 5
  });

  it('يطبق باقتين عند توفر مكونات مضاعفة', () => {
    const { applied, totals } = totalAfterOffers([
      drink('d1', 20),
      shisha('s1', 60),
      drink('d2', 12),
      shisha('s2', 65),
    ]);
    expect(applied[0].timesApplied).toBe(2);
    expect(totals.grandTotal).toBe(110);
  });

  it('يحترم حد التكرار في الطلب الواحد', () => {
    const limited: OfferSpec = { ...OFFER, maxPerOrder: 1 };
    const { applied } = totalAfterOffers(
      [drink('d1', 20), shisha('s1', 60), drink('d2', 20), shisha('s2', 60)],
      [limited],
    );
    expect(applied[0].timesApplied).toBe(1);
  });

  it('يتعامل مع الكميات داخل السطر الواحد', () => {
    const lines = [
      { ...drink('d', 20), quantity: 2 },
      shisha('s', 60, 2),
    ];
    const { applied, totals } = totalAfterOffers(lines);
    expect(applied[0].timesApplied).toBe(2);
    expect(totals.grandTotal).toBe(110);
  });

  it('يترك الوحدات الزائدة بسعرها الكامل', () => {
    // 3 مشروبات + شيشة واحدة ⇒ باقة واحدة + مشروبان بسعرهما
    const lines = [{ ...drink('d', 20), quantity: 3 }, shisha('s', 60)];
    const { applied, totals } = totalAfterOffers(lines);
    expect(applied[0].timesApplied).toBe(1);
    expect(totals.grandTotal).toBe(95); // 55 + 20 + 20
  });

  it('يسجل التوفير وتفاصيل الأصناف المشمولة', () => {
    const { applied } = totalAfterOffers([drink('d', 20), shisha('s', 60)]);
    expect(applied[0].savings).toBeGreaterThan(0);
    expect(applied[0].offerTotal).toBe(55);
    expect(applied[0].items).toHaveLength(2);
  });

  it('ينحرف بحد أقصى هللة واحدة عندما يتعذر السعر تمامًا', () => {
    // بعض التركيبات لا يمكن أن تعطي 55.00 بالضبط بسبب تقريب كل سطر لهللتين
    const { totals } = totalAfterOffers([drink('d', 15), shisha('s', 60)]);
    expect(Math.abs(totals.grandTotal - 55)).toBeLessThanOrEqual(0.01);
    // وعند التعذر نرجّح الأقل لصالح العميل
    expect(totals.grandTotal).toBeLessThanOrEqual(55);
  });
});

describe('سريان العرض زمنيًا', () => {
  const base = {
    isActive: true,
    startsAt: null,
    endsAt: null,
    daysOfWeek: [] as number[],
    startTime: null,
    endTime: null,
  };
  // الأحد 2 أغسطس 2026، الساعة 18:00 بتوقيت الرياض
  const sundayEvening = new Date(Date.UTC(2026, 7, 2, 15, 0));

  it('العرض المعطل لا يسري', () => {
    expect(isOfferActiveNow({ ...base, isActive: false }, sundayEvening)).toBe(false);
  });

  it('يسري بلا قيود زمنية', () => {
    expect(isOfferActiveNow(base, sundayEvening)).toBe(true);
  });

  it('يحترم تاريخ البداية والنهاية', () => {
    expect(
      isOfferActiveNow({ ...base, startsAt: new Date(Date.UTC(2026, 8, 1)) }, sundayEvening),
    ).toBe(false);
    expect(
      isOfferActiveNow({ ...base, endsAt: new Date(Date.UTC(2026, 6, 1)) }, sundayEvening),
    ).toBe(false);
  });

  it('يحترم أيام الأسبوع', () => {
    expect(isOfferActiveNow({ ...base, daysOfWeek: [0] }, sundayEvening)).toBe(true);
    expect(isOfferActiveNow({ ...base, daysOfWeek: [1, 2] }, sundayEvening)).toBe(false);
  });

  it('يحترم النافذة الزمنية اليومية', () => {
    expect(
      isOfferActiveNow({ ...base, startTime: '16:00', endTime: '23:00' }, sundayEvening),
    ).toBe(true);
    expect(
      isOfferActiveNow({ ...base, startTime: '06:00', endTime: '12:00' }, sundayEvening),
    ).toBe(false);
  });

  it('يدعم نافذة تعبر منتصف الليل', () => {
    // 20:00 حتى 02:00 — الساعة 18:00 خارجها
    expect(
      isOfferActiveNow({ ...base, startTime: '20:00', endTime: '02:00' }, sundayEvening),
    ).toBe(false);
    // الساعة 01:00 بتوقيت الرياض داخلها
    const afterMidnight = new Date(Date.UTC(2026, 7, 2, 22, 0));
    expect(
      isOfferActiveNow({ ...base, startTime: '20:00', endTime: '02:00' }, afterMidnight),
    ).toBe(true);
  });
});
