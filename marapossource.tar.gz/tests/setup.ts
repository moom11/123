/** تهيئة بيئة الاختبارات */
process.env.JWT_ACCESS_SECRET ??= 'test-access-secret-at-least-32-characters';
process.env.JWT_REFRESH_SECRET ??= 'test-refresh-secret-at-least-32-characters';
process.env.ENCRYPTION_KEY ??=
  '1111111111111111111111111111111111111111111111111111111111111111';
process.env.APP_TIMEZONE ??= 'Asia/Riyadh';
process.env.BUSINESS_DAY_START_HOUR ??= '5';
