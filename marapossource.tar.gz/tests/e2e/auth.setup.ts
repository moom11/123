import { test as setup, expect } from '@playwright/test';
import path from 'node:path';

/**
 * تسجيل دخول مرة واحدة لكل دور وحفظ الجلسة،
 * حتى لا تصطدم الاختبارات بحد محاولات تسجيل الدخول (Rate Limit).
 */
export const AUTH_DIR = path.join(__dirname, '.auth');

const ACCOUNTS = [
  { role: 'admin', id: '1001', password: 'Admin@1234' },
  { role: 'cashier', id: '1003', password: 'Cashier@1234' },
  { role: 'waiter', id: '1004', password: 'Waiter@1234' },
];

for (const account of ACCOUNTS) {
  setup(`تهيئة جلسة ${account.role}`, async ({ page }) => {
    await page.goto('/login');
    await page.getByLabel('رقم الموظف أو البريد الإلكتروني').fill(account.id);
    await page.getByLabel('كلمة المرور').fill(account.password);
    await page.getByRole('button', { name: 'تسجيل الدخول' }).click();
    await page.waitForURL('**/dashboard', { timeout: 30_000 });
    await expect(page.getByText('مبيعات اليوم')).toBeVisible();
    await page.context().storageState({ path: path.join(AUTH_DIR, `${account.role}.json`) });
  });
}
