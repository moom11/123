import { expect, test } from '@playwright/test';
import path from 'node:path';

/**
 * اختبارات شاملة لدورة البيع الأساسية عبر الواجهة.
 * تعتمد على الحسابات التجريبية الناتجة عن `npm run db:seed`،
 * وعلى الجلسات المحفوظة في مشروع «setup».
 */

const AUTH = (role: string) => path.join(__dirname, '.auth', `${role}.json`);

test.describe('تسجيل الدخول', () => {
  // هذه المجموعة تعمل بدون جلسة محفوظة
  test.use({ storageState: { cookies: [], origins: [] } });

  test('يرفض بيانات دخول خاطئة', async ({ page }) => {
    await page.goto('/login');
    await page.getByLabel('رقم الموظف أو البريد الإلكتروني').fill('1003');
    await page.getByLabel('كلمة المرور').fill('wrong-password-here');
    await page.getByRole('button', { name: 'تسجيل الدخول' }).click();
    await expect(page.getByText(/غير صحيحة|تجاوزت عدد الطلبات/)).toBeVisible();
    await expect(page).toHaveURL(/\/login/);
  });

  test('يحوّل الزائر غير المسجل إلى صفحة الدخول', async ({ page }) => {
    await page.goto('/dashboard');
    await page.waitForURL('**/login', { timeout: 20_000 });
  });
});

test.describe('واجهة عربية RTL وصلاحيات الأدوار', () => {
  test('لوحة التحكم تعمل باتجاه RTL', async ({ browser }) => {
    const context = await browser.newContext({ storageState: AUTH('cashier') });
    const page = await context.newPage();
    await page.goto('/dashboard');
    await expect(page.locator('html')).toHaveAttribute('dir', 'rtl');
    await expect(page.locator('html')).toHaveAttribute('lang', 'ar');
    await expect(page.getByText('مبيعات اليوم')).toBeVisible();
    await expect(page.getByText('ضريبة التبغ')).toBeVisible();
    await context.close();
  });

  test('الكاشير لا يرى شاشات الإدارة', async ({ browser }) => {
    const context = await browser.newContext({ storageState: AUTH('cashier') });
    const page = await context.newPage();
    await page.goto('/dashboard');
    await expect(page.getByRole('link', { name: /نقاط البيع/ })).toBeVisible();
    await expect(page.getByRole('link', { name: /سجل التدقيق/ })).toHaveCount(0);
    await expect(page.getByRole('link', { name: /المستخدمون/ })).toHaveCount(0);
    await context.close();
  });

  test('مدير النظام يرى جميع الشاشات', async ({ browser }) => {
    const context = await browser.newContext({ storageState: AUTH('admin') });
    const page = await context.newPage();
    await page.goto('/dashboard');
    await expect(page.getByRole('link', { name: /سجل التدقيق/ })).toBeVisible();
    await expect(page.getByRole('link', { name: /الربط مع Odoo/ })).toBeVisible();
    await expect(page.getByRole('link', { name: /الإعدادات/ })).toBeVisible();
    await context.close();
  });

  test('مقدم الطلب لا يصل لشاشة الصندوق', async ({ browser }) => {
    const context = await browser.newContext({ storageState: AUTH('waiter') });
    const page = await context.newPage();
    await page.goto('/dashboard');
    await expect(page.getByRole('link', { name: /الصندوق والمصروفات/ })).toHaveCount(0);
    await context.close();
  });
});

test.describe('دورة بيع كاملة من شاشة نقاط البيع', () => {
  test.use({ storageState: AUTH('cashier') });

  test('يضيف منتجًا بضغطة واحدة ثم يدفع نقدًا ويصدر الفاتورة', async ({ page }) => {
    await page.goto('/pos');
    await page.getByRole('button', { name: /شاورما عربي/ }).click();
    await expect(page.getByText(/^طلب ORD-/)).toBeVisible({ timeout: 20_000 });

    const payButton = page.getByRole('button', { name: /الدفع \(F4\)/ });
    await expect(payButton).toBeEnabled();
    await payButton.click();

    await expect(page.getByText('المبلغ المطلوب')).toBeVisible();
    await page.getByRole('button', { name: 'نقدي', exact: true }).first().click();
    await page.getByRole('button', { name: /تأكيد الدفع/ }).click();

    // تظهر نافذة الفاتورة الجاهزة للطباعة بمقاس 80 مم
    await expect(page.getByRole('heading', { name: /فاتورة INV-/ })).toBeVisible({
      timeout: 30_000,
    });
    await expect(page.getByText('فاتورة ضريبية مبسطة')).toBeVisible();
    await expect(page.getByRole('button', { name: /طباعة/ })).toBeVisible();
  });

  test('يعرض خيارات المنتج عند وجودها فقط', async ({ page }) => {
    await page.goto('/pos');
    await page.getByRole('button', { name: /كابتشينو/ }).click();
    await expect(page.getByText('نوع الحليب')).toBeVisible();
    await expect(page.getByText('درجة السكر')).toBeVisible();
    await expect(page.getByRole('button', { name: /إضافة —/ })).toBeVisible();
  });

  test('يمنع الدفع إذا لم يكتمل المبلغ', async ({ page }) => {
    await page.goto('/pos');
    await page.getByRole('button', { name: /مياه معدنية/ }).click();
    await expect(page.getByText(/^طلب ORD-/)).toBeVisible({ timeout: 20_000 });

    await page.getByRole('button', { name: /الدفع \(F4\)/ }).click();
    await page.getByRole('button', { name: /دفع مختلط/ }).click();

    const amountInput = page.locator('input[type="number"]').first();
    await amountInput.fill('1');
    await expect(page.getByRole('button', { name: /تأكيد الدفع/ })).toBeDisabled();
    await expect(page.getByText(/متبقٍ/)).toBeVisible();
  });

  test('ضريبة التبغ تظهر منفصلة عن ضريبة القيمة المضافة في السلة', async ({ page }) => {
    await page.goto('/pos');
    await page.getByRole('button', { name: /شيشة تفاحتين/ }).click();
    await expect(page.getByText(/^طلب ORD-/)).toBeVisible({ timeout: 20_000 });
    await expect(page.getByText('ضريبة التبغ')).toBeVisible();
    await expect(page.getByText('ضريبة القيمة المضافة')).toBeVisible();
    await expect(page.getByText('الإجمالي النهائي')).toBeVisible();
  });

  test('يعلّق الطلب ثم يسترجعه', async ({ page }) => {
    await page.goto('/pos');
    await page.getByRole('button', { name: /شاي أخضر/ }).click();
    await expect(page.getByText(/^طلب ORD-/)).toBeVisible({ timeout: 20_000 });

    await page.getByRole('button', { name: /تعليق \(F8\)/ }).click();
    await expect(page.getByText('تم تعليق الطلب')).toBeVisible({ timeout: 15_000 });

    await page.getByTitle('الطلبات المعلقة').click();
    await expect(page.getByText('الطلبات المعلقة')).toBeVisible();
    await page.getByRole('button', { name: 'استرجاع' }).first().click();
    await expect(page.getByText(/^طلب ORD-/)).toBeVisible();
  });
});

test.describe('الطاولات والورديات', () => {
  test.use({ storageState: AUTH('cashier') });

  test('تعرض شاشة الطاولات الحالات بألوان واضحة', async ({ page }) => {
    await page.goto('/tables');
    await expect(page.getByText('الدور الأرضي')).toBeVisible({ timeout: 20_000 });
    await expect(page.getByText('متاحة').first()).toBeVisible();
  });

  test('تعرض شاشة الورديات النقد المتوقع', async ({ page }) => {
    await page.goto('/shifts');
    await expect(page.getByText('الوردية الحالية')).toBeVisible({ timeout: 20_000 });
    await expect(page.getByText('النقد المتوقع').first()).toBeVisible();
    await expect(page.getByText('سجل الورديات')).toBeVisible();
  });
});

test.describe('التقارير والربط مع Odoo', () => {
  test.use({ storageState: AUTH('admin') });

  test('التقارير تفصل الضريبتين وتتيح التصدير', async ({ page }) => {
    await page.goto('/reports');
    await expect(page.getByText('ضريبة القيمة المضافة')).toBeVisible({ timeout: 20_000 });
    await expect(page.getByText('ضريبة التبغ')).toBeVisible();
    await expect(page.getByRole('button', { name: /Excel/ })).toBeVisible();
    await expect(page.getByRole('button', { name: /CSV/ })).toBeVisible();
    await expect(page.getByRole('button', { name: /PDF \/ طباعة/ })).toBeVisible();
  });

  test('شاشة المزامنة تعرض الحالات وأزرار إعادة الإرسال', async ({ page }) => {
    await page.goto('/odoo');
    await expect(page.getByText('حالة الربط مع Odoo')).toBeVisible({ timeout: 20_000 });
    await expect(page.getByText('سجل عمليات المزامنة')).toBeVisible();
    await expect(page.getByRole('button', { name: /إعادة مزامنة الفاشلة/ })).toBeVisible();
  });

  test('سجل التدقيق يعرض العمليات الحساسة', async ({ page }) => {
    await page.goto('/audit');
    await expect(page.locator('select')).toBeVisible({ timeout: 20_000 });
    await expect(page.getByText('التاريخ والوقت')).toBeVisible();
  });
});
