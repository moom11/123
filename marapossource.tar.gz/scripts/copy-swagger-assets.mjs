// ينسخ ملفات Swagger UI الثابتة إلى مجلد public ليعمل التوثيق بدون إنترنت
import { cp, mkdir, access } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const src = join(root, 'node_modules', 'swagger-ui-dist');
const dest = join(root, 'public', 'swagger');

const FILES = [
  'swagger-ui.css',
  'swagger-ui-bundle.js',
  'swagger-ui-standalone-preset.js',
  'favicon-32x32.png',
];

try {
  await access(src);
} catch {
  console.warn('[swagger] swagger-ui-dist غير مثبت — تم تخطي نسخ الملفات.');
  process.exit(0);
}

await mkdir(dest, { recursive: true });
for (const file of FILES) {
  try {
    await cp(join(src, file), join(dest, file));
  } catch (err) {
    console.warn(`[swagger] تعذر نسخ ${file}: ${err.message}`);
  }
}
console.log('[swagger] تم تجهيز ملفات التوثيق في public/swagger');
