/**
 * Service Worker — دعم العمل عند انقطاع الإنترنت (PWA).
 *
 * الاستراتيجية:
 *  - أصول التطبيق: Cache First مع تحديث في الخلفية.
 *  - طلبات القراءة من الـ API: Network First مع الرجوع إلى النسخة المخزنة.
 *  - طلبات الكتابة: لا تُخزَّن هنا — يتكفل بها طابور IndexedDB في التطبيق
 *    (كل عملية تحمل UUID فريدًا يمنع تكرارها على الخادم).
 */

const CACHE_VERSION = 'mara-pos-v1';
const APP_SHELL = ['/', '/pos', '/dashboard', '/manifest.webmanifest', '/icon.svg'];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(CACHE_VERSION)
      .then((cache) => cache.addAll(APP_SHELL).catch(() => undefined))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(keys.filter((key) => key !== CACHE_VERSION).map((key) => caches.delete(key))),
      )
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  // بيانات القراءة: الشبكة أولًا ثم الذاكرة المؤقتة
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const clone = response.clone();
          caches.open(CACHE_VERSION).then((cache) => cache.put(request, clone));
          return response;
        })
        .catch(() => caches.match(request).then((cached) => cached ?? offlineJson())),
    );
    return;
  }

  // الأصول: الذاكرة المؤقتة أولًا
  event.respondWith(
    caches.match(request).then((cached) => {
      const network = fetch(request)
        .then((response) => {
          const clone = response.clone();
          caches.open(CACHE_VERSION).then((cache) => cache.put(request, clone));
          return response;
        })
        .catch(() => cached);
      return cached ?? network;
    }),
  );
});

function offlineJson() {
  return new Response(
    JSON.stringify({
      success: false,
      error: { code: 'OFFLINE', message: 'لا يوجد اتصال بالخادم — يتم العمل دون اتصال' },
    }),
    { status: 503, headers: { 'Content-Type': 'application/json' } },
  );
}
