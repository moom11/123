/**
 * =============================================================================
 * استيراد المنيو من ملف JSON
 * =============================================================================
 * تشغيل:  npm run menu:import
 *         npm run menu:import -- --deactivate-old   (لتعطيل المنتجات السابقة)
 *
 * الملف المصدر: prisma/data/menu.json — عدّله ثم أعد التشغيل لتحديث الأسعار.
 * الاستيراد يعمل بالـ upsert على كود المنتج (SKU)، فتكراره آمن ولا ينشئ نسخًا مكررة.
 *
 * المنتجات القديمة لا تُحذف أبدًا (حفاظًا على سجل الفواتير) — تُعطَّل فقط عند الطلب.
 */
import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { PrepStation, PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

interface MenuCategory {
  nameAr: string;
  iconEmoji: string;
  color: string;
  sortOrder: number;
}

interface MenuProduct {
  sku: string;
  nameAr: string;
  category: string;
  price: number;
  prepStation: keyof typeof PrepStation;
  isTobacco: boolean;
  unit: string;
  sourceSection?: string;
  sourcePage?: number;
}

interface MenuFile {
  meta: { pricesIncludeVat: boolean; note?: string };
  categories: MenuCategory[];
  products: MenuProduct[];
}

async function main() {
  const deactivateOld = process.argv.includes('--deactivate-old');
  const branchCode = process.env.BRANCH_CODE ?? 'MARA-01';

  const file = join(process.cwd(), 'prisma', 'data', 'menu.json');
  if (!existsSync(file)) {
    throw new Error(
      `ملف المنيو غير موجود: ${file}\n` +
        'أنشئه بصيغة { meta, categories, products } — راجع الواجهات في أعلى هذا الملف.',
    );
  }
  const menu = JSON.parse(readFileSync(file, 'utf8')) as MenuFile;

  const branch = await prisma.branch.findUnique({ where: { code: branchCode } });
  if (!branch) {
    throw new Error(`الفرع بالكود ${branchCode} غير موجود — شغّل npm run db:seed أولًا`);
  }

  const vat = await prisma.tax.findFirst({
    where: { type: 'VAT', isDefault: true, isActive: true },
  });
  const tobacco = await prisma.tax.findFirst({
    where: { type: 'TOBACCO', isActive: true },
    orderBy: { isDefault: 'desc' },
  });

  if (!vat) throw new Error('لا توجد ضريبة قيمة مضافة افتراضية — شغّل npm run db:seed أولًا');
  if (!tobacco) console.warn('⚠ لا توجد ضريبة تبغ مفعّلة — منتجات الشيشة ستُستورد بدونها');

  console.log(`\n📥 استيراد المنيو إلى فرع «${branch.nameAr}»`);
  console.log(
    `   الأسعار ${menu.meta.pricesIncludeVat ? 'شاملة' : 'غير شاملة'} ضريبة القيمة المضافة\n`,
  );

  // ---------------------------------------------------------------------------
  // التصنيفات
  // ---------------------------------------------------------------------------
  const categoryIds = new Map<string, string>();
  for (const category of menu.categories) {
    const existing = await prisma.category.findFirst({
      where: { branchId: branch.id, nameAr: category.nameAr },
    });
    const saved = existing
      ? await prisma.category.update({
          where: { id: existing.id },
          data: {
            color: category.color,
            iconEmoji: category.iconEmoji,
            sortOrder: category.sortOrder,
            isActive: true,
          },
        })
      : await prisma.category.create({
          data: {
            branchId: branch.id,
            nameAr: category.nameAr,
            color: category.color,
            iconEmoji: category.iconEmoji,
            sortOrder: category.sortOrder,
          },
        });
    categoryIds.set(category.nameAr, saved.id);
  }
  console.log(`   ✓ ${menu.categories.length} تصنيفًا`);

  // ---------------------------------------------------------------------------
  // المنتجات
  // ---------------------------------------------------------------------------
  const importedSkus: string[] = [];
  let created = 0;
  let updated = 0;

  for (const [index, product] of menu.products.entries()) {
    const categoryId = categoryIds.get(product.category);
    if (!categoryId) {
      console.warn(`   ⚠ تخطي ${product.nameAr}: التصنيف «${product.category}» غير معرّف`);
      continue;
    }

    const data = {
      categoryId,
      nameAr: product.nameAr,
      price: product.price,
      priceIncludesVat: menu.meta.pricesIncludeVat,
      vatTaxId: vat.id,
      isTobacco: product.isTobacco,
      tobaccoTaxId: product.isTobacco ? (tobacco?.id ?? null) : null,
      unit: product.unit,
      prepStation: PrepStation[product.prepStation],
      sortOrder: index,
      isActive: true,
      showInPos: true,
    };

    const existing = await prisma.product.findUnique({
      where: { branchId_sku: { branchId: branch.id, sku: product.sku } },
    });

    if (existing) {
      await prisma.product.update({ where: { id: existing.id }, data });
      updated += 1;
    } else {
      await prisma.product.create({ data: { ...data, branchId: branch.id, sku: product.sku } });
      created += 1;
    }
    importedSkus.push(product.sku);
  }

  console.log(`   ✓ ${created} منتجًا جديدًا · ${updated} منتجًا محدّثًا`);

  // ---------------------------------------------------------------------------
  // تعطيل المنتجات القديمة (اختياري) — لا تُحذف حفاظًا على سجل الفواتير
  // ---------------------------------------------------------------------------
  if (deactivateOld) {
    const result = await prisma.product.updateMany({
      where: { branchId: branch.id, sku: { notIn: importedSkus }, isActive: true },
      data: { isActive: false, showInPos: false },
    });
    if (result.count > 0) {
      console.log(
        `   ✓ عُطّل ${result.count} منتجًا لا ينتمي للمنيو (لم يُحذف — سجل الفواتير محفوظ)`,
      );
    }
  }

  // ---------------------------------------------------------------------------
  // ملخص
  // ---------------------------------------------------------------------------
  const tobaccoCount = menu.products.filter((p) => p.isTobacco).length;
  console.log('\n📊 الملخص:');
  for (const category of menu.categories) {
    const count = menu.products.filter((p) => p.category === category.nameAr).length;
    console.log(`   ${category.iconEmoji} ${category.nameAr.padEnd(22)} ${count}`);
  }
  console.log(`\n   منتجات خاضعة لضريبة التبغ: ${tobaccoCount}`);
  if (menu.meta.note) console.log(`\n   ℹ ${menu.meta.note}`);
  console.log();
}

main()
  .then(() => prisma.$disconnect())
  .catch(async (error) => {
    console.error('❌ فشل الاستيراد:', error);
    await prisma.$disconnect();
    process.exit(1);
  });
