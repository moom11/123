-- CreateEnum
CREATE TYPE "OfferType" AS ENUM ('COMBO_FIXED_PRICE');

-- AlterEnum
ALTER TYPE "DiscountType" ADD VALUE 'OFFER';

-- AlterTable
ALTER TABLE "discounts" ADD COLUMN     "offer_id" TEXT;

-- AlterTable
ALTER TABLE "orders" ADD COLUMN     "dismissed_offer_ids" TEXT[];

-- CreateTable
CREATE TABLE "offers" (
    "id" TEXT NOT NULL,
    "branch_id" TEXT NOT NULL,
    "name_ar" TEXT NOT NULL,
    "name_en" TEXT,
    "description" TEXT,
    "type" "OfferType" NOT NULL DEFAULT 'COMBO_FIXED_PRICE',
    "fixed_price" DECIMAL(12,4) NOT NULL,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "priority" INTEGER NOT NULL DEFAULT 0,
    "starts_at" TIMESTAMP(3),
    "ends_at" TIMESTAMP(3),
    "days_of_week" INTEGER[],
    "start_time" TEXT,
    "end_time" TEXT,
    "max_per_order" INTEGER NOT NULL DEFAULT 0,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "offers_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "offer_components" (
    "id" TEXT NOT NULL,
    "offer_id" TEXT NOT NULL,
    "name_ar" TEXT NOT NULL,
    "quantity" INTEGER NOT NULL DEFAULT 1,
    "category_ids" TEXT[],
    "product_ids" TEXT[],
    "max_unit_price" DECIMAL(12,4),
    "min_unit_price" DECIMAL(12,4),
    "tobacco_only" BOOLEAN,
    "sort_order" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "offer_components_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "offers_branch_id_is_active_idx" ON "offers"("branch_id", "is_active");

-- CreateIndex
CREATE INDEX "offer_components_offer_id_idx" ON "offer_components"("offer_id");

-- CreateIndex
CREATE INDEX "discounts_offer_id_idx" ON "discounts"("offer_id");

-- AddForeignKey
ALTER TABLE "offers" ADD CONSTRAINT "offers_branch_id_fkey" FOREIGN KEY ("branch_id") REFERENCES "branches"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "offer_components" ADD CONSTRAINT "offer_components_offer_id_fkey" FOREIGN KEY ("offer_id") REFERENCES "offers"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "discounts" ADD CONSTRAINT "discounts_offer_id_fkey" FOREIGN KEY ("offer_id") REFERENCES "offers"("id") ON DELETE SET NULL ON UPDATE CASCADE;
