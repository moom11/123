-- رقم المرتجع يُولَّد بتسلسل مستقل لكل فرع، لذا يجب أن يكون التفرد مركبًا
-- مع الفرع بدلًا من التفرد العام (وإلا تتعارض الأرقام عند إضافة فروع جديدة).

-- 1) إضافة العمود كاختياري أولًا
ALTER TABLE "refunds" ADD COLUMN "branch_id" TEXT;

-- 2) تعبئة البيانات القائمة من فرع الفاتورة المرتبطة
UPDATE "refunds" r
SET "branch_id" = i."branch_id"
FROM "invoices" i
WHERE r."invoice_id" = i."id" AND r."branch_id" IS NULL;

-- 3) جعل العمود إلزاميًا بعد التعبئة
ALTER TABLE "refunds" ALTER COLUMN "branch_id" SET NOT NULL;

-- 4) استبدال التفرد العام بتفرد مركب مع الفرع
DROP INDEX IF EXISTS "refunds_refund_number_key";
CREATE UNIQUE INDEX "refunds_branch_id_refund_number_key"
  ON "refunds"("branch_id", "refund_number");

-- 5) ربط المفتاح الأجنبي
ALTER TABLE "refunds" ADD CONSTRAINT "refunds_branch_id_fkey"
  FOREIGN KEY ("branch_id") REFERENCES "branches"("id")
  ON DELETE RESTRICT ON UPDATE CASCADE;
