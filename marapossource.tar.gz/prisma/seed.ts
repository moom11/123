/**
 * =============================================================================
 * البيانات التجريبية — مارا لاونج
 * =============================================================================
 * تشغيل: npm run db:seed
 *
 * ينشئ: شركة وفرعًا واحدًا، الأدوار والصلاحيات، أربعة مستخدمين تجريبيين،
 * الضرائب، طرق الدفع، الأدوار والمناطق والطاولات، التصنيفات والمنتجات،
 * وردية مفتوحة، ومجموعة فواتير تجريبية.
 */
import {
  CashMovementType,
  PaymentMethodType,
  PrepStation,
  PrismaClient,
  RoleCode,
  TableStatus,
  TaxType,
  TobaccoTaxBase,
} from '@prisma/client';
import bcrypt from 'bcryptjs';
import { PERMISSIONS, ROLE_LABELS, ROLE_PERMISSIONS } from '../src/lib/auth/permissions';
import { getBusinessDay } from '../src/lib/business-day';

const prisma = new PrismaClient();

const hash = (value: string) => bcrypt.hashSync(value, 10);

async function main() {
  console.log('🌱 بدء زراعة البيانات التجريبية...');

  // ---------------------------------------------------------------------------
  // 1) الصلاحيات والأدوار
  // ---------------------------------------------------------------------------
  for (const [code, meta] of Object.entries(PERMISSIONS)) {
    await prisma.permission.upsert({
      where: { code },
      create: { code, nameAr: meta.nameAr, group: meta.group },
      update: { nameAr: meta.nameAr, group: meta.group },
    });
  }
  console.log(`   ✓ ${Object.keys(PERMISSIONS).length} صلاحية`);

  const allPermissions = await prisma.permission.findMany();
  const permissionByCode = new Map(allPermissions.map((p) => [p.code, p.id]));

  for (const roleCode of Object.keys(ROLE_PERMISSIONS) as RoleCode[]) {
    const role = await prisma.role.upsert({
      where: { code: roleCode },
      create: { code: roleCode, nameAr: ROLE_LABELS[roleCode] },
      update: { nameAr: ROLE_LABELS[roleCode] },
    });
    await prisma.rolePermission.deleteMany({ where: { roleId: role.id } });
    await prisma.rolePermission.createMany({
      data: ROLE_PERMISSIONS[roleCode]
        .map((code) => permissionByCode.get(code))
        .filter((id): id is string => Boolean(id))
        .map((permissionId) => ({ roleId: role.id, permissionId })),
      skipDuplicates: true,
    });
  }
  console.log('   ✓ 4 أدوار وظيفية مع صلاحياتها');

  // ---------------------------------------------------------------------------
  // 2) الشركة والفرع
  // ---------------------------------------------------------------------------
  const company = await prisma.company.upsert({
    where: { id: '00000000-0000-4000-8000-000000000001' },
    create: {
      id: '00000000-0000-4000-8000-000000000001',
      nameAr: 'مؤسسة مارا للضيافة',
      nameEn: 'Mara Hospitality',
      vatNumber: '300000000000003',
      crNumber: '1010101010',
      phone: '+966500000000',
      address: 'الرياض، المملكة العربية السعودية',
      currency: 'SAR',
      timezone: 'Asia/Riyadh',
    },
    update: {},
  });

  const branch = await prisma.branch.upsert({
    where: { code: 'MARA-01' },
    create: {
      companyId: company.id,
      code: 'MARA-01',
      nameAr: 'مارا لاونج',
      nameEn: 'Mara Lounge',
      phone: '+966510000000',
      address: 'الرياض — حي الملقا',
    },
    update: {},
  });

  await prisma.branchSetting.upsert({
    where: { branchId: branch.id },
    create: {
      branchId: branch.id,
      businessDayStartHour: 5,
      timezone: 'Asia/Riyadh',
      paymentRoundingTolerance: 0.05,
      cashDiffTolerance: 0,
      enableDelivery: false,
      enableCreditPayment: false,
      maxDiscountPercent: 50,
      requireManagerForDiscount: true,
      primaryColor: '#C8102E',
      secondaryColor: '#111111',
    },
    update: {},
  });
  console.log('   ✓ الشركة والفرع «مارا لاونج»');

  const device = await prisma.device.upsert({
    where: { branchId_code: { branchId: branch.id, code: 'POS-01' } },
    create: { branchId: branch.id, code: 'POS-01', name: 'كاشير الصالة الرئيسية' },
    update: {},
  });

  // ---------------------------------------------------------------------------
  // 3) المستخدمون
  // ---------------------------------------------------------------------------
  const roles = await prisma.role.findMany();
  const roleByCode = new Map(roles.map((r) => [r.code, r.id]));

  const usersSeed = [
    {
      employeeNo: '1001',
      email: 'admin@mara.local',
      fullName: 'عبدالله المدير',
      password: process.env.SEED_ADMIN_PASSWORD ?? 'Admin@1234',
      role: RoleCode.SYSTEM_ADMIN,
      pin: '1111',
    },
    {
      employeeNo: '1002',
      email: 'manager@mara.local',
      fullName: 'سارة مديرة الفرع',
      password: process.env.SEED_MANAGER_PASSWORD ?? 'Manager@1234',
      role: RoleCode.BRANCH_MANAGER,
      pin: '2222',
    },
    {
      employeeNo: '1003',
      email: 'cashier@mara.local',
      fullName: 'خالد الكاشير',
      password: process.env.SEED_CASHIER_PASSWORD ?? 'Cashier@1234',
      role: RoleCode.CASHIER,
      pin: null,
    },
    {
      employeeNo: '1004',
      email: 'waiter@mara.local',
      fullName: 'فهد مقدم الطلبات',
      password: process.env.SEED_WAITER_PASSWORD ?? 'Waiter@1234',
      role: RoleCode.WAITER,
      pin: null,
    },
  ];

  const createdUsers = new Map<RoleCode, string>();
  for (const seed of usersSeed) {
    const user = await prisma.user.upsert({
      where: { employeeNo: seed.employeeNo },
      create: {
        branchId: branch.id,
        employeeNo: seed.employeeNo,
        email: seed.email,
        fullName: seed.fullName,
        passwordHash: hash(seed.password),
        managerPinHash: seed.pin ? hash(seed.pin) : null,
      },
      update: {
        passwordHash: hash(seed.password),
        managerPinHash: seed.pin ? hash(seed.pin) : null,
      },
    });
    const roleId = roleByCode.get(seed.role)!;
    await prisma.userRole.upsert({
      where: { userId_roleId: { userId: user.id, roleId } },
      create: { userId: user.id, roleId },
      update: {},
    });
    createdUsers.set(seed.role, user.id);
  }
  console.log('   ✓ 4 مستخدمين تجريبيين');

  // ---------------------------------------------------------------------------
  // 4) الضرائب
  // ---------------------------------------------------------------------------
  const vat = await prisma.tax.upsert({
    where: { code: 'VAT15' },
    create: {
      code: 'VAT15',
      nameAr: 'ضريبة القيمة المضافة',
      nameEn: 'VAT',
      type: TaxType.VAT,
      rate: 15,
      isDefault: true,
    },
    update: { rate: 15, isDefault: true },
  });

  const tobaccoTax = await prisma.tax.upsert({
    where: { code: 'TOBACCO100' },
    create: {
      code: 'TOBACCO100',
      nameAr: 'ضريبة التبغ (الانتقائية)',
      nameEn: 'Tobacco Excise Tax',
      type: TaxType.TOBACCO,
      rate: 100,
      tobaccoBase: TobaccoTaxBase.PERCENT_OF_PRICE,
      minAmountPerUnit: 0,
      isDefault: true,
    },
    update: { rate: 100, tobaccoBase: TobaccoTaxBase.PERCENT_OF_PRICE },
  });
  console.log('   ✓ ضريبة القيمة المضافة 15% وضريبة التبغ');

  // ---------------------------------------------------------------------------
  // 5) طرق الدفع
  // ---------------------------------------------------------------------------
  const paymentMethodsSeed = [
    { code: 'CASH', nameAr: 'نقدي', type: PaymentMethodType.CASH, cash: true, drawer: true, active: true },
    { code: 'MADA', nameAr: 'شبكة مدى', type: PaymentMethodType.MADA, cash: false, drawer: false, active: true },
    { code: 'VISA', nameAr: 'فيزا', type: PaymentMethodType.VISA, cash: false, drawer: false, active: true },
    { code: 'MASTERCARD', nameAr: 'ماستركارد', type: PaymentMethodType.MASTERCARD, cash: false, drawer: false, active: true },
    { code: 'APPLE_PAY', nameAr: 'Apple Pay', type: PaymentMethodType.APPLE_PAY, cash: false, drawer: false, active: true },
    { code: 'BANK_TRANSFER', nameAr: 'تحويل بنكي', type: PaymentMethodType.BANK_TRANSFER, cash: false, drawer: false, active: true },
    { code: 'CREDIT', nameAr: 'آجل', type: PaymentMethodType.CREDIT, cash: false, drawer: false, active: false },
  ];

  const methodByCode = new Map<string, string>();
  for (const [index, seed] of paymentMethodsSeed.entries()) {
    const method = await prisma.paymentMethod.upsert({
      where: { code: seed.code },
      create: {
        code: seed.code,
        nameAr: seed.nameAr,
        type: seed.type,
        affectsCashDrawer: seed.cash,
        opensDrawer: seed.drawer,
        isActive: seed.active,
        sortOrder: index,
      },
      update: { isActive: seed.active, affectsCashDrawer: seed.cash },
    });
    methodByCode.set(seed.code, method.id);
  }
  console.log('   ✓ 7 طرق دفع (الآجل معطل افتراضيًا)');

  // ---------------------------------------------------------------------------
  // 6) الأدوار والمناطق والطاولات
  // ---------------------------------------------------------------------------
  const floorsSeed = [
    { nameAr: 'الدور الأرضي', areas: ['الصالة الداخلية', 'التراس'] },
    { nameAr: 'الدور الأول', areas: ['الجلسات العائلية'] },
  ];

  let tableCounter = 1;
  for (const [floorIndex, floorSeed] of floorsSeed.entries()) {
    const existingFloor = await prisma.floor.findFirst({
      where: { branchId: branch.id, nameAr: floorSeed.nameAr },
    });
    const floor =
      existingFloor ??
      (await prisma.floor.create({
        data: { branchId: branch.id, nameAr: floorSeed.nameAr, sortOrder: floorIndex },
      }));

    for (const [areaIndex, areaName] of floorSeed.areas.entries()) {
      const existingArea = await prisma.area.findFirst({
        where: { floorId: floor.id, nameAr: areaName },
      });
      const area =
        existingArea ??
        (await prisma.area.create({
          data: { floorId: floor.id, nameAr: areaName, sortOrder: areaIndex },
        }));

      for (let i = 0; i < 5; i += 1) {
        const number = String(tableCounter).padStart(2, '0');
        tableCounter += 1;
        await prisma.restaurantTable.upsert({
          where: { branchId_number: { branchId: branch.id, number } },
          create: {
            branchId: branch.id,
            floorId: floor.id,
            areaId: area.id,
            number,
            nameAr: `طاولة ${number}`,
            seats: i % 2 === 0 ? 4 : 6,
            status: TableStatus.AVAILABLE,
            posX: (i % 3) * 120,
            posY: Math.floor(i / 3) * 120,
          },
          update: {},
        });
      }
    }
  }
  console.log(`   ✓ ${tableCounter - 1} طاولة موزعة على دورين`);

  // ---------------------------------------------------------------------------
  // 7) التصنيفات والمنتجات
  // ---------------------------------------------------------------------------
  const categoriesSeed = [
    { nameAr: 'أطعمة', color: '#C8102E', emoji: '🍽️', station: PrepStation.KITCHEN },
    { nameAr: 'مشروبات ساخنة', color: '#8B5E34', emoji: '☕', station: PrepStation.BAR },
    { nameAr: 'مشروبات باردة', color: '#2563EB', emoji: '🥤', station: PrepStation.BAR },
    { nameAr: 'حلويات', color: '#DB2777', emoji: '🍰', station: PrepStation.KITCHEN },
    { nameAr: 'شيشة', color: '#111111', emoji: '💨', station: PrepStation.SHISHA },
  ];

  const categoryByName = new Map<string, string>();
  for (const [index, seed] of categoriesSeed.entries()) {
    const existing = await prisma.category.findFirst({
      where: { branchId: branch.id, nameAr: seed.nameAr },
    });
    const category =
      existing ??
      (await prisma.category.create({
        data: {
          branchId: branch.id,
          nameAr: seed.nameAr,
          color: seed.color,
          iconEmoji: seed.emoji,
          sortOrder: index,
        },
      }));
    categoryByName.set(seed.nameAr, category.id);
  }

  interface ProductSeed {
    sku: string;
    nameAr: string;
    nameEn?: string;
    category: string;
    price: number;
    station: PrepStation;
    isTobacco?: boolean;
    unit?: string;
    variants?: { nameAr: string; delta: number; isDefault?: boolean }[];
    modifierGroups?: {
      nameAr: string;
      selectionType: 'SINGLE' | 'MULTIPLE';
      required?: boolean;
      maxSelect?: number;
      options: { nameAr: string; delta: number; isDefault?: boolean }[];
    }[];
  }

  const productsSeed: ProductSeed[] = [
    {
      sku: 'DEMO-F-001',
      nameAr: 'برجر لحم مشوي',
      nameEn: 'Grilled Beef Burger',
      category: 'أطعمة',
      price: 45,
      station: PrepStation.KITCHEN,
      modifierGroups: [
        {
          nameAr: 'الإضافات',
          selectionType: 'MULTIPLE',
          maxSelect: 4,
          options: [
            { nameAr: 'جبن شيدر', delta: 5 },
            { nameAr: 'بيكن بقري', delta: 8 },
            { nameAr: 'صوص حار', delta: 2 },
            { nameAr: 'بيض', delta: 4 },
          ],
        },
      ],
    },
    {
      sku: 'DEMO-F-002',
      nameAr: 'شاورما عربي',
      category: 'أطعمة',
      price: 28,
      station: PrepStation.KITCHEN,
    },
    {
      sku: 'DEMO-F-003',
      nameAr: 'سلطة سيزر بالدجاج',
      category: 'أطعمة',
      price: 38,
      station: PrepStation.KITCHEN,
    },
    {
      sku: 'DEMO-F-004',
      nameAr: 'بطاطس مقلية',
      category: 'أطعمة',
      price: 18,
      station: PrepStation.KITCHEN,
      variants: [
        { nameAr: 'وسط', delta: 0, isDefault: true },
        { nameAr: 'كبير', delta: 7 },
      ],
    },
    {
      sku: 'DEMO-H-001',
      nameAr: 'قهوة عربية',
      category: 'مشروبات ساخنة',
      price: 15,
      station: PrepStation.BAR,
      variants: [
        { nameAr: 'فنجان', delta: 0, isDefault: true },
        { nameAr: 'دلة صغيرة', delta: 20 },
      ],
    },
    {
      sku: 'DEMO-H-002',
      nameAr: 'كابتشينو',
      nameEn: 'Cappuccino',
      category: 'مشروبات ساخنة',
      price: 20,
      station: PrepStation.BAR,
      variants: [
        { nameAr: 'صغير', delta: -3 },
        { nameAr: 'وسط', delta: 0, isDefault: true },
        { nameAr: 'كبير', delta: 5 },
      ],
      modifierGroups: [
        {
          nameAr: 'نوع الحليب',
          selectionType: 'SINGLE',
          required: true,
          options: [
            { nameAr: 'حليب كامل الدسم', delta: 0, isDefault: true },
            { nameAr: 'حليب قليل الدسم', delta: 0 },
            { nameAr: 'حليب لوز', delta: 4 },
          ],
        },
        {
          nameAr: 'درجة السكر',
          selectionType: 'SINGLE',
          required: false,
          options: [
            { nameAr: 'بدون سكر', delta: 0, isDefault: true },
            { nameAr: 'سكر خفيف', delta: 0 },
            { nameAr: 'سكر عادي', delta: 0 },
          ],
        },
        {
          nameAr: 'النكهة',
          selectionType: 'MULTIPLE',
          maxSelect: 2,
          options: [
            { nameAr: 'فانيلا', delta: 3 },
            { nameAr: 'كراميل', delta: 3 },
            { nameAr: 'بندق', delta: 3 },
          ],
        },
      ],
    },
    {
      sku: 'DEMO-H-003',
      nameAr: 'شاي أخضر',
      category: 'مشروبات ساخنة',
      price: 12,
      station: PrepStation.BAR,
    },
    {
      sku: 'DEMO-C-001',
      nameAr: 'آيس لاتيه',
      category: 'مشروبات باردة',
      price: 24,
      station: PrepStation.BAR,
    },
    {
      sku: 'DEMO-C-002',
      nameAr: 'عصير برتقال طازج',
      category: 'مشروبات باردة',
      price: 22,
      station: PrepStation.BAR,
    },
    {
      sku: 'DEMO-C-003',
      nameAr: 'مياه معدنية',
      category: 'مشروبات باردة',
      price: 5,
      station: PrepStation.BAR,
    },
    {
      sku: 'DEMO-D-001',
      nameAr: 'تشيز كيك',
      category: 'حلويات',
      price: 26,
      station: PrepStation.KITCHEN,
    },
    {
      sku: 'DEMO-D-002',
      nameAr: 'كنافة بالقشطة',
      category: 'حلويات',
      price: 32,
      station: PrepStation.KITCHEN,
    },
    {
      sku: 'DEMO-S-001',
      nameAr: 'شيشة تفاحتين',
      category: 'شيشة',
      price: 60,
      station: PrepStation.SHISHA,
      isTobacco: true,
      unit: 'HEAD',
    },
    {
      sku: 'DEMO-S-002',
      nameAr: 'شيشة عنب نعناع',
      category: 'شيشة',
      price: 65,
      station: PrepStation.SHISHA,
      isTobacco: true,
      unit: 'HEAD',
    },
    {
      sku: 'DEMO-S-003',
      nameAr: 'تغيير رأس معسل',
      category: 'شيشة',
      price: 35,
      station: PrepStation.SHISHA,
      isTobacco: true,
      unit: 'HEAD',
    },
  ];

  for (const [index, seed] of productsSeed.entries()) {
    const product = await prisma.product.upsert({
      where: { branchId_sku: { branchId: branch.id, sku: seed.sku } },
      create: {
        branchId: branch.id,
        categoryId: categoryByName.get(seed.category)!,
        nameAr: seed.nameAr,
        nameEn: seed.nameEn ?? null,
        sku: seed.sku,
        price: seed.price,
        priceIncludesVat: true,
        vatTaxId: vat.id,
        isTobacco: Boolean(seed.isTobacco),
        tobaccoTaxId: seed.isTobacco ? tobaccoTax.id : null,
        unit: seed.unit ?? 'PCS',
        prepStation: seed.station,
        sortOrder: index,
      },
      update: { price: seed.price, vatTaxId: vat.id },
    });

    for (const [vIndex, variant] of (seed.variants ?? []).entries()) {
      const existing = await prisma.productVariant.findFirst({
        where: { productId: product.id, nameAr: variant.nameAr },
      });
      if (!existing) {
        await prisma.productVariant.create({
          data: {
            productId: product.id,
            nameAr: variant.nameAr,
            priceDelta: variant.delta,
            isDefault: variant.isDefault ?? false,
            sortOrder: vIndex,
          },
        });
      }
    }

    for (const [gIndex, group] of (seed.modifierGroups ?? []).entries()) {
      const existingGroup = await prisma.productModifierGroup.findFirst({
        where: { productId: product.id, nameAr: group.nameAr },
      });
      const created =
        existingGroup ??
        (await prisma.productModifierGroup.create({
          data: {
            productId: product.id,
            nameAr: group.nameAr,
            selectionType: group.selectionType,
            isRequired: group.required ?? false,
            minSelect: group.required ? 1 : 0,
            maxSelect: group.maxSelect ?? 1,
            sortOrder: gIndex,
          },
        }));

      for (const [oIndex, option] of group.options.entries()) {
        const existingOption = await prisma.productModifier.findFirst({
          where: { groupId: created.id, nameAr: option.nameAr },
        });
        if (!existingOption) {
          await prisma.productModifier.create({
            data: {
              groupId: created.id,
              nameAr: option.nameAr,
              priceDelta: option.delta,
              isDefault: option.isDefault ?? false,
              sortOrder: oIndex,
            },
          });
        }
      }
    }
  }
  console.log(`   ✓ 5 تصنيفات و${productsSeed.length} منتجًا مع الخيارات والإضافات`);

  // ---------------------------------------------------------------------------
  // 8) تصنيفات المصروفات والطابعات
  // ---------------------------------------------------------------------------
  for (const nameAr of ['مشتريات يومية', 'صيانة', 'مواصلات', 'رواتب وأجور', 'أخرى']) {
    const existing = await prisma.expenseCategory.findFirst({ where: { nameAr } });
    if (!existing) await prisma.expenseCategory.create({ data: { nameAr } });
  }

  const printersSeed = [
    { nameAr: 'طابعة الكاشير', station: PrepStation.NONE, receipt: true, ip: '192.168.1.50' },
    { nameAr: 'طابعة المطبخ', station: PrepStation.KITCHEN, receipt: false, ip: '192.168.1.51' },
    { nameAr: 'طابعة البار', station: PrepStation.BAR, receipt: false, ip: '192.168.1.52' },
    { nameAr: 'طابعة الشيشة', station: PrepStation.SHISHA, receipt: false, ip: '192.168.1.53' },
  ];
  for (const seed of printersSeed) {
    const existing = await prisma.printer.findFirst({
      where: { branchId: branch.id, nameAr: seed.nameAr },
    });
    if (!existing) {
      await prisma.printer.create({
        data: {
          branchId: branch.id,
          nameAr: seed.nameAr,
          station: seed.station,
          isReceiptPrinter: seed.receipt,
          ipAddress: seed.ip,
        },
      });
    }
  }
  console.log('   ✓ تصنيفات المصروفات و4 طابعات حرارية 80مم');

  // ---------------------------------------------------------------------------
  // 9) عرض ترويجي تجريبي: مشروب + معسل بسعر ثابت
  // ---------------------------------------------------------------------------
  // كل تصنيفات المشروبات — التجريبية منها وتصنيفات المنيو الفعلي.
  // الطعام مستثنى عمدًا: العرض على المشروبات وحدها.
  const DRINK_CATEGORY_NAMES = [
    'مشروبات ساخنة',
    'مشروبات باردة',
    'قهوة باردة',
    'عصائر طازجة',
    'موهيتو',
    'مشروبات غازية',
  ];
  // نقرأ من قاعدة البيانات لا من خريطة الزراعة، حتى تُلتقط التصنيفات التي
  // أنشأها استيراد المنيو الفعلي (npm run menu:import) ولم تكن ضمن التجريبية.
  const drinkCategories = await prisma.category.findMany({
    where: { branchId: branch.id, nameAr: { in: DRINK_CATEGORY_NAMES } },
    select: { id: true },
  });
  const drinkCategoryIds = drinkCategories.map((c) => c.id);
  const shishaCategoryId = categoryByName.get('شيشة');

  const existingOffer = await prisma.offer.findFirst({
    where: { branchId: branch.id, nameAr: 'مشروب + معسل بـ 55' },
    include: { components: true },
  });

  // إعادة التشغيل بعد استيراد منيو جديد تضيف تصنيفات مشروبات لم تكن موجودة،
  // فنحدّث مكوّن المشروب ليشملها بدل ترك العرض معلقًا على تصنيفات قديمة.
  if (existingOffer) {
    const drinkComponent = existingOffer.components.find((c) => c.tobaccoOnly === false);
    if (drinkComponent) {
      const missing = drinkCategoryIds.filter((id) => !drinkComponent.categoryIds.includes(id));
      if (missing.length > 0) {
        await prisma.offerComponent.update({
          where: { id: drinkComponent.id },
          data: { categoryIds: [...drinkComponent.categoryIds, ...missing] },
        });
        console.log(`   ✓ حُدّث مكوّن المشروب في العرض ليشمل ${missing.length} تصنيفًا جديدًا`);
      }
    }
  }

  if (!existingOffer && shishaCategoryId) {
    await prisma.offer.create({
      data: {
        branchId: branch.id,
        nameAr: 'مشروب + معسل بـ 55',
        description: 'أي مشروب أقل من 22 ر.س مع أي نكهة معسل بسعر 55 ر.س شاملة الضرائب',
        fixedPrice: 55,
        priority: 10,
        maxPerOrder: 0,
        daysOfWeek: [],
        components: {
          create: [
            {
              nameAr: 'أي مشروب أقل من 22 ر.س',
              quantity: 1,
              categoryIds: drinkCategoryIds,
              productIds: [],
              // 21.99 تعني «أقل من 22» لأن المطابقة بـ «أقل من أو يساوي»
              maxUnitPrice: 21.99,
              tobaccoOnly: false,
              sortOrder: 0,
            },
            {
              nameAr: 'أي نكهة معسل',
              quantity: 1,
              categoryIds: [shishaCategoryId],
              productIds: [],
              tobaccoOnly: true,
              sortOrder: 1,
            },
          ],
        },
      },
    });
  }
  console.log('   ✓ عرض ترويجي: مشروب + معسل بـ 55 (يُطبق تلقائيًا)');

  // ---------------------------------------------------------------------------
  // 10) إعدادات Odoo (معطلة حتى يدخل المستخدم بياناته)
  // ---------------------------------------------------------------------------
  await prisma.odooSetting.upsert({
    where: { branchId: branch.id },
    create: {
      branchId: branch.id,
      isEnabled: false,
      url: 'https://example.odoo.com',
      database: 'mara_db',
      username: 'admin@mara.local',
      protocol: 'JSON_RPC',
      postingMode: 'DAILY_SUMMARY',
      productSyncDirection: 'ODOO_TO_POS',
      odooIsMasterOnConflict: true,
    },
    update: {},
  });
  console.log('   ✓ إعدادات Odoo (وضع الملخص اليومي — معطلة حتى الإعداد)');

  // ---------------------------------------------------------------------------
  // 11) وردية مفتوحة وفواتير تجريبية
  // ---------------------------------------------------------------------------
  const cashierId = createdUsers.get(RoleCode.CASHIER)!;
  const businessDay = getBusinessDay(new Date(), 5, 'Asia/Riyadh');

  const openShift = await prisma.shift.findFirst({
    where: { branchId: branch.id, status: 'OPEN' },
  });

  let shiftId: string;
  if (openShift) {
    shiftId = openShift.id;
  } else {
    const shift = await prisma.shift.create({
      data: {
        branchId: branch.id,
        userId: cashierId,
        deviceId: device.id,
        shiftNumber: 'SH-00001',
        businessDay,
        openingFloat: 500,
        openingNote: 'وردية تجريبية',
      },
    });
    await prisma.cashMovement.create({
      data: {
        branchId: branch.id,
        shiftId: shift.id,
        userId: cashierId,
        type: CashMovementType.OPENING_FLOAT,
        amount: 500,
        businessDay,
        note: 'رصيد افتتاحي',
      },
    });
    // نضبط عداد الورديات ليتوافق مع الرقم المزروع
    await prisma.sequence.upsert({
      where: { branchId_name_scope: { branchId: branch.id, name: 'SHIFT', scope: 'GLOBAL' } },
      create: { branchId: branch.id, name: 'SHIFT', scope: 'GLOBAL', value: 1 },
      update: { value: 1 },
    });
    shiftId = shift.id;
  }
  console.log('   ✓ وردية مفتوحة برصيد افتتاحي 500 ر.س');

  // فواتير تجريبية عبر خدمات النظام الحقيقية (لضمان صحة الاحتساب)
  const invoiceCount = await prisma.invoice.count({ where: { branchId: branch.id } });
  if (invoiceCount === 0) {
    await createDemoInvoices(branch.id, cashierId, shiftId, methodByCode);
    console.log('   ✓ 3 فواتير تجريبية مدفوعة (نقدي، شبكة، دفع مختلط)');
  } else {
    console.log('   • الفواتير التجريبية موجودة مسبقًا — تم التخطي');
  }

  console.log('\n✅ اكتملت زراعة البيانات.\n');
  console.log('الحسابات التجريبية (رقم الموظف / كلمة المرور):');
  for (const seed of usersSeed) {
    console.log(
      `   • ${ROLE_LABELS[seed.role].padEnd(12)} ${seed.employeeNo} / ${seed.password}   (${seed.email})`,
    );
  }
  console.log('\nرمز المدير لاعتماد العمليات: 1111 (مدير النظام) — 2222 (مدير الفرع)\n');
}

/** ينشئ فواتير تجريبية باستخدام خدمات النظام نفسها */
async function createDemoInvoices(
  branchId: string,
  userId: string,
  shiftId: string,
  methodByCode: Map<string, string>,
) {
  const { createOrder } = await import('../src/lib/pos/order-service');
  const { checkoutOrder } = await import('../src/lib/pos/checkout-service');
  const { toNumber, round2 } = await import('../src/lib/money');

  const products = await prisma.product.findMany({ where: { branchId } });
  const bySku = new Map(products.map((p) => [p.sku, p]));
  const tables = await prisma.restaurantTable.findMany({
    where: { branchId },
    orderBy: { number: 'asc' },
    take: 3,
  });

  const scenarios = [
    {
      type: 'DINE_IN' as const,
      tableId: tables[0]?.id,
      guests: 2,
      items: [
        { sku: 'DEMO-F-001', qty: 2 },
        { sku: 'DEMO-H-002', qty: 2 },
      ],
      payment: 'CASH',
    },
    {
      type: 'DINE_IN' as const,
      tableId: tables[1]?.id,
      guests: 4,
      items: [
        { sku: 'DEMO-S-001', qty: 1 },
        { sku: 'DEMO-H-001', qty: 2 },
        { sku: 'DEMO-D-001', qty: 1 },
      ],
      payment: 'MADA',
    },
    {
      type: 'TAKEAWAY' as const,
      tableId: null,
      guests: null,
      items: [
        { sku: 'DEMO-F-002', qty: 3 },
        { sku: 'DEMO-C-002', qty: 2 },
      ],
      payment: 'MIXED',
    },
  ];

  for (const scenario of scenarios) {
    const order = await createOrder({
      branchId,
      userId,
      type: scenario.type,
      tableId: scenario.tableId ?? null,
      guestCount: scenario.guests,
      shiftId,
      items: scenario.items
        .filter((i) => bySku.has(i.sku))
        .map((i) => ({ productId: bySku.get(i.sku)!.id, quantity: i.qty })),
    });

    const total = round2(toNumber(order.grandTotal));
    const payments =
      scenario.payment === 'MIXED'
        ? [
            { paymentMethodId: methodByCode.get('MADA')!, amount: round2(total / 2) },
            {
              paymentMethodId: methodByCode.get('CASH')!,
              amount: round2(total - round2(total / 2)),
            },
          ]
        : [{ paymentMethodId: methodByCode.get(scenario.payment)!, amount: total }];

    await checkoutOrder({ orderId: order.id, userId, shiftId, payments });
  }
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (error) => {
    console.error('❌ فشل في زراعة البيانات:', error);
    await prisma.$disconnect();
    process.exit(1);
  });
