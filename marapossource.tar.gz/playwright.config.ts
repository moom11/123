import { defineConfig, devices } from '@playwright/test';
import path from 'node:path';

/**
 * اختبارات شاملة (E2E) للعمليات الأساسية.
 * تشترط وجود قاعدة بيانات مهيأة ببيانات السييد: `npm run db:seed`.
 *
 * التشغيل: npm run test:e2e
 *
 * ملاحظة: تُسجَّل الجلسات مرة واحدة في مشروع «setup» ثم تُعاد استخدامها،
 * حتى لا تصطدم الاختبارات بحد محاولات تسجيل الدخول.
 */
const AUTH_DIR = path.join(__dirname, 'tests/e2e/.auth');

/**
 * في بعض بيئات التشغيل يكون Chromium مثبتًا مسبقًا بإصدار مختلف عما يتوقعه
 * Playwright؛ عندها نمرر مساره صراحةً عبر CHROMIUM_EXECUTABLE_PATH.
 */
const executablePath = process.env.CHROMIUM_EXECUTABLE_PATH;
const launchOptions = executablePath ? { launchOptions: { executablePath } } : {};

export default defineConfig({
  testDir: './tests/e2e',
  fullyParallel: false,
  workers: 1,
  retries: process.env.CI ? 1 : 0,
  reporter: process.env.CI ? 'list' : [['html', { open: 'never' }]],
  timeout: 60_000,
  use: {
    baseURL: process.env.APP_URL ?? 'http://localhost:3000',
    locale: 'ar-SA',
    timezoneId: 'Asia/Riyadh',
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    ...launchOptions,
  },
  projects: [
    { name: 'setup', testMatch: /auth\.setup\.ts/ },
    {
      name: 'chromium',
      dependencies: ['setup'],
      testIgnore: /auth\.setup\.ts/,
      use: { ...devices['Desktop Chrome'], ...launchOptions },
    },
    {
      name: 'tablet',
      dependencies: ['setup'],
      testIgnore: /auth\.setup\.ts/,
      use: { ...devices['iPad (gen 7) landscape'], ...launchOptions },
    },
  ],
  webServer: {
    command: 'npm run start',
    url: 'http://localhost:3000/login',
    reuseExistingServer: true,
    timeout: 120_000,
  },
});

export { AUTH_DIR };
