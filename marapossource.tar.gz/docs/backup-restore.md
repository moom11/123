# النسخ الاحتياطي والاستعادة

## النسخ التلقائي (Docker Compose)

خدمة `backup` تعمل تلقائيًا وتقوم بالآتي:

- نسخة احتياطية **يومية** مضغوطة بصيغة `.sql.gz`.
- تُحفظ في مجلد `./backups` على الخادم المضيف.
- تحتفظ بآخر **14 نسخة** وتحذف الأقدم تلقائيًا.
- تسمية الملفات: `mara_pos_YYYYMMDD_HHMMSS.sql.gz`.

للاطلاع على سجل النسخ:

```bash
docker compose logs -f backup
```

---

## النسخ اليدوي

### عبر Docker

```bash
docker compose exec db pg_dump -U mara mara_pos | gzip > backup_$(date +%F).sql.gz
```

### بدون Docker

```bash
pg_dump -U mara -h localhost mara_pos | gzip > backup_$(date +%F).sql.gz
```

### نسخة تشمل البنية فقط (بدون بيانات)

```bash
pg_dump -U mara -h localhost --schema-only mara_pos > schema.sql
```

---

## الاستعادة

> ⚠️ **الاستعادة تستبدل البيانات الحالية.** خذ نسخة احتياطية قبل الاستعادة.

### عبر Docker

```bash
# 1) إيقاف التطبيق والعامل حتى لا يكتبا أثناء الاستعادة
docker compose stop app worker

# 2) إعادة إنشاء قاعدة بيانات نظيفة
docker compose exec db psql -U mara -d postgres -c "DROP DATABASE IF EXISTS mara_pos;"
docker compose exec db psql -U mara -d postgres -c "CREATE DATABASE mara_pos OWNER mara;"

# 3) الاستعادة
gunzip -c backups/mara_pos_20260802_030000.sql.gz \
  | docker compose exec -T db psql -U mara -d mara_pos

# 4) تشغيل التطبيق مجددًا
docker compose start app worker
```

### بدون Docker

```bash
gunzip -c backup.sql.gz | psql -U mara -h localhost -d mara_pos
```

---

## نقاط مهمة

### مفتاح التشفير

بيانات الاتصال بـ Odoo مشفرة بـ `ENCRYPTION_KEY`. **احتفظ بنسخة آمنة من هذا المفتاح
منفصلة عن النسخ الاحتياطية.** بدونه لن يمكن فك تشفير مفتاح API بعد الاستعادة،
وستحتاج إلى إعادة إدخاله من شاشة إعدادات Odoo.

### الهجرات بعد الاستعادة

إذا كانت النسخة من إصدار أقدم، طبّق الهجرات بعد الاستعادة:

```bash
docker compose exec app npx prisma migrate deploy
```

### التحقق من سلامة النسخة

```bash
gunzip -t backup.sql.gz && echo "الملف سليم"
```

### الملفات المرفوعة

صور المنتجات ومستندات المصروفات تُخزَّن في وحدة التخزين `uploads`.
انسخها بشكل منفصل:

```bash
docker run --rm -v 123_uploads:/data -v $(pwd):/backup alpine \
  tar czf /backup/uploads_$(date +%F).tar.gz -C /data .
```

---

## جدولة النسخ خارج Docker

أضف إلى crontab (نسخة يومية الساعة 3:00 صباحًا):

```
0 3 * * * pg_dump -U mara mara_pos | gzip > /var/backups/mara/mara_pos_$(date +\%Y\%m\%d).sql.gz
0 4 * * * find /var/backups/mara -name 'mara_pos_*.sql.gz' -mtime +14 -delete
```

---

## اختبار خطة التعافي

يُنصح باختبار الاستعادة **شهريًا** على قاعدة بيانات منفصلة:

```bash
createdb -U mara mara_pos_restore_test
gunzip -c backup.sql.gz | psql -U mara -d mara_pos_restore_test
psql -U mara -d mara_pos_restore_test -c "SELECT COUNT(*) FROM invoices;"
dropdb -U mara mara_pos_restore_test
```
