import {
  CashMovementType,
  InvoiceStatus,
  OrderStatus,
  Prisma,
  RefundType,
  SyncEntity,
} from '@prisma/client';
import { prisma } from '@/lib/prisma';
import { BadRequest, Conflict, NotFound } from '@/lib/api/errors';
import { round2, toDecimal, toNumber } from '@/lib/money';
import { nextRefundNumber } from '@/lib/sequences';
import { enqueueSyncJob } from '@/lib/odoo/sync-queue';

export interface RefundItemInput {
  invoiceItemId: string;
  quantity: number;
}

export interface CreateRefundInput {
  invoiceId: string;
  userId: string;
  shiftId?: string | null;
  reason: string;
  /** فارغ = إرجاع كامل الفاتورة */
  items?: RefundItemInput[];
  approvedById?: string | null;
  idempotencyKey?: string | null;
}

/**
 * إنشاء مرتجع (كامل أو جزئي).
 *
 * القواعد:
 *  - الفاتورة الأصلية لا تُحذف أبدًا؛ تتغير حالتها إلى مرتجعة كليًا أو جزئيًا.
 *  - يُصدر مستند مرتجع مستقل مرتبط بالفاتورة الأصلية.
 *  - يُعاد المبلغ بنفس طرق الدفع الأصلية بشكل تناسبي.
 *  - يُرحّل المرتجع إلى Odoo كإشعار دائن.
 */
export async function createRefund(input: CreateRefundInput) {
  if (!input.reason?.trim()) throw BadRequest('سبب الإرجاع مطلوب');

  const idempotencyKey =
    input.idempotencyKey ?? `refund:${input.invoiceId}:${Date.now()}`;

  const existing = await prisma.refund.findUnique({
    where: { idempotencyKey },
    include: { items: true },
  });
  if (existing) return existing;

  const refundId = await prisma.$transaction(async (tx) => {
    const invoice = await tx.invoice.findUnique({
      where: { id: input.invoiceId },
      include: { items: true, payments: { include: { paymentMethod: true } } },
    });
    if (!invoice) throw NotFound('الفاتورة غير موجودة');
    if (invoice.status === InvoiceStatus.CANCELLED) {
      throw Conflict('لا يمكن إرجاع فاتورة ملغاة');
    }
    if (invoice.status === InvoiceStatus.REFUNDED) {
      throw Conflict('الفاتورة مرتجعة بالكامل مسبقًا');
    }

    // تحديد الأصناف المرتجعة
    const requested: RefundItemInput[] =
      input.items && input.items.length > 0
        ? input.items
        : invoice.items.map((item) => ({
            invoiceItemId: item.id,
            quantity: round2(
              toNumber(item.quantity) - toNumber(item.refundedQuantity),
            ),
          }));

    const itemsById = new Map(invoice.items.map((i) => [i.id, i]));
    let subtotal = 0;
    let vatTotal = 0;
    let tobaccoTotal = 0;
    const refundLines: {
      invoiceItemId: string;
      quantity: number;
      amount: number;
      vatAmount: number;
      tobaccoTaxAmount: number;
    }[] = [];

    for (const line of requested) {
      if (line.quantity <= 0) continue;
      const item = itemsById.get(line.invoiceItemId);
      if (!item) throw NotFound(`الصنف ${line.invoiceItemId} غير موجود في الفاتورة`);

      const soldQty = toNumber(item.quantity);
      const alreadyRefunded = toNumber(item.refundedQuantity);
      const available = round2(soldQty - alreadyRefunded);
      if (line.quantity > available + 1e-9) {
        throw BadRequest(
          `الكمية المطلوب إرجاعها من «${item.nameAr}» (${line.quantity}) تتجاوز المتاح (${available})`,
        );
      }

      // نُرجع القيم بالتناسب مع الكمية المرتجعة
      const ratio = soldQty > 0 ? line.quantity / soldQty : 0;
      const amount = round2(toNumber(item.netBeforeTax) * ratio);
      const vatAmount = round2(toNumber(item.vatAmount) * ratio);
      const tobaccoAmount = round2(toNumber(item.tobaccoTaxAmount) * ratio);

      subtotal += amount;
      vatTotal += vatAmount;
      tobaccoTotal += tobaccoAmount;

      refundLines.push({
        invoiceItemId: item.id,
        quantity: line.quantity,
        amount,
        vatAmount,
        tobaccoTaxAmount: tobaccoAmount,
      });
    }

    if (refundLines.length === 0) {
      throw BadRequest('لا توجد أصناف قابلة للإرجاع');
    }

    subtotal = round2(subtotal);
    vatTotal = round2(vatTotal);
    tobaccoTotal = round2(tobaccoTotal);
    const grandTotal = round2(subtotal + vatTotal + tobaccoTotal);

    // توزيع مبلغ الإرجاع على طرق الدفع الأصلية بالتناسب
    const capturedPayments = invoice.payments.filter((p) => p.status === 'CAPTURED');
    const paidTotal = round2(
      capturedPayments.reduce((acc, p) => acc + toNumber(p.amount), 0),
    );
    const refundPayments = capturedPayments.map((payment) => {
      const share =
        paidTotal > 0 ? round2((grandTotal * toNumber(payment.amount)) / paidTotal) : 0;
      return {
        paymentId: payment.id,
        paymentMethodId: payment.paymentMethodId,
        methodName: payment.paymentMethod.nameAr,
        methodType: payment.paymentMethod.type,
        affectsCashDrawer: payment.paymentMethod.affectsCashDrawer,
        amount: share,
      };
    });

    const refundNumber = await nextRefundNumber(tx, invoice.branchId);

    // هل أصبحت الفاتورة مرتجعة بالكامل؟
    const fullyRefunded = invoice.items.every((item) => {
      const refundedNow =
        refundLines.find((l) => l.invoiceItemId === item.id)?.quantity ?? 0;
      return (
        round2(toNumber(item.refundedQuantity) + refundedNow) >=
        round2(toNumber(item.quantity)) - 1e-9
      );
    });

    const refund = await tx.refund.create({
      data: {
        branchId: invoice.branchId,
        invoiceId: invoice.id,
        shiftId: input.shiftId ?? invoice.shiftId,
        refundNumber,
        type: fullyRefunded ? RefundType.FULL : RefundType.PARTIAL,
        reason: input.reason,
        subtotal: toDecimal(subtotal),
        vatTotal: toDecimal(vatTotal),
        tobaccoTaxTotal: toDecimal(tobaccoTotal),
        grandTotal: toDecimal(grandTotal),
        businessDay: invoice.businessDay,
        createdById: input.userId,
        approvedById: input.approvedById ?? null,
        refundPayments: refundPayments as unknown as Prisma.JsonArray,
        idempotencyKey,
      },
    });

    for (const line of refundLines) {
      await tx.refundItem.create({
        data: {
          refundId: refund.id,
          invoiceItemId: line.invoiceItemId,
          quantity: toDecimal(line.quantity, 3),
          amount: toDecimal(line.amount),
          vatAmount: toDecimal(line.vatAmount),
          tobaccoTaxAmount: toDecimal(line.tobaccoTaxAmount),
        },
      });
      await tx.invoiceItem.update({
        where: { id: line.invoiceItemId },
        data: { refundedQuantity: { increment: toDecimal(line.quantity, 3) } },
      });
    }

    await tx.invoice.update({
      where: { id: invoice.id },
      data: {
        status: fullyRefunded
          ? InvoiceStatus.REFUNDED
          : InvoiceStatus.PARTIALLY_REFUNDED,
        refundedTotal: { increment: toDecimal(grandTotal) },
      },
    });

    await tx.order.update({
      where: { id: invoice.orderId },
      data: {
        status: fullyRefunded ? OrderStatus.REFUNDED : OrderStatus.PARTIALLY_REFUNDED,
      },
    });

    // إخراج النقد من الصندوق لما أُعيد نقدًا
    const shiftId = input.shiftId ?? invoice.shiftId;
    const cashRefund = refundPayments
      .filter((p) => p.affectsCashDrawer)
      .reduce((acc, p) => acc + p.amount, 0);
    if (shiftId && cashRefund > 0) {
      await tx.cashMovement.create({
        data: {
          branchId: invoice.branchId,
          shiftId,
          userId: input.userId,
          type: CashMovementType.REFUND_CASH_OUT,
          amount: toDecimal(-round2(cashRefund)),
          businessDay: invoice.businessDay,
          note: `مرتجع ${refundNumber} — فاتورة ${invoice.invoiceNumber}`,
          referenceId: refund.id,
        },
      });
    }

    await tx.invoiceChangeLog.create({
      data: {
        invoiceId: invoice.id,
        userId: input.userId,
        action: 'REFUND_CREATED',
        newValue: {
          refundNumber,
          grandTotal,
          type: fullyRefunded ? 'FULL' : 'PARTIAL',
          items: refundLines,
        } as unknown as Prisma.JsonObject,
        reason: input.reason,
      },
    });

    await enqueueSyncJob(tx, {
      branchId: invoice.branchId,
      entity: SyncEntity.REFUND,
      entityId: refund.id,
      idempotencyKey: `refund:${refund.id}`,
    });

    return refund.id;
  });

  return prisma.refund.findUniqueOrThrow({
    where: { id: refundId },
    include: { items: { include: { invoiceItem: true } }, invoice: true },
  });
}
