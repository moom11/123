import { distributeProportionally, round2, roundTo } from '@/lib/money';

/**
 * =============================================================================
 * محرك احتساب الضرائب
 * =============================================================================
 *
 * ترتيب الاحتساب المعتمد (المطابق للممارسة السعودية):
 *
 *   1) الصافي قبل الضريبة (net)
 *   2) الخصم يُطبق على الصافي قبل الضريبة
 *   3) ضريبة التبغ (الانتقائية) تُحتسب على الصافي بعد الخصم
 *   4) ضريبة القيمة المضافة تُحتسب على (الصافي بعد الخصم + ضريبة التبغ)
 *   5) الإجمالي = الصافي + ضريبة التبغ + ضريبة القيمة المضافة
 *
 * ضريبة التبغ لا تُدمج أبدًا مع ضريبة القيمة المضافة في المخرجات،
 * وتُخزن كقيمة مستقلة في كل سطر وفي الفاتورة.
 *
 * عندما يكون السعر المدخل شاملًا للضريبة نعكس المعادلة لاستخراج الصافي.
 */

export type TobaccoBase = 'PERCENT_OF_PRICE' | 'FIXED_PER_UNIT';

export interface TaxLineInput {
  /** معرّف السطر — يستخدم لربط النتائج بالمدخلات */
  id: string;
  quantity: number;
  /** سعر الوحدة كما أُدخل في المنتج */
  unitPrice: number;
  /** مجموع فروق أسعار الخيارات والإضافات لكل وحدة */
  modifiersPrice?: number;
  /** هل السعر المدخل شامل ضريبة القيمة المضافة (وضريبة التبغ إن وُجدت)؟ */
  priceIncludesVat: boolean;
  /** نسبة ضريبة القيمة المضافة (15 تعني 15%) */
  vatRate: number;
  isTobacco?: boolean;
  tobaccoBase?: TobaccoBase | null;
  /** نسبة ضريبة التبغ عند PERCENT_OF_PRICE */
  tobaccoRate?: number | null;
  /** مبلغ ثابت لكل وحدة عند FIXED_PER_UNIT */
  tobaccoFixedAmount?: number | null;
  /** الحد الأدنى لضريبة التبغ لكل وحدة */
  tobaccoMinPerUnit?: number | null;
  /** خصم على مستوى السطر (مبلغ بالريال) */
  lineDiscount?: number;
}

export interface TaxLineResult {
  id: string;
  quantity: number;
  /** سعر الوحدة الصافي قبل أي ضريبة */
  netUnitPrice: number;
  /** الإجمالي قبل الخصم والضريبة */
  lineSubtotal: number;
  discountAmount: number;
  netBeforeTax: number;
  vatRate: number;
  vatAmount: number;
  isTobacco: boolean;
  tobaccoTaxBase: TobaccoBase | null;
  tobaccoTaxRate: number | null;
  tobaccoTaxAmount: number;
  lineTotal: number;
}

export interface OrderDiscountInput {
  type: 'PERCENT' | 'AMOUNT' | 'COUPON';
  value: number;
  /** الحد الأعلى لقيمة الخصم */
  maxAmount?: number | null;
}

export interface TaxTotals {
  subtotal: number;
  discountTotal: number;
  netBeforeTax: number;
  vatTotal: number;
  tobaccoTaxTotal: number;
  grandTotal: number;
}

export interface TaxCalculationResult {
  lines: TaxLineResult[];
  totals: TaxTotals;
}

/** سعر الوحدة الإجمالي كما يراه المستخدم (السعر + الإضافات) */
function grossUnitPrice(line: TaxLineInput): number {
  return roundTo(line.unitPrice + (line.modifiersPrice ?? 0), 4);
}

/**
 * استخراج الصافي لكل وحدة قبل جميع الضرائب.
 * عند السعر الشامل نعكس معادلة الضريبتين معًا.
 */
export function computeNetUnitPrice(line: TaxLineInput): number {
  const gross = grossUnitPrice(line);
  const vatFactor = 1 + (line.vatRate || 0) / 100;

  if (!line.priceIncludesVat) {
    return roundTo(gross, 4);
  }

  if (!line.isTobacco) {
    return roundTo(gross / vatFactor, 4);
  }

  const base = line.tobaccoBase ?? 'PERCENT_OF_PRICE';
  if (base === 'FIXED_PER_UNIT') {
    const fixed = line.tobaccoFixedAmount ?? 0;
    // G = (n + F) × (1 + V) ⇒ n = G / (1 + V) − F
    return roundTo(Math.max(gross / vatFactor - fixed, 0), 4);
  }

  const tobaccoFactor = 1 + (line.tobaccoRate ?? 0) / 100;
  // G = n × (1 + R) × (1 + V) ⇒ n = G / ((1 + R)(1 + V))
  return roundTo(gross / (tobaccoFactor * vatFactor), 4);
}

/** احتساب ضريبة التبغ لسطر بعد تحديد صافيه وكميته */
export function computeTobaccoTax(
  line: TaxLineInput,
  netBeforeTax: number,
  quantity: number,
): number {
  if (!line.isTobacco || quantity <= 0) return 0;

  const base = line.tobaccoBase ?? 'PERCENT_OF_PRICE';
  let amount: number;

  if (base === 'FIXED_PER_UNIT') {
    amount = (line.tobaccoFixedAmount ?? 0) * quantity;
  } else {
    amount = (netBeforeTax * (line.tobaccoRate ?? 0)) / 100;
  }

  // تطبيق الحد الأدنى للضريبة لكل وحدة عند تفعيله
  const minPerUnit = line.tobaccoMinPerUnit ?? 0;
  if (minPerUnit > 0) {
    amount = Math.max(amount, minPerUnit * quantity);
  }

  return round2(amount);
}

/** احتساب قيمة خصم على مستوى الفاتورة انطلاقًا من الصافي */
export function computeOrderDiscountAmount(
  discount: OrderDiscountInput | null | undefined,
  netBase: number,
): number {
  if (!discount || netBase <= 0) return 0;
  let amount =
    discount.type === 'PERCENT'
      ? (netBase * discount.value) / 100
      : discount.value;

  if (discount.maxAmount != null && discount.maxAmount > 0) {
    amount = Math.min(amount, discount.maxAmount);
  }
  // لا يتجاوز الخصم قيمة الفاتورة
  amount = Math.min(amount, netBase);
  return round2(Math.max(amount, 0));
}

/**
 * الدالة الرئيسية: تحسب الضرائب لكل الأسطر وإجماليات الفاتورة.
 */
export function calculateOrderTaxes(
  lines: TaxLineInput[],
  orderDiscount?: OrderDiscountInput | null,
): TaxCalculationResult {
  const activeLines = lines.filter((l) => l.quantity > 0);

  // 1) الصافي والخصم على مستوى السطر
  const preliminary = activeLines.map((line) => {
    const netUnitPrice = computeNetUnitPrice(line);
    const lineSubtotal = round2(netUnitPrice * line.quantity);
    const lineDiscount = round2(Math.min(line.lineDiscount ?? 0, lineSubtotal));
    return {
      line,
      netUnitPrice,
      lineSubtotal,
      lineDiscount,
      netAfterLineDiscount: round2(lineSubtotal - lineDiscount),
    };
  });

  // 2) توزيع خصم الفاتورة على الأسطر بالتناسب مع صافي كل سطر
  const netBase = round2(
    preliminary.reduce((acc, p) => acc + p.netAfterLineDiscount, 0),
  );
  const orderDiscountAmount = computeOrderDiscountAmount(orderDiscount, netBase);
  const shares = distributeProportionally(
    orderDiscountAmount,
    preliminary.map((p) => p.netAfterLineDiscount),
  );

  // 3) الضرائب لكل سطر
  const results: TaxLineResult[] = preliminary.map((p, index) => {
    const { line } = p;
    const discountAmount = round2(p.lineDiscount + shares[index]);
    const netBeforeTax = round2(p.lineSubtotal - discountAmount);
    const tobaccoTaxAmount = computeTobaccoTax(line, netBeforeTax, line.quantity);
    const vatAmount = round2(
      ((netBeforeTax + tobaccoTaxAmount) * (line.vatRate || 0)) / 100,
    );

    return {
      id: line.id,
      quantity: line.quantity,
      netUnitPrice: p.netUnitPrice,
      lineSubtotal: p.lineSubtotal,
      discountAmount,
      netBeforeTax,
      vatRate: line.vatRate || 0,
      vatAmount,
      isTobacco: Boolean(line.isTobacco),
      tobaccoTaxBase: line.isTobacco ? (line.tobaccoBase ?? 'PERCENT_OF_PRICE') : null,
      tobaccoTaxRate: line.isTobacco ? (line.tobaccoRate ?? null) : null,
      tobaccoTaxAmount,
      lineTotal: round2(netBeforeTax + tobaccoTaxAmount + vatAmount),
    };
  });

  // 4) الإجماليات
  const totals: TaxTotals = {
    subtotal: round2(results.reduce((a, r) => a + r.lineSubtotal, 0)),
    discountTotal: round2(results.reduce((a, r) => a + r.discountAmount, 0)),
    netBeforeTax: round2(results.reduce((a, r) => a + r.netBeforeTax, 0)),
    vatTotal: round2(results.reduce((a, r) => a + r.vatAmount, 0)),
    tobaccoTaxTotal: round2(results.reduce((a, r) => a + r.tobaccoTaxAmount, 0)),
    grandTotal: round2(results.reduce((a, r) => a + r.lineTotal, 0)),
  };

  return { lines: results, totals };
}
