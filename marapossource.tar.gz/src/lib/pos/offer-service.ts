import { DiscountScope, DiscountType, type Prisma } from '@prisma/client';
import type { TransactionClient } from '@/lib/prisma';
import { toDecimal, toNumber } from '@/lib/money';
import {
  applyOffers,
  isOfferActiveNow,
  type AppliedOffer,
  type OfferLine,
  type OfferSpec,
} from '@/lib/pos/offer-engine';

/**
 * ربط محرك العروض بقاعدة البيانات:
 * يجلب العروض السارية، يطبقها على أسطر الطلب، ويحفظ الخصومات الناتجة.
 *
 * الخصومات المولّدة من العروض مشتقة بالكامل — تُحذف وتُعاد كتابتها
 * في كل إعادة احتساب، فلا تتراكم ولا تتقادم.
 */

/** يجلب العروض السارية حاليًا للفرع، مستثنيًا ما ألغاه الكاشير لهذا الطلب */
export async function loadActiveOffers(
  client: TransactionClient,
  branchId: string,
  dismissedOfferIds: string[] = [],
  now: Date = new Date(),
): Promise<OfferSpec[]> {
  const offers = await client.offer.findMany({
    where: { branchId, isActive: true, id: { notIn: dismissedOfferIds } },
    include: { components: { orderBy: { sortOrder: 'asc' } } },
    orderBy: { priority: 'desc' },
  });

  return offers
    .filter((offer) => isOfferActiveNow(offer, now))
    .map((offer) => ({
      id: offer.id,
      nameAr: offer.nameAr,
      fixedPrice: toNumber(offer.fixedPrice),
      priority: offer.priority,
      maxPerOrder: offer.maxPerOrder,
      components: offer.components.map((component) => ({
        id: component.id,
        nameAr: component.nameAr,
        quantity: component.quantity,
        categoryIds: component.categoryIds,
        productIds: component.productIds,
        maxUnitPrice:
          component.maxUnitPrice != null ? toNumber(component.maxUnitPrice) : null,
        minUnitPrice:
          component.minUnitPrice != null ? toNumber(component.minUnitPrice) : null,
        tobaccoOnly: component.tobaccoOnly,
      })),
    }));
}

/**
 * يعيد حساب عروض الطلب ويحفظ خصوماتها.
 * تُستدعى من داخل recalculateOrder قبل الاحتساب النهائي.
 */
export async function syncOrderOffers(
  client: TransactionClient,
  params: {
    orderId: string;
    branchId: string;
    userId: string;
    dismissedOfferIds: string[];
    lines: OfferLine[];
    /** صافي كل سطر قبل الضريبة بعد الخصومات اليدوية */
    netByLine: Map<string, number>;
    now?: Date;
  },
): Promise<AppliedOffer[]> {
  // الخصومات المولّدة من العروض مشتقة — نحذفها دائمًا ونعيد بناءها
  await client.discount.deleteMany({
    where: { orderId: params.orderId, type: DiscountType.OFFER },
  });

  if (params.lines.length === 0) return [];

  const offers = await loadActiveOffers(
    client,
    params.branchId,
    params.dismissedOfferIds,
    params.now,
  );
  if (offers.length === 0) return [];

  const applied = applyOffers(params.lines, offers, params.netByLine);

  for (const offer of applied) {
    for (const lineDiscount of offer.lineDiscounts) {
      if (lineDiscount.amount <= 0) continue;
      await client.discount.create({
        data: {
          orderId: params.orderId,
          orderItemId: lineDiscount.lineId,
          offerId: offer.offerId,
          type: DiscountType.OFFER,
          scope: DiscountScope.ORDER_ITEM,
          value: toDecimal(offer.offerTotal, 4),
          amount: toDecimal(lineDiscount.amount),
          reason: `عرض: ${offer.offerName}`,
          createdById: params.userId,
        },
      });
    }
  }

  return applied;
}

/** يخفي عرضًا عن طلب معين (إلغاء يدوي من الكاشير) */
export async function dismissOffer(
  client: TransactionClient,
  orderId: string,
  offerId: string,
) {
  const order = await client.order.findUniqueOrThrow({
    where: { id: orderId },
    select: { dismissedOfferIds: true },
  });
  if (order.dismissedOfferIds.includes(offerId)) return;
  await client.order.update({
    where: { id: orderId },
    data: { dismissedOfferIds: { push: offerId } },
  });
}

/** يعيد تفعيل عرض أُلغي يدويًا */
export async function restoreOffer(
  client: TransactionClient,
  orderId: string,
  offerId: string,
) {
  const order = await client.order.findUniqueOrThrow({
    where: { id: orderId },
    select: { dismissedOfferIds: true },
  });
  await client.order.update({
    where: { id: orderId },
    data: { dismissedOfferIds: order.dismissedOfferIds.filter((id) => id !== offerId) },
  });
}

/** ملخص العروض المطبقة على طلب — لعرضه في الواجهة والفاتورة */
export async function getOrderOfferSummary(
  client: TransactionClient,
  orderId: string,
): Promise<{ offerId: string; offerName: string; savings: number }[]> {
  const discounts = await client.discount.findMany({
    where: { orderId, type: DiscountType.OFFER },
    include: { offer: { select: { nameAr: true } } },
  });

  const byOffer = new Map<string, { offerId: string; offerName: string; savings: number }>();
  for (const discount of discounts) {
    if (!discount.offerId) continue;
    const entry = byOffer.get(discount.offerId) ?? {
      offerId: discount.offerId,
      offerName: discount.offer?.nameAr ?? 'عرض',
      savings: 0,
    };
    entry.savings += toNumber(discount.amount);
    byOffer.set(discount.offerId, entry);
  }
  return Array.from(byOffer.values());
}

export type { AppliedOffer, OfferLine, OfferSpec };
export type OfferJson = Prisma.JsonObject;
