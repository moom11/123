import {
  DiscountScope,
  DiscountType,
  OrderStatus,
  OrderType,
  Prisma,
  TableStatus,
  type PrepStation,
} from '@prisma/client';
import { prisma, type TransactionClient } from '@/lib/prisma';
import { BadRequest, Conflict, NotFound, UnprocessableEntity } from '@/lib/api/errors';
import { round2, toDecimal, toNumber } from '@/lib/money';
import {
  calculateOrderTaxes,
  type OrderDiscountInput,
  type TaxLineInput,
} from '@/lib/pos/tax-engine';
import { syncOrderOffers } from '@/lib/pos/offer-service';
import type { OfferLine } from '@/lib/pos/offer-engine';
import { nextOrderNumber } from '@/lib/sequences';
import { currentBusinessDay, getBranchSettings } from '@/lib/settings';

export interface OrderItemModifierInput {
  groupId?: string;
  groupName?: string;
  modifierId: string;
  name: string;
  priceDelta: number;
}

export interface AddItemInput {
  productId: string;
  variantId?: string | null;
  quantity: number;
  note?: string | null;
  modifiers?: OrderItemModifierInput[];
  /** خصم على مستوى السطر بمبلغ ثابت */
  lineDiscount?: number;
}

export interface CreateOrderInput {
  branchId: string;
  userId: string;
  type: OrderType;
  tableId?: string | null;
  guestCount?: number | null;
  customerName?: string | null;
  customerPhone?: string | null;
  note?: string | null;
  shiftId?: string | null;
  /** معرف محلي من الجهاز لمنع تكرار الطلب عند العمل دون اتصال */
  clientUuid?: string | null;
  items?: AddItemInput[];
}

export const ORDER_INCLUDE = {
  items: {
    orderBy: { createdAt: 'asc' },
    include: { product: { select: { imageUrl: true, prepStation: true } } },
  },
  table: { select: { id: true, number: true, nameAr: true, status: true } },
  user: { select: { id: true, fullName: true, employeeNo: true } },
  discounts: { include: { offer: { select: { id: true, nameAr: true } } } },
} satisfies Prisma.OrderInclude;

export type OrderWithRelations = Prisma.OrderGetPayload<{ include: typeof ORDER_INCLUDE }>;

/** الحالات التي لا تزال تسمح بتعديل الطلب */
const EDITABLE_STATUSES: OrderStatus[] = [
  OrderStatus.DRAFT,
  OrderStatus.HELD,
  OrderStatus.SENT_TO_PREP,
];

export function assertEditable(order: { status: OrderStatus }) {
  if (!EDITABLE_STATUSES.includes(order.status)) {
    throw Conflict(`لا يمكن تعديل طلب في الحالة الحالية (${order.status})`);
  }
}

/**
 * يبني مدخلات محرك الضرائب من أسطر الطلب المخزنة.
 * كل سطر يحمل نسخته الضريبية وقت البيع.
 */
function toTaxLines(
  items: {
    id: string;
    quantity: Prisma.Decimal;
    unitPrice: Prisma.Decimal;
    modifiersPrice: Prisma.Decimal;
    priceIncludesVat: boolean;
    vatRate: Prisma.Decimal;
    isTobacco: boolean;
    tobaccoTaxBase: string | null;
    tobaccoTaxRate: Prisma.Decimal | null;
    discountAmount: Prisma.Decimal;
    isVoided: boolean;
  }[],
  tobaccoMeta: Map<string, { fixedAmount: number | null; minPerUnit: number | null }>,
  lineDiscounts: Map<string, number>,
): TaxLineInput[] {
  return items
    .filter((item) => !item.isVoided)
    .map((item) => {
      const meta = tobaccoMeta.get(item.id);
      return {
        id: item.id,
        quantity: toNumber(item.quantity),
        unitPrice: toNumber(item.unitPrice),
        modifiersPrice: toNumber(item.modifiersPrice),
        priceIncludesVat: item.priceIncludesVat,
        vatRate: toNumber(item.vatRate),
        isTobacco: item.isTobacco,
        tobaccoBase: (item.tobaccoTaxBase as 'PERCENT_OF_PRICE' | 'FIXED_PER_UNIT') ?? null,
        tobaccoRate: item.tobaccoTaxRate ? toNumber(item.tobaccoTaxRate) : null,
        tobaccoFixedAmount: meta?.fixedAmount ?? null,
        tobaccoMinPerUnit: meta?.minPerUnit ?? null,
        lineDiscount: lineDiscounts.get(item.id) ?? 0,
      };
    });
}

/**
 * إعادة احتساب كامل للطلب وحفظ النتائج في قاعدة البيانات.
 * تُستدعى بعد أي تعديل على الأسطر أو الخصومات.
 */
export async function recalculateOrder(
  client: TransactionClient,
  orderId: string,
): Promise<OrderWithRelations> {
  const order = await client.order.findUnique({
    where: { id: orderId },
    include: { items: true, discounts: true },
  });
  if (!order) throw NotFound('الطلب غير موجود');

  // نجلب بيانات ضريبة التبغ الأصلية (المبلغ الثابت والحد الأدنى) للأسطر المعنية
  const tobaccoProductIds = order.items
    .filter((item) => item.isTobacco && !item.isVoided)
    .map((item) => item.productId);

  const tobaccoMeta = new Map<
    string,
    { fixedAmount: number | null; minPerUnit: number | null }
  >();
  if (tobaccoProductIds.length > 0) {
    const products = await client.product.findMany({
      where: { id: { in: tobaccoProductIds } },
      include: { tobaccoTax: true },
    });
    const byProduct = new Map(products.map((p) => [p.id, p]));
    for (const item of order.items) {
      const product = byProduct.get(item.productId);
      if (product?.tobaccoTax) {
        tobaccoMeta.set(item.id, {
          fixedAmount: product.tobaccoTax.fixedAmount
            ? toNumber(product.tobaccoTax.fixedAmount)
            : null,
          minPerUnit: product.tobaccoTax.minAmountPerUnit
            ? toNumber(product.tobaccoTax.minAmountPerUnit)
            : null,
        });
      }
    }
  }

  /** يجمع خصومات الأسطر من سجلات الخصم، مع إمكانية استثناء الخصومات المشتقة من العروض */
  const collectLineDiscounts = (
    discounts: { scope: DiscountScope; orderItemId: string | null; amount: unknown; type: DiscountType }[],
    includeOffers: boolean,
  ) => {
    const map = new Map<string, number>();
    for (const discount of discounts) {
      if (discount.scope !== DiscountScope.ORDER_ITEM || !discount.orderItemId) continue;
      if (!includeOffers && discount.type === DiscountType.OFFER) continue;
      map.set(
        discount.orderItemId,
        round2((map.get(discount.orderItemId) ?? 0) + toNumber(discount.amount as never)),
      );
    }
    return map;
  };

  // خصم الفاتورة (نأخذ آخر خصم يدوي مسجل على مستوى الطلب)
  const orderDiscountRecord = order.discounts
    .filter((d) => d.scope === DiscountScope.ORDER)
    .at(-1);
  const orderDiscount: OrderDiscountInput | null = orderDiscountRecord
    ? {
        type: orderDiscountRecord.type === DiscountType.PERCENT ? 'PERCENT' : 'AMOUNT',
        value: toNumber(orderDiscountRecord.value),
      }
    : null;

  // ---------------------------------------------------------------------------
  // 1) احتساب أولي بالخصومات اليدوية فقط — يعطينا صافي كل سطر
  //    وهو الأساس الذي يبني عليه محرك العروض مطابقته وحساباته.
  // ---------------------------------------------------------------------------
  const manualLineDiscounts = collectLineDiscounts(order.discounts, false);
  const baselineTaxLines = toTaxLines(order.items, tobaccoMeta, manualLineDiscounts);
  const baseline = calculateOrderTaxes(baselineTaxLines, orderDiscount);
  const netByLine = new Map(baseline.lines.map((l) => [l.id, l.netBeforeTax]));

  // ---------------------------------------------------------------------------
  // 2) تطبيق العروض تلقائيًا وتوليد خصوماتها
  // ---------------------------------------------------------------------------
  const activeItems = order.items.filter((item) => !item.isVoided);
  const productMeta = await client.product.findMany({
    where: { id: { in: activeItems.map((i) => i.productId) } },
    select: { id: true, categoryId: true },
  });
  const categoryByProduct = new Map(productMeta.map((p) => [p.id, p.categoryId]));

  const offerLines: OfferLine[] = baselineTaxLines.map((taxLine) => {
    const item = activeItems.find((i) => i.id === taxLine.id)!;
    return {
      ...taxLine,
      productId: item.productId,
      categoryId: categoryByProduct.get(item.productId) ?? '',
      displayUnitPrice: round2(
        toNumber(item.unitPrice) + toNumber(item.modifiersPrice),
      ),
      name: item.nameAr,
    } as OfferLine;
  });

  await syncOrderOffers(client, {
    orderId,
    branchId: order.branchId,
    userId: order.userId,
    dismissedOfferIds: order.dismissedOfferIds,
    lines: offerLines,
    netByLine,
  });

  // ---------------------------------------------------------------------------
  // 3) الاحتساب النهائي شاملًا خصومات العروض
  // ---------------------------------------------------------------------------
  const allDiscounts = await client.discount.findMany({ where: { orderId } });
  const lineDiscounts = collectLineDiscounts(allDiscounts, true);
  const taxLines = toTaxLines(order.items, tobaccoMeta, lineDiscounts);
  const { lines, totals } = calculateOrderTaxes(taxLines, orderDiscount);

  // تحديث الأسطر
  const byId = new Map(lines.map((l) => [l.id, l]));
  for (const item of order.items) {
    const result = byId.get(item.id);
    if (!result) {
      if (!item.isVoided) continue;
      // السطر الملغى تصفّر قيمه
      await client.orderItem.update({
        where: { id: item.id },
        data: {
          lineSubtotal: toDecimal(0),
          discountAmount: toDecimal(0),
          netBeforeTax: toDecimal(0),
          vatAmount: toDecimal(0),
          tobaccoTaxAmount: toDecimal(0),
          lineTotal: toDecimal(0),
        },
      });
      continue;
    }
    await client.orderItem.update({
      where: { id: item.id },
      data: {
        lineSubtotal: toDecimal(result.lineSubtotal),
        discountAmount: toDecimal(result.discountAmount),
        netBeforeTax: toDecimal(result.netBeforeTax),
        vatAmount: toDecimal(result.vatAmount),
        tobaccoTaxAmount: toDecimal(result.tobaccoTaxAmount),
        lineTotal: toDecimal(result.lineTotal),
      },
    });
  }

  // تحديث القيمة المحتسبة لخصم الفاتورة
  if (orderDiscountRecord) {
    const orderLevelDiscount = round2(
      totals.discountTotal -
        Array.from(lineDiscounts.values()).reduce((a, b) => a + b, 0),
    );
    await client.discount.update({
      where: { id: orderDiscountRecord.id },
      data: { amount: toDecimal(Math.max(orderLevelDiscount, 0)) },
    });
  }

  await client.order.update({
    where: { id: orderId },
    data: {
      subtotal: toDecimal(totals.subtotal),
      discountTotal: toDecimal(totals.discountTotal),
      vatTotal: toDecimal(totals.vatTotal),
      tobaccoTaxTotal: toDecimal(totals.tobaccoTaxTotal),
      grandTotal: toDecimal(totals.grandTotal),
    },
  });

  return client.order.findUniqueOrThrow({
    where: { id: orderId },
    include: ORDER_INCLUDE,
  });
}

/** إنشاء طلب جديد (مع أسطره الأولية إن وُجدت) */
export async function createOrder(input: CreateOrderInput): Promise<OrderWithRelations> {
  const settings = await getBranchSettings(input.branchId);

  if (input.type === OrderType.DELIVERY && !settings.enableDelivery) {
    throw UnprocessableEntity('خدمة التوصيل معطلة حاليًا من إعدادات الفرع');
  }
  if (input.type === OrderType.DINE_IN && !input.tableId) {
    throw BadRequest('يجب اختيار الطاولة لطلبات داخل المطعم');
  }

  // منع التكرار عند إعادة الإرسال من وضع العمل دون اتصال
  if (input.clientUuid) {
    const existing = await prisma.order.findUnique({
      where: { clientUuid: input.clientUuid },
      include: ORDER_INCLUDE,
    });
    if (existing) return existing;
  }

  const businessDay = await currentBusinessDay(input.branchId);

  const orderId = await prisma.$transaction(async (tx) => {
    if (input.tableId) {
      const table = await tx.restaurantTable.findFirst({
        where: { id: input.tableId, branchId: input.branchId },
      });
      if (!table) throw NotFound('الطاولة غير موجودة');
    }

    const orderNumber = await nextOrderNumber(
      tx,
      input.branchId,
      businessDay,
      settings.orderPrefix,
    );

    const order = await tx.order.create({
      data: {
        branchId: input.branchId,
        orderNumber,
        clientUuid: input.clientUuid ?? null,
        type: input.type,
        status: OrderStatus.DRAFT,
        tableId: input.tableId ?? null,
        guestCount: input.guestCount ?? null,
        userId: input.userId,
        shiftId: input.shiftId ?? null,
        businessDay,
        customerName: input.customerName ?? null,
        customerPhone: input.customerPhone ?? null,
        note: input.note ?? null,
      },
    });

    for (const item of input.items ?? []) {
      await insertOrderItem(tx, order.id, input.branchId, item);
    }

    if (input.tableId) {
      await tx.restaurantTable.update({
        where: { id: input.tableId },
        data: { status: TableStatus.OCCUPIED },
      });
    }

    return order.id;
  });

  return prisma.$transaction((tx) => recalculateOrder(tx, orderId));
}

/** إدراج سطر جديد في الطلب مع تجميد بيانات المنتج والضريبة وقت البيع */
export async function insertOrderItem(
  client: TransactionClient,
  orderId: string,
  branchId: string,
  input: AddItemInput,
) {
  if (input.quantity <= 0) throw BadRequest('الكمية يجب أن تكون أكبر من صفر');

  const product = await client.product.findFirst({
    where: { id: input.productId, branchId, isActive: true },
    include: { vatTax: true, tobaccoTax: true, variants: true },
  });
  if (!product) throw NotFound('المنتج غير موجود أو غير نشط');

  let unitPrice = toNumber(product.price);
  let variantName = '';
  if (input.variantId) {
    const variant = product.variants.find((v) => v.id === input.variantId);
    if (!variant) throw NotFound('الخيار المحدد غير موجود لهذا المنتج');
    unitPrice = round2(unitPrice + toNumber(variant.priceDelta));
    variantName = ` - ${variant.nameAr}`;
  }

  const modifiers = input.modifiers ?? [];
  const modifiersPrice = round2(
    modifiers.reduce((acc, m) => acc + (m.priceDelta ?? 0), 0),
  );

  const vatRate = product.vatTax ? toNumber(product.vatTax.rate) : 0;
  const tobaccoTax = product.isTobacco ? product.tobaccoTax : null;

  const item = await client.orderItem.create({
    data: {
      orderId,
      productId: product.id,
      variantId: input.variantId ?? null,
      nameAr: `${product.nameAr}${variantName}`,
      nameEn: product.nameEn,
      sku: product.sku,
      quantity: toDecimal(input.quantity, 3),
      unitPrice: toDecimal(unitPrice, 4),
      priceIncludesVat: product.priceIncludesVat,
      modifiersPrice: toDecimal(modifiersPrice, 4),
      lineSubtotal: toDecimal(0),
      netBeforeTax: toDecimal(0),
      vatRate: toDecimal(vatRate, 4),
      isTobacco: product.isTobacco,
      tobaccoTaxBase: tobaccoTax?.tobaccoBase ?? null,
      tobaccoTaxRate: tobaccoTax ? toDecimal(toNumber(tobaccoTax.rate), 4) : null,
      lineTotal: toDecimal(0),
      prepStation: product.prepStation,
      note: input.note ?? null,
      modifiers: modifiers.length > 0 ? (modifiers as unknown as Prisma.JsonArray) : Prisma.JsonNull,
    },
  });

  if (input.lineDiscount && input.lineDiscount > 0) {
    const order = await client.order.findUniqueOrThrow({
      where: { id: orderId },
      select: { userId: true },
    });
    await client.discount.create({
      data: {
        orderId,
        orderItemId: item.id,
        type: DiscountType.AMOUNT,
        scope: DiscountScope.ORDER_ITEM,
        value: toDecimal(input.lineDiscount),
        amount: toDecimal(input.lineDiscount),
        createdById: order.userId,
      },
    });
  }

  return item;
}

export async function addItemToOrder(orderId: string, input: AddItemInput) {
  return prisma.$transaction(async (tx) => {
    const order = await tx.order.findUnique({ where: { id: orderId } });
    if (!order) throw NotFound('الطلب غير موجود');
    assertEditable(order);
    await insertOrderItem(tx, orderId, order.branchId, input);
    return recalculateOrder(tx, orderId);
  });
}

export async function updateItemQuantity(
  orderId: string,
  itemId: string,
  quantity: number,
) {
  return prisma.$transaction(async (tx) => {
    const order = await tx.order.findUnique({ where: { id: orderId } });
    if (!order) throw NotFound('الطلب غير موجود');
    assertEditable(order);

    if (quantity <= 0) {
      await tx.orderItem.delete({ where: { id: itemId } });
    } else {
      await tx.orderItem.update({
        where: { id: itemId },
        data: { quantity: toDecimal(quantity, 3) },
      });
    }
    return recalculateOrder(tx, orderId);
  });
}

/**
 * إلغاء منتج من الطلب. إذا كان الطلب قد أُرسل للتحضير نُبقي السطر
 * ونعلّمه كملغى مع السبب (لا نحذف الأثر)، وإلا نحذفه.
 */
export async function voidOrderItem(
  orderId: string,
  itemId: string,
  reason: string,
) {
  return prisma.$transaction(async (tx) => {
    const order = await tx.order.findUnique({ where: { id: orderId } });
    if (!order) throw NotFound('الطلب غير موجود');
    assertEditable(order);

    if (order.status === OrderStatus.SENT_TO_PREP) {
      await tx.orderItem.update({
        where: { id: itemId },
        data: { isVoided: true, voidReason: reason, voidedAt: new Date() },
      });
    } else {
      await tx.orderItem.delete({ where: { id: itemId } });
    }
    return recalculateOrder(tx, orderId);
  });
}

/** تعليق الطلب لاسترجاعه لاحقًا */
export async function holdOrder(orderId: string) {
  const order = await prisma.order.findUnique({ where: { id: orderId } });
  if (!order) throw NotFound('الطلب غير موجود');
  if (order.status !== OrderStatus.DRAFT && order.status !== OrderStatus.SENT_TO_PREP) {
    throw Conflict('لا يمكن تعليق هذا الطلب في حالته الحالية');
  }
  return prisma.order.update({
    where: { id: orderId },
    data: { status: OrderStatus.HELD },
    include: ORDER_INCLUDE,
  });
}

export async function resumeOrder(orderId: string) {
  const order = await prisma.order.findUnique({ where: { id: orderId } });
  if (!order) throw NotFound('الطلب غير موجود');
  if (order.status !== OrderStatus.HELD) {
    throw Conflict('الطلب غير معلق');
  }
  return prisma.order.update({
    where: { id: orderId },
    data: { status: OrderStatus.DRAFT },
    include: ORDER_INCLUDE,
  });
}

/** إلغاء الطلب قبل الدفع — لا يُحذف الطلب بل تتغير حالته */
export async function cancelOrder(orderId: string, reason: string) {
  return prisma.$transaction(async (tx) => {
    const order = await tx.order.findUnique({
      where: { id: orderId },
      include: { invoices: true },
    });
    if (!order) throw NotFound('الطلب غير موجود');
    if (order.invoices.some((inv) => inv.status === 'PAID')) {
      throw Conflict('لا يمكن إلغاء طلب مرتبط بفاتورة مدفوعة — استخدم المرتجعات');
    }
    if (order.status === OrderStatus.CANCELLED) {
      throw Conflict('الطلب ملغى مسبقًا');
    }

    const updated = await tx.order.update({
      where: { id: orderId },
      data: {
        status: OrderStatus.CANCELLED,
        cancelledAt: new Date(),
        cancelReason: reason,
      },
      include: ORDER_INCLUDE,
    });

    await tx.invoice.updateMany({
      where: { orderId, status: { in: ['DRAFT', 'HELD', 'SENT_TO_PREP', 'COMPLETED'] } },
      data: { status: 'CANCELLED', cancelledAt: new Date(), cancelReason: reason },
    });

    if (order.tableId) {
      await releaseTableIfIdle(tx, order.tableId, orderId);
    }
    return updated;
  });
}

/** تحرير الطاولة عندما لا يبقى عليها أي طلب نشط */
export async function releaseTableIfIdle(
  client: TransactionClient,
  tableId: string,
  excludeOrderId?: string,
) {
  const activeCount = await client.order.count({
    where: {
      tableId,
      id: excludeOrderId ? { not: excludeOrderId } : undefined,
      status: { in: [OrderStatus.DRAFT, OrderStatus.HELD, OrderStatus.SENT_TO_PREP] },
    },
  });
  if (activeCount === 0) {
    await client.restaurantTable.update({
      where: { id: tableId },
      data: { status: TableStatus.NEEDS_CLEANING },
    });
  }
}

/** إرسال الطلب لمحطات التحضير وإنشاء تذاكر المطبخ/البار/الشيشة */
export async function sendOrderToPreparation(orderId: string) {
  return prisma.$transaction(async (tx) => {
    const order = await tx.order.findUnique({
      where: { id: orderId },
      include: { items: true, table: true },
    });
    if (!order) throw NotFound('الطلب غير موجود');
    assertEditable(order);

    const pending = order.items.filter((item) => !item.isVoided);
    if (pending.length === 0) throw UnprocessableEntity('الطلب لا يحتوي على أصناف');

    // تجميع الأصناف حسب محطة التحضير
    const byStation = new Map<PrepStation, typeof pending>();
    for (const item of pending) {
      if (item.prepStation === 'NONE') continue;
      const list = byStation.get(item.prepStation) ?? [];
      list.push(item);
      byStation.set(item.prepStation, list);
    }

    const created = [];
    for (const [station, items] of byStation) {
      // لا نعيد إنشاء تذكرة لنفس المحطة إن كانت قائمة بالفعل
      const existing = await tx.kitchenTicket.findFirst({
        where: { orderId, station, status: { notIn: ['CANCELLED', 'SERVED'] } },
      });
      const payload = {
        orderNumber: order.orderNumber,
        orderType: order.type,
        tableNumber: order.table?.number ?? null,
        guestCount: order.guestCount,
        note: order.note,
        items: items.map((item) => ({
          name: item.nameAr,
          quantity: toNumber(item.quantity),
          note: item.note,
          modifiers: item.modifiers,
        })),
      };

      if (existing) {
        created.push(
          await tx.kitchenTicket.update({
            where: { id: existing.id },
            data: { payload: payload as unknown as Prisma.JsonObject, status: 'QUEUED' },
          }),
        );
      } else {
        const count = await tx.kitchenTicket.count({ where: { orderId } });
        created.push(
          await tx.kitchenTicket.create({
            data: {
              orderId,
              station,
              ticketNo: `${order.orderNumber}-${count + 1}`,
              payload: payload as unknown as Prisma.JsonObject,
            },
          }),
        );
      }
    }

    await tx.order.update({
      where: { id: orderId },
      data: { status: OrderStatus.SENT_TO_PREP, sentToPrepAt: new Date() },
    });

    return { order: await recalculateOrder(tx, orderId), tickets: created };
  });
}

/** نقل الطلب إلى طاولة أخرى */
export async function transferOrderTable(orderId: string, targetTableId: string) {
  return prisma.$transaction(async (tx) => {
    const order = await tx.order.findUnique({ where: { id: orderId } });
    if (!order) throw NotFound('الطلب غير موجود');
    assertEditable(order);

    const target = await tx.restaurantTable.findFirst({
      where: { id: targetTableId, branchId: order.branchId, isActive: true },
    });
    if (!target) throw NotFound('الطاولة الهدف غير موجودة');

    const previousTableId = order.tableId;
    const updated = await tx.order.update({
      where: { id: orderId },
      data: { tableId: targetTableId },
      include: ORDER_INCLUDE,
    });

    await tx.restaurantTable.update({
      where: { id: targetTableId },
      data: { status: TableStatus.OCCUPIED },
    });
    if (previousTableId && previousTableId !== targetTableId) {
      await releaseTableIfIdle(tx, previousTableId, orderId);
    }
    return updated;
  });
}

/** دمج طلبين — تنتقل أسطر المصدر إلى الهدف ويُعلّم المصدر كمدموج */
export async function mergeOrders(sourceOrderId: string, targetOrderId: string) {
  if (sourceOrderId === targetOrderId) {
    throw BadRequest('لا يمكن دمج الطلب مع نفسه');
  }
  return prisma.$transaction(async (tx) => {
    const source = await tx.order.findUnique({
      where: { id: sourceOrderId },
      include: { items: true },
    });
    const target = await tx.order.findUnique({ where: { id: targetOrderId } });
    if (!source || !target) throw NotFound('أحد الطلبين غير موجود');
    assertEditable(source);
    assertEditable(target);
    if (source.branchId !== target.branchId) {
      throw BadRequest('لا يمكن دمج طلبات من فروع مختلفة');
    }

    await tx.orderItem.updateMany({
      where: { orderId: sourceOrderId },
      data: { orderId: targetOrderId },
    });
    await tx.discount.updateMany({
      where: { orderId: sourceOrderId },
      data: { orderId: targetOrderId },
    });
    await tx.order.update({
      where: { id: sourceOrderId },
      data: {
        status: OrderStatus.CANCELLED,
        mergedIntoId: targetOrderId,
        cancelledAt: new Date(),
        cancelReason: `تم الدمج مع الطلب ${target.orderNumber}`,
      },
    });
    if (source.tableId) {
      await releaseTableIfIdle(tx, source.tableId, sourceOrderId);
    }
    await recalculateOrder(tx, sourceOrderId);
    return recalculateOrder(tx, targetOrderId);
  });
}

/**
 * تقسيم الطلب: نقل مجموعة من الأسطر إلى طلب جديد على نفس الطاولة.
 * يُستخدم لتقسيم الفاتورة بين أكثر من عميل.
 */
export async function splitOrder(
  orderId: string,
  itemIds: string[],
  userId: string,
): Promise<{ source: OrderWithRelations; target: OrderWithRelations }> {
  if (itemIds.length === 0) throw BadRequest('حدد الأصناف المراد فصلها');

  return prisma.$transaction(async (tx) => {
    const order = await tx.order.findUnique({
      where: { id: orderId },
      include: { items: true },
    });
    if (!order) throw NotFound('الطلب غير موجود');
    assertEditable(order);

    const movable = order.items.filter((i) => itemIds.includes(i.id) && !i.isVoided);
    if (movable.length === 0) throw BadRequest('الأصناف المحددة غير موجودة في الطلب');
    if (movable.length === order.items.filter((i) => !i.isVoided).length) {
      throw BadRequest('لا يمكن نقل جميع الأصناف — استخدم النقل بدل التقسيم');
    }

    const settings = await getBranchSettings(order.branchId, tx);
    const orderNumber = await nextOrderNumber(
      tx,
      order.branchId,
      order.businessDay,
      settings.orderPrefix,
    );

    const newOrder = await tx.order.create({
      data: {
        branchId: order.branchId,
        orderNumber,
        type: order.type,
        status: OrderStatus.DRAFT,
        tableId: order.tableId,
        guestCount: order.guestCount,
        userId,
        shiftId: order.shiftId,
        businessDay: order.businessDay,
        note: `مقسّمة من الطلب ${order.orderNumber}`,
      },
    });

    await tx.orderItem.updateMany({
      where: { id: { in: movable.map((i) => i.id) } },
      data: { orderId: newOrder.id },
    });
    await tx.discount.updateMany({
      where: { orderItemId: { in: movable.map((i) => i.id) } },
      data: { orderId: newOrder.id },
    });

    return {
      source: await recalculateOrder(tx, orderId),
      target: await recalculateOrder(tx, newOrder.id),
    };
  });
}
