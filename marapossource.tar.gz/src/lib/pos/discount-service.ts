import { DiscountScope, DiscountType } from '@prisma/client';
import { prisma } from '@/lib/prisma';
import { BadRequest, Conflict, Forbidden, NotFound } from '@/lib/api/errors';
import { round2, toDecimal, toNumber } from '@/lib/money';
import { getBranchSettings } from '@/lib/settings';
import { assertEditable, recalculateOrder } from '@/lib/pos/order-service';
import { computeOrderDiscountAmount } from '@/lib/pos/tax-engine';
import { hasPermission } from '@/lib/auth/permissions';

export interface ApplyDiscountInput {
  orderId: string;
  /** فارغ = خصم على كامل الفاتورة */
  orderItemId?: string | null;
  type: DiscountType;
  value: number;
  reason?: string | null;
  couponCode?: string | null;
  userId: string;
  userPermissions: string[];
  /** معرف المدير المعتمد عند الحاجة */
  approvedById?: string | null;
}

/**
 * تطبيق خصم مع التحقق من:
 *  - الحد الأعلى للخصم من إعدادات الفرع.
 *  - صلاحية المستخدم.
 *  - الحاجة إلى اعتماد مدير.
 *  - صلاحية الكوبون ومدته وحد استخدامه.
 */
export async function applyDiscount(input: ApplyDiscountInput) {
  if (input.value <= 0) throw BadRequest('قيمة الخصم يجب أن تكون أكبر من صفر');
  if (!hasPermission(input.userPermissions, 'discounts.apply')) {
    throw Forbidden('لا تملك صلاحية تطبيق الخصومات');
  }

  return prisma.$transaction(async (tx) => {
    const order = await tx.order.findUnique({
      where: { id: input.orderId },
      include: { items: true },
    });
    if (!order) throw NotFound('الطلب غير موجود');
    assertEditable(order);

    const settings = await getBranchSettings(order.branchId, tx);

    // قاعدة الخصم: صافي السطر أو صافي الطلب
    let base: number;
    if (input.orderItemId) {
      const item = order.items.find((i) => i.id === input.orderItemId);
      if (!item) throw NotFound('الصنف غير موجود في الطلب');
      base = round2(toNumber(item.lineSubtotal));
    } else {
      base = round2(
        order.items
          .filter((i) => !i.isVoided)
          .reduce((acc, i) => acc + toNumber(i.lineSubtotal), 0),
      );
    }
    if (base <= 0) throw BadRequest('لا يمكن تطبيق خصم على قيمة صفرية');

    let couponId: string | null = null;
    let type = input.type;
    let value = input.value;
    let maxAmount: number | null = null;

    if (input.couponCode) {
      const coupon = await tx.coupon.findUnique({
        where: { code: input.couponCode.trim().toUpperCase() },
      });
      if (!coupon || !coupon.isActive) throw NotFound('كوبون الخصم غير صالح');
      const now = new Date();
      if (coupon.startsAt && coupon.startsAt > now) {
        throw Conflict('الكوبون لم يبدأ بعد');
      }
      if (coupon.endsAt && coupon.endsAt < now) {
        throw Conflict('انتهت صلاحية الكوبون');
      }
      if (coupon.usageLimit != null && coupon.usedCount >= coupon.usageLimit) {
        throw Conflict('تم استنفاد عدد مرات استخدام الكوبون');
      }
      couponId = coupon.id;
      type = coupon.type === DiscountType.PERCENT ? DiscountType.PERCENT : DiscountType.AMOUNT;
      value = toNumber(coupon.value);
      maxAmount = coupon.maxAmount ? toNumber(coupon.maxAmount) : null;
      await tx.coupon.update({
        where: { id: coupon.id },
        data: { usedCount: { increment: 1 } },
      });
    }

    const amount = computeOrderDiscountAmount(
      { type: type === DiscountType.PERCENT ? 'PERCENT' : 'AMOUNT', value, maxAmount },
      base,
    );

    // التحقق من الحد الأعلى المسموح به كنسبة من القاعدة
    const percentOfBase = base > 0 ? (amount / base) * 100 : 0;
    const maxPercent = toNumber(settings.maxDiscountPercent);
    if (percentOfBase > maxPercent + 1e-9) {
      throw BadRequest(
        `الخصم (${percentOfBase.toFixed(1)}%) يتجاوز الحد الأعلى المسموح (${maxPercent}%)`,
      );
    }

    // الحاجة إلى اعتماد مدير
    const selfApproved = hasPermission(input.userPermissions, 'discounts.approve');
    if (settings.requireManagerForDiscount && !selfApproved && !input.approvedById) {
      throw Forbidden('هذا الخصم يحتاج اعتماد المدير');
    }

    // خصم واحد فقط على مستوى الطلب — نستبدل السابق
    if (!input.orderItemId) {
      await tx.discount.deleteMany({
        where: { orderId: input.orderId, scope: DiscountScope.ORDER },
      });
    } else {
      await tx.discount.deleteMany({
        where: { orderItemId: input.orderItemId, scope: DiscountScope.ORDER_ITEM },
      });
    }

    const discount = await tx.discount.create({
      data: {
        orderId: input.orderId,
        orderItemId: input.orderItemId ?? null,
        couponId,
        type: couponId ? DiscountType.COUPON : type,
        scope: input.orderItemId ? DiscountScope.ORDER_ITEM : DiscountScope.ORDER,
        value: toDecimal(value, 4),
        amount: toDecimal(amount),
        reason: input.reason ?? null,
        approvedById: input.approvedById ?? (selfApproved ? input.userId : null),
        createdById: input.userId,
      },
    });

    const updatedOrder = await recalculateOrder(tx, input.orderId);
    return { discount, order: updatedOrder };
  });
}

/** إزالة خصم */
export async function removeDiscount(orderId: string, discountId: string) {
  return prisma.$transaction(async (tx) => {
    const order = await tx.order.findUnique({ where: { id: orderId } });
    if (!order) throw NotFound('الطلب غير موجود');
    assertEditable(order);
    await tx.discount.delete({ where: { id: discountId } });
    return recalculateOrder(tx, orderId);
  });
}
