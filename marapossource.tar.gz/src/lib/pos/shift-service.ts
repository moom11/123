import {
  CashMovementType,
  Prisma,
  ShiftStatus,
  SyncEntity,
} from '@prisma/client';
import { prisma, type TransactionClient } from '@/lib/prisma';
import { BadRequest, Conflict, NotFound } from '@/lib/api/errors';
import { round2, toDecimal, toNumber } from '@/lib/money';
import { nextShiftNumber } from '@/lib/sequences';
import { currentBusinessDay, getBranchSettings } from '@/lib/settings';
import { enqueueSyncJob } from '@/lib/odoo/sync-queue';

/** الحركات التي تدخل نقدًا إلى الصندوق */
const CASH_IN_TYPES: CashMovementType[] = [
  CashMovementType.SALE_CASH_IN,
  CashMovementType.ADVANCE_SETTLEMENT,
];

/** الحركات التي تخرج نقدًا من الصندوق */
const CASH_OUT_TYPES: CashMovementType[] = [
  CashMovementType.EXPENSE,
  CashMovementType.WITHDRAWAL,
  CashMovementType.DEPOSIT_TO_MAIN_SAFE,
  CashMovementType.EMPLOYEE_ADVANCE,
  CashMovementType.REFUND_CASH_OUT,
];

/** إشارة المبلغ حسب نوع الحركة (+ دخول، − خروج) */
export function movementSign(type: CashMovementType): number {
  if (CASH_IN_TYPES.includes(type)) return 1;
  if (CASH_OUT_TYPES.includes(type)) return -1;
  return 0; // OPENING_FLOAT / CLOSING_COUNT / DRAWER_OPEN لا تُحتسب كحركة
}

export interface OpenShiftInput {
  branchId: string;
  userId: string;
  deviceId?: string | null;
  openingFloat: number;
  note?: string | null;
}

/** فتح وردية جديدة — لا يُسمح بأكثر من وردية مفتوحة لنفس المستخدم على نفس الجهاز */
export async function openShift(input: OpenShiftInput) {
  if (input.openingFloat < 0) throw BadRequest('الرصيد الافتتاحي لا يمكن أن يكون سالبًا');

  const existing = await prisma.shift.findFirst({
    where: {
      branchId: input.branchId,
      userId: input.userId,
      status: ShiftStatus.OPEN,
    },
  });
  if (existing) throw Conflict('لديك وردية مفتوحة بالفعل — أغلقها قبل فتح وردية جديدة');

  const businessDay = await currentBusinessDay(input.branchId);

  return prisma.$transaction(async (tx) => {
    const shiftNumber = await nextShiftNumber(tx, input.branchId);
    const shift = await tx.shift.create({
      data: {
        branchId: input.branchId,
        userId: input.userId,
        deviceId: input.deviceId ?? null,
        shiftNumber,
        businessDay,
        openingFloat: toDecimal(input.openingFloat),
        openingNote: input.note ?? null,
      },
    });

    if (input.openingFloat > 0) {
      await tx.cashMovement.create({
        data: {
          branchId: input.branchId,
          shiftId: shift.id,
          userId: input.userId,
          type: CashMovementType.OPENING_FLOAT,
          amount: toDecimal(input.openingFloat),
          businessDay,
          note: 'رصيد افتتاحي',
        },
      });
    }

    if (input.deviceId) {
      await tx.device.update({
        where: { id: input.deviceId },
        data: { lastSeenAt: new Date() },
      });
    }

    return shift;
  });
}

export interface ShiftSummary {
  shiftId: string;
  shiftNumber: string;
  status: ShiftStatus;
  openedAt: Date;
  closedAt: Date | null;
  cashierName: string;
  openingFloat: number;
  cashSales: number;
  cardSales: number;
  otherSales: number;
  totalSales: number;
  refunds: number;
  expenses: number;
  withdrawals: number;
  deposits: number;
  employeeAdvances: number;
  drawerOpenCount: number;
  invoiceCount: number;
  expectedCash: number;
  countedCash: number | null;
  cashDifference: number | null;
  vatTotal: number;
  tobaccoTaxTotal: number;
  discountTotal: number;
}

/** ملخص كامل لحالة الوردية — يستخدم في الإغلاق والتقارير والطباعة */
export async function getShiftSummary(
  shiftId: string,
  client: TransactionClient = prisma,
): Promise<ShiftSummary> {
  const shift = await client.shift.findUnique({
    where: { id: shiftId },
    include: { user: { select: { fullName: true } } },
  });
  if (!shift) throw NotFound('الوردية غير موجودة');

  const [payments, movements, invoices, refunds] = await Promise.all([
    client.payment.findMany({
      where: { shiftId, status: 'CAPTURED' },
      include: { paymentMethod: true },
    }),
    client.cashMovement.findMany({ where: { shiftId } }),
    client.invoice.findMany({
      where: { shiftId, status: { in: ['PAID', 'PARTIALLY_REFUNDED', 'REFUNDED'] } },
      select: {
        vatTotal: true,
        tobaccoTaxTotal: true,
        discountTotal: true,
        grandTotal: true,
      },
    }),
    client.refund.findMany({ where: { shiftId } }),
  ]);

  let cashSales = 0;
  let cardSales = 0;
  let otherSales = 0;
  for (const payment of payments) {
    const amount = toNumber(payment.amount);
    if (payment.paymentMethod.affectsCashDrawer) cashSales += amount;
    else if (
      ['MADA', 'VISA', 'MASTERCARD', 'APPLE_PAY'].includes(payment.paymentMethod.type)
    ) {
      cardSales += amount;
    } else otherSales += amount;
  }

  const sumMovements = (type: CashMovementType) =>
    round2(
      movements
        .filter((m) => m.type === type)
        .reduce((acc, m) => acc + Math.abs(toNumber(m.amount)), 0),
    );

  const expenses = sumMovements(CashMovementType.EXPENSE);
  const withdrawals = sumMovements(CashMovementType.WITHDRAWAL);
  const deposits = sumMovements(CashMovementType.DEPOSIT_TO_MAIN_SAFE);
  const employeeAdvances = sumMovements(CashMovementType.EMPLOYEE_ADVANCE);
  const advanceSettlements = sumMovements(CashMovementType.ADVANCE_SETTLEMENT);
  const refundCashOut = sumMovements(CashMovementType.REFUND_CASH_OUT);
  const drawerOpenCount = movements.filter(
    (m) => m.type === CashMovementType.DRAWER_OPEN,
  ).length;

  const openingFloat = toNumber(shift.openingFloat);

  // النقد المتوقع = الافتتاحي + النقد الداخل − النقد الخارج
  const expectedCash = round2(
    openingFloat +
      cashSales +
      advanceSettlements -
      expenses -
      withdrawals -
      deposits -
      employeeAdvances -
      refundCashOut,
  );

  const countedCash = shift.countedCash != null ? toNumber(shift.countedCash) : null;

  return {
    shiftId: shift.id,
    shiftNumber: shift.shiftNumber,
    status: shift.status,
    openedAt: shift.openedAt,
    closedAt: shift.closedAt,
    cashierName: shift.user.fullName,
    openingFloat,
    cashSales: round2(cashSales),
    cardSales: round2(cardSales),
    otherSales: round2(otherSales),
    totalSales: round2(cashSales + cardSales + otherSales),
    refunds: round2(refunds.reduce((acc, r) => acc + toNumber(r.grandTotal), 0)),
    expenses,
    withdrawals,
    deposits,
    employeeAdvances,
    drawerOpenCount,
    invoiceCount: invoices.length,
    expectedCash,
    countedCash,
    cashDifference: countedCash != null ? round2(countedCash - expectedCash) : null,
    vatTotal: round2(invoices.reduce((acc, i) => acc + toNumber(i.vatTotal), 0)),
    tobaccoTaxTotal: round2(
      invoices.reduce((acc, i) => acc + toNumber(i.tobaccoTaxTotal), 0),
    ),
    discountTotal: round2(invoices.reduce((acc, i) => acc + toNumber(i.discountTotal), 0)),
  };
}

export interface CloseShiftInput {
  shiftId: string;
  countedCash: number;
  differenceReason?: string | null;
  note?: string | null;
  /** المستخدم الذي يعتمد الفرق (مدير) */
  approvedById?: string | null;
}

/**
 * إغلاق الوردية مع احتساب الفرق.
 * عند وجود فرق يتجاوز السماحية تُصبح الوردية «بانتظار اعتماد المدير».
 */
export async function closeShift(input: CloseShiftInput) {
  return prisma.$transaction(async (tx) => {
    const shift = await tx.shift.findUnique({ where: { id: input.shiftId } });
    if (!shift) throw NotFound('الوردية غير موجودة');
    if (shift.status === ShiftStatus.CLOSED) throw Conflict('الوردية مغلقة مسبقًا');

    // لا نغلق وردية عليها طلبات مفتوحة
    const openOrders = await tx.order.count({
      where: {
        shiftId: shift.id,
        status: { in: ['DRAFT', 'HELD', 'SENT_TO_PREP'] },
      },
    });
    if (openOrders > 0) {
      throw Conflict(`لا يمكن إغلاق الوردية — يوجد ${openOrders} طلب مفتوح`);
    }

    const summary = await getShiftSummary(input.shiftId, tx);
    const difference = round2(input.countedCash - summary.expectedCash);
    const settings = await getBranchSettings(shift.branchId, tx);
    const tolerance = toNumber(settings.cashDiffTolerance);

    const needsApproval =
      Math.abs(difference) > tolerance && !input.approvedById;

    if (Math.abs(difference) > tolerance && !input.differenceReason) {
      throw BadRequest('يجب إدخال سبب الفرق النقدي قبل إغلاق الوردية');
    }

    await tx.cashMovement.create({
      data: {
        branchId: shift.branchId,
        shiftId: shift.id,
        userId: shift.userId,
        type: CashMovementType.CLOSING_COUNT,
        amount: toDecimal(input.countedCash),
        businessDay: shift.businessDay,
        note: 'جرد إغلاق الوردية',
      },
    });

    const closed = await tx.shift.update({
      where: { id: input.shiftId },
      data: {
        status: needsApproval ? ShiftStatus.PENDING_APPROVAL : ShiftStatus.CLOSED,
        closedAt: new Date(),
        expectedCash: toDecimal(summary.expectedCash),
        countedCash: toDecimal(input.countedCash),
        cashDifference: toDecimal(difference),
        differenceReason: input.differenceReason ?? null,
        closingNote: input.note ?? null,
        approvedById: input.approvedById ?? null,
        approvedAt: input.approvedById ? new Date() : null,
      },
    });

    return { shift: closed, summary: { ...summary, countedCash: input.countedCash, cashDifference: difference } };
  });
}

/** اعتماد فرق الصندوق من المدير */
export async function approveShiftDifference(
  shiftId: string,
  managerId: string,
  note?: string,
) {
  const shift = await prisma.shift.findUnique({ where: { id: shiftId } });
  if (!shift) throw NotFound('الوردية غير موجودة');
  if (shift.status !== ShiftStatus.PENDING_APPROVAL) {
    throw Conflict('الوردية لا تنتظر اعتمادًا');
  }
  return prisma.shift.update({
    where: { id: shiftId },
    data: {
      status: ShiftStatus.CLOSED,
      approvedById: managerId,
      approvedAt: new Date(),
      closingNote: note ?? shift.closingNote,
    },
  });
}

export interface CashMovementInput {
  branchId: string;
  shiftId?: string | null;
  userId: string;
  type: CashMovementType;
  amount: number;
  note?: string | null;
  categoryId?: string | null;
  documentUrl?: string | null;
}

/**
 * تسجيل حركة صندوق.
 * ملاحظة محاسبية: الإيداع في الصندوق الرئيسي ليس مصروفًا —
 * يُخزن بنوع DEPOSIT_TO_MAIN_SAFE ويُعرض منفصلًا في التقارير.
 */
export async function recordCashMovement(input: CashMovementInput) {
  if (input.amount <= 0 && input.type !== CashMovementType.DRAWER_OPEN) {
    throw BadRequest('المبلغ يجب أن يكون أكبر من صفر');
  }

  const businessDay = await currentBusinessDay(input.branchId);
  const sign = movementSign(input.type);
  const signedAmount = round2(input.amount * (sign === 0 ? 1 : sign));

  return prisma.$transaction(async (tx) => {
    if (input.shiftId) {
      const shift = await tx.shift.findUnique({ where: { id: input.shiftId } });
      if (!shift) throw NotFound('الوردية غير موجودة');
      if (shift.status !== ShiftStatus.OPEN) {
        throw Conflict('لا يمكن تسجيل حركات على وردية مغلقة');
      }
    }

    const movement = await tx.cashMovement.create({
      data: {
        branchId: input.branchId,
        shiftId: input.shiftId ?? null,
        userId: input.userId,
        type: input.type,
        amount: toDecimal(signedAmount),
        businessDay,
        note: input.note ?? null,
      },
    });

    // المصروفات والعُهد تُسجَّل أيضًا كمستند مصروف قابل للاعتماد والترحيل
    const expenseTypes: CashMovementType[] = [
      CashMovementType.EXPENSE,
      CashMovementType.EMPLOYEE_ADVANCE,
      CashMovementType.ADVANCE_SETTLEMENT,
      CashMovementType.WITHDRAWAL,
      CashMovementType.DEPOSIT_TO_MAIN_SAFE,
    ];

    let expense = null;
    if (expenseTypes.includes(input.type)) {
      expense = await tx.expense.create({
        data: {
          branchId: input.branchId,
          shiftId: input.shiftId ?? null,
          userId: input.userId,
          categoryId: input.categoryId ?? null,
          type: input.type,
          amount: toDecimal(input.amount),
          description: input.note ?? EXPENSE_TYPE_LABELS[input.type],
          documentUrl: input.documentUrl ?? null,
          businessDay,
          cashMovementId: movement.id,
          idempotencyKey: `expense:${movement.id}`,
        },
      });

      // الإيداع في الصندوق الرئيسي ليس مصروفًا محاسبيًا، لكنه يُرحّل كتحويل
      await enqueueSyncJob(tx, {
        branchId: input.branchId,
        entity: SyncEntity.EXPENSE,
        entityId: expense.id,
        idempotencyKey: `expense:${expense.id}`,
      });
    }

    return { movement, expense };
  });
}

export const EXPENSE_TYPE_LABELS: Record<CashMovementType, string> = {
  OPENING_FLOAT: 'رصيد افتتاحي',
  SALE_CASH_IN: 'مبيعات نقدية',
  REFUND_CASH_OUT: 'استرداد نقدي',
  EXPENSE: 'مصروف من الصندوق',
  WITHDRAWAL: 'سحب نقدي',
  DEPOSIT_TO_MAIN_SAFE: 'إيداع في الصندوق الرئيسي',
  EMPLOYEE_ADVANCE: 'عهدة موظف',
  ADVANCE_SETTLEMENT: 'استرداد عهدة',
  DRAWER_OPEN: 'فتح درج النقد',
  CLOSING_COUNT: 'جرد الإغلاق',
};

/** الوردية المفتوحة الحالية للمستخدم */
export async function getCurrentShift(branchId: string, userId: string) {
  return prisma.shift.findFirst({
    where: { branchId, userId, status: ShiftStatus.OPEN },
    orderBy: { openedAt: 'desc' },
    include: { user: { select: { fullName: true, employeeNo: true } }, device: true },
  });
}

/** تسجيل فتح درج النقد (للتدقيق) */
export async function recordDrawerOpen(
  branchId: string,
  shiftId: string,
  userId: string,
  reason: string,
) {
  const businessDay = await currentBusinessDay(branchId);
  return prisma.cashMovement.create({
    data: {
      branchId,
      shiftId,
      userId,
      type: CashMovementType.DRAWER_OPEN,
      amount: new Prisma.Decimal(0),
      businessDay,
      note: reason,
    },
  });
}
