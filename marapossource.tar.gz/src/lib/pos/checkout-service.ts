import {
  InvoiceStatus,
  OrderStatus,
  Prisma,
  ShiftStatus,
  SyncEntity,
  TableStatus,
} from '@prisma/client';
import { prisma, type TransactionClient } from '@/lib/prisma';
import { BadRequest, Conflict, NotFound, UnprocessableEntity } from '@/lib/api/errors';
import { amountsMatch, round2, toDecimal, toNumber } from '@/lib/money';
import { nextInvoiceNumber } from '@/lib/sequences';
import { getBranchSettings } from '@/lib/settings';
import { generateZatcaQr } from '@/lib/pos/zatca-qr';
import { releaseTableIfIdle } from '@/lib/pos/order-service';
import { enqueueSyncJob } from '@/lib/odoo/sync-queue';

export interface PaymentInput {
  paymentMethodId: string;
  amount: number;
  /** المبلغ المستلم فعليًا (للنقد) */
  receivedAmount?: number | null;
  reference?: string | null;
}

export interface CheckoutInput {
  orderId: string;
  userId: string;
  shiftId?: string | null;
  payments: PaymentInput[];
  customerName?: string | null;
  customerPhone?: string | null;
  /** مفتاح منع التكرار المرسل من الجهاز — يمنع إغلاق نفس الفاتورة مرتين */
  idempotencyKey?: string | null;
}

export const INVOICE_INCLUDE = {
  items: true,
  payments: { include: { paymentMethod: true } },
  refunds: { include: { items: true } },
  user: { select: { id: true, fullName: true, employeeNo: true } },
  order: { select: { id: true, orderNumber: true, type: true, guestCount: true } },
} satisfies Prisma.InvoiceInclude;

export type InvoiceWithRelations = Prisma.InvoiceGetPayload<{
  include: typeof INVOICE_INCLUDE;
}>;

/**
 * إغلاق الطلب وإصدار فاتورة مدفوعة داخل معاملة قاعدة بيانات واحدة.
 *
 * القواعد المطبقة:
 *  - لا تُغلق الفاتورة إذا لم يساوِ مجموع المدفوعات الإجمالي المطلوب
 *    (مع سماحية تقريب قابلة للضبط من الإعدادات).
 *  - يُمنع تكرار إغلاق نفس الطلب عبر مفتاح منع التكرار.
 *  - تُخزن نسخة ثابتة من الضرائب داخل الفاتورة.
 *  - تُدرج مهمة مزامنة مع Odoo دون تعطيل البيع عند تعذر الاتصال.
 */
export async function checkoutOrder(input: CheckoutInput): Promise<InvoiceWithRelations> {
  if (input.payments.length === 0) {
    throw BadRequest('يجب تحديد طريقة دفع واحدة على الأقل');
  }
  if (input.payments.some((p) => p.amount <= 0)) {
    throw BadRequest('مبالغ الدفع يجب أن تكون أكبر من صفر');
  }

  const idempotencyKey = input.idempotencyKey ?? `checkout:${input.orderId}`;

  // فحص مبكر خارج المعاملة: هل أُغلق هذا الطلب مسبقًا؟
  const already = await prisma.invoice.findUnique({
    where: { idempotencyKey },
    include: INVOICE_INCLUDE,
  });
  if (already) return already;

  const invoiceId = await prisma.$transaction(
    async (tx) => {
      const order = await tx.order.findUnique({
        where: { id: input.orderId },
        include: { items: true, table: true, branch: { include: { company: true } } },
      });
      if (!order) throw NotFound('الطلب غير موجود');
      if (order.status === OrderStatus.CANCELLED) {
        throw Conflict('الطلب ملغى ولا يمكن تحصيله');
      }
      if (order.status === OrderStatus.PAID) {
        throw Conflict('الطلب مدفوع مسبقًا');
      }

      const activeItems = order.items.filter((item) => !item.isVoided);
      if (activeItems.length === 0) {
        throw UnprocessableEntity('لا يمكن إصدار فاتورة لطلب بدون أصناف');
      }

      const settings = await getBranchSettings(order.branchId, tx);
      const grandTotal = toNumber(order.grandTotal);

      // التحقق من تطابق المدفوعات مع الإجمالي ضمن سماحية التقريب
      const paymentMethods = await tx.paymentMethod.findMany({
        where: { id: { in: input.payments.map((p) => p.paymentMethodId) } },
      });
      if (paymentMethods.length !== new Set(input.payments.map((p) => p.paymentMethodId)).size) {
        throw NotFound('إحدى طرق الدفع المحددة غير موجودة');
      }
      const inactive = paymentMethods.find((m) => !m.isActive);
      if (inactive) {
        throw UnprocessableEntity(`طريقة الدفع «${inactive.nameAr}» غير مفعلة`);
      }
      const creditMethod = paymentMethods.find((m) => m.type === 'CREDIT');
      if (creditMethod && !settings.enableCreditPayment) {
        throw UnprocessableEntity('الدفع الآجل معطل من إعدادات الفرع');
      }

      const paidTotal = round2(input.payments.reduce((acc, p) => acc + p.amount, 0));
      const tolerance = toNumber(settings.paymentRoundingTolerance);
      if (!amountsMatch(paidTotal, grandTotal, tolerance)) {
        throw UnprocessableEntity(
          `مجموع المدفوعات (${paidTotal.toFixed(2)}) لا يساوي إجمالي الفاتورة (${grandTotal.toFixed(2)})`,
          { paidTotal, grandTotal, tolerance },
        );
      }

      // الوردية: نستخدم المحددة أو الوردية المفتوحة للمستخدم
      const shift = input.shiftId
        ? await tx.shift.findUnique({ where: { id: input.shiftId } })
        : await tx.shift.findFirst({
            where: {
              branchId: order.branchId,
              userId: input.userId,
              status: ShiftStatus.OPEN,
            },
            orderBy: { openedAt: 'desc' },
          });
      if (shift && shift.status !== ShiftStatus.OPEN) {
        throw Conflict('الوردية المحددة مغلقة');
      }

      const invoiceNumber = await nextInvoiceNumber(
        tx,
        order.branchId,
        settings.invoicePrefix,
      );

      const subtotal = toNumber(order.subtotal);
      const discountTotal = toNumber(order.discountTotal);
      const vatTotal = toNumber(order.vatTotal);
      const tobaccoTaxTotal = toNumber(order.tobaccoTaxTotal);
      const netBeforeTax = round2(subtotal - discountTotal);

      // نسخة ثابتة من إعدادات الضرائب وقت البيع
      const taxSnapshot = {
        capturedAt: new Date().toISOString(),
        vat: {
          totalRate: activeItems.length > 0 ? toNumber(activeItems[0].vatRate) : 0,
          amount: vatTotal,
          rates: Array.from(
            new Set(activeItems.map((i) => toNumber(i.vatRate))),
          ),
        },
        tobacco: {
          amount: tobaccoTaxTotal,
          lines: activeItems
            .filter((i) => i.isTobacco)
            .map((i) => ({
              sku: i.sku,
              base: i.tobaccoTaxBase,
              rate: i.tobaccoTaxRate ? toNumber(i.tobaccoTaxRate) : null,
              amount: toNumber(i.tobaccoTaxAmount),
            })),
        },
      };

      const cashPayment = input.payments.find((p) => {
        const method = paymentMethods.find((m) => m.id === p.paymentMethodId);
        return method?.affectsCashDrawer;
      });
      const receivedCash = cashPayment?.receivedAmount ?? cashPayment?.amount ?? 0;
      const changeDue =
        cashPayment && cashPayment.receivedAmount
          ? round2(Math.max(receivedCash - cashPayment.amount, 0))
          : 0;

      const company = order.branch.company;
      const invoice = await tx.invoice.create({
        data: {
          branchId: order.branchId,
          orderId: order.id,
          invoiceNumber,
          status: InvoiceStatus.PAID,
          type: order.type,
          userId: input.userId,
          shiftId: shift?.id ?? null,
          businessDay: order.businessDay,
          tableNumber: order.table?.number ?? null,
          customerName: input.customerName ?? order.customerName,
          customerPhone: input.customerPhone ?? order.customerPhone,
          subtotal: toDecimal(subtotal),
          discountTotal: toDecimal(discountTotal),
          netBeforeTax: toDecimal(netBeforeTax),
          vatTotal: toDecimal(vatTotal),
          tobaccoTaxTotal: toDecimal(tobaccoTaxTotal),
          grandTotal: toDecimal(grandTotal),
          paidTotal: toDecimal(paidTotal),
          changeDue: toDecimal(changeDue),
          taxSnapshot: taxSnapshot as unknown as Prisma.JsonObject,
          idempotencyKey,
          closedAt: new Date(),
          qrPayload: settings.showQrOnInvoice
            ? generateZatcaQr({
                sellerName: company.nameAr,
                vatNumber: company.vatNumber ?? '',
                timestamp: new Date(),
                totalWithVat: grandTotal,
                vatAmount: vatTotal,
              })
            : null,
        },
      });

      // أسطر الفاتورة — نسخة ثابتة من أسطر الطلب
      for (const item of activeItems) {
        await tx.invoiceItem.create({
          data: {
            invoiceId: invoice.id,
            orderItemId: item.id,
            productId: item.productId,
            nameAr: item.nameAr,
            sku: item.sku,
            quantity: item.quantity,
            unitPrice: item.unitPrice,
            lineSubtotal: item.lineSubtotal,
            discountAmount: item.discountAmount,
            netBeforeTax: item.netBeforeTax,
            vatRate: item.vatRate,
            vatAmount: item.vatAmount,
            isTobacco: item.isTobacco,
            tobaccoTaxAmount: item.tobaccoTaxAmount,
            lineTotal: item.lineTotal,
            prepStation: item.prepStation,
            modifiers: item.modifiers ?? Prisma.JsonNull,
            note: item.note,
          },
        });
      }

      // المدفوعات
      for (const [index, payment] of input.payments.entries()) {
        const method = paymentMethods.find((m) => m.id === payment.paymentMethodId)!;
        const isCash = method.affectsCashDrawer;
        await tx.payment.create({
          data: {
            invoiceId: invoice.id,
            paymentMethodId: payment.paymentMethodId,
            shiftId: shift?.id ?? null,
            amount: toDecimal(payment.amount),
            receivedAmount:
              payment.receivedAmount != null ? toDecimal(payment.receivedAmount) : null,
            changeAmount: isCash ? toDecimal(changeDue) : toDecimal(0),
            reference: payment.reference ?? null,
            businessDay: order.businessDay,
            idempotencyKey: `${idempotencyKey}:pay:${index}`,
          },
        });

        // حركة صندوق للمدفوعات النقدية
        if (isCash && shift) {
          await tx.cashMovement.create({
            data: {
              branchId: order.branchId,
              shiftId: shift.id,
              userId: input.userId,
              type: 'SALE_CASH_IN',
              amount: toDecimal(payment.amount),
              businessDay: order.businessDay,
              note: `مبيعات نقدية — فاتورة ${invoiceNumber}`,
              referenceId: invoice.id,
            },
          });
        }
      }

      await tx.order.update({
        where: { id: order.id },
        data: {
          status: OrderStatus.PAID,
          closedAt: new Date(),
          shiftId: shift?.id ?? order.shiftId,
        },
      });

      await tx.invoiceChangeLog.create({
        data: {
          invoiceId: invoice.id,
          userId: input.userId,
          action: 'INVOICE_CLOSED',
          newValue: {
            invoiceNumber,
            grandTotal,
            paidTotal,
            payments: input.payments.map((p) => ({
              methodId: p.paymentMethodId,
              amount: p.amount,
            })),
          } as unknown as Prisma.JsonObject,
        },
      });

      if (order.tableId) {
        await tx.restaurantTable.update({
          where: { id: order.tableId },
          data: { status: TableStatus.NEEDS_CLEANING },
        });
        await releaseTableIfIdle(tx, order.tableId, order.id);
      }

      // إدراج مهمة المزامنة داخل نفس المعاملة لضمان الاتساق
      await enqueueSyncJob(tx, {
        branchId: order.branchId,
        entity: SyncEntity.INVOICE,
        entityId: invoice.id,
        idempotencyKey: `invoice:${invoice.id}`,
      });

      return invoice.id;
    },
    { timeout: 20000, isolationLevel: Prisma.TransactionIsolationLevel.ReadCommitted },
  );

  return prisma.invoice.findUniqueOrThrow({
    where: { id: invoiceId },
    include: INVOICE_INCLUDE,
  });
}

/** إلغاء فاتورة مكتملة — لا تُحذف أبدًا، فقط تتغير حالتها */
export async function cancelInvoice(
  invoiceId: string,
  userId: string,
  reason: string,
): Promise<InvoiceWithRelations> {
  return prisma.$transaction(async (tx) => {
    const invoice = await tx.invoice.findUnique({
      where: { id: invoiceId },
      include: { payments: true },
    });
    if (!invoice) throw NotFound('الفاتورة غير موجودة');
    if (invoice.status === InvoiceStatus.CANCELLED) {
      throw Conflict('الفاتورة ملغاة مسبقًا');
    }
    if (invoice.status === InvoiceStatus.REFUNDED) {
      throw Conflict('الفاتورة مرتجعة بالكامل');
    }

    await tx.payment.updateMany({
      where: { invoiceId },
      data: { status: 'VOIDED' },
    });

    // عكس الحركات النقدية المرتبطة
    const cashPayments = await tx.payment.findMany({
      where: { invoiceId },
      include: { paymentMethod: true },
    });
    for (const payment of cashPayments) {
      if (payment.paymentMethod.affectsCashDrawer && payment.shiftId) {
        await tx.cashMovement.create({
          data: {
            branchId: invoice.branchId,
            shiftId: payment.shiftId,
            userId,
            type: 'REFUND_CASH_OUT',
            amount: toDecimal(-toNumber(payment.amount)),
            businessDay: invoice.businessDay,
            note: `إلغاء فاتورة ${invoice.invoiceNumber}`,
            referenceId: invoice.id,
          },
        });
      }
    }

    const updated = await tx.invoice.update({
      where: { id: invoiceId },
      data: {
        status: InvoiceStatus.CANCELLED,
        cancelledAt: new Date(),
        cancelReason: reason,
      },
      include: INVOICE_INCLUDE,
    });

    await tx.order.update({
      where: { id: invoice.orderId },
      data: { status: OrderStatus.CANCELLED, cancelledAt: new Date(), cancelReason: reason },
    });

    await tx.invoiceChangeLog.create({
      data: {
        invoiceId,
        userId,
        action: 'INVOICE_CANCELLED',
        oldValue: { status: invoice.status } as unknown as Prisma.JsonObject,
        newValue: { status: InvoiceStatus.CANCELLED } as unknown as Prisma.JsonObject,
        reason,
      },
    });

    return updated;
  });
}

/** إجمالي النقد المتوقع في الصندوق لوردية معينة */
export async function computeExpectedCash(
  client: TransactionClient,
  shiftId: string,
): Promise<number> {
  const shift = await client.shift.findUnique({ where: { id: shiftId } });
  if (!shift) throw NotFound('الوردية غير موجودة');

  const movements = await client.cashMovement.findMany({
    where: { shiftId, type: { not: 'DRAWER_OPEN' } },
  });
  const movementsTotal = movements
    .filter((m) => m.type !== 'OPENING_FLOAT' && m.type !== 'CLOSING_COUNT')
    .reduce((acc, m) => acc + toNumber(m.amount), 0);

  return round2(toNumber(shift.openingFloat) + movementsTotal);
}
