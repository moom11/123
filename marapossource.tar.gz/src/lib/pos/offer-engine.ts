import { round2, roundTo } from '@/lib/money';
import { calculateOrderTaxes, type TaxLineInput } from '@/lib/pos/tax-engine';

/**
 * =============================================================================
 * محرك العروض (الباقات بسعر ثابت)
 * =============================================================================
 *
 * مثال: «أي مشروب أقل من 22 ر.س + أي معسل = 55 ر.س».
 *
 * كيف يعمل:
 *  1) يفكك أسطر الطلب إلى وحدات مفردة.
 *  2) يطابق كل مكوّن من مكونات العرض مع الوحدات المؤهلة.
 *  3) يستهلك الوحدات **الأغلى أولًا** — أي أن العميل يحصل دائمًا على أفضل سعر.
 *  4) يحسب الخصم المطلوب ليصبح إجمالي الباقة مساويًا للسعر الثابت بالضبط.
 *  5) يوزع الخصم على الأسطر المشاركة بالتناسب مع صافي الوحدات المستهلكة.
 *
 * الجانب الضريبي: الخصم يُطبق على **الصافي قبل الضريبة**، ثم يعيد محرك
 * الضرائب احتساب ضريبة التبغ وضريبة القيمة المضافة لكل سطر على حدة،
 * فتبقى الضريبتان منفصلتين تمامًا ويظل الإجمالي مطابقًا لسعر العرض.
 */

export interface OfferComponentSpec {
  id: string;
  nameAr: string;
  quantity: number;
  categoryIds: string[];
  productIds: string[];
  maxUnitPrice: number | null;
  minUnitPrice: number | null;
  /** null = لا يهم · true = التبغ فقط · false = غير التبغ */
  tobaccoOnly: boolean | null;
}

export interface OfferSpec {
  id: string;
  nameAr: string;
  /** السعر النهائي للباقة شاملًا جميع الضرائب */
  fixedPrice: number;
  priority: number;
  /** 0 = بلا حد */
  maxPerOrder: number;
  components: OfferComponentSpec[];
}

/** سطر الطلب كما يراه محرك العروض */
export interface OfferLine extends TaxLineInput {
  productId: string;
  categoryId: string;
  /** سعر الوحدة المعروض للعميل (شامل الإضافات) — يُستخدم في شروط المطابقة */
  displayUnitPrice: number;
}

export interface OfferLineDiscount {
  lineId: string;
  /** مبلغ الخصم على الصافي لهذا السطر */
  amount: number;
}

export interface AppliedOffer {
  offerId: string;
  offerName: string;
  /** عدد مرات تطبيق الباقة داخل الطلب */
  timesApplied: number;
  /** السعر الأصلي لمجموع الأصناف المشمولة */
  originalTotal: number;
  /** السعر بعد تطبيق العرض */
  offerTotal: number;
  /** قيمة التوفير للعميل */
  savings: number;
  /** توزيع الخصم على الأسطر (على الصافي) */
  lineDiscounts: OfferLineDiscount[];
  /** تفصيل الوحدات المشمولة للعرض في الواجهة */
  items: { lineId: string; name: string; units: number }[];
}

/** وحدة مفردة مشتقة من سطر الطلب */
interface Unit {
  lineId: string;
  productId: string;
  categoryId: string;
  displayUnitPrice: number;
  netUnitPrice: number;
  isTobacco: boolean;
  name: string;
}

const EPSILON = 0.005;

/** هل تطابق الوحدة شروط المكوّن؟ */
export function unitMatchesComponent(unit: Unit, component: OfferComponentSpec): boolean {
  if (component.productIds.length > 0 && !component.productIds.includes(unit.productId)) {
    return false;
  }
  if (
    component.categoryIds.length > 0 &&
    !component.categoryIds.includes(unit.categoryId)
  ) {
    return false;
  }
  if (component.tobaccoOnly === true && !unit.isTobacco) return false;
  if (component.tobaccoOnly === false && unit.isTobacco) return false;
  if (
    component.maxUnitPrice != null &&
    unit.displayUnitPrice > component.maxUnitPrice + 1e-9
  ) {
    return false;
  }
  if (
    component.minUnitPrice != null &&
    unit.displayUnitPrice < component.minUnitPrice - 1e-9
  ) {
    return false;
  }
  return true;
}

/** يفكك الأسطر إلى وحدات مفردة مع صافي كل وحدة */
function explodeToUnits(lines: OfferLine[], netByLine: Map<string, number>): Unit[] {
  const units: Unit[] = [];
  for (const line of lines) {
    const quantity = Math.floor(line.quantity);
    // الكميات الكسرية لا تدخل في الباقات (لا معنى لنصف شيشة داخل عرض)
    if (quantity < 1) continue;
    const netPerUnit = (netByLine.get(line.id) ?? 0) / line.quantity;
    for (let i = 0; i < quantity; i += 1) {
      units.push({
        lineId: line.id,
        productId: line.productId,
        categoryId: line.categoryId,
        displayUnitPrice: line.displayUnitPrice,
        netUnitPrice: netPerUnit,
        isTobacco: Boolean(line.isTobacco),
        name: (line as OfferLine & { name?: string }).name ?? line.productId,
      });
    }
  }
  return units;
}

/**
 * يحاول تكوين باقة واحدة من الوحدات المتاحة.
 * يستهلك الوحدات الأغلى أولًا لتعظيم فائدة العميل.
 */
function matchOneBundle(
  available: Unit[],
  components: OfferComponentSpec[],
): Unit[] | null {
  const consumed: Unit[] = [];
  const taken = new Set<number>();

  // نبدأ بالمكونات الأكثر تقييدًا (أقل عدد مرشحين) لتفادي الفشل الزائف
  const ordered = [...components].sort((a, b) => {
    const countA = available.filter((u) => unitMatchesComponent(u, a)).length;
    const countB = available.filter((u) => unitMatchesComponent(u, b)).length;
    return countA - countB;
  });

  for (const component of ordered) {
    const candidates = available
      .map((unit, index) => ({ unit, index }))
      .filter(({ unit, index }) => !taken.has(index) && unitMatchesComponent(unit, component))
      // الأغلى أولًا ⇒ أكبر خصم للعميل
      .sort((a, b) => b.unit.displayUnitPrice - a.unit.displayUnitPrice);

    if (candidates.length < component.quantity) return null;

    for (let i = 0; i < component.quantity; i += 1) {
      taken.add(candidates[i].index);
      consumed.push(candidates[i].unit);
    }
  }

  return consumed;
}

/**
 * يحسب إجمالي مجموعة من الوحدات بعد خصم مبلغ معين من صافيها،
 * موزعًا بالتناسب. يستخدمه البحث الثنائي للوصول إلى سعر العرض بدقة.
 */
function bundleTotalAfterNetDiscount(
  bundleUnits: Unit[],
  lines: Map<string, OfferLine>,
  netDiscount: number,
): number {
  const netByLine = new Map<string, number>();
  for (const unit of bundleUnits) {
    netByLine.set(unit.lineId, (netByLine.get(unit.lineId) ?? 0) + unit.netUnitPrice);
  }
  const bundleNet = Array.from(netByLine.values()).reduce((a, b) => a + b, 0);
  if (bundleNet <= 0) return 0;

  // توزيع الخصم بالتناسب مع صافي كل سطر، دون تقريب في هذه المرحلة
  const discountByLine = new Map<string, number>(
    Array.from(netByLine.entries()).map(([lineId, net]) => [
      lineId,
      (net / bundleNet) * netDiscount,
    ]),
  );

  return calculateOrderTaxes(buildBundleLines(bundleUnits, lines, discountByLine))
    .totals.grandTotal;
}

/**
 * يبني أسطرًا افتراضية تمثل الوحدات المشمولة في الباقة فقط.
 *
 * مهم: نحتفظ بسعر الوحدة الأصلي وبعلَم «شامل الضريبة» كما هما، ولا نمرر
 * الصافي المقرّب — وإلا اختلف التقريب عن الاحتساب الحقيقي للطلب وظهر
 * فرق هللة على الفاتورة.
 */
function buildBundleLines(
  bundleUnits: Unit[],
  lines: Map<string, OfferLine>,
  discountByLine: Map<string, number>,
): TaxLineInput[] {
  const unitsByLine = new Map<string, number>();
  for (const unit of bundleUnits) {
    unitsByLine.set(unit.lineId, (unitsByLine.get(unit.lineId) ?? 0) + 1);
  }

  const virtualLines: TaxLineInput[] = [];
  for (const [lineId, units] of unitsByLine) {
    const source = lines.get(lineId);
    if (!source) continue;
    virtualLines.push({
      ...source,
      id: `${lineId}:bundle`,
      quantity: units,
      lineDiscount: discountByLine.get(lineId) ?? 0,
    });
  }
  return virtualLines;
}

/** يحسب إجمالي الباقة بخصومات صريحة لكل سطر (بعد التقريب) */
function bundleTotalWithLineDiscounts(
  bundleUnits: Unit[],
  lines: Map<string, OfferLine>,
  discountByLine: Map<string, number>,
): number {
  return calculateOrderTaxes(buildBundleLines(bundleUnits, lines, discountByLine))
    .totals.grandTotal;
}

/**
 * معامل تحويل الخصم على الصافي إلى أثر على الإجمالي لسطر معين.
 * يستخدم لتصحيح فروق التقريب بمقدار هللة واحدة.
 */
function lineTotalMultiplier(line: OfferLine): number {
  const vatFactor = 1 + (line.vatRate || 0) / 100;
  // المبلغ الثابت لكل وحدة لا يتأثر بتغير الصافي، أما النسبة فتتأثر
  const tobaccoFactor =
    line.isTobacco && (line.tobaccoBase ?? 'PERCENT_OF_PRICE') === 'PERCENT_OF_PRICE'
      ? 1 + (line.tobaccoRate ?? 0) / 100
      : 1;
  return vatFactor * tobaccoFactor;
}

/**
 * يحل عدديًا قيمة الخصم على الصافي التي تجعل إجمالي الباقة مساويًا للسعر المستهدف.
 * البحث الثنائي يتعامل مع كل أنماط الضرائب بما فيها المبلغ الثابت لكل وحدة
 * والحد الأدنى لضريبة التبغ (حيث تكون العلاقة غير خطية).
 */
export function solveNetDiscountForTarget(
  bundleUnits: Unit[],
  lines: Map<string, OfferLine>,
  targetTotal: number,
): number {
  const bundleNet = bundleUnits.reduce((sum, u) => sum + u.netUnitPrice, 0);
  if (bundleNet <= 0) return 0;

  const totalAtZero = bundleTotalAfterNetDiscount(bundleUnits, lines, 0);
  // العرض أغلى من السعر الأصلي ⇒ لا خصم (لا نرفع السعر على العميل أبدًا)
  if (totalAtZero <= targetTotal + EPSILON) return 0;

  let low = 0;
  let high = bundleNet;
  for (let i = 0; i < 60; i += 1) {
    const mid = (low + high) / 2;
    const total = bundleTotalAfterNetDiscount(bundleUnits, lines, mid);
    if (total > targetTotal) low = mid;
    else high = mid;
  }
  return roundTo(high, 4);
}

/** هل العرض ساري المفعول في هذه اللحظة؟ */
export function isOfferActiveNow(
  offer: {
    isActive: boolean;
    startsAt: Date | null;
    endsAt: Date | null;
    daysOfWeek: number[];
    startTime: string | null;
    endTime: string | null;
  },
  now: Date,
  timezone = 'Asia/Riyadh',
): boolean {
  if (!offer.isActive) return false;
  if (offer.startsAt && now < offer.startsAt) return false;
  if (offer.endsAt && now > offer.endsAt) return false;

  const formatter = new Intl.DateTimeFormat('en-US', {
    timeZone: timezone,
    weekday: 'short',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
  const parts = formatter.formatToParts(now);
  const weekdayName = parts.find((p) => p.type === 'weekday')?.value ?? 'Sun';
  const hour = Number(parts.find((p) => p.type === 'hour')?.value ?? '0') % 24;
  const minute = Number(parts.find((p) => p.type === 'minute')?.value ?? '0');

  const weekdayIndex = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(
    weekdayName,
  );
  if (offer.daysOfWeek.length > 0 && !offer.daysOfWeek.includes(weekdayIndex)) {
    return false;
  }

  if (offer.startTime && offer.endTime) {
    const current = hour * 60 + minute;
    const [sh, sm] = offer.startTime.split(':').map(Number);
    const [eh, em] = offer.endTime.split(':').map(Number);
    const start = sh * 60 + (sm || 0);
    const end = eh * 60 + (em || 0);
    // نافذة تعبر منتصف الليل (مثال 20:00 إلى 02:00)
    const inWindow = start <= end
      ? current >= start && current <= end
      : current >= start || current <= end;
    if (!inWindow) return false;
  }

  return true;
}

/**
 * الدالة الرئيسية: تطبق العروض المؤهلة على أسطر الطلب.
 * تعيد قائمة العروض المطبقة مع توزيع الخصم على الأسطر.
 */
export function applyOffers(
  lines: OfferLine[],
  offers: OfferSpec[],
  netByLine: Map<string, number>,
): AppliedOffer[] {
  const lineMap = new Map(lines.map((l) => [l.id, l]));
  let available = explodeToUnits(lines, netByLine);
  const applied: AppliedOffer[] = [];

  // الأولوية الأعلى أولًا، ثم الأكبر توفيرًا للعميل عند التساوي
  const ordered = [...offers].sort((a, b) => b.priority - a.priority);

  for (const offer of ordered) {
    if (offer.components.length === 0) continue;

    const bundles: Unit[][] = [];
    const limit = offer.maxPerOrder > 0 ? offer.maxPerOrder : Number.MAX_SAFE_INTEGER;

    while (bundles.length < limit) {
      const bundle = matchOneBundle(available, offer.components);
      if (!bundle) break;
      bundles.push(bundle);
      // نزيل الوحدات المستهلكة من المتاح
      const remaining = [...available];
      for (const unit of bundle) {
        const index = remaining.indexOf(unit);
        if (index >= 0) remaining.splice(index, 1);
      }
      available = remaining;
    }

    if (bundles.length === 0) continue;

    const allUnits = bundles.flat();
    const originalTotal = bundleTotalAfterNetDiscount(allUnits, lineMap, 0);
    const targetTotal = round2(offer.fixedPrice * bundles.length);
    const netDiscount = solveNetDiscountForTarget(allUnits, lineMap, targetTotal);

    if (netDiscount <= 0) continue;

    // توزيع الخصم على الأسطر بالتناسب مع صافي الوحدات المستهلكة
    const netByBundleLine = new Map<string, number>();
    for (const unit of allUnits) {
      netByBundleLine.set(
        unit.lineId,
        (netByBundleLine.get(unit.lineId) ?? 0) + unit.netUnitPrice,
      );
    }
    const bundleNet = Array.from(netByBundleLine.values()).reduce((a, b) => a + b, 0);

    const discountByLine = new Map<string, number>(
      Array.from(netByBundleLine.entries()).map(([lineId, net]) => [
        lineId,
        round2((net / bundleNet) * netDiscount),
      ]),
    );

    // -------------------------------------------------------------------------
    // تصحيح فروق التقريب
    // -------------------------------------------------------------------------
    // بعد تقريب خصم كل سطر إلى هللتين قد ينحرف الإجمالي بمقدار هللة، فيرى
    // العميل «55.01» على فاتورة عرض سعره 55. نصحح ذلك ببحث صغير.
    //
    // ملاحظة مهمة: تعديل هللة واحدة على سطر تبغ يغيّر الإجمالي بمقدار 0.023
    // (لأن الصافي يمر بضريبة التبغ ثم ض.ق.م)، فلا يمكنه الوصول إلى فرق 0.01.
    // لذلك نبدأ التصحيح من الأسطر ذات أقل معامل ضريبي — عادةً المشروب.
    const candidates = Array.from(netByBundleLine.keys())
      .map((lineId) => ({
        lineId,
        multiplier: lineTotalMultiplier(lineMap.get(lineId)!),
        cap: netByBundleLine.get(lineId) ?? 0,
      }))
      .sort((a, b) => a.multiplier - b.multiplier);

    // نجرب تعديلات صغيرة على كل سطر ونختار الأقرب للسعر المستهدف.
    //
    // قد يكون السعر المستهدف غير قابل للتحقيق تمامًا: فمثلًا سطر بصافي 9.56
    // ينتج إجمالي 10.99، وبصافي 9.57 ينتج 11.01 — لأن الصافي والضريبة
    // يُقرَّبان معًا لأعلى. عندها لا وجود لقيمة تعطي 11.00 بالضبط.
    // في هذه الحالة نختار الأقرب، ومع التعادل نرجّح **الأقل** لصالح العميل.
    let best = {
      total: bundleTotalWithLineDiscounts(allUnits, lineMap, discountByLine),
      discounts: new Map(discountByLine),
    };
    const score = (total: number) => ({
      distance: Math.abs(total - targetTotal),
      // عند تساوي البعد نفضّل الإجمالي الأقل (في مصلحة العميل)
      favoursCustomer: total <= targetTotal ? 0 : 1,
    });

    if (score(best.total).distance >= EPSILON) {
      const steps = [-0.03, -0.02, -0.01, 0.01, 0.02, 0.03];
      for (const candidate of candidates) {
        const original = discountByLine.get(candidate.lineId) ?? 0;
        for (const step of steps) {
          const next = round2(original + step);
          if (next < 0 || next > candidate.cap) continue;
          discountByLine.set(candidate.lineId, next);
          const total = bundleTotalWithLineDiscounts(allUnits, lineMap, discountByLine);
          const a = score(total);
          const b = score(best.total);
          if (
            a.distance < b.distance - 1e-9 ||
            (Math.abs(a.distance - b.distance) < 1e-9 && a.favoursCustomer < b.favoursCustomer)
          ) {
            best = { total, discounts: new Map(discountByLine) };
          }
          discountByLine.set(candidate.lineId, original);
        }
        if (score(best.total).distance < EPSILON) break;
      }
      for (const [lineId, amount] of best.discounts) discountByLine.set(lineId, amount);
    }

    const lineDiscounts: OfferLineDiscount[] = Array.from(discountByLine.entries()).map(
      ([lineId, amount]) => ({ lineId, amount }),
    );

    const itemCounts = new Map<string, number>();
    for (const unit of allUnits) {
      itemCounts.set(unit.lineId, (itemCounts.get(unit.lineId) ?? 0) + 1);
    }

    applied.push({
      offerId: offer.id,
      offerName: offer.nameAr,
      timesApplied: bundles.length,
      originalTotal: round2(originalTotal),
      offerTotal: targetTotal,
      savings: round2(originalTotal - targetTotal),
      lineDiscounts,
      items: Array.from(itemCounts.entries()).map(([lineId, units]) => ({
        lineId,
        name: allUnits.find((u) => u.lineId === lineId)?.name ?? '',
        units,
      })),
    });
  }

  return applied;
}
