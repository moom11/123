/**
 * توليد رمز QR للفاتورة المبسطة وفق متطلبات هيئة الزكاة والضريبة والجمارك (ZATCA).
 * الترميز TLV (Tag-Length-Value) ثم Base64.
 *
 * الحقول الخمسة الإلزامية:
 *   1) اسم البائع
 *   2) الرقم الضريبي للبائع
 *   3) الطابع الزمني (ISO 8601)
 *   4) إجمالي الفاتورة شامل الضريبة
 *   5) إجمالي ضريبة القيمة المضافة
 */

function tlv(tag: number, value: string): Buffer {
  const valueBuffer = Buffer.from(value, 'utf8');
  return Buffer.concat([
    Buffer.from([tag]),
    Buffer.from([valueBuffer.length]),
    valueBuffer,
  ]);
}

export interface ZatcaQrInput {
  sellerName: string;
  vatNumber: string;
  timestamp: Date;
  totalWithVat: number;
  vatAmount: number;
}

export function generateZatcaQr(input: ZatcaQrInput): string {
  const payload = Buffer.concat([
    tlv(1, input.sellerName),
    tlv(2, input.vatNumber),
    tlv(3, input.timestamp.toISOString()),
    tlv(4, input.totalWithVat.toFixed(2)),
    tlv(5, input.vatAmount.toFixed(2)),
  ]);
  return payload.toString('base64');
}
