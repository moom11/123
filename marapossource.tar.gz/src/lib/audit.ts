import type { NextRequest } from 'next/server';
import { prisma, type TransactionClient } from '@/lib/prisma';
import { getClientIp } from '@/lib/api/handler';

/** الأحداث القابلة للتدقيق في النظام */
export const AUDIT_ACTIONS = {
  LOGIN: 'تسجيل الدخول',
  LOGIN_FAILED: 'محاولة دخول فاشلة',
  LOGOUT: 'تسجيل الخروج',
  SHIFT_OPEN: 'فتح وردية',
  SHIFT_CLOSE: 'إغلاق وردية',
  SHIFT_APPROVE_DIFF: 'اعتماد فرق صندوق',
  PRICE_CHANGE: 'تغيير سعر',
  DISCOUNT_APPLIED: 'تطبيق خصم',
  ITEM_VOIDED: 'إلغاء منتج',
  ORDER_CANCELLED: 'إلغاء طلب',
  INVOICE_CANCELLED: 'إلغاء فاتورة',
  INVOICE_CLOSED: 'إغلاق فاتورة',
  REFUND_CREATED: 'إنشاء مرتجع',
  TAX_UPDATED: 'تعديل ضريبة',
  ODOO_SETTINGS_UPDATED: 'تعديل إعدادات Odoo',
  SYNC_RETRY: 'إعادة مزامنة',
  USER_CREATED: 'إنشاء مستخدم',
  USER_UPDATED: 'تعديل مستخدم',
  PRODUCT_CREATED: 'إنشاء منتج',
  PRODUCT_UPDATED: 'تعديل منتج',
  SETTINGS_UPDATED: 'تعديل الإعدادات',
  CASH_MOVEMENT: 'حركة صندوق',
  EXPENSE_CREATED: 'تسجيل مصروف',
  FILE_UPLOADED: 'رفع ملف',
  TABLE_TRANSFER: 'نقل طاولة',
  ORDER_MERGED: 'دمج طلبات',
  INVOICE_SPLIT: 'تقسيم فاتورة',
} as const;

export type AuditAction = keyof typeof AUDIT_ACTIONS;

export interface AuditInput {
  action: AuditAction;
  entity: string;
  entityId?: string | null;
  userId?: string | null;
  branchId?: string | null;
  oldValue?: unknown;
  newValue?: unknown;
  request?: NextRequest;
  ip?: string | null;
  userAgent?: string | null;
}

/**
 * كتابة سجل تدقيق. لا يجب أن يُفشل فشلُ التدقيق العمليةَ الأصلية،
 * لذلك نلتقط الأخطاء ونسجلها فقط.
 */
export async function writeAudit(
  input: AuditInput,
  client: TransactionClient = prisma,
): Promise<void> {
  try {
    await client.auditLog.create({
      data: {
        userId: input.userId ?? null,
        branchId: input.branchId ?? null,
        action: input.action,
        entity: input.entity,
        entityId: input.entityId ?? null,
        oldValue: sanitize(input.oldValue),
        newValue: sanitize(input.newValue),
        ip: input.ip ?? (input.request ? getClientIp(input.request) : null),
        userAgent:
          input.userAgent ?? input.request?.headers.get('user-agent') ?? null,
      },
    });
  } catch (error) {
    console.error('[audit] تعذر كتابة سجل التدقيق:', error);
  }
}

const SENSITIVE_KEYS = [
  'password',
  'passwordHash',
  'apiKey',
  'apiKeyEncrypted',
  'token',
  'refreshToken',
  'managerPin',
  'managerPinHash',
  'secret',
];

/** إزالة أي بيانات حساسة قبل تخزينها في السجل */
export function sanitize(value: unknown): any {
  if (value === null || value === undefined) return undefined;
  if (typeof value !== 'object') return value;
  if (Array.isArray(value)) return value.map(sanitize);

  const result: Record<string, unknown> = {};
  for (const [key, val] of Object.entries(value as Record<string, unknown>)) {
    if (SENSITIVE_KEYS.some((s) => key.toLowerCase().includes(s.toLowerCase()))) {
      result[key] = '***';
    } else if (val instanceof Date) {
      result[key] = val.toISOString();
    } else if (typeof val === 'object' && val !== null) {
      result[key] = sanitize(val);
    } else {
      result[key] = val;
    }
  }
  return result;
}
