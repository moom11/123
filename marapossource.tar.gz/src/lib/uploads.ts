/**
 * =============================================================================
 * رفع الملفات — صور المنتجات ومستندات المصروفات
 * =============================================================================
 * تُحفظ الملفات في public/uploads فتُخدم كملفات ثابتة عبر /uploads/...
 * في Docker المجلد مربوط بـ volume باسم uploads حتى تبقى بعد إعادة البناء.
 *
 * الأمان:
 *  - قائمة بيضاء لأنواع الصور، والتحقق من التوقيع الثنائي (magic bytes)
 *    لا من ترويسة Content-Type التي يتحكم بها العميل
 *  - اسم الملف يُولَّد عشوائيًا ولا يُشتق من اسم المستخدم إطلاقًا،
 *    فلا مجال لاجتياز المسارات (path traversal)
 *  - حد أقصى للحجم يُطبق قبل الكتابة على القرص
 */
import { randomUUID } from 'node:crypto';
import { mkdir, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { BadRequest } from '@/lib/api/errors';

/** الحد الأقصى لحجم الملف بالبايت (5 ميجابايت) */
export const MAX_UPLOAD_BYTES = Number(process.env.MAX_UPLOAD_BYTES ?? 5 * 1024 * 1024);

/** المجلد الفرعي داخل public/uploads */
export type UploadKind = 'products' | 'expenses';

interface ImageType {
  extension: string;
  /** توقيع بداية الملف — نتحقق منه بدل الوثوق بترويسة العميل */
  matches: (bytes: Uint8Array) => boolean;
}

const startsWith = (bytes: Uint8Array, signature: number[], offset = 0) =>
  signature.every((byte, i) => bytes[offset + i] === byte);

/**
 * الأنواع المسموحة فقط. SVG مستثنى عمدًا: يمكن أن يحتوي على JavaScript
 * فيصبح ناقلًا لهجمات XSS عند فتحه مباشرة من نفس النطاق.
 */
const ALLOWED_TYPES: Record<string, ImageType> = {
  'image/jpeg': {
    extension: 'jpg',
    matches: (b) => startsWith(b, [0xff, 0xd8, 0xff]),
  },
  'image/png': {
    extension: 'png',
    matches: (b) => startsWith(b, [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
  },
  'image/webp': {
    extension: 'webp',
    // RIFF....WEBP
    matches: (b) => startsWith(b, [0x52, 0x49, 0x46, 0x46]) && startsWith(b, [0x57, 0x45, 0x42, 0x50], 8),
  },
  'image/gif': {
    extension: 'gif',
    matches: (b) => startsWith(b, [0x47, 0x49, 0x46, 0x38]),
  },
};

export const ALLOWED_MIME_TYPES = Object.keys(ALLOWED_TYPES);

/** يستنتج النوع من التوقيع الثنائي، ويعيد null إن لم يطابق أي نوع مسموح */
export function detectImageType(bytes: Uint8Array): { mime: string; extension: string } | null {
  for (const [mime, type] of Object.entries(ALLOWED_TYPES)) {
    if (type.matches(bytes)) return { mime, extension: type.extension };
  }
  return null;
}

export interface StoredFile {
  /** المسار العام الذي يُحفظ في قاعدة البيانات ويُعرض في الواجهة */
  url: string;
  mime: string;
  size: number;
}

/**
 * يتحقق من الملف ويكتبه على القرص، ويعيد رابطه العام.
 * يرمي BadRequest برسالة عربية عند أي مخالفة.
 */
export async function storeUpload(file: File, kind: UploadKind): Promise<StoredFile> {
  if (file.size === 0) throw BadRequest('الملف فارغ');
  if (file.size > MAX_UPLOAD_BYTES) {
    const mb = (MAX_UPLOAD_BYTES / (1024 * 1024)).toFixed(0);
    throw BadRequest(`حجم الملف يتجاوز الحد المسموح (${mb} ميجابايت)`);
  }

  const bytes = new Uint8Array(await file.arrayBuffer());
  // الحجم الفعلي بعد القراءة — لا نثق بـ file.size وحده
  if (bytes.byteLength > MAX_UPLOAD_BYTES) {
    throw BadRequest('حجم الملف يتجاوز الحد المسموح');
  }

  const detected = detectImageType(bytes);
  if (!detected) {
    throw BadRequest('نوع الملف غير مسموح — الصور المقبولة: JPG، PNG، WebP، GIF');
  }

  const directory = join(process.cwd(), 'public', 'uploads', kind);
  await mkdir(directory, { recursive: true });

  // اسم عشوائي بالكامل: لا يعتمد على أي مدخل من المستخدم
  const filename = `${randomUUID()}.${detected.extension}`;
  await writeFile(join(directory, filename), bytes);

  return {
    url: `/uploads/${kind}/${filename}`,
    mime: detected.mime,
    size: bytes.byteLength,
  };
}
