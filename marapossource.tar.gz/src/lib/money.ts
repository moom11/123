import { Prisma } from '@prisma/client';

/** عدد الخانات العشرية المستخدمة في العرض والتخزين النهائي (هللات) */
export const MONEY_SCALE = 2;

/**
 * التقريب المصرفي المعتاد (half-up) على خانتين عشريتين.
 * نستخدم تصحيح الفاصلة العائمة (epsilon) لتفادي أخطاء مثل 1.005 → 1.00.
 */
export function round2(value: number): number {
  if (!Number.isFinite(value)) return 0;
  const factor = 10 ** MONEY_SCALE;
  return Math.round((value + Number.EPSILON * Math.sign(value || 1)) * factor) / factor;
}

/** تقريب على عدد خانات مخصص — يستخدم للكميات والنسب */
export function roundTo(value: number, decimals: number): number {
  if (!Number.isFinite(value)) return 0;
  const factor = 10 ** decimals;
  return Math.round((value + Number.EPSILON * Math.sign(value || 1)) * factor) / factor;
}

/** تحويل أي قيمة قادمة من Prisma (Decimal) أو من الشبكة إلى رقم */
export function toNumber(value: Prisma.Decimal | number | string | null | undefined): number {
  if (value === null || value === undefined) return 0;
  if (typeof value === 'number') return value;
  if (typeof value === 'string') {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : 0;
  }
  return Number(value.toString());
}

/** تحويل رقم إلى Decimal مقرب لتخزينه في قاعدة البيانات */
export function toDecimal(value: number, decimals = MONEY_SCALE): Prisma.Decimal {
  return new Prisma.Decimal(roundTo(value, decimals).toFixed(decimals));
}

/** مقارنة مبلغين مع سماحية تقريب */
export function amountsMatch(a: number, b: number, tolerance = 0): boolean {
  return Math.abs(round2(a) - round2(b)) <= round2(tolerance) + 1e-9;
}

/** تنسيق المبلغ للعرض بالعربية */
export function formatMoney(value: number | Prisma.Decimal | string, currency = 'SAR'): string {
  const num = toNumber(value as Prisma.Decimal);
  return `${num.toLocaleString('ar-SA', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })} ${currency === 'SAR' ? 'ر.س' : currency}`;
}

/**
 * توزيع مبلغ إجمالي على عدة أسطر بالتناسب مع أوزانها،
 * مع ضمان أن مجموع الأنصبة يساوي المبلغ الأصلي تمامًا (بدون فقد هللات).
 */
export function distributeProportionally(total: number, weights: number[]): number[] {
  const sumWeights = weights.reduce((acc, w) => acc + w, 0);
  if (sumWeights <= 0 || weights.length === 0) {
    return weights.map(() => 0);
  }
  const raw = weights.map((w) => (total * w) / sumWeights);
  const rounded = raw.map((v) => round2(v));
  const drift = round2(total - rounded.reduce((acc, v) => acc + v, 0));
  if (drift !== 0) {
    // نضيف فرق التقريب إلى أكبر سطر لضمان تطابق المجموع
    let largestIndex = 0;
    for (let i = 1; i < raw.length; i += 1) {
      if (raw[i] > raw[largestIndex]) largestIndex = i;
    }
    rounded[largestIndex] = round2(rounded[largestIndex] + drift);
  }
  return rounded;
}
