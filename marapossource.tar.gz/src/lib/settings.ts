import type { BranchSetting } from '@prisma/client';
import { prisma, type TransactionClient } from '@/lib/prisma';
import { DEFAULT_BUSINESS_DAY_START_HOUR, DEFAULT_TIMEZONE, getBusinessDay } from '@/lib/business-day';
import { toNumber } from '@/lib/money';

/** يجلب إعدادات الفرع وينشئ الافتراضية عند عدم وجودها */
export async function getBranchSettings(
  branchId: string,
  client: TransactionClient = prisma,
): Promise<BranchSetting> {
  const existing = await client.branchSetting.findUnique({ where: { branchId } });
  if (existing) return existing;
  return client.branchSetting.create({ data: { branchId } });
}

export interface ResolvedSettings {
  businessDayStartHour: number;
  timezone: string;
  paymentRoundingTolerance: number;
  cashDiffTolerance: number;
  enableDelivery: boolean;
  enableCreditPayment: boolean;
  maxDiscountPercent: number;
  requireManagerForDiscount: boolean;
  invoicePrefix: string;
  orderPrefix: string;
  showQrOnInvoice: boolean;
}

export function resolveSettings(setting: BranchSetting): ResolvedSettings {
  return {
    businessDayStartHour: setting.businessDayStartHour ?? DEFAULT_BUSINESS_DAY_START_HOUR,
    timezone: setting.timezone ?? DEFAULT_TIMEZONE,
    paymentRoundingTolerance: toNumber(setting.paymentRoundingTolerance),
    cashDiffTolerance: toNumber(setting.cashDiffTolerance),
    enableDelivery: setting.enableDelivery,
    enableCreditPayment: setting.enableCreditPayment,
    maxDiscountPercent: toNumber(setting.maxDiscountPercent),
    requireManagerForDiscount: setting.requireManagerForDiscount,
    invoicePrefix: setting.invoicePrefix,
    orderPrefix: setting.orderPrefix,
    showQrOnInvoice: setting.showQrOnInvoice,
  };
}

/** اليوم التشغيلي الحالي وفق إعدادات الفرع */
export async function currentBusinessDay(
  branchId: string,
  client: TransactionClient = prisma,
  now: Date = new Date(),
): Promise<Date> {
  const settings = await getBranchSettings(branchId, client);
  return getBusinessDay(now, settings.businessDayStartHour, settings.timezone);
}
