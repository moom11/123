/**
 * حساب اليوم التشغيلي.
 *
 * اليوم التشغيلي الافتراضي يبدأ الساعة 5:00 صباحًا وينتهي 5:00 صباح اليوم التالي.
 * أي عملية تتم الساعة 2:00 صباحًا تُحتسب على اليوم السابق.
 * ساعة البداية قابلة للتعديل من إعدادات الفرع.
 */

export const DEFAULT_BUSINESS_DAY_START_HOUR = Number(
  process.env.BUSINESS_DAY_START_HOUR ?? 5,
);

export const DEFAULT_TIMEZONE = process.env.APP_TIMEZONE ?? 'Asia/Riyadh';

interface LocalParts {
  year: number;
  month: number;
  day: number;
  hour: number;
  minute: number;
  second: number;
}

/** استخراج مكونات التاريخ في منطقة زمنية محددة دون الاعتماد على مكتبات خارجية */
export function getLocalParts(date: Date, timezone = DEFAULT_TIMEZONE): LocalParts {
  const formatter = new Intl.DateTimeFormat('en-US', {
    timeZone: timezone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  });
  const parts = formatter.formatToParts(date);
  const get = (type: string) => Number(parts.find((p) => p.type === type)?.value ?? '0');
  return {
    year: get('year'),
    month: get('month'),
    day: get('day'),
    // بعض البيئات تعيد 24 بدل 0 عند منتصف الليل
    hour: get('hour') % 24,
    minute: get('minute'),
    second: get('second'),
  };
}

/**
 * يعيد اليوم التشغيلي كتاريخ UTC عند منتصف الليل (نوع DATE في قاعدة البيانات).
 */
export function getBusinessDay(
  date: Date = new Date(),
  startHour: number = DEFAULT_BUSINESS_DAY_START_HOUR,
  timezone: string = DEFAULT_TIMEZONE,
): Date {
  const local = getLocalParts(date, timezone);
  // قبل ساعة البداية ⇒ ننتمي لليوم التشغيلي السابق
  const dayOffset = local.hour < startHour ? -1 : 0;
  const asUtc = Date.UTC(local.year, local.month - 1, local.day + dayOffset);
  return new Date(asUtc);
}

/** صيغة نصية YYYY-MM-DD لليوم التشغيلي */
export function formatBusinessDay(date: Date): string {
  return date.toISOString().slice(0, 10);
}

/**
 * نطاق زمني فعلي (بداية/نهاية) ليوم تشغيلي معين، بتوقيت UTC،
 * لاستخدامه في استعلامات created_at.
 */
export function getBusinessDayRange(
  businessDay: Date,
  startHour: number = DEFAULT_BUSINESS_DAY_START_HOUR,
  timezone: string = DEFAULT_TIMEZONE,
): { start: Date; end: Date } {
  const y = businessDay.getUTCFullYear();
  const m = businessDay.getUTCMonth();
  const d = businessDay.getUTCDate();

  const start = zonedTimeToUtc(y, m, d, startHour, timezone);
  const end = zonedTimeToUtc(y, m, d + 1, startHour, timezone);
  return { start, end };
}

/**
 * يحوّل وقتًا محليًا في منطقة زمنية إلى لحظة UTC.
 * يعمل بالتقريب المتتابع لأن إزاحة المنطقة قد تتغير (توقيت صيفي).
 */
export function zonedTimeToUtc(
  year: number,
  monthIndex: number,
  day: number,
  hour: number,
  timezone = DEFAULT_TIMEZONE,
): Date {
  // تخمين أولي: نعامل القيمة كأنها UTC ثم نصحح بالإزاحة الفعلية
  let guess = new Date(Date.UTC(year, monthIndex, day, hour, 0, 0));
  for (let i = 0; i < 3; i += 1) {
    const local = getLocalParts(guess, timezone);
    const localAsUtc = Date.UTC(
      local.year,
      local.month - 1,
      local.day,
      local.hour,
      local.minute,
      local.second,
    );
    const targetAsUtc = Date.UTC(year, monthIndex, day, hour, 0, 0);
    const diff = targetAsUtc - localAsUtc;
    if (diff === 0) break;
    guess = new Date(guess.getTime() + diff);
  }
  return guess;
}

/** هل التاريخ المحدد يقع ضمن اليوم التشغيلي المعطى؟ */
export function isWithinBusinessDay(
  date: Date,
  businessDay: Date,
  startHour: number = DEFAULT_BUSINESS_DAY_START_HOUR,
  timezone: string = DEFAULT_TIMEZONE,
): boolean {
  const { start, end } = getBusinessDayRange(businessDay, startHour, timezone);
  return date >= start && date < end;
}

/** تحويل نص YYYY-MM-DD إلى تاريخ يوم تشغيلي (UTC midnight) */
export function parseBusinessDay(value: string): Date {
  const [y, m, d] = value.split('-').map(Number);
  return new Date(Date.UTC(y, (m ?? 1) - 1, d ?? 1));
}
