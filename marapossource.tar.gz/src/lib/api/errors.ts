/** أخطاء موحدة لطبقة الـ API مع رسائل عربية وأكواد HTTP مناسبة */

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public code: string = 'ERROR',
    public details?: unknown,
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

export const BadRequest = (message = 'طلب غير صالح', details?: unknown) =>
  new ApiError(400, message, 'BAD_REQUEST', details);

export const Unauthorized = (message = 'يجب تسجيل الدخول للمتابعة') =>
  new ApiError(401, message, 'UNAUTHORIZED');

export const Forbidden = (message = 'لا تملك صلاحية تنفيذ هذه العملية') =>
  new ApiError(403, message, 'FORBIDDEN');

export const NotFound = (message = 'العنصر المطلوب غير موجود') =>
  new ApiError(404, message, 'NOT_FOUND');

export const Conflict = (message = 'تعارض في البيانات', details?: unknown) =>
  new ApiError(409, message, 'CONFLICT', details);

export const UnprocessableEntity = (message: string, details?: unknown) =>
  new ApiError(422, message, 'UNPROCESSABLE', details);

export const TooManyRequests = (message = 'تجاوزت عدد الطلبات المسموح، حاول لاحقًا') =>
  new ApiError(429, message, 'RATE_LIMITED');

export const ServerError = (message = 'حدث خطأ غير متوقع في الخادم') =>
  new ApiError(500, message, 'INTERNAL_ERROR');
