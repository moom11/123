/**
 * مواصفة OpenAPI 3.0 لواجهات النظام.
 * تُعرض عبر /api/docs (Swagger UI) و /api/docs/openapi.json.
 */

const money = { type: 'number', format: 'double' } as const;

function jsonResponse(description: string, schema: Record<string, unknown> = { type: 'object' }) {
  return {
    description,
    content: {
      'application/json': {
        schema: {
          type: 'object',
          properties: { success: { type: 'boolean' }, data: schema },
        },
      },
    },
  };
}

const ERROR_RESPONSES = {
  400: { description: 'طلب غير صالح' },
  401: { description: 'غير مصرح — يجب تسجيل الدخول' },
  403: { description: 'لا تملك الصلاحية المطلوبة' },
  404: { description: 'العنصر غير موجود' },
  409: { description: 'تعارض في البيانات' },
  422: { description: 'البيانات المرسلة غير صالحة' },
  429: { description: 'تجاوز حد الطلبات' },
};

const dayParams = [
  { name: 'from', in: 'query', schema: { type: 'string', format: 'date' }, description: 'من يوم تشغيلي' },
  { name: 'to', in: 'query', schema: { type: 'string', format: 'date' }, description: 'إلى يوم تشغيلي' },
];

export function buildOpenApiSpec() {
  return {
    openapi: '3.0.3',
    info: {
      title: 'Mara POS API — نظام نقاط البيع والمحاسبة',
      version: '1.0.0',
      description: [
        'واجهات REST لنظام نقاط بيع ومحاسبة مطعم ومقهى، مع طبقة تكامل مستقلة مع Odoo.',
        '',
        '**المصادقة**: JWT عبر ترويسة `Authorization: Bearer <accessToken>` أو عبر الكوكيز بعد تسجيل الدخول.',
        '',
        '**الضرائب**: ضريبة القيمة المضافة وضريبة التبغ تُحسبان وتُعرضان بشكل مستقل، وتُخزنان كنسخة ثابتة داخل الفاتورة.',
        '',
        '**منع التكرار**: عمليات الإغلاق والمرتجعات والمزامنة تستخدم `idempotencyKey` لمنع تنفيذ العملية مرتين.',
      ].join('\n'),
    },
    servers: [{ url: process.env.APP_URL ?? 'http://localhost:3000', description: 'الخادم الحالي' }],
    tags: [
      { name: 'المصادقة', description: 'تسجيل الدخول والجلسات' },
      { name: 'المنتجات', description: 'المنتجات والتصنيفات والضرائب' },
      { name: 'الطاولات', description: 'الأدوار والمناطق والطاولات' },
      { name: 'الطلبات', description: 'دورة البيع من فتح الطلب حتى الدفع' },
      { name: 'الفواتير', description: 'الفواتير والمرتجعات' },
      { name: 'الورديات', description: 'الورديات والصندوق والمصروفات' },
      { name: 'التقارير', description: 'التقارير والتصدير ولوحة التحكم' },
      { name: 'Odoo', description: 'الربط والمزامنة مع Odoo' },
      { name: 'الإدارة', description: 'المستخدمون والإعدادات وسجل التدقيق' },
    ],
    components: {
      securitySchemes: {
        bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' },
        cookieAuth: { type: 'apiKey', in: 'cookie', name: 'mara_access' },
      },
      schemas: {
        Error: {
          type: 'object',
          properties: {
            success: { type: 'boolean', example: false },
            error: {
              type: 'object',
              properties: {
                code: { type: 'string' },
                message: { type: 'string' },
                details: {},
              },
            },
          },
        },
        Product: {
          type: 'object',
          properties: {
            id: { type: 'string', format: 'uuid' },
            nameAr: { type: 'string' },
            nameEn: { type: 'string', nullable: true },
            sku: { type: 'string' },
            barcode: { type: 'string', nullable: true },
            price: money,
            priceIncludesVat: { type: 'boolean' },
            isTobacco: { type: 'boolean' },
            prepStation: { type: 'string', enum: ['KITCHEN', 'BAR', 'SHISHA', 'NONE'] },
            odooProductId: { type: 'integer', nullable: true },
            syncStatus: {
              type: 'string',
              enum: ['PENDING', 'IN_PROGRESS', 'SYNCED', 'FAILED', 'NEEDS_REVIEW'],
            },
          },
        },
        Order: {
          type: 'object',
          properties: {
            id: { type: 'string', format: 'uuid' },
            orderNumber: { type: 'string' },
            type: { type: 'string', enum: ['DINE_IN', 'TAKEAWAY', 'PICKUP', 'DELIVERY'] },
            status: {
              type: 'string',
              enum: [
                'DRAFT', 'HELD', 'SENT_TO_PREP', 'COMPLETED',
                'PAID', 'CANCELLED', 'PARTIALLY_REFUNDED', 'REFUNDED',
              ],
            },
            subtotal: money,
            discountTotal: money,
            vatTotal: money,
            tobaccoTaxTotal: money,
            grandTotal: money,
          },
        },
        Invoice: {
          type: 'object',
          properties: {
            id: { type: 'string', format: 'uuid' },
            invoiceNumber: { type: 'string' },
            reference: { type: 'string', format: 'uuid' },
            status: { type: 'string' },
            netBeforeTax: money,
            vatTotal: money,
            tobaccoTaxTotal: money,
            grandTotal: money,
            paidTotal: money,
            qrPayload: { type: 'string', nullable: true, description: 'رمز QR بصيغة ZATCA TLV/Base64' },
            syncStatus: { type: 'string' },
            odooRecordId: { type: 'integer', nullable: true },
          },
        },
        PaymentInput: {
          type: 'object',
          required: ['paymentMethodId', 'amount'],
          properties: {
            paymentMethodId: { type: 'string', format: 'uuid' },
            amount: money,
            receivedAmount: { ...money, nullable: true, description: 'المبلغ المستلم نقدًا لحساب الباقي' },
            reference: { type: 'string', nullable: true },
          },
        },
      },
    },
    security: [{ bearerAuth: [] }, { cookieAuth: [] }],
    paths: {
      '/api/auth/login': {
        post: {
          tags: ['المصادقة'],
          summary: 'تسجيل الدخول برقم الموظف أو البريد الإلكتروني',
          security: [],
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  required: ['identifier', 'password'],
                  properties: {
                    identifier: { type: 'string', example: '1003' },
                    password: { type: 'string', example: 'Cashier@1234' },
                  },
                },
              },
            },
          },
          responses: { 200: jsonResponse('تم تسجيل الدخول'), ...ERROR_RESPONSES },
        },
      },
      '/api/auth/refresh': {
        post: {
          tags: ['المصادقة'],
          summary: 'تجديد رمز الدخول',
          security: [],
          responses: { 200: jsonResponse('تم التجديد'), ...ERROR_RESPONSES },
        },
      },
      '/api/auth/logout': {
        post: { tags: ['المصادقة'], summary: 'تسجيل الخروج', responses: { 200: jsonResponse('تم') } },
      },
      '/api/auth/me': {
        get: {
          tags: ['المصادقة'],
          summary: 'بيانات المستخدم الحالي وصلاحياته',
          responses: { 200: jsonResponse('بيانات المستخدم'), ...ERROR_RESPONSES },
        },
      },

      '/api/uploads': {
        post: {
          tags: ['المنتجات'],
          summary: 'رفع صورة (منتج أو مستند مصروف)',
          description:
            'multipart/form-data بحقلي file وkind. النوع يُتحقق منه بالتوقيع الثنائي لا بترويسة العميل، ' +
            'واسم الملف يُولَّد عشوائيًا. المسموح: JPG، PNG، WebP، GIF حتى 5 ميجابايت.',
          requestBody: {
            required: true,
            content: {
              'multipart/form-data': {
                schema: {
                  type: 'object',
                  required: ['file'],
                  properties: {
                    file: { type: 'string', format: 'binary' },
                    kind: { type: 'string', enum: ['products', 'expenses'], default: 'products' },
                  },
                },
              },
            },
          },
          responses: {
            201: jsonResponse('تم الرفع', {
              type: 'object',
              properties: {
                url: { type: 'string', example: '/uploads/products/uuid.png' },
                mime: { type: 'string' },
                size: { type: 'integer' },
              },
            }),
            ...ERROR_RESPONSES,
          },
        },
      },
      '/api/products': {
        get: {
          tags: ['المنتجات'],
          summary: 'قائمة المنتجات',
          parameters: [
            { name: 'categoryId', in: 'query', schema: { type: 'string', format: 'uuid' } },
            { name: 'search', in: 'query', schema: { type: 'string' } },
            { name: 'posOnly', in: 'query', schema: { type: 'string', enum: ['true', 'false'] } },
          ],
          responses: {
            200: jsonResponse('المنتجات', { type: 'array', items: { $ref: '#/components/schemas/Product' } }),
            ...ERROR_RESPONSES,
          },
        },
        post: { tags: ['المنتجات'], summary: 'إنشاء منتج', responses: { 201: jsonResponse('تم الإنشاء'), ...ERROR_RESPONSES } },
      },
      '/api/products/{id}': {
        get: { tags: ['المنتجات'], summary: 'تفاصيل منتج', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('المنتج'), ...ERROR_RESPONSES } },
        patch: { tags: ['المنتجات'], summary: 'تعديل منتج (تغيير السعر يتطلب صلاحية مستقلة)', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('تم التعديل'), ...ERROR_RESPONSES } },
        delete: { tags: ['المنتجات'], summary: 'تعطيل منتج', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('تم التعطيل'), ...ERROR_RESPONSES } },
      },
      '/api/categories': {
        get: { tags: ['المنتجات'], summary: 'التصنيفات', responses: { 200: jsonResponse('التصنيفات') } },
        post: { tags: ['المنتجات'], summary: 'إنشاء تصنيف', responses: { 201: jsonResponse('تم') } },
      },
      '/api/taxes': {
        get: { tags: ['المنتجات'], summary: 'الضرائب (القيمة المضافة والتبغ)', responses: { 200: jsonResponse('الضرائب') } },
        post: { tags: ['المنتجات'], summary: 'إنشاء ضريبة', responses: { 201: jsonResponse('تم') } },
      },
      '/api/taxes/{id}': {
        patch: { tags: ['المنتجات'], summary: 'تعديل ضريبة (لا يؤثر على الفواتير القديمة)', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('تم') } },
      },
      '/api/payment-methods': {
        get: { tags: ['الطلبات'], summary: 'طرق الدفع المتاحة', responses: { 200: jsonResponse('طرق الدفع') } },
      },

      '/api/floors': { get: { tags: ['الطاولات'], summary: 'الأدوار والمناطق والطاولات', responses: { 200: jsonResponse('الأدوار') } } },
      '/api/tables': {
        get: {
          tags: ['الطاولات'],
          summary: 'الطاولات مع الطلبات النشطة',
          parameters: [
            { name: 'floorId', in: 'query', schema: { type: 'string', format: 'uuid' } },
            { name: 'status', in: 'query', schema: { type: 'string', enum: ['AVAILABLE', 'OCCUPIED', 'AWAITING_PAYMENT', 'RESERVED', 'NEEDS_CLEANING'] } },
          ],
          responses: { 200: jsonResponse('الطاولات') },
        },
      },
      '/api/tables/{id}': {
        patch: { tags: ['الطاولات'], summary: 'تحديث حالة الطاولة', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('تم') } },
      },

      '/api/orders': {
        get: { tags: ['الطلبات'], summary: 'قائمة الطلبات', responses: { 200: jsonResponse('الطلبات', { type: 'array', items: { $ref: '#/components/schemas/Order' } }) } },
        post: {
          tags: ['الطلبات'],
          summary: 'فتح طلب جديد',
          description: 'يدعم `clientUuid` لمنع تكرار الطلب عند إعادة الإرسال بعد العمل دون اتصال.',
          responses: { 201: jsonResponse('تم الإنشاء', { $ref: '#/components/schemas/Order' }), ...ERROR_RESPONSES },
        },
      },
      '/api/orders/{id}': { get: { tags: ['الطلبات'], summary: 'تفاصيل الطلب', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('الطلب') } } },
      '/api/orders/{id}/items': { post: { tags: ['الطلبات'], summary: 'إضافة صنف', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 201: jsonResponse('تمت الإضافة') } } },
      '/api/orders/{id}/items/{itemId}': {
        patch: { tags: ['الطلبات'], summary: 'تعديل الكمية', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }, { name: 'itemId', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('تم') } },
        delete: { tags: ['الطلبات'], summary: 'إلغاء صنف (يتطلب سببًا)', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }, { name: 'itemId', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('تم') } },
      },
      '/api/orders/{id}/hold': { post: { tags: ['الطلبات'], summary: 'تعليق الطلب', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('تم') } } },
      '/api/orders/{id}/resume': { post: { tags: ['الطلبات'], summary: 'استرجاع طلب معلق', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('تم') } } },
      '/api/orders/{id}/cancel': { post: { tags: ['الطلبات'], summary: 'إلغاء الطلب قبل الدفع', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('تم') } } },
      '/api/orders/{id}/send-to-prep': { post: { tags: ['الطلبات'], summary: 'إرسال للمطبخ/البار/الشيشة', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('تم إنشاء تذاكر التحضير') } } },
      '/api/orders/{id}/transfer': { post: { tags: ['الطاولات'], summary: 'نقل الطلب إلى طاولة أخرى', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('تم') } } },
      '/api/orders/{id}/merge': { post: { tags: ['الطاولات'], summary: 'دمج طلبين (يتطلب اعتماد مدير)', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('تم') } } },
      '/api/orders/{id}/split': { post: { tags: ['الطاولات'], summary: 'تقسيم الفاتورة بنقل أصناف إلى طلب جديد', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('تم') } } },
      '/api/orders/{id}/discount': {
        post: { tags: ['الطلبات'], summary: 'تطبيق خصم', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('تم'), ...ERROR_RESPONSES } },
        delete: { tags: ['الطلبات'], summary: 'إزالة خصم', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('تم') } },
      },
      '/api/orders/{id}/checkout': {
        post: {
          tags: ['الطلبات'],
          summary: 'تحصيل الدفع وإغلاق الفاتورة',
          description: 'يدعم الدفع المختلط ويمنع الإغلاق إذا لم يساوِ مجموع المدفوعات الإجمالي (مع سماحية تقريب من الإعدادات).',
          parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  required: ['payments'],
                  properties: {
                    payments: { type: 'array', items: { $ref: '#/components/schemas/PaymentInput' } },
                    shiftId: { type: 'string', format: 'uuid', nullable: true },
                    idempotencyKey: { type: 'string', nullable: true },
                  },
                },
              },
            },
          },
          responses: { 201: jsonResponse('تم إصدار الفاتورة', { $ref: '#/components/schemas/Invoice' }), ...ERROR_RESPONSES },
        },
      },

      '/api/invoices': { get: { tags: ['الفواتير'], summary: 'سجل الفواتير', responses: { 200: jsonResponse('الفواتير') } } },
      '/api/invoices/{id}': { get: { tags: ['الفواتير'], summary: 'تفاصيل الفاتورة مع سجل التعديلات', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('الفاتورة') } } },
      '/api/invoices/{id}/cancel': { post: { tags: ['الفواتير'], summary: 'إلغاء فاتورة (لا تُحذف، تتغير حالتها)', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('تم') } } },
      '/api/invoices/{id}/refund': { post: { tags: ['الفواتير'], summary: 'إرجاع كامل أو جزئي', description: 'يُعاد المبلغ بنفس طرق الدفع الأصلية ويُرحّل إلى Odoo كإشعار دائن.', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 201: jsonResponse('تم إنشاء المرتجع') } } },

      '/api/shifts': {
        get: { tags: ['الورديات'], summary: 'قائمة الورديات', responses: { 200: jsonResponse('الورديات') } },
        post: { tags: ['الورديات'], summary: 'فتح وردية', responses: { 201: jsonResponse('تم الفتح'), ...ERROR_RESPONSES } },
      },
      '/api/shifts/current': { get: { tags: ['الورديات'], summary: 'الوردية المفتوحة الحالية مع ملخصها', responses: { 200: jsonResponse('الوردية') } } },
      '/api/shifts/{id}/summary': { get: { tags: ['الورديات'], summary: 'تقرير إغلاق الوردية', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('الملخص') } } },
      '/api/shifts/{id}/close': { post: { tags: ['الورديات'], summary: 'إغلاق الوردية واحتساب الفرق', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('تم الإغلاق'), ...ERROR_RESPONSES } } },
      '/api/shifts/{id}/approve': { post: { tags: ['الورديات'], summary: 'اعتماد المدير لفرق الصندوق', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('تم الاعتماد') } } },
      '/api/cash-movements': {
        get: { tags: ['الورديات'], summary: 'حركات الصندوق', responses: { 200: jsonResponse('الحركات') } },
        post: { tags: ['الورديات'], summary: 'تسجيل مصروف/سحب/إيداع/عهدة', description: 'الإيداع في الصندوق الرئيسي يُسجل بنوع مستقل ولا يُعد مصروفًا.', responses: { 201: jsonResponse('تم التسجيل') } },
      },
      '/api/expenses': { get: { tags: ['الورديات'], summary: 'المصروفات والمسحوبات', responses: { 200: jsonResponse('المصروفات') } } },
      '/api/expenses/{id}': { patch: { tags: ['الورديات'], summary: 'اعتماد أو رفض المصروف', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('تم') } } },
      '/api/expense-categories': { get: { tags: ['الورديات'], summary: 'تصنيفات المصروفات', responses: { 200: jsonResponse('التصنيفات') } } },
      '/api/kitchen-tickets': { get: { tags: ['الطلبات'], summary: 'تذاكر التحضير حسب المحطة', responses: { 200: jsonResponse('التذاكر') } } },

      '/api/reports/dashboard': { get: { tags: ['التقارير'], summary: 'مؤشرات لوحة التحكم لليوم التشغيلي', responses: { 200: jsonResponse('اللوحة') } } },
      '/api/reports/sales': { get: { tags: ['التقارير'], summary: 'تقرير المبيعات', parameters: dayParams, responses: { 200: jsonResponse('التقرير') } } },
      '/api/reports/payments': { get: { tags: ['التقارير'], summary: 'تقرير طرق الدفع', parameters: dayParams, responses: { 200: jsonResponse('التقرير') } } },
      '/api/reports/products': { get: { tags: ['التقارير'], summary: 'تقرير المنتجات', parameters: dayParams, responses: { 200: jsonResponse('التقرير') } } },
      '/api/reports/employees': { get: { tags: ['التقارير'], summary: 'تقرير الموظفين', parameters: dayParams, responses: { 200: jsonResponse('التقرير') } } },
      '/api/reports/shifts': { get: { tags: ['التقارير'], summary: 'تقرير الورديات', parameters: dayParams, responses: { 200: jsonResponse('التقرير') } } },
      '/api/reports/export': {
        get: {
          tags: ['التقارير'],
          summary: 'تصدير التقارير إلى Excel أو CSV',
          parameters: [
            { name: 'report', in: 'query', required: true, schema: { type: 'string', enum: ['sales', 'payments', 'products', 'employees', 'shifts'] } },
            { name: 'format', in: 'query', schema: { type: 'string', enum: ['xlsx', 'csv'], default: 'xlsx' } },
            ...dayParams,
          ],
          responses: { 200: { description: 'ملف التقرير' }, ...ERROR_RESPONSES },
        },
      },

      '/api/odoo/settings': {
        get: { tags: ['Odoo'], summary: 'إعدادات الربط (مفتاح API لا يُعاد أبدًا)', responses: { 200: jsonResponse('الإعدادات') } },
        put: { tags: ['Odoo'], summary: 'حفظ الإعدادات مع تشفير بيانات الاعتماد', responses: { 200: jsonResponse('تم الحفظ') } },
      },
      '/api/odoo/test': { post: { tags: ['Odoo'], summary: 'اختبار الاتصال بخادم Odoo', responses: { 200: jsonResponse('نتيجة الاختبار') } } },
      '/api/odoo/sync-jobs': { get: { tags: ['Odoo'], summary: 'مهام المزامنة وحالاتها', responses: { 200: jsonResponse('المهام') } } },
      '/api/odoo/sync-jobs/{id}/retry': { post: { tags: ['Odoo'], summary: 'إعادة إرسال عملية فاشلة', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('تمت إعادة الجدولة') } } },
      '/api/odoo/sync-jobs/retry-all': { post: { tags: ['Odoo'], summary: 'إعادة جدولة كل العمليات الفاشلة', responses: { 200: jsonResponse('تم') } } },
      '/api/odoo/sync-logs': { get: { tags: ['Odoo'], summary: 'السجل الفني للطلبات والردود', responses: { 200: jsonResponse('السجل') } } },
      '/api/odoo/products/pull': { post: { tags: ['Odoo'], summary: 'جلب المنتجات والأسعار من Odoo', responses: { 200: jsonResponse('نتيجة المزامنة') } } },
      '/api/odoo/daily-summary': {
        get: { tags: ['Odoo'], summary: 'عرض ملخص يوم تشغيلي', responses: { 200: jsonResponse('الملخص') } },
        post: { tags: ['Odoo'], summary: 'بناء الملخص اليومي وجدولة ترحيله', responses: { 200: jsonResponse('تم') } },
      },
      '/api/cron/sync': { post: { tags: ['Odoo'], summary: 'تشغيل دورة معالجة الطابور (محمي برمز CRON_SECRET)', security: [], responses: { 200: jsonResponse('نتيجة الدورة') } } },

      '/api/users': {
        get: { tags: ['الإدارة'], summary: 'مستخدمو الفرع', responses: { 200: jsonResponse('المستخدمون') } },
        post: { tags: ['الإدارة'], summary: 'إنشاء مستخدم', responses: { 201: jsonResponse('تم') } },
      },
      '/api/users/{id}': { patch: { tags: ['الإدارة'], summary: 'تعديل مستخدم', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 200: jsonResponse('تم') } } },
      '/api/settings': {
        get: { tags: ['الإدارة'], summary: 'إعدادات الفرع', responses: { 200: jsonResponse('الإعدادات') } },
        put: { tags: ['الإدارة'], summary: 'تعديل الإعدادات (اليوم التشغيلي، السماحيات، الألوان)', responses: { 200: jsonResponse('تم') } },
      },
      '/api/audit-logs': { get: { tags: ['الإدارة'], summary: 'سجل التدقيق', responses: { 200: jsonResponse('السجل') } } },
    },
  };
}
