/**
 * محدد معدل الطلبات — تطبيق في الذاكرة بنافذة منزلقة مبسطة.
 * كافٍ لفرع واحد يعمل على خادم واحد. عند التوسع لعدة خوادم
 * يمكن استبدال المخزن بـ Redis دون تغيير الواجهة.
 */

interface Bucket {
  count: number;
  resetAt: number;
}

const buckets = new Map<string, Bucket>();

/** تنظيف دوري للمفاتيح المنتهية حتى لا تنمو الذاكرة */
function sweep(now: number) {
  if (buckets.size < 5000) return;
  for (const [key, bucket] of buckets) {
    if (bucket.resetAt <= now) buckets.delete(key);
  }
}

export interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  resetAt: number;
}

export function checkRateLimit(
  key: string,
  max = Number(process.env.RATE_LIMIT_MAX ?? 120),
  windowMs = Number(process.env.RATE_LIMIT_WINDOW_MS ?? 60000),
): RateLimitResult {
  const now = Date.now();
  sweep(now);

  const existing = buckets.get(key);
  if (!existing || existing.resetAt <= now) {
    const bucket = { count: 1, resetAt: now + windowMs };
    buckets.set(key, bucket);
    return { allowed: true, remaining: max - 1, resetAt: bucket.resetAt };
  }

  existing.count += 1;
  return {
    allowed: existing.count <= max,
    remaining: Math.max(max - existing.count, 0),
    resetAt: existing.resetAt,
  };
}

export function resetRateLimit(key?: string) {
  if (key) buckets.delete(key);
  else buckets.clear();
}
