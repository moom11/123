import { cookies, headers } from 'next/headers';
import type { NextRequest } from 'next/server';
import { ACCESS_COOKIE, verifyAccessToken, type AccessTokenPayload } from '@/lib/auth/tokens';
import { hasPermission, type PermissionCode } from '@/lib/auth/permissions';
import { Forbidden, Unauthorized } from '@/lib/api/errors';

export type Session = AccessTokenPayload;

/** استخراج الرمز من ترويسة Authorization أو من الكوكيز */
async function extractToken(request?: NextRequest): Promise<string | null> {
  const headerList = request ? request.headers : await headers();
  const authHeader = headerList.get('authorization');
  if (authHeader?.toLowerCase().startsWith('bearer ')) {
    return authHeader.slice(7).trim();
  }
  if (request) {
    return request.cookies.get(ACCESS_COOKIE)?.value ?? null;
  }
  const cookieStore = await cookies();
  return cookieStore.get(ACCESS_COOKIE)?.value ?? null;
}

export async function getSession(request?: NextRequest): Promise<Session | null> {
  const token = await extractToken(request);
  if (!token) return null;
  return verifyAccessToken(token);
}

export async function requireSession(request?: NextRequest): Promise<Session> {
  const session = await getSession(request);
  if (!session) throw Unauthorized();
  return session;
}

export async function requirePermission(
  required: PermissionCode | PermissionCode[],
  request?: NextRequest,
): Promise<Session> {
  const session = await requireSession(request);
  if (!hasPermission(session.permissions, required)) {
    const list = Array.isArray(required) ? required.join('، ') : required;
    throw Forbidden(`لا تملك الصلاحية المطلوبة: ${list}`);
  }
  return session;
}

/** الفرع الحالي للمستخدم — النظام يعمل حاليًا بفرع واحد */
export function requireBranch(session: Session): string {
  if (!session.branchId) {
    throw Forbidden('المستخدم غير مرتبط بأي فرع');
  }
  return session.branchId;
}
