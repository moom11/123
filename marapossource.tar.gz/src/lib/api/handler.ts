import { NextResponse, type NextRequest } from 'next/server';
import { Prisma } from '@prisma/client';
import { ZodError, type ZodTypeAny, type z } from 'zod';
import { ApiError, BadRequest, TooManyRequests } from '@/lib/api/errors';
import { checkRateLimit } from '@/lib/api/rate-limit';

export interface ApiSuccess<T> {
  success: true;
  data: T;
  meta?: Record<string, unknown>;
}

export interface ApiFailure {
  success: false;
  error: { code: string; message: string; details?: unknown };
}

export function ok<T>(data: T, meta?: Record<string, unknown>, status = 200) {
  return NextResponse.json<ApiSuccess<T>>({ success: true, data, meta }, { status });
}

export function created<T>(data: T, meta?: Record<string, unknown>) {
  return ok(data, meta, 201);
}

export function fail(error: ApiError) {
  return NextResponse.json<ApiFailure>(
    {
      success: false,
      error: { code: error.code, message: error.message, details: error.details },
    },
    { status: error.status },
  );
}

/** عنوان IP الخاص بالطلب مع مراعاة الوكلاء العكسيين */
export function getClientIp(request: NextRequest): string {
  const forwarded = request.headers.get('x-forwarded-for');
  if (forwarded) return forwarded.split(',')[0].trim();
  return request.headers.get('x-real-ip') ?? 'unknown';
}

function translatePrismaError(error: Prisma.PrismaClientKnownRequestError): ApiError {
  switch (error.code) {
    case 'P2002': {
      const target = (error.meta?.target as string[] | undefined)?.join('، ') ?? 'الحقل';
      return new ApiError(409, `القيمة مكررة ولا يمكن تكرارها: ${target}`, 'DUPLICATE');
    }
    case 'P2003':
      return new ApiError(
        409,
        'لا يمكن تنفيذ العملية لوجود ارتباط ببيانات أخرى',
        'FK_CONSTRAINT',
      );
    case 'P2025':
      return new ApiError(404, 'العنصر المطلوب غير موجود', 'NOT_FOUND');
    default:
      return new ApiError(400, `خطأ في قاعدة البيانات (${error.code})`, 'DB_ERROR');
  }
}

export function toApiError(error: unknown): ApiError {
  if (error instanceof ApiError) return error;
  if (error instanceof ZodError) {
    const details = error.issues.map((issue) => ({
      field: issue.path.join('.'),
      message: issue.message,
    }));
    return new ApiError(422, 'البيانات المرسلة غير صالحة', 'VALIDATION_ERROR', details);
  }
  if (error instanceof Prisma.PrismaClientKnownRequestError) {
    return translatePrismaError(error);
  }
  if (error instanceof Prisma.PrismaClientValidationError) {
    return new ApiError(400, 'بنية البيانات المرسلة غير صحيحة', 'DB_VALIDATION');
  }
  const message = error instanceof Error ? error.message : 'خطأ غير معروف';
  if (process.env.NODE_ENV !== 'test') {
    console.error('[api] خطأ غير متوقع:', error);
  }
  return new ApiError(500, message, 'INTERNAL_ERROR');
}

export interface RouteOptions {
  /** حد الطلبات لهذا المسار */
  rateLimit?: { max: number; windowMs?: number; scope?: string };
}

type Handler<Ctx> = (request: NextRequest, context: Ctx) => Promise<Response> | Response;

/**
 * غلاف موحد لجميع مسارات الـ API:
 * يطبق تحديد المعدل، ويحوّل الأخطاء إلى استجابات JSON عربية موحدة.
 */
export function route<Ctx = { params: Promise<Record<string, string>> }>(
  handler: Handler<Ctx>,
  options: RouteOptions = {},
) {
  return async (request: NextRequest, context: Ctx): Promise<Response> => {
    try {
      if (options.rateLimit) {
        const scope = options.rateLimit.scope ?? new URL(request.url).pathname;
        const key = `${getClientIp(request)}:${scope}`;
        const result = checkRateLimit(
          key,
          options.rateLimit.max,
          options.rateLimit.windowMs,
        );
        if (!result.allowed) throw TooManyRequests();
      }
      return await handler(request, context);
    } catch (error) {
      return fail(toApiError(error));
    }
  };
}

/** قراءة جسم الطلب والتحقق منه بمخطط Zod */
export async function parseBody<S extends ZodTypeAny>(
  request: NextRequest,
  schema: S,
): Promise<z.infer<S>> {
  let json: unknown;
  try {
    json = await request.json();
  } catch {
    throw BadRequest('جسم الطلب يجب أن يكون JSON صالحًا');
  }
  return schema.parse(json);
}

/** التحقق من معاملات الاستعلام بمخطط Zod */
export function parseQuery<S extends ZodTypeAny>(
  request: NextRequest,
  schema: S,
): z.infer<S> {
  const params = Object.fromEntries(new URL(request.url).searchParams.entries());
  return schema.parse(params);
}
