import {
  Prisma,
  SyncEntity,
  SyncStatus,
  type OdooSetting,
} from '@prisma/client';
import { prisma } from '@/lib/prisma';
import { decryptSecret } from '@/lib/crypto';
import { NotFound, UnprocessableEntity } from '@/lib/api/errors';
import { round2, toNumber } from '@/lib/money';
import { formatBusinessDay } from '@/lib/business-day';
import { INVOICE_INCLUDE } from '@/lib/pos/checkout-service';
import { OdooClient, OdooError, createOdooClient } from '@/lib/odoo/client';
import {
  mapDailySummaryToOdoo,
  mapInvoiceToOdoo,
  mapOdooProductToPos,
  mapPaymentToOdoo,
  mapPosProductToOdoo,
  type OdooProductRecord,
} from '@/lib/odoo/mappers';
import { completeJob, enqueueSyncJob, type JobOutcome } from '@/lib/odoo/sync-queue';

/**
 * =============================================================================
 * Odoo Integration Service
 * =============================================================================
 * طبقة تكامل مستقلة تمامًا عن منطق نقطة البيع.
 * فشل أي عملية هنا لا يوقف البيع — يُسجل فقط ويُعاد جدولته.
 */

export async function getOdooSettings(branchId: string): Promise<OdooSetting | null> {
  return prisma.odooSetting.findUnique({ where: { branchId } });
}

export async function getOdooClient(branchId: string): Promise<OdooClient> {
  const settings = await getOdooSettings(branchId);
  if (!settings) throw NotFound('لم يتم إعداد الربط مع Odoo لهذا الفرع');
  if (!settings.isEnabled) {
    throw UnprocessableEntity('الربط مع Odoo معطل من الإعدادات');
  }
  return createOdooClient({
    url: settings.url,
    database: settings.database,
    username: settings.username,
    apiKey: decryptSecret(settings.apiKeyEncrypted),
    protocol: settings.protocol,
  });
}

/** اختبار الاتصال وتحديث حالته في الإعدادات */
export async function testOdooConnection(branchId: string) {
  const settings = await getOdooSettings(branchId);
  if (!settings) throw NotFound('لم يتم إعداد الربط مع Odoo لهذا الفرع');

  try {
    const client = createOdooClient({
      url: settings.url,
      database: settings.database,
      username: settings.username,
      apiKey: decryptSecret(settings.apiKeyEncrypted),
      protocol: settings.protocol,
    });
    const info = await client.testConnection();
    await prisma.odooSetting.update({
      where: { branchId },
      data: {
        lastConnectionCheckAt: new Date(),
        lastConnectionOk: true,
        lastConnectionMessage: `تم الاتصال بنجاح — إصدار Odoo ${info.version}`,
      },
    });
    return { ok: true, ...info };
  } catch (error) {
    const message = error instanceof Error ? error.message : 'خطأ غير معروف';
    await prisma.odooSetting.update({
      where: { branchId },
      data: {
        lastConnectionCheckAt: new Date(),
        lastConnectionOk: false,
        lastConnectionMessage: message,
      },
    });
    return { ok: false, message };
  }
}

// -----------------------------------------------------------------------------
// ترحيل الفواتير
// -----------------------------------------------------------------------------

/** إرسال فاتورة واحدة إلى Odoo (وضع «إرسال كل فاتورة») */
export async function pushInvoice(invoiceId: string): Promise<JobOutcome> {
  const started = Date.now();
  const invoice = await prisma.invoice.findUnique({
    where: { id: invoiceId },
    include: { ...INVOICE_INCLUDE, branch: true, shift: true },
  });
  if (!invoice) {
    return { success: false, error: 'الفاتورة غير موجودة', retryable: false };
  }

  // منع التكرار: الفاتورة المرحلة مسبقًا لا تُرسل مرة أخرى
  if (invoice.odooRecordId) {
    return {
      success: true,
      odooRecordId: invoice.odooRecordId,
      durationMs: Date.now() - started,
      response: { skipped: 'الفاتورة مرحّلة مسبقًا' },
    };
  }

  const settings = await getOdooSettings(invoice.branchId);
  if (!settings || !settings.isEnabled) {
    return { success: false, error: 'الربط مع Odoo غير مفعل', retryable: false };
  }

  let payload: unknown;
  try {
    const client = await getOdooClient(invoice.branchId);

    // نبحث عن الفاتورة في Odoo أولًا — يحمي من التكرار عند انقطاع الرد
    const existing = await client.searchRead<{ id: number }>(
      'account.move',
      [['ref', '=', invoice.invoiceNumber]],
      ['id'],
      { limit: 1 },
    );
    if (existing.length > 0) {
      return {
        success: true,
        odooRecordId: existing[0].id,
        durationMs: Date.now() - started,
        response: { matched: 'وُجدت فاتورة بنفس المرجع في Odoo' },
      };
    }

    const productIds = invoice.items.map((i) => i.productId);
    const products = await prisma.product.findMany({
      where: { id: { in: productIds } },
      select: { id: true, odooProductId: true },
    });
    const productMap = new Map<string, number>();
    for (const product of products) {
      if (product.odooProductId) productMap.set(product.id, product.odooProductId);
    }

    payload = mapInvoiceToOdoo(invoice, {
      settings,
      productMap,
      employeeName: invoice.user.fullName,
      branchName: invoice.branch.nameAr,
      shiftNumber: invoice.shift?.shiftNumber ?? null,
    });

    const odooId = await client.create('account.move', payload as unknown as Record<string, unknown>);
    // ترحيل القيد
    await client.execute('account.move', 'action_post', [[odooId]]).catch(() => {
      // بعض النسخ تمنع الترحيل التلقائي — نبقي الفاتورة كمسودة
    });

    // ترحيل المدفوعات المرتبطة
    for (const payment of invoice.payments) {
      await pushPaymentWithClient(client, payment.id, settings).catch((err) => {
        console.warn('[odoo] تعذر ترحيل الدفعة:', err?.message);
      });
    }

    return {
      success: true,
      odooRecordId: odooId,
      request: payload,
      response: { id: odooId },
      durationMs: Date.now() - started,
    };
  } catch (error) {
    const retryable = error instanceof OdooError ? error.retryable : true;
    return {
      success: false,
      error: error instanceof Error ? error.message : 'خطأ غير معروف',
      retryable,
      request: payload,
      durationMs: Date.now() - started,
    };
  }
}

async function pushPaymentWithClient(
  client: OdooClient,
  paymentId: string,
  settings: OdooSetting,
) {
  const payment = await prisma.payment.findUnique({
    where: { id: paymentId },
    include: { paymentMethod: true, invoice: { select: { invoiceNumber: true } } },
  });
  if (!payment || payment.odooRecordId) return;

  const journalId =
    payment.paymentMethod.odooJournalId ??
    (payment.paymentMethod.affectsCashDrawer
      ? settings.cashJournalId ?? undefined
      : settings.bankJournalId ?? undefined);

  const payload = mapPaymentToOdoo(
    payment,
    journalId ?? undefined,
    settings,
    `${payment.invoice.invoiceNumber} / ${payment.paymentMethod.nameAr}`,
  );
  const odooId = await client.create('account.payment', payload as unknown as Record<string, unknown>);

  await prisma.payment.update({
    where: { id: paymentId },
    data: {
      odooRecordId: odooId,
      syncStatus: SyncStatus.SYNCED,
      lastSyncAt: new Date(),
      syncErrorMessage: null,
    },
  });
}

/** ترحيل مرتجع كإشعار دائن في Odoo */
export async function pushRefund(refundId: string): Promise<JobOutcome> {
  const started = Date.now();
  const refund = await prisma.refund.findUnique({
    where: { id: refundId },
    include: {
      items: { include: { invoiceItem: true } },
      invoice: { include: { branch: true } },
    },
  });
  if (!refund) return { success: false, error: 'المرتجع غير موجود', retryable: false };
  if (refund.odooRecordId) {
    return { success: true, odooRecordId: refund.odooRecordId, durationMs: Date.now() - started };
  }

  const settings = await getOdooSettings(refund.invoice.branchId);
  if (!settings || !settings.isEnabled) {
    return { success: false, error: 'الربط مع Odoo غير مفعل', retryable: false };
  }

  let payload: Record<string, unknown> | undefined;
  try {
    const client = await getOdooClient(refund.invoice.branchId);

    const existing = await client.searchRead<{ id: number }>(
      'account.move',
      [['ref', '=', refund.refundNumber]],
      ['id'],
      { limit: 1 },
    );
    if (existing.length > 0) {
      return { success: true, odooRecordId: existing[0].id, durationMs: Date.now() - started };
    }

    const productIds = refund.items.map((i) => i.invoiceItem.productId);
    const products = await prisma.product.findMany({
      where: { id: { in: productIds } },
      select: { id: true, odooProductId: true },
    });
    const productMap = new Map(
      products.filter((p) => p.odooProductId).map((p) => [p.id, p.odooProductId!]),
    );

    const lines = refund.items.map((item) => {
      const quantity = toNumber(item.quantity);
      const net = round2(toNumber(item.amount));
      const odooProductId = productMap.get(item.invoiceItem.productId);
      return [
        0,
        0,
        {
          name: item.invoiceItem.nameAr,
          quantity,
          price_unit: quantity > 0 ? round2(net / quantity) : 0,
          ...(odooProductId ? { product_id: odooProductId } : {}),
        },
      ];
    });

    const tobacco = toNumber(refund.tobaccoTaxTotal);
    if (tobacco > 0) {
      lines.push([
        0,
        0,
        {
          name: 'ضريبة التبغ — مرتجع',
          quantity: 1,
          price_unit: tobacco,
          ...(settings.tobaccoTaxAccountId
            ? { account_id: settings.tobaccoTaxAccountId }
            : {}),
        },
      ]);
    }

    payload = {
      move_type: 'out_refund',
      partner_id: settings.defaultPartnerId ?? 1,
      invoice_date: formatBusinessDay(refund.businessDay),
      ref: refund.refundNumber,
      ...(settings.salesJournalId ? { journal_id: settings.salesJournalId } : {}),
      narration: [
        `مرتجع فاتورة نقطة البيع: ${refund.invoice.invoiceNumber}`,
        `رقم المرتجع: ${refund.refundNumber}`,
        `السبب: ${refund.reason}`,
        `ضريبة القيمة المضافة: ${toNumber(refund.vatTotal).toFixed(2)}`,
        `ضريبة التبغ: ${tobacco.toFixed(2)}`,
      ].join('\n'),
      invoice_line_ids: lines,
    };

    const odooId = await client.create('account.move', payload);
    await client.execute('account.move', 'action_post', [[odooId]]).catch(() => undefined);

    return {
      success: true,
      odooRecordId: odooId,
      request: payload,
      response: { id: odooId },
      durationMs: Date.now() - started,
    };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'خطأ غير معروف',
      retryable: error instanceof OdooError ? error.retryable : true,
      request: payload,
      durationMs: Date.now() - started,
    };
  }
}

/** ترحيل الملخص اليومي (الوضع الافتراضي) */
export async function pushDailySummary(closingId: string): Promise<JobOutcome> {
  const started = Date.now();
  const closing = await prisma.dailyClosing.findUnique({
    where: { id: closingId },
    include: { branch: true },
  });
  if (!closing) return { success: false, error: 'الإغلاق اليومي غير موجود', retryable: false };
  if (closing.odooRecordId) {
    return { success: true, odooRecordId: closing.odooRecordId, durationMs: Date.now() - started };
  }

  const settings = await getOdooSettings(closing.branchId);
  if (!settings || !settings.isEnabled) {
    return { success: false, error: 'الربط مع Odoo غير مفعل', retryable: false };
  }

  let payload: ReturnType<typeof mapDailySummaryToOdoo> | undefined;
  try {
    const client = await getOdooClient(closing.branchId);
    payload = mapDailySummaryToOdoo(closing, settings, closing.branch.nameAr);

    const existing = await client.searchRead<{ id: number }>(
      'account.move',
      [['ref', '=', payload.ref]],
      ['id'],
      { limit: 1 },
    );
    if (existing.length > 0) {
      return { success: true, odooRecordId: existing[0].id, durationMs: Date.now() - started };
    }

    // نُنشئ قيدًا محاسبيًا واحدًا يحمل تفاصيل اليوم في الملاحظات.
    // الحسابات التفصيلية تُضبط من إعدادات الربط.
    const odooId = await client.create('account.move', {
      move_type: payload.move_type,
      date: payload.date,
      ref: payload.ref,
      ...(payload.journal_id ? { journal_id: payload.journal_id } : {}),
      narration: payload.narration,
    });

    return {
      success: true,
      odooRecordId: odooId,
      request: payload,
      response: { id: odooId },
      durationMs: Date.now() - started,
    };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'خطأ غير معروف',
      retryable: error instanceof OdooError ? error.retryable : true,
      request: payload,
      durationMs: Date.now() - started,
    };
  }
}

/** ترحيل منتج من نقطة البيع إلى Odoo */
export async function pushProduct(productId: string): Promise<JobOutcome> {
  const started = Date.now();
  const product = await prisma.product.findUnique({ where: { id: productId } });
  if (!product) return { success: false, error: 'المنتج غير موجود', retryable: false };

  const settings = await getOdooSettings(product.branchId);
  if (!settings || !settings.isEnabled) {
    return { success: false, error: 'الربط مع Odoo غير مفعل', retryable: false };
  }
  if (settings.productSyncDirection === 'ODOO_TO_POS') {
    return {
      success: false,
      error: 'اتجاه مزامنة المنتجات مضبوط على «من Odoo إلى نقطة البيع» فقط',
      retryable: false,
    };
  }

  try {
    const client = await getOdooClient(product.branchId);
    const values = mapPosProductToOdoo(product);

    if (product.odooProductId) {
      await client.write('product.template', [product.odooProductId], values);
      return {
        success: true,
        odooRecordId: product.odooProductId,
        request: values,
        durationMs: Date.now() - started,
      };
    }

    // نبحث بالكود الداخلي لتفادي إنشاء منتج مكرر
    const existing = await client.searchRead<{ id: number }>(
      'product.template',
      [['default_code', '=', product.sku]],
      ['id'],
      { limit: 1 },
    );
    const odooId =
      existing.length > 0
        ? existing[0].id
        : await client.create('product.template', values);
    if (existing.length > 0) {
      await client.write('product.template', [odooId], values);
    }

    return {
      success: true,
      odooRecordId: odooId,
      request: values,
      response: { id: odooId },
      durationMs: Date.now() - started,
    };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'خطأ غير معروف',
      retryable: error instanceof OdooError ? error.retryable : true,
      durationMs: Date.now() - started,
    };
  }
}

/**
 * جلب المنتجات والأسعار من Odoo إلى نقطة البيع.
 * عند التعارض، Odoo هو المصدر الأساسي افتراضيًا (قابل للتغيير من الإعدادات).
 */
export async function pullProductsFromOdoo(branchId: string): Promise<{
  created: number;
  updated: number;
  skipped: number;
  errors: string[];
}> {
  const settings = await getOdooSettings(branchId);
  if (!settings || !settings.isEnabled) {
    throw UnprocessableEntity('الربط مع Odoo غير مفعل');
  }
  if (settings.productSyncDirection === 'POS_TO_ODOO') {
    throw UnprocessableEntity(
      'اتجاه مزامنة المنتجات مضبوط على «من نقطة البيع إلى Odoo» فقط',
    );
  }

  const client = await getOdooClient(branchId);
  const records = await client.searchRead<OdooProductRecord>(
    'product.template',
    [['sale_ok', '=', true]],
    ['id', 'name', 'default_code', 'barcode', 'list_price', 'active', 'categ_id', 'uom_id'],
    { limit: 1000 },
  );

  const defaultCategory = await ensureImportCategory(branchId);
  const vatTax = await prisma.tax.findFirst({
    where: { type: 'VAT', isDefault: true, isActive: true },
  });

  let created = 0;
  let updated = 0;
  let skipped = 0;
  const errors: string[] = [];

  for (const record of records) {
    try {
      const mapped = mapOdooProductToPos(record);
      const existing = await prisma.product.findFirst({
        where: {
          branchId,
          OR: [{ odooProductId: record.id }, { sku: mapped.sku }],
        },
      });

      if (!existing) {
        await prisma.product.create({
          data: {
            branchId,
            categoryId: defaultCategory.id,
            nameAr: mapped.nameAr,
            sku: mapped.sku,
            barcode: mapped.barcode,
            price: new Prisma.Decimal(mapped.price.toFixed(4)),
            priceIncludesVat: true,
            vatTaxId: vatTax?.id ?? null,
            unit: mapped.unit,
            isActive: mapped.isActive,
            odooProductId: mapped.odooProductId,
            syncStatus: SyncStatus.SYNCED,
            lastSyncAt: new Date(),
          },
        });
        created += 1;
        continue;
      }

      // عند التعارض: نطبق سياسة المصدر الأساسي
      if (!settings.odooIsMasterOnConflict && existing.lastSyncAt && existing.updatedAt > existing.lastSyncAt) {
        skipped += 1;
        continue;
      }

      await prisma.product.update({
        where: { id: existing.id },
        data: {
          nameAr: mapped.nameAr,
          barcode: mapped.barcode ?? existing.barcode,
          price: new Prisma.Decimal(mapped.price.toFixed(4)),
          isActive: mapped.isActive,
          unit: mapped.unit,
          odooProductId: mapped.odooProductId,
          syncStatus: SyncStatus.SYNCED,
          lastSyncAt: new Date(),
          syncErrorMessage: null,
        },
      });
      updated += 1;
    } catch (error) {
      errors.push(
        `المنتج ${record.name}: ${error instanceof Error ? error.message : 'خطأ'}`,
      );
    }
  }

  await prisma.syncLog.create({
    data: {
      entity: SyncEntity.PRODUCT,
      status: errors.length > 0 ? SyncStatus.NEEDS_REVIEW : SyncStatus.SYNCED,
      responseBody: { created, updated, skipped, errors } as unknown as Prisma.InputJsonValue,
      errorMessage: errors.length > 0 ? errors.slice(0, 5).join(' | ') : null,
    },
  });

  return { created, updated, skipped, errors };
}

async function ensureImportCategory(branchId: string) {
  const existing = await prisma.category.findFirst({
    where: { branchId, nameAr: 'مستورد من Odoo' },
  });
  if (existing) return existing;
  return prisma.category.create({
    data: { branchId, nameAr: 'مستورد من Odoo', sortOrder: 999 },
  });
}

// -----------------------------------------------------------------------------
// معالج المهام
// -----------------------------------------------------------------------------

/** توجيه المهمة إلى المعالج المناسب حسب نوع الكيان */
export async function processSyncJob(jobId: string): Promise<JobOutcome> {
  const job = await prisma.syncJob.findUnique({ where: { id: jobId } });
  if (!job) return { success: false, error: 'المهمة غير موجودة', retryable: false };

  switch (job.entity) {
    case SyncEntity.INVOICE:
      return pushInvoice(job.entityId);
    case SyncEntity.REFUND:
      return pushRefund(job.entityId);
    case SyncEntity.DAILY_SUMMARY:
      return pushDailySummary(job.entityId);
    case SyncEntity.PRODUCT:
      return pushProduct(job.entityId);
    default:
      return {
        success: false,
        error: `نوع كيان غير مدعوم: ${job.entity}`,
        retryable: false,
      };
  }
}

/**
 * تشغيل دورة معالجة واحدة للطابور.
 * تُستدعى من العامل الخلفي أو من مسار cron.
 */
export async function runSyncCycle(
  workerId: string,
  batchSize = 20,
): Promise<{ processed: number; succeeded: number; failed: number }> {
  const { claimPendingJobs } = await import('@/lib/odoo/sync-queue');
  const jobIds = await claimPendingJobs(workerId, batchSize);

  let succeeded = 0;
  let failed = 0;

  for (const jobId of jobIds) {
    const outcome = await processSyncJob(jobId).catch((error) => ({
      success: false,
      error: error instanceof Error ? error.message : 'خطأ غير معروف',
      retryable: true,
    }));
    await completeJob(jobId, outcome);
    if (outcome.success) succeeded += 1;
    else failed += 1;
  }

  return { processed: jobIds.length, succeeded, failed };
}

/**
 * وضع الملخص اليومي: بدل ترحيل كل فاتورة، نُلغي مهام الفواتير المعلقة
 * وننشئ مهمة ملخص واحدة لليوم التشغيلي.
 */
export async function scheduleDailySummary(branchId: string, closingId: string) {
  return prisma.$transaction(async (tx) => {
    // نُعلّم مهام الفواتير المعلقة كمشمولة في الملخص
    await tx.syncJob.updateMany({
      where: {
        branchId,
        entity: SyncEntity.INVOICE,
        status: { in: [SyncStatus.PENDING, SyncStatus.FAILED] },
      },
      data: {
        status: SyncStatus.SYNCED,
        lastError: 'مشمولة ضمن الملخص اليومي',
        lastSyncAt: new Date(),
      },
    });

    return enqueueSyncJob(tx, {
      branchId,
      entity: SyncEntity.DAILY_SUMMARY,
      entityId: closingId,
      idempotencyKey: `daily-summary:${closingId}`,
    });
  });
}
