import { Prisma, SyncEntity, SyncStatus, SyncDirection } from '@prisma/client';
import { prisma, type TransactionClient } from '@/lib/prisma';

/**
 * =============================================================================
 * طابور المزامنة مع Odoo
 * =============================================================================
 * طابور مبني على قاعدة البيانات (بدون Redis) يضمن:
 *  - منع إرسال نفس العملية مرتين عبر idempotency_key فريد.
 *  - إعادة المحاولة التلقائية بتأخير تصاعدي عند فشل الاتصال.
 *  - قفل المهام أثناء المعالجة حتى لا يلتقطها عاملان في نفس الوقت.
 *  - استمرار نقطة البيع في العمل عند تعطل Odoo (الفشل لا يوقف البيع).
 */

export interface EnqueueInput {
  branchId: string;
  entity: SyncEntity;
  entityId: string;
  idempotencyKey: string;
  direction?: SyncDirection;
  payload?: Prisma.InputJsonValue;
  maxAttempts?: number;
}

/**
 * إدراج مهمة مزامنة. آمن للاستدعاء المتكرر — إذا كان المفتاح موجودًا
 * لا تُنشأ مهمة جديدة (منع التكرار).
 */
export async function enqueueSyncJob(
  client: TransactionClient,
  input: EnqueueInput,
) {
  const existing = await client.syncJob.findUnique({
    where: { idempotencyKey: input.idempotencyKey },
  });
  if (existing) return existing;

  return client.syncJob.create({
    data: {
      branchId: input.branchId,
      entity: input.entity,
      entityId: input.entityId,
      direction: input.direction ?? SyncDirection.PUSH,
      idempotencyKey: input.idempotencyKey,
      payload: input.payload,
      maxAttempts: input.maxAttempts ?? 5,
      nextRetryAt: new Date(),
    },
  });
}

/** التأخير التصاعدي بين المحاولات: 30s, 2m, 8m, 32m, 2h (بحد أقصى ساعتين) */
export function backoffDelayMs(attempt: number): number {
  const base = 30_000;
  const delay = base * 4 ** Math.max(attempt - 1, 0);
  return Math.min(delay, 2 * 60 * 60 * 1000);
}

/**
 * سحب دفعة من المهام الجاهزة للمعالجة مع قفلها ذريًا.
 * نستخدم FOR UPDATE SKIP LOCKED حتى يعمل أكثر من عامل بأمان.
 */
export async function claimPendingJobs(
  workerId: string,
  batchSize = 20,
): Promise<string[]> {
  const rows = await prisma.$queryRaw<{ id: string }[]>`
    WITH ready AS (
      SELECT id FROM sync_jobs
      WHERE status IN ('PENDING', 'FAILED')
        AND attempts < max_attempts
        AND (next_retry_at IS NULL OR next_retry_at <= NOW())
        AND (locked_at IS NULL OR locked_at < NOW() - INTERVAL '5 minutes')
      ORDER BY created_at ASC
      LIMIT ${batchSize}
      FOR UPDATE SKIP LOCKED
    )
    UPDATE sync_jobs
    SET status = 'IN_PROGRESS', locked_at = NOW(), locked_by = ${workerId}, updated_at = NOW()
    WHERE id IN (SELECT id FROM ready)
    RETURNING id
  `;
  return rows.map((r) => r.id);
}

export interface JobOutcome {
  success: boolean;
  odooRecordId?: number | null;
  error?: string;
  retryable?: boolean;
  request?: unknown;
  response?: unknown;
  durationMs?: number;
}

/** تسجيل نتيجة معالجة مهمة وتحديث حالتها وحالة السجل المرتبط */
export async function completeJob(jobId: string, outcome: JobOutcome) {
  const job = await prisma.syncJob.findUnique({ where: { id: jobId } });
  if (!job) return;

  const attempts = job.attempts + 1;
  const exhausted = attempts >= job.maxAttempts;

  let status: SyncStatus;
  if (outcome.success) {
    status = SyncStatus.SYNCED;
  } else if (outcome.retryable === false || exhausted) {
    // خطأ غير قابل لإعادة المحاولة أو استُنفدت المحاولات ⇒ يحتاج مراجعة بشرية
    status = SyncStatus.NEEDS_REVIEW;
  } else {
    status = SyncStatus.FAILED;
  }

  await prisma.$transaction(async (tx) => {
    await tx.syncJob.update({
      where: { id: jobId },
      data: {
        status,
        attempts,
        odooRecordId: outcome.odooRecordId ?? job.odooRecordId,
        lastError: outcome.error ?? null,
        lastSyncAt: outcome.success ? new Date() : job.lastSyncAt,
        nextRetryAt:
          status === SyncStatus.FAILED ? new Date(Date.now() + backoffDelayMs(attempts)) : null,
        lockedAt: null,
        lockedBy: null,
      },
    });

    await tx.syncLog.create({
      data: {
        syncJobId: jobId,
        entity: job.entity,
        entityId: job.entityId,
        status,
        requestBody: (outcome.request as Prisma.InputJsonValue) ?? Prisma.JsonNull,
        responseBody: (outcome.response as Prisma.InputJsonValue) ?? Prisma.JsonNull,
        errorMessage: outcome.error ?? null,
        durationMs: outcome.durationMs ?? null,
      },
    });

    await updateEntitySyncState(tx, job.entity, job.entityId, {
      status,
      odooRecordId: outcome.odooRecordId ?? null,
      attempts,
      error: outcome.error ?? null,
    });
  });
}

/** تحديث حقول المزامنة على السجل الأصلي (فاتورة/دفعة/مرتجع/منتج/ملخص) */
export async function updateEntitySyncState(
  client: TransactionClient,
  entity: SyncEntity,
  entityId: string,
  state: {
    status: SyncStatus;
    odooRecordId: number | null;
    attempts: number;
    error: string | null;
  },
) {
  const data = {
    syncStatus: state.status,
    odooRecordId: state.odooRecordId ?? undefined,
    lastSyncAt: state.status === SyncStatus.SYNCED ? new Date() : undefined,
    syncAttempts: state.attempts,
    syncErrorMessage: state.error,
  };

  try {
    switch (entity) {
      case SyncEntity.INVOICE:
        await client.invoice.update({ where: { id: entityId }, data });
        break;
      case SyncEntity.PAYMENT:
        await client.payment.update({ where: { id: entityId }, data });
        break;
      case SyncEntity.REFUND:
        await client.refund.update({ where: { id: entityId }, data });
        break;
      case SyncEntity.PRODUCT:
        await client.product.update({
          where: { id: entityId },
          data: {
            syncStatus: data.syncStatus,
            odooProductId: state.odooRecordId ?? undefined,
            lastSyncAt: data.lastSyncAt,
            syncAttempts: data.syncAttempts,
            syncErrorMessage: data.syncErrorMessage,
          },
        });
        break;
      case SyncEntity.DAILY_SUMMARY:
        await client.dailyClosing.update({ where: { id: entityId }, data });
        break;
      case SyncEntity.EXPENSE:
        await client.expense.update({ where: { id: entityId }, data });
        break;
      default:
        break;
    }
  } catch (error) {
    // السجل قد يكون محذوفًا أو غير موجود — لا نُفشل المهمة بسبب ذلك
    console.warn(`[sync] تعذر تحديث حالة السجل ${entity}:${entityId}`, error);
  }
}

/** إعادة جدولة مهمة فاشلة يدويًا من شاشة المزامنة */
export async function retryJob(jobId: string) {
  const job = await prisma.syncJob.findUnique({ where: { id: jobId } });
  if (!job) return null;
  if (job.status === SyncStatus.SYNCED) return job;

  return prisma.syncJob.update({
    where: { id: jobId },
    data: {
      status: SyncStatus.PENDING,
      attempts: 0,
      nextRetryAt: new Date(),
      lastError: null,
      lockedAt: null,
      lockedBy: null,
      maxAttempts: Math.max(job.maxAttempts, job.attempts + 3),
    },
  });
}

/** إعادة جدولة جميع المهام الفاشلة لفرع معين */
export async function retryAllFailed(branchId: string) {
  const result = await prisma.syncJob.updateMany({
    where: {
      branchId,
      status: { in: [SyncStatus.FAILED, SyncStatus.NEEDS_REVIEW] },
    },
    data: {
      status: SyncStatus.PENDING,
      attempts: 0,
      nextRetryAt: new Date(),
      lastError: null,
      lockedAt: null,
      lockedBy: null,
    },
  });
  return result.count;
}
