import { XMLBuilder, XMLParser } from 'fast-xml-parser';

/**
 * =============================================================================
 * عميل Odoo — يدعم JSON-RPC و XML-RPC
 * =============================================================================
 * يعمل مع Odoo Online و Odoo.sh و Odoo Community.
 * لا تُسجّل بيانات الاعتماد في أي سجل أو استثناء.
 */

export interface OdooConnectionConfig {
  url: string;
  database: string;
  username: string;
  /** مفتاح API أو كلمة المرور (بعد فك التشفير) */
  apiKey: string;
  protocol: 'JSON_RPC' | 'XML_RPC' | 'REST';
  timeoutMs?: number;
}

export class OdooError extends Error {
  constructor(
    message: string,
    public readonly retryable: boolean,
    public readonly raw?: unknown,
  ) {
    super(message);
    this.name = 'OdooError';
  }
}

const DEFAULT_TIMEOUT = 20000;

function normalizeUrl(url: string): string {
  return url.replace(/\/+$/, '');
}

/** أخطاء الشبكة والانقطاع قابلة لإعادة المحاولة، بينما أخطاء البيانات لا */
function isRetryableMessage(message: string): boolean {
  const retryablePatterns = [
    'fetch failed',
    'ECONNREFUSED',
    'ETIMEDOUT',
    'ENOTFOUND',
    'ECONNRESET',
    'socket hang up',
    'timeout',
    'Service Unavailable',
    'Bad Gateway',
    'Gateway Timeout',
    'Too Many Requests',
  ];
  return retryablePatterns.some((p) => message.toLowerCase().includes(p.toLowerCase()));
}

async function fetchWithTimeout(
  url: string,
  init: RequestInit,
  timeoutMs: number,
): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'خطأ في الاتصال';
    throw new OdooError(
      `تعذر الاتصال بخادم Odoo: ${message}`,
      true,
      undefined,
    );
  } finally {
    clearTimeout(timer);
  }
}

// -----------------------------------------------------------------------------
// JSON-RPC
// -----------------------------------------------------------------------------

let jsonRpcId = 0;

async function jsonRpcCall(
  config: OdooConnectionConfig,
  service: string,
  method: string,
  args: unknown[],
): Promise<unknown> {
  jsonRpcId += 1;
  const body = {
    jsonrpc: '2.0',
    method: 'call',
    id: jsonRpcId,
    params: { service, method, args },
  };

  const response = await fetchWithTimeout(
    `${normalizeUrl(config.url)}/jsonrpc`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    },
    config.timeoutMs ?? DEFAULT_TIMEOUT,
  );

  if (!response.ok) {
    const text = await response.text().catch(() => '');
    throw new OdooError(
      `استجابة غير متوقعة من Odoo (${response.status})`,
      response.status >= 500 || response.status === 429,
      text.slice(0, 500),
    );
  }

  const json = (await response.json()) as {
    result?: unknown;
    error?: { message?: string; data?: { message?: string; name?: string } };
  };

  if (json.error) {
    const message =
      json.error.data?.message ?? json.error.message ?? 'خطأ غير معروف من Odoo';
    throw new OdooError(message, isRetryableMessage(message), json.error);
  }
  return json.result;
}

// -----------------------------------------------------------------------------
// XML-RPC
// -----------------------------------------------------------------------------

const xmlBuilder = new XMLBuilder({
  ignoreAttributes: false,
  suppressEmptyNode: true,
});
const xmlParser = new XMLParser({
  ignoreAttributes: false,
  parseTagValue: false,
  trimValues: true,
});

function toXmlValue(value: unknown): unknown {
  if (value === null || value === undefined) return { nil: '' };
  if (typeof value === 'boolean') return { boolean: value ? 1 : 0 };
  if (typeof value === 'number') {
    return Number.isInteger(value) ? { int: value } : { double: value };
  }
  if (typeof value === 'string') return { string: value };
  if (Array.isArray(value)) {
    return { array: { data: { value: value.map(toXmlValue) } } };
  }
  if (typeof value === 'object') {
    const members = Object.entries(value as Record<string, unknown>).map(
      ([name, val]) => ({ name, value: toXmlValue(val) }),
    );
    return { struct: { member: members } };
  }
  return { string: String(value) };
}

function fromXmlValue(node: any): unknown {
  if (node === null || node === undefined) return null;
  if (typeof node !== 'object') return node;
  if ('nil' in node) return null;
  if ('boolean' in node) return String(node.boolean) === '1';
  if ('int' in node) return Number(node.int);
  if ('i4' in node) return Number(node.i4);
  if ('double' in node) return Number(node.double);
  if ('string' in node) return typeof node.string === 'object' ? '' : String(node.string);
  if ('dateTime.iso8601' in node) return String(node['dateTime.iso8601']);
  if ('array' in node) {
    const data = node.array?.data?.value;
    if (data === undefined) return [];
    return (Array.isArray(data) ? data : [data]).map(fromXmlValue);
  }
  if ('struct' in node) {
    const members = node.struct?.member;
    if (!members) return {};
    const list = Array.isArray(members) ? members : [members];
    const result: Record<string, unknown> = {};
    for (const member of list) {
      result[String(member.name)] = fromXmlValue(member.value);
    }
    return result;
  }
  // قيمة بدون نوع صريح تُعامل كنص
  if ('#text' in node) return String(node['#text']);
  return null;
}

async function xmlRpcCall(
  config: OdooConnectionConfig,
  endpoint: string,
  methodName: string,
  params: unknown[],
): Promise<unknown> {
  const payload = xmlBuilder.build({
    methodCall: {
      methodName,
      params: { param: params.map((p) => ({ value: toXmlValue(p) })) },
    },
  });

  const response = await fetchWithTimeout(
    `${normalizeUrl(config.url)}/xmlrpc/2/${endpoint}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'text/xml' },
      body: `<?xml version="1.0"?>${payload}`,
    },
    config.timeoutMs ?? DEFAULT_TIMEOUT,
  );

  const text = await response.text();
  if (!response.ok) {
    throw new OdooError(
      `استجابة غير متوقعة من Odoo (${response.status})`,
      response.status >= 500 || response.status === 429,
      text.slice(0, 500),
    );
  }

  const parsed = xmlParser.parse(text) as any;
  const fault = parsed?.methodResponse?.fault;
  if (fault) {
    const faultValue = fromXmlValue(fault.value) as Record<string, unknown>;
    const message = String(faultValue?.faultString ?? 'خطأ من Odoo');
    throw new OdooError(message, isRetryableMessage(message), faultValue);
  }
  return fromXmlValue(parsed?.methodResponse?.params?.param?.value);
}

// -----------------------------------------------------------------------------
// الواجهة العامة
// -----------------------------------------------------------------------------

export class OdooClient {
  private uid: number | null = null;

  constructor(private readonly config: OdooConnectionConfig) {
    if (!config.url) throw new OdooError('رابط Odoo غير معرّف', false);
    if (!config.database) throw new OdooError('اسم قاعدة بيانات Odoo غير معرّف', false);
  }

  /** المصادقة والحصول على معرف المستخدم */
  async authenticate(): Promise<number> {
    if (this.uid !== null) return this.uid;

    const args = [this.config.database, this.config.username, this.config.apiKey, {}];
    const result =
      this.config.protocol === 'XML_RPC'
        ? await xmlRpcCall(this.config, 'common', 'authenticate', args)
        : await jsonRpcCall(this.config, 'common', 'login', [
            this.config.database,
            this.config.username,
            this.config.apiKey,
          ]);

    if (!result || typeof result !== 'number') {
      throw new OdooError(
        'فشل تسجيل الدخول إلى Odoo — تحقق من اسم المستخدم ومفتاح API وقاعدة البيانات',
        false,
      );
    }
    this.uid = result;
    return result;
  }

  /** استدعاء أي دالة على أي نموذج في Odoo */
  async execute<T = unknown>(
    model: string,
    method: string,
    args: unknown[] = [],
    kwargs: Record<string, unknown> = {},
  ): Promise<T> {
    const uid = await this.authenticate();
    if (this.config.protocol === 'XML_RPC') {
      return (await xmlRpcCall(this.config, 'object', 'execute_kw', [
        this.config.database,
        uid,
        this.config.apiKey,
        model,
        method,
        args,
        kwargs,
      ])) as T;
    }
    return (await jsonRpcCall(this.config, 'object', 'execute_kw', [
      this.config.database,
      uid,
      this.config.apiKey,
      model,
      method,
      args,
      kwargs,
    ])) as T;
  }

  async create(model: string, values: Record<string, unknown>): Promise<number> {
    const result = await this.execute<number | number[]>(model, 'create', [values]);
    return Array.isArray(result) ? result[0] : result;
  }

  async write(model: string, ids: number[], values: Record<string, unknown>) {
    return this.execute<boolean>(model, 'write', [ids, values]);
  }

  async searchRead<T = Record<string, unknown>>(
    model: string,
    domain: unknown[] = [],
    fields: string[] = [],
    options: { limit?: number; offset?: number; order?: string } = {},
  ): Promise<T[]> {
    return this.execute<T[]>(model, 'search_read', [domain], {
      fields,
      ...options,
    });
  }

  async searchCount(model: string, domain: unknown[] = []): Promise<number> {
    return this.execute<number>(model, 'search_count', [domain]);
  }

  /** اختبار الاتصال — يعيد معلومات الخادم والمستخدم */
  async testConnection(): Promise<{ uid: number; version: string }> {
    const versionInfo =
      this.config.protocol === 'XML_RPC'
        ? await xmlRpcCall(this.config, 'common', 'version', [])
        : await jsonRpcCall(this.config, 'common', 'version', []);
    const uid = await this.authenticate();
    const version =
      (versionInfo as { server_version?: string })?.server_version ?? 'غير معروف';
    return { uid, version };
  }
}

export function createOdooClient(config: OdooConnectionConfig): OdooClient {
  return new OdooClient(config);
}
