import type { OdooSetting } from '@prisma/client';
import { round2, toNumber } from '@/lib/money';
import { formatBusinessDay } from '@/lib/business-day';
import type { InvoiceWithRelations } from '@/lib/pos/checkout-service';

/**
 * تحويل بيانات نقطة البيع إلى بنية سجلات Odoo المحاسبية.
 *
 * ملاحظة مهمة: ضريبة التبغ تُرحّل كسطر مستقل بحسابها الخاص،
 * ولا تُدمج مع ضريبة القيمة المضافة.
 */

export interface OdooInvoicePayload {
  move_type: 'out_invoice' | 'out_refund';
  partner_id: number;
  invoice_date: string;
  ref: string;
  journal_id?: number;
  company_id?: number;
  narration: string;
  invoice_line_ids: [number, number, Record<string, unknown>][];
  /** حقول مرجعية إضافية تظهر في الملاحظات */
  x_pos_reference?: string;
}

interface InvoiceMapContext {
  settings: OdooSetting;
  /** خريطة معرفات منتجات نقطة البيع إلى منتجات Odoo */
  productMap: Map<string, number>;
  employeeName: string;
  branchName: string;
  shiftNumber: string | null;
}

function analyticDistribution(settings: OdooSetting): Record<string, unknown> {
  if (!settings.analyticAccountId) return {};
  return { analytic_distribution: { [String(settings.analyticAccountId)]: 100 } };
}

/** بناء سطور فاتورة Odoo من أسطر فاتورة نقطة البيع */
export function mapInvoiceLines(
  invoice: InvoiceWithRelations,
  ctx: InvoiceMapContext,
): [number, number, Record<string, unknown>][] {
  const lines: [number, number, Record<string, unknown>][] = [];

  for (const item of invoice.items) {
    const odooProductId = ctx.productMap.get(item.productId);
    const quantity = toNumber(item.quantity);
    const net = toNumber(item.netBeforeTax);
    const unitPrice = quantity > 0 ? round2(net / quantity) : 0;

    lines.push([
      0,
      0,
      {
        name: item.nameAr,
        quantity,
        price_unit: unitPrice,
        ...(odooProductId ? { product_id: odooProductId } : {}),
        ...analyticDistribution(ctx.settings),
      },
    ]);
  }

  // سطر مستقل لضريبة التبغ إن وُجدت
  const tobaccoTotal = toNumber(invoice.tobaccoTaxTotal);
  if (tobaccoTotal > 0) {
    lines.push([
      0,
      0,
      {
        name: 'ضريبة التبغ (الانتقائية)',
        quantity: 1,
        price_unit: tobaccoTotal,
        ...(ctx.settings.tobaccoTaxAccountId
          ? { account_id: ctx.settings.tobaccoTaxAccountId }
          : {}),
        ...analyticDistribution(ctx.settings),
      },
    ]);
  }

  return lines;
}

/** تحويل فاتورة نقطة بيع إلى فاتورة عميل في Odoo */
export function mapInvoiceToOdoo(
  invoice: InvoiceWithRelations,
  ctx: InvoiceMapContext,
): OdooInvoicePayload {
  const narrationParts = [
    `رقم فاتورة نقطة البيع: ${invoice.invoiceNumber}`,
    `الفرع: ${ctx.branchName}`,
    `الموظف: ${ctx.employeeName}`,
    `نوع الطلب: ${invoice.type}`,
    ctx.shiftNumber ? `رقم الوردية: ${ctx.shiftNumber}` : null,
    `اليوم التشغيلي: ${formatBusinessDay(invoice.businessDay)}`,
    `ضريبة القيمة المضافة: ${toNumber(invoice.vatTotal).toFixed(2)}`,
    `ضريبة التبغ: ${toNumber(invoice.tobaccoTaxTotal).toFixed(2)}`,
    `الخصومات: ${toNumber(invoice.discountTotal).toFixed(2)}`,
    `طرق الدفع: ${invoice.payments
      .map((p) => `${p.paymentMethod.nameAr} ${toNumber(p.amount).toFixed(2)}`)
      .join('، ')}`,
  ].filter(Boolean);

  return {
    move_type: 'out_invoice',
    partner_id: ctx.settings.defaultPartnerId ?? 1,
    invoice_date: formatBusinessDay(invoice.businessDay),
    ref: invoice.invoiceNumber,
    ...(ctx.settings.salesJournalId ? { journal_id: ctx.settings.salesJournalId } : {}),
    ...(ctx.settings.companyId ? { company_id: ctx.settings.companyId } : {}),
    narration: narrationParts.join('\n'),
    invoice_line_ids: mapInvoiceLines(invoice, ctx),
    x_pos_reference: invoice.reference,
  };
}

export interface OdooPaymentPayload {
  payment_type: 'inbound';
  partner_type: 'customer';
  partner_id: number;
  amount: number;
  date: string;
  ref: string;
  journal_id?: number;
}

/** تحويل دفعة إلى سجل دفع في Odoo باستخدام دفتر اليومية المناسب */
export function mapPaymentToOdoo(
  payment: { amount: unknown; businessDay: Date; reference?: string | null },
  methodJournalId: number | undefined,
  settings: OdooSetting,
  ref: string,
): OdooPaymentPayload {
  return {
    payment_type: 'inbound',
    partner_type: 'customer',
    partner_id: settings.defaultPartnerId ?? 1,
    amount: toNumber(payment.amount as never),
    date: formatBusinessDay(payment.businessDay),
    ref,
    ...(methodJournalId ? { journal_id: methodJournalId } : {}),
  };
}

export interface DailySummaryLine {
  label: string;
  amount: number;
  accountId?: number | null;
}

export interface DailySummaryPayload {
  move_type: 'entry';
  date: string;
  ref: string;
  journal_id?: number;
  narration: string;
  lines: DailySummaryLine[];
}

/**
 * بناء ملخص يومي واحد بدل إرسال كل فاتورة على حدة.
 * هذا هو الوضع الافتراضي لتقليل عدد العمليات داخل Odoo.
 */
export function mapDailySummaryToOdoo(
  closing: {
    businessDay: Date;
    salesBeforeTax: unknown;
    vatTotal: unknown;
    tobaccoTaxTotal: unknown;
    discountTotal: unknown;
    refundTotal: unknown;
    cashTotal: unknown;
    cardTotal: unknown;
    otherTotal: unknown;
    cashDifference: unknown;
    invoiceCount: number;
  },
  settings: OdooSetting,
  branchName: string,
): DailySummaryPayload {
  const day = formatBusinessDay(closing.businessDay);

  const lines: DailySummaryLine[] = [
    { label: 'إجمالي المبيعات قبل الضريبة', amount: toNumber(closing.salesBeforeTax as never) },
    {
      label: 'ضريبة القيمة المضافة',
      amount: toNumber(closing.vatTotal as never),
      accountId: settings.vatAccountId,
    },
    {
      label: 'ضريبة التبغ',
      amount: toNumber(closing.tobaccoTaxTotal as never),
      accountId: settings.tobaccoTaxAccountId,
    },
    {
      label: 'الخصومات',
      amount: toNumber(closing.discountTotal as never),
      accountId: settings.discountAccountId,
    },
    {
      label: 'المرتجعات',
      amount: toNumber(closing.refundTotal as never),
      accountId: settings.refundAccountId,
    },
    {
      label: 'إجمالي التحصيل النقدي',
      amount: toNumber(closing.cashTotal as never),
      accountId: settings.cashJournalId,
    },
    {
      label: 'إجمالي التحصيل بالشبكة',
      amount: toNumber(closing.cardTotal as never),
      accountId: settings.bankJournalId,
    },
    {
      label: 'فروقات الصندوق',
      amount: toNumber(closing.cashDifference as never),
      accountId: settings.cashDiffAccountId,
    },
  ];

  return {
    move_type: 'entry',
    date: day,
    ref: `POS-SUMMARY-${day}`,
    ...(settings.salesJournalId ? { journal_id: settings.salesJournalId } : {}),
    narration: [
      `ملخص مبيعات نقطة البيع — ${branchName}`,
      `اليوم التشغيلي: ${day}`,
      `عدد الفواتير: ${closing.invoiceCount}`,
      ...lines.map((l) => `${l.label}: ${l.amount.toFixed(2)}`),
    ].join('\n'),
    lines,
  };
}

export interface OdooProductRecord {
  id: number;
  name: string;
  default_code?: string | false;
  barcode?: string | false;
  list_price?: number;
  active?: boolean;
  categ_id?: [number, string] | false;
  uom_id?: [number, string] | false;
  taxes_id?: number[];
}

/** تحويل منتج Odoo إلى بنية منتج نقطة البيع */
export function mapOdooProductToPos(record: OdooProductRecord) {
  return {
    odooProductId: record.id,
    nameAr: record.name,
    sku: typeof record.default_code === 'string' ? record.default_code : `ODOO-${record.id}`,
    barcode: typeof record.barcode === 'string' ? record.barcode : null,
    price: round2(record.list_price ?? 0),
    isActive: record.active !== false,
    odooCategoryName: Array.isArray(record.categ_id) ? record.categ_id[1] : null,
    unit: Array.isArray(record.uom_id) ? record.uom_id[1] : 'PCS',
  };
}

/** تحويل منتج نقطة البيع إلى قيم منتج Odoo */
export function mapPosProductToOdoo(product: {
  nameAr: string;
  nameEn: string | null;
  sku: string;
  barcode: string | null;
  price: unknown;
  isActive: boolean;
}) {
  return {
    name: product.nameAr,
    default_code: product.sku,
    ...(product.barcode ? { barcode: product.barcode } : {}),
    list_price: toNumber(product.price as never),
    active: product.isActive,
    type: 'consu',
    available_in_pos: true,
  };
}
