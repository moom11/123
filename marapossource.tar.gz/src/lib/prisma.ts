import { PrismaClient } from '@prisma/client';

/**
 * عميل Prisma وحيد لكل عملية — يمنع استنفاد اتصالات قاعدة البيانات
 * أثناء إعادة التحميل الساخن في بيئة التطوير.
 */
const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['warn', 'error'] : ['error'],
  });

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = prisma;
}

export type TransactionClient = Omit<
  PrismaClient,
  '$connect' | '$disconnect' | '$on' | '$transaction' | '$use' | '$extends'
>;
