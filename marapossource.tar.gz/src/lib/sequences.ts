import type { TransactionClient } from '@/lib/prisma';
import { prisma } from '@/lib/prisma';
import { formatBusinessDay } from '@/lib/business-day';

/**
 * توليد الأرقام المتسلسلة بشكل ذري داخل قاعدة البيانات.
 *
 * نستخدم UPSERT مع زيادة ذرية حتى لا يحدث تضارب في الأرقام عند
 * تشغيل أكثر من جهاز نقطة بيع في نفس اللحظة.
 */
export type SequenceName = 'ORDER' | 'INVOICE' | 'SHIFT' | 'REFUND' | 'KITCHEN_TICKET';

export async function nextSequence(
  client: TransactionClient,
  branchId: string,
  name: SequenceName,
  scope = 'GLOBAL',
): Promise<number> {
  const rows = await client.$queryRaw<{ value: number }[]>`
    INSERT INTO sequences (id, branch_id, name, scope, value, updated_at)
    VALUES (gen_random_uuid(), ${branchId}::uuid, ${name}, ${scope}, 1, NOW())
    ON CONFLICT (branch_id, name, scope)
    DO UPDATE SET value = sequences.value + 1, updated_at = NOW()
    RETURNING value
  `;
  return rows[0]?.value ?? 1;
}

/** رقم طلب بالشكل ORD-20260802-0001 (متسلسل ضمن اليوم التشغيلي) */
export async function nextOrderNumber(
  client: TransactionClient,
  branchId: string,
  businessDay: Date,
  prefix = 'ORD',
): Promise<string> {
  const scope = formatBusinessDay(businessDay);
  const value = await nextSequence(client, branchId, 'ORDER', scope);
  return `${prefix}-${scope.replace(/-/g, '')}-${String(value).padStart(4, '0')}`;
}

/** رقم فاتورة متسلسل ولا يعاد استخدامه أبدًا (متسلسل عام للفرع) */
export async function nextInvoiceNumber(
  client: TransactionClient,
  branchId: string,
  prefix = 'INV',
): Promise<string> {
  const value = await nextSequence(client, branchId, 'INVOICE');
  return `${prefix}-${String(value).padStart(6, '0')}`;
}

export async function nextShiftNumber(
  client: TransactionClient,
  branchId: string,
): Promise<string> {
  const value = await nextSequence(client, branchId, 'SHIFT');
  return `SH-${String(value).padStart(5, '0')}`;
}

export async function nextRefundNumber(
  client: TransactionClient,
  branchId: string,
): Promise<string> {
  const value = await nextSequence(client, branchId, 'REFUND');
  return `RET-${String(value).padStart(6, '0')}`;
}

export async function nextKitchenTicketNumber(
  client: TransactionClient,
  branchId: string,
  businessDay: Date,
): Promise<string> {
  const scope = formatBusinessDay(businessDay);
  const value = await nextSequence(client, branchId, 'KITCHEN_TICKET', scope);
  return String(value).padStart(3, '0');
}

/** نسخة تستخدم خارج المعاملات */
export const sequences = {
  order: (branchId: string, day: Date, prefix?: string) =>
    nextOrderNumber(prisma, branchId, day, prefix),
  invoice: (branchId: string, prefix?: string) =>
    nextInvoiceNumber(prisma, branchId, prefix),
  shift: (branchId: string) => nextShiftNumber(prisma, branchId),
  refund: (branchId: string) => nextRefundNumber(prisma, branchId),
};
