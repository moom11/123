import { InvoiceStatus, Prisma, SyncStatus } from '@prisma/client';
import { prisma } from '@/lib/prisma';
import { round2, toNumber } from '@/lib/money';
import { parseBusinessDay } from '@/lib/business-day';

export interface ReportRange {
  branchId: string;
  from: Date;
  to: Date;
}

const COUNTED_STATUSES: InvoiceStatus[] = [
  InvoiceStatus.PAID,
  InvoiceStatus.PARTIALLY_REFUNDED,
  InvoiceStatus.REFUNDED,
];

export function parseRange(
  branchId: string,
  from?: string,
  to?: string,
): ReportRange {
  const today = new Date();
  const fallback = new Date(
    Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate()),
  );
  return {
    branchId,
    from: from ? parseBusinessDay(from) : fallback,
    to: to ? parseBusinessDay(to) : fallback,
  };
}

function dayFilter(range: ReportRange) {
  return {
    branchId: range.branchId,
    businessDay: { gte: range.from, lte: range.to },
  };
}

// -----------------------------------------------------------------------------
// تقرير المبيعات
// -----------------------------------------------------------------------------

export interface SalesReport {
  totalSales: number;
  netSales: number;
  salesBeforeTax: number;
  vatTotal: number;
  tobaccoTaxTotal: number;
  discountTotal: number;
  refundTotal: number;
  invoiceCount: number;
  averageInvoice: number;
}

export async function getSalesReport(range: ReportRange): Promise<SalesReport> {
  const [invoices, refunds] = await Promise.all([
    prisma.invoice.findMany({
      where: { ...dayFilter(range), status: { in: COUNTED_STATUSES } },
      select: {
        grandTotal: true,
        netBeforeTax: true,
        vatTotal: true,
        tobaccoTaxTotal: true,
        discountTotal: true,
      },
    }),
    prisma.refund.findMany({
      where: {
        businessDay: { gte: range.from, lte: range.to },
        invoice: { branchId: range.branchId },
      },
      select: { grandTotal: true },
    }),
  ]);

  const totalSales = round2(invoices.reduce((a, i) => a + toNumber(i.grandTotal), 0));
  const refundTotal = round2(refunds.reduce((a, r) => a + toNumber(r.grandTotal), 0));

  return {
    totalSales,
    netSales: round2(totalSales - refundTotal),
    salesBeforeTax: round2(invoices.reduce((a, i) => a + toNumber(i.netBeforeTax), 0)),
    vatTotal: round2(invoices.reduce((a, i) => a + toNumber(i.vatTotal), 0)),
    tobaccoTaxTotal: round2(
      invoices.reduce((a, i) => a + toNumber(i.tobaccoTaxTotal), 0),
    ),
    discountTotal: round2(invoices.reduce((a, i) => a + toNumber(i.discountTotal), 0)),
    refundTotal,
    invoiceCount: invoices.length,
    averageInvoice: invoices.length > 0 ? round2(totalSales / invoices.length) : 0,
  };
}

// -----------------------------------------------------------------------------
// تقرير طرق الدفع
// -----------------------------------------------------------------------------

export interface PaymentMethodReportRow {
  methodId: string;
  methodName: string;
  methodType: string;
  amount: number;
  count: number;
}

export interface PaymentsReport {
  rows: PaymentMethodReportRow[];
  totalCollected: number;
  totalSales: number;
  /** الفرق بين إجمالي المبيعات وإجمالي التحصيل */
  variance: number;
  mixedPaymentInvoices: number;
}

export async function getPaymentsReport(range: ReportRange): Promise<PaymentsReport> {
  const payments = await prisma.payment.findMany({
    where: {
      status: 'CAPTURED',
      businessDay: { gte: range.from, lte: range.to },
      invoice: { branchId: range.branchId, status: { in: COUNTED_STATUSES } },
    },
    include: { paymentMethod: true },
  });

  const byMethod = new Map<string, PaymentMethodReportRow>();
  const invoicePaymentCount = new Map<string, number>();

  for (const payment of payments) {
    const key = payment.paymentMethodId;
    const row = byMethod.get(key) ?? {
      methodId: key,
      methodName: payment.paymentMethod.nameAr,
      methodType: payment.paymentMethod.type,
      amount: 0,
      count: 0,
    };
    row.amount = round2(row.amount + toNumber(payment.amount));
    row.count += 1;
    byMethod.set(key, row);

    invoicePaymentCount.set(
      payment.invoiceId,
      (invoicePaymentCount.get(payment.invoiceId) ?? 0) + 1,
    );
  }

  const totalCollected = round2(
    Array.from(byMethod.values()).reduce((a, r) => a + r.amount, 0),
  );
  const sales = await getSalesReport(range);

  return {
    rows: Array.from(byMethod.values()).sort((a, b) => b.amount - a.amount),
    totalCollected,
    totalSales: sales.totalSales,
    variance: round2(sales.totalSales - totalCollected),
    mixedPaymentInvoices: Array.from(invoicePaymentCount.values()).filter((c) => c > 1)
      .length,
  };
}

// -----------------------------------------------------------------------------
// تقرير المنتجات
// -----------------------------------------------------------------------------

export interface ProductReportRow {
  productId: string;
  name: string;
  sku: string;
  categoryName: string;
  prepStation: string;
  quantity: number;
  netSales: number;
}

export interface ProductsReport {
  topProducts: ProductReportRow[];
  bottomProducts: ProductReportRow[];
  byCategory: { categoryName: string; quantity: number; netSales: number }[];
  byStation: { station: string; quantity: number; netSales: number }[];
}

export async function getProductsReport(range: ReportRange): Promise<ProductsReport> {
  const items = await prisma.invoiceItem.findMany({
    where: {
      invoice: { ...dayFilter(range), status: { in: COUNTED_STATUSES } },
    },
    select: {
      productId: true,
      nameAr: true,
      sku: true,
      quantity: true,
      netBeforeTax: true,
      prepStation: true,
    },
  });

  const productIds = Array.from(new Set(items.map((i) => i.productId)));
  const products = await prisma.product.findMany({
    where: { id: { in: productIds } },
    include: { category: { select: { nameAr: true } } },
  });
  const categoryByProduct = new Map(
    products.map((p) => [p.id, p.category?.nameAr ?? 'غير مصنف']),
  );

  const byProduct = new Map<string, ProductReportRow>();
  for (const item of items) {
    const row = byProduct.get(item.productId) ?? {
      productId: item.productId,
      name: item.nameAr,
      sku: item.sku,
      categoryName: categoryByProduct.get(item.productId) ?? 'غير مصنف',
      prepStation: item.prepStation,
      quantity: 0,
      netSales: 0,
    };
    row.quantity = round2(row.quantity + toNumber(item.quantity));
    row.netSales = round2(row.netSales + toNumber(item.netBeforeTax));
    byProduct.set(item.productId, row);
  }

  const sorted = Array.from(byProduct.values()).sort((a, b) => b.quantity - a.quantity);

  const aggregate = <K extends string>(
    keyFn: (row: ProductReportRow) => K,
  ): { key: K; quantity: number; netSales: number }[] => {
    const map = new Map<K, { key: K; quantity: number; netSales: number }>();
    for (const row of sorted) {
      const key = keyFn(row);
      const entry = map.get(key) ?? { key, quantity: 0, netSales: 0 };
      entry.quantity = round2(entry.quantity + row.quantity);
      entry.netSales = round2(entry.netSales + row.netSales);
      map.set(key, entry);
    }
    return Array.from(map.values()).sort((a, b) => b.netSales - a.netSales);
  };

  return {
    topProducts: sorted.slice(0, 20),
    bottomProducts: sorted.slice(-20).reverse(),
    byCategory: aggregate((r) => r.categoryName).map((e) => ({
      categoryName: e.key,
      quantity: e.quantity,
      netSales: e.netSales,
    })),
    byStation: aggregate((r) => r.prepStation).map((e) => ({
      station: e.key,
      quantity: e.quantity,
      netSales: e.netSales,
    })),
  };
}

// -----------------------------------------------------------------------------
// تقرير الموظفين
// -----------------------------------------------------------------------------

export interface EmployeeReportRow {
  userId: string;
  fullName: string;
  employeeNo: string;
  sales: number;
  orderCount: number;
  discountTotal: number;
  cancelledCount: number;
  refundTotal: number;
  averageInvoice: number;
}

export async function getEmployeesReport(
  range: ReportRange,
): Promise<EmployeeReportRow[]> {
  const invoices = await prisma.invoice.findMany({
    where: { ...dayFilter(range) },
    include: { user: { select: { fullName: true, employeeNo: true } } },
  });

  const refunds = await prisma.refund.findMany({
    where: {
      businessDay: { gte: range.from, lte: range.to },
      invoice: { branchId: range.branchId },
    },
    select: { createdById: true, grandTotal: true },
  });

  const byUser = new Map<string, EmployeeReportRow>();
  for (const invoice of invoices) {
    const row = byUser.get(invoice.userId) ?? {
      userId: invoice.userId,
      fullName: invoice.user.fullName,
      employeeNo: invoice.user.employeeNo,
      sales: 0,
      orderCount: 0,
      discountTotal: 0,
      cancelledCount: 0,
      refundTotal: 0,
      averageInvoice: 0,
    };
    if (COUNTED_STATUSES.includes(invoice.status)) {
      row.sales = round2(row.sales + toNumber(invoice.grandTotal));
      row.orderCount += 1;
      row.discountTotal = round2(row.discountTotal + toNumber(invoice.discountTotal));
    }
    if (invoice.status === InvoiceStatus.CANCELLED) row.cancelledCount += 1;
    byUser.set(invoice.userId, row);
  }

  for (const refund of refunds) {
    const row = byUser.get(refund.createdById);
    if (row) row.refundTotal = round2(row.refundTotal + toNumber(refund.grandTotal));
  }

  return Array.from(byUser.values())
    .map((row) => ({
      ...row,
      averageInvoice: row.orderCount > 0 ? round2(row.sales / row.orderCount) : 0,
    }))
    .sort((a, b) => b.sales - a.sales);
}

// -----------------------------------------------------------------------------
// تقرير الورديات
// -----------------------------------------------------------------------------

export interface ShiftReportRow {
  shiftId: string;
  shiftNumber: string;
  cashierName: string;
  openedAt: Date;
  closedAt: Date | null;
  status: string;
  openingFloat: number;
  cashSales: number;
  expenses: number;
  withdrawals: number;
  deposits: number;
  expectedCash: number;
  countedCash: number | null;
  difference: number | null;
}

export async function getShiftsReport(range: ReportRange): Promise<ShiftReportRow[]> {
  const shifts = await prisma.shift.findMany({
    where: dayFilter(range),
    include: {
      user: { select: { fullName: true } },
      cashMovements: true,
      payments: { include: { paymentMethod: true } },
    },
    orderBy: { openedAt: 'desc' },
  });

  return shifts.map((shift) => {
    const sumType = (type: string) =>
      round2(
        shift.cashMovements
          .filter((m) => m.type === type)
          .reduce((a, m) => a + Math.abs(toNumber(m.amount)), 0),
      );

    const cashSales = round2(
      shift.payments
        .filter((p) => p.paymentMethod.affectsCashDrawer && p.status === 'CAPTURED')
        .reduce((a, p) => a + toNumber(p.amount), 0),
    );

    return {
      shiftId: shift.id,
      shiftNumber: shift.shiftNumber,
      cashierName: shift.user.fullName,
      openedAt: shift.openedAt,
      closedAt: shift.closedAt,
      status: shift.status,
      openingFloat: toNumber(shift.openingFloat),
      cashSales,
      expenses: sumType('EXPENSE'),
      withdrawals: sumType('WITHDRAWAL'),
      deposits: sumType('DEPOSIT_TO_MAIN_SAFE'),
      expectedCash: shift.expectedCash != null ? toNumber(shift.expectedCash) : 0,
      countedCash: shift.countedCash != null ? toNumber(shift.countedCash) : null,
      difference: shift.cashDifference != null ? toNumber(shift.cashDifference) : null,
    };
  });
}

// -----------------------------------------------------------------------------
// لوحة التحكم
// -----------------------------------------------------------------------------

export interface DashboardData {
  businessDay: string;
  sales: SalesReport;
  cashSales: number;
  cardSales: number;
  expenses: number;
  deposits: number;
  currentShift: {
    id: string;
    shiftNumber: string;
    cashierName: string;
    openedAt: Date;
    expectedCash: number;
  } | null;
  topProducts: { name: string; quantity: number; netSales: number }[];
  failedSyncCount: number;
  pendingSyncCount: number;
}

export async function getDashboard(
  branchId: string,
  businessDay: Date,
  userId?: string,
): Promise<DashboardData> {
  const range: ReportRange = { branchId, from: businessDay, to: businessDay };

  const [sales, payments, movements, products, failedSyncCount, pendingSyncCount, shift] =
    await Promise.all([
      getSalesReport(range),
      prisma.payment.findMany({
        where: {
          status: 'CAPTURED',
          businessDay,
          invoice: { branchId, status: { in: COUNTED_STATUSES } },
        },
        include: { paymentMethod: true },
      }),
      prisma.cashMovement.findMany({ where: { branchId, businessDay } }),
      getProductsReport(range),
      prisma.syncJob.count({
        where: { branchId, status: { in: [SyncStatus.FAILED, SyncStatus.NEEDS_REVIEW] } },
      }),
      prisma.syncJob.count({ where: { branchId, status: SyncStatus.PENDING } }),
      prisma.shift.findFirst({
        where: { branchId, status: 'OPEN', ...(userId ? { userId } : {}) },
        orderBy: { openedAt: 'desc' },
        include: { user: { select: { fullName: true } } },
      }),
    ]);

  const cashSales = round2(
    payments
      .filter((p) => p.paymentMethod.affectsCashDrawer)
      .reduce((a, p) => a + toNumber(p.amount), 0),
  );
  const cardSales = round2(
    payments
      .filter((p) =>
        ['MADA', 'VISA', 'MASTERCARD', 'APPLE_PAY'].includes(p.paymentMethod.type),
      )
      .reduce((a, p) => a + toNumber(p.amount), 0),
  );

  const sumMovement = (type: string) =>
    round2(
      movements
        .filter((m) => m.type === type)
        .reduce((a, m) => a + Math.abs(toNumber(m.amount)), 0),
    );

  let expectedCash = 0;
  if (shift) {
    const { getShiftSummary } = await import('@/lib/pos/shift-service');
    expectedCash = (await getShiftSummary(shift.id)).expectedCash;
  }

  return {
    businessDay: businessDay.toISOString().slice(0, 10),
    sales,
    cashSales,
    cardSales,
    expenses: sumMovement('EXPENSE'),
    deposits: sumMovement('DEPOSIT_TO_MAIN_SAFE'),
    currentShift: shift
      ? {
          id: shift.id,
          shiftNumber: shift.shiftNumber,
          cashierName: shift.user.fullName,
          openedAt: shift.openedAt,
          expectedCash,
        }
      : null,
    topProducts: products.topProducts.slice(0, 5).map((p) => ({
      name: p.name,
      quantity: p.quantity,
      netSales: p.netSales,
    })),
    failedSyncCount,
    pendingSyncCount,
  };
}

// -----------------------------------------------------------------------------
// الإغلاق اليومي
// -----------------------------------------------------------------------------

/** بناء/تحديث سجل الإغلاق اليومي — أساس الملخص المرسل إلى Odoo */
export async function buildDailyClosing(branchId: string, businessDay: Date) {
  const range: ReportRange = { branchId, from: businessDay, to: businessDay };
  const [sales, paymentsReport, shifts, movements] = await Promise.all([
    getSalesReport(range),
    getPaymentsReport(range),
    getShiftsReport(range),
    prisma.cashMovement.findMany({ where: { branchId, businessDay } }),
  ]);

  const cashTotal = round2(
    paymentsReport.rows
      .filter((r) => r.methodType === 'CASH')
      .reduce((a, r) => a + r.amount, 0),
  );
  const cardTotal = round2(
    paymentsReport.rows
      .filter((r) => ['MADA', 'VISA', 'MASTERCARD', 'APPLE_PAY'].includes(r.methodType))
      .reduce((a, r) => a + r.amount, 0),
  );
  const otherTotal = round2(paymentsReport.totalCollected - cashTotal - cardTotal);

  const sumMovement = (type: string) =>
    round2(
      movements
        .filter((m) => m.type === type)
        .reduce((a, m) => a + Math.abs(toNumber(m.amount)), 0),
    );

  const cashDifference = round2(
    shifts.reduce((a, s) => a + (s.difference ?? 0), 0),
  );

  const data = {
    totalSales: sales.totalSales,
    netSales: sales.netSales,
    salesBeforeTax: sales.salesBeforeTax,
    vatTotal: sales.vatTotal,
    tobaccoTaxTotal: sales.tobaccoTaxTotal,
    discountTotal: sales.discountTotal,
    refundTotal: sales.refundTotal,
    cashTotal,
    cardTotal,
    otherTotal,
    expenseTotal: sumMovement('EXPENSE'),
    depositTotal: sumMovement('DEPOSIT_TO_MAIN_SAFE'),
    cashDifference,
    invoiceCount: sales.invoiceCount,
    breakdown: {
      paymentMethods: paymentsReport.rows,
      shifts: shifts.map((s) => ({
        shiftNumber: s.shiftNumber,
        cashier: s.cashierName,
        expected: s.expectedCash,
        counted: s.countedCash,
        difference: s.difference,
      })),
    } as unknown as Prisma.InputJsonValue,
  };

  return prisma.dailyClosing.upsert({
    where: { branchId_businessDay: { branchId, businessDay } },
    create: {
      branchId,
      businessDay,
      ...data,
      idempotencyKey: `daily:${branchId}:${businessDay.toISOString().slice(0, 10)}`,
    },
    update: data,
  });
}
