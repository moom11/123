import ExcelJS from 'exceljs';

/**
 * مصدّرات التقارير: Excel و CSV.
 * تصدير PDF يتم عبر صفحة الطباعة المخصصة في الواجهة (طباعة إلى PDF من المتصفح)
 * لضمان عرض النصوص العربية بشكل صحيح دون الحاجة لخطوط مضمّنة.
 */

/** صف تصدير: أي كائن بمفاتيح نصية */
export type ExportRow = Record<string, unknown> | object;

export interface ExportColumn {
  key: string;
  header: string;
  width?: number;
  /** تنسيق رقمي (مبالغ) */
  money?: boolean;
}

/** يبني ملف Excel بترتيب أعمدة من اليمين إلى اليسار */
export async function buildExcel(
  sheetName: string,
  columns: ExportColumn[],
  rows: ExportRow[],
  title?: string,
): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'Mara POS';
  workbook.created = new Date();

  const sheet = workbook.addWorksheet(sheetName.slice(0, 30), {
    views: [{ rightToLeft: true, state: 'frozen', ySplit: title ? 2 : 1 }],
  });

  if (title) {
    sheet.mergeCells(1, 1, 1, Math.max(columns.length, 1));
    const titleCell = sheet.getCell(1, 1);
    titleCell.value = title;
    titleCell.font = { bold: true, size: 14 };
    titleCell.alignment = { horizontal: 'center' };
  }

  const headerRow = sheet.addRow(columns.map((c) => c.header));
  headerRow.font = { bold: true, color: { argb: 'FFFFFFFF' } };
  headerRow.eachCell((cell) => {
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFC8102E' } };
    cell.alignment = { horizontal: 'center', vertical: 'middle' };
  });

  for (const row of rows) {
    const values = columns.map((column) => {
      const value = (row as Record<string, unknown>)[column.key];
      if (value instanceof Date) return value.toISOString().slice(0, 19).replace('T', ' ');
      return value ?? '';
    });
    const added = sheet.addRow(values);
    columns.forEach((column, index) => {
      if (column.money) {
        added.getCell(index + 1).numFmt = '#,##0.00';
      }
    });
  }

  columns.forEach((column, index) => {
    sheet.getColumn(index + 1).width = column.width ?? 18;
  });

  const buffer = await workbook.xlsx.writeBuffer();
  return Buffer.from(buffer);
}

/** يبني ملف CSV مع BOM لضمان عرض العربية في Excel */
export function buildCsv(
  columns: ExportColumn[],
  rows: ExportRow[],
): string {
  const escape = (value: unknown): string => {
    if (value === null || value === undefined) return '';
    const text = value instanceof Date ? value.toISOString() : String(value);
    return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
  };

  const lines = [
    columns.map((c) => escape(c.header)).join(','),
    ...rows.map((row) => columns.map((c) => escape((row as Record<string, unknown>)[c.key])).join(",")),
  ];
  return `﻿${lines.join('\r\n')}`;
}
