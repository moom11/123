import { createHash, randomBytes } from 'node:crypto';
import { SignJWT, jwtVerify } from 'jose';
import type { RoleCode } from '@prisma/client';

const encoder = new TextEncoder();

export const ACCESS_COOKIE = 'mara_access';
export const REFRESH_COOKIE = 'mara_refresh';

export interface AccessTokenPayload {
  sub: string;
  employeeNo: string;
  fullName: string;
  branchId: string | null;
  roles: RoleCode[];
  permissions: string[];
}

function requireSecret(name: 'JWT_ACCESS_SECRET' | 'JWT_REFRESH_SECRET'): Uint8Array {
  const value = process.env[name];
  if (!value || value.length < 16) {
    throw new Error(
      `المتغير البيئي ${name} غير معرّف أو قصير جدًا. راجع ملف .env`,
    );
  }
  return encoder.encode(value);
}

export function accessTtlSeconds(): number {
  return Number(process.env.JWT_ACCESS_TTL_MINUTES ?? 30) * 60;
}

export function refreshTtlSeconds(): number {
  return Number(process.env.JWT_REFRESH_TTL_DAYS ?? 30) * 24 * 60 * 60;
}

export async function signAccessToken(payload: AccessTokenPayload): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: 'HS256' })
    .setSubject(payload.sub)
    .setIssuedAt(now)
    .setExpirationTime(now + accessTtlSeconds())
    .setIssuer('mara-pos')
    .sign(requireSecret('JWT_ACCESS_SECRET'));
}

export async function verifyAccessToken(
  token: string,
): Promise<AccessTokenPayload | null> {
  try {
    const { payload } = await jwtVerify(token, requireSecret('JWT_ACCESS_SECRET'), {
      issuer: 'mara-pos',
    });
    return {
      sub: String(payload.sub),
      employeeNo: String(payload.employeeNo ?? ''),
      fullName: String(payload.fullName ?? ''),
      branchId: (payload.branchId as string | null) ?? null,
      roles: (payload.roles as RoleCode[]) ?? [],
      permissions: (payload.permissions as string[]) ?? [],
    };
  } catch {
    return null;
  }
}

export interface RefreshTokenBundle {
  token: string;
  tokenHash: string;
  expiresAt: Date;
}

/**
 * رمز التحديث عبارة عن سلسلة عشوائية طويلة. نخزن بصمته (SHA-256) فقط
 * في قاعدة البيانات حتى لا تكون الرموز قابلة للاستخدام عند تسرب النسخة الاحتياطية.
 */
export function createRefreshToken(): RefreshTokenBundle {
  const token = randomBytes(48).toString('base64url');
  return {
    token,
    tokenHash: hashRefreshToken(token),
    expiresAt: new Date(Date.now() + refreshTtlSeconds() * 1000),
  };
}

export function hashRefreshToken(token: string): string {
  return createHash('sha256').update(token).digest('hex');
}

/** خيارات كوكيز آمنة للرموز */
export function cookieOptions(maxAgeSeconds: number) {
  return {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax' as const,
    path: '/',
    maxAge: maxAgeSeconds,
  };
}
