import type { RoleCode } from '@prisma/client';
import { prisma } from '@/lib/prisma';
import { Forbidden, Unauthorized } from '@/lib/api/errors';
import { verifyPassword } from '@/lib/auth/password';
import {
  createRefreshToken,
  hashRefreshToken,
  signAccessToken,
  type AccessTokenPayload,
} from '@/lib/auth/tokens';

export interface LoginResult {
  accessToken: string;
  refreshToken: string;
  refreshExpiresAt: Date;
  user: {
    id: string;
    employeeNo: string;
    fullName: string;
    email: string | null;
    branchId: string | null;
    branchName: string | null;
    roles: RoleCode[];
    permissions: string[];
  };
}

/** يجمع صلاحيات المستخدم من جميع أدواره */
export async function loadUserContext(userId: string) {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    include: {
      branch: { select: { nameAr: true } },
      roles: {
        include: {
          role: { include: { permissions: { include: { permission: true } } } },
        },
      },
    },
  });
  if (!user) throw Unauthorized('المستخدم غير موجود');
  if (!user.isActive) throw Forbidden('الحساب معطل — راجع مدير النظام');

  const roles = user.roles.map((ur) => ur.role.code);
  const permissions = Array.from(
    new Set(
      user.roles.flatMap((ur) => ur.role.permissions.map((rp) => rp.permission.code)),
    ),
  );

  return { user, roles, permissions };
}

export async function login(
  identifier: string,
  password: string,
  meta: { ip?: string | null; userAgent?: string | null } = {},
): Promise<LoginResult> {
  const trimmed = identifier.trim();
  const user = await prisma.user.findFirst({
    where: {
      OR: [{ employeeNo: trimmed }, { email: trimmed.toLowerCase() }],
    },
  });

  // رسالة موحدة حتى لا نكشف وجود الحساب من عدمه
  const invalid = Unauthorized('رقم الموظف أو البريد الإلكتروني أو كلمة المرور غير صحيحة');
  if (!user) throw invalid;
  if (!(await verifyPassword(password, user.passwordHash))) throw invalid;
  if (!user.isActive) throw Forbidden('الحساب معطل — راجع مدير النظام');

  const { roles, permissions } = await loadUserContext(user.id);
  const branch = user.branchId
    ? await prisma.branch.findUnique({
        where: { id: user.branchId },
        select: { nameAr: true },
      })
    : null;

  const payload: AccessTokenPayload = {
    sub: user.id,
    employeeNo: user.employeeNo,
    fullName: user.fullName,
    branchId: user.branchId,
    roles,
    permissions,
  };

  const accessToken = await signAccessToken(payload);
  const refresh = createRefreshToken();

  await prisma.$transaction([
    prisma.refreshToken.create({
      data: {
        userId: user.id,
        tokenHash: refresh.tokenHash,
        expiresAt: refresh.expiresAt,
        ip: meta.ip ?? null,
        userAgent: meta.userAgent ?? null,
      },
    }),
    prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    }),
  ]);

  return {
    accessToken,
    refreshToken: refresh.token,
    refreshExpiresAt: refresh.expiresAt,
    user: {
      id: user.id,
      employeeNo: user.employeeNo,
      fullName: user.fullName,
      email: user.email,
      branchId: user.branchId,
      branchName: branch?.nameAr ?? null,
      roles,
      permissions,
    },
  };
}

/** تدوير رمز التحديث: نلغي القديم وننشئ جديدًا في نفس العملية */
export async function refreshSession(
  token: string,
  meta: { ip?: string | null; userAgent?: string | null } = {},
): Promise<LoginResult> {
  const tokenHash = hashRefreshToken(token);
  const stored = await prisma.refreshToken.findUnique({
    where: { tokenHash },
    include: { user: true },
  });

  if (!stored || stored.revokedAt || stored.expiresAt < new Date()) {
    throw Unauthorized('انتهت صلاحية الجلسة — يرجى تسجيل الدخول مجددًا');
  }
  if (!stored.user.isActive) throw Forbidden('الحساب معطل');

  const { roles, permissions } = await loadUserContext(stored.userId);
  const branch = stored.user.branchId
    ? await prisma.branch.findUnique({
        where: { id: stored.user.branchId },
        select: { nameAr: true },
      })
    : null;

  const accessToken = await signAccessToken({
    sub: stored.userId,
    employeeNo: stored.user.employeeNo,
    fullName: stored.user.fullName,
    branchId: stored.user.branchId,
    roles,
    permissions,
  });
  const next = createRefreshToken();

  await prisma.$transaction([
    prisma.refreshToken.update({
      where: { id: stored.id },
      data: { revokedAt: new Date() },
    }),
    prisma.refreshToken.create({
      data: {
        userId: stored.userId,
        tokenHash: next.tokenHash,
        expiresAt: next.expiresAt,
        ip: meta.ip ?? null,
        userAgent: meta.userAgent ?? null,
      },
    }),
  ]);

  return {
    accessToken,
    refreshToken: next.token,
    refreshExpiresAt: next.expiresAt,
    user: {
      id: stored.user.id,
      employeeNo: stored.user.employeeNo,
      fullName: stored.user.fullName,
      email: stored.user.email,
      branchId: stored.user.branchId,
      branchName: branch?.nameAr ?? null,
      roles,
      permissions,
    },
  };
}

export async function logout(token: string | null) {
  if (!token) return;
  await prisma.refreshToken.updateMany({
    where: { tokenHash: hashRefreshToken(token), revokedAt: null },
    data: { revokedAt: new Date() },
  });
}

/** التحقق من رمز المدير لاعتماد العمليات الحساسة */
export async function verifyManagerPin(
  branchId: string,
  pin: string,
  requiredPermission: string,
): Promise<{ id: string; fullName: string }> {
  const candidates = await prisma.user.findMany({
    where: {
      branchId,
      isActive: true,
      managerPinHash: { not: null },
    },
    include: {
      roles: {
        include: {
          role: { include: { permissions: { include: { permission: true } } } },
        },
      },
    },
  });

  for (const candidate of candidates) {
    if (!candidate.managerPinHash) continue;
    if (!(await verifyPassword(pin, candidate.managerPinHash))) continue;

    const permissions = candidate.roles.flatMap((ur) =>
      ur.role.permissions.map((rp) => rp.permission.code),
    );
    if (!permissions.includes(requiredPermission)) {
      throw Forbidden('المدير المحدد لا يملك صلاحية اعتماد هذه العملية');
    }
    return { id: candidate.id, fullName: candidate.fullName };
  }

  throw Forbidden('رمز المدير غير صحيح');
}
