import { RoleCode } from '@prisma/client';

/**
 * قائمة الصلاحيات في النظام. كل صلاحية لها كود ثابت واسم عربي ومجموعة.
 * تُزرع في جدول permissions عند تشغيل السييد.
 */
export const PERMISSIONS = {
  // المستخدمون
  'users.view': { nameAr: 'عرض المستخدمين', group: 'المستخدمون' },
  'users.manage': { nameAr: 'إدارة المستخدمين', group: 'المستخدمون' },

  // المنتجات
  'products.view': { nameAr: 'عرض المنتجات', group: 'المنتجات' },
  'products.manage': { nameAr: 'إدارة المنتجات والتصنيفات', group: 'المنتجات' },
  'products.change_price': { nameAr: 'تعديل الأسعار', group: 'المنتجات' },

  // الضرائب والإعدادات
  'taxes.view': { nameAr: 'عرض الضرائب', group: 'الإعدادات' },
  'taxes.manage': { nameAr: 'إدارة الضرائب', group: 'الإعدادات' },
  'settings.manage': { nameAr: 'إدارة إعدادات الفرع', group: 'الإعدادات' },

  // نقاط البيع
  'pos.use': { nameAr: 'استخدام شاشة نقاط البيع', group: 'نقاط البيع' },
  'orders.create': { nameAr: 'إنشاء الطلبات', group: 'الطلبات' },
  'orders.hold': { nameAr: 'تعليق واسترجاع الطلبات', group: 'الطلبات' },
  'orders.send_to_prep': { nameAr: 'إرسال الطلب للتحضير', group: 'الطلبات' },
  'orders.cancel': { nameAr: 'إلغاء الطلب قبل الدفع', group: 'الطلبات' },
  'orders.void_item': { nameAr: 'إلغاء منتج من الطلب', group: 'الطلبات' },
  'orders.transfer_table': { nameAr: 'نقل الطلب بين الطاولات', group: 'الطاولات' },
  'orders.merge': { nameAr: 'دمج الطلبات والطاولات', group: 'الطاولات' },
  'orders.split': { nameAr: 'تقسيم الفاتورة', group: 'الطاولات' },

  // المدفوعات والفواتير
  'payments.collect': { nameAr: 'تحصيل المدفوعات', group: 'المدفوعات' },
  'invoices.view': { nameAr: 'عرض الفواتير', group: 'الفواتير' },
  'invoices.print': { nameAr: 'طباعة الفواتير', group: 'الفواتير' },
  'invoices.cancel': { nameAr: 'إلغاء فاتورة مكتملة', group: 'الفواتير' },
  'refunds.create': { nameAr: 'تنفيذ المرتجعات', group: 'الفواتير' },

  // الخصومات
  'discounts.apply': { nameAr: 'تطبيق الخصومات', group: 'الخصومات' },
  'discounts.approve': { nameAr: 'اعتماد الخصومات', group: 'الخصومات' },

  // الورديات والصندوق
  'shifts.open': { nameAr: 'فتح الوردية', group: 'الورديات' },
  'shifts.close': { nameAr: 'إغلاق الوردية', group: 'الورديات' },
  'shifts.view_all': { nameAr: 'عرض جميع الورديات', group: 'الورديات' },
  'shifts.approve_difference': { nameAr: 'اعتماد فروقات الصندوق', group: 'الورديات' },
  'cash.manage': { nameAr: 'تسجيل المصروفات والمسحوبات', group: 'الصندوق' },
  'cash.approve': { nameAr: 'اعتماد المصروفات', group: 'الصندوق' },

  // التقارير
  'reports.view': { nameAr: 'عرض تقارير الفرع', group: 'التقارير' },
  'reports.view_all': { nameAr: 'عرض جميع التقارير', group: 'التقارير' },
  'reports.export': { nameAr: 'تصدير التقارير', group: 'التقارير' },

  // Odoo
  'odoo.configure': { nameAr: 'إعداد الربط مع Odoo', group: 'Odoo' },
  'odoo.view_sync': { nameAr: 'عرض سجل المزامنة', group: 'Odoo' },
  'odoo.retry_sync': { nameAr: 'إعادة إرسال العمليات الفاشلة', group: 'Odoo' },

  // التدقيق
  'audit.view': { nameAr: 'عرض سجل التدقيق', group: 'التدقيق' },
} as const;

export type PermissionCode = keyof typeof PERMISSIONS;

export const ALL_PERMISSIONS = Object.keys(PERMISSIONS) as PermissionCode[];

/** مصفوفة الصلاحيات الافتراضية لكل دور وظيفي */
export const ROLE_PERMISSIONS: Record<RoleCode, PermissionCode[]> = {
  // مدير النظام يمتلك جميع الصلاحيات
  SYSTEM_ADMIN: ALL_PERMISSIONS,

  BRANCH_MANAGER: [
    'users.view',
    'products.view',
    'taxes.view',
    'pos.use',
    'orders.create',
    'orders.hold',
    'orders.send_to_prep',
    'orders.cancel',
    'orders.void_item',
    'orders.transfer_table',
    'orders.merge',
    'orders.split',
    'payments.collect',
    'invoices.view',
    'invoices.print',
    'invoices.cancel',
    'refunds.create',
    'discounts.apply',
    'discounts.approve',
    'shifts.open',
    'shifts.close',
    'shifts.view_all',
    'shifts.approve_difference',
    'cash.manage',
    'cash.approve',
    'reports.view',
    'reports.export',
    'odoo.view_sync',
    'odoo.retry_sync',
  ],

  CASHIER: [
    'pos.use',
    'products.view',
    'orders.create',
    'orders.hold',
    'orders.send_to_prep',
    'orders.cancel',
    'orders.void_item',
    'orders.transfer_table',
    'payments.collect',
    'invoices.view',
    'invoices.print',
    'discounts.apply',
    'shifts.open',
    'shifts.close',
    'cash.manage',
  ],

  WAITER: [
    'pos.use',
    'products.view',
    'orders.create',
    'orders.hold',
    'orders.send_to_prep',
    'orders.transfer_table',
    'invoices.view',
  ],
};

export const ROLE_LABELS: Record<RoleCode, string> = {
  SYSTEM_ADMIN: 'مدير النظام',
  BRANCH_MANAGER: 'مدير الفرع',
  CASHIER: 'كاشير',
  WAITER: 'مقدم الطلب',
};

/** العمليات التي تحتاج اعتماد مدير عند تنفيذها من دور أدنى */
export const MANAGER_APPROVAL_PERMISSIONS: PermissionCode[] = [
  'invoices.cancel',
  'refunds.create',
  'discounts.approve',
  'orders.merge',
  'products.change_price',
  'shifts.approve_difference',
];

export function hasPermission(
  userPermissions: string[],
  required: PermissionCode | PermissionCode[],
): boolean {
  const list = Array.isArray(required) ? required : [required];
  return list.every((code) => userPermissions.includes(code));
}

export function hasAnyPermission(
  userPermissions: string[],
  required: PermissionCode[],
): boolean {
  return required.some((code) => userPermissions.includes(code));
}
