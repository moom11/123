'use client';

/**
 * =============================================================================
 * طابور العمل دون اتصال
 * =============================================================================
 * يُخزن العمليات محليًا في IndexedDB عند انقطاع الإنترنت، ويرفعها عند عودته.
 *
 * قواعد أساسية:
 *  - كل عملية تحمل UUID خاصًا بها (clientUuid / idempotencyKey) يمنع تكرارها
 *    على الخادم عند إعادة الإرسال.
 *  - لا تُحذف أي بيانات محلية قبل نجاح رفعها إلى الخادم.
 *  - أرقام الفواتير تُولَّد على الخادم فقط، فلا يحدث تضارب بينها.
 */

const DB_NAME = 'mara-pos-offline';
const DB_VERSION = 1;
const STORE = 'operations';

export interface PendingOperation {
  id: string;
  method: 'POST' | 'PATCH' | 'PUT' | 'DELETE';
  path: string;
  body: unknown;
  createdAt: number;
  attempts: number;
  lastError?: string;
  /** وصف مقروء يظهر للمستخدم */
  label: string;
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE)) {
        const store = db.createObjectStore(STORE, { keyPath: 'id' });
        store.createIndex('createdAt', 'createdAt');
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function withStore<T>(
  mode: IDBTransactionMode,
  handler: (store: IDBObjectStore) => IDBRequest<T> | void,
): Promise<T | undefined> {
  if (typeof indexedDB === 'undefined') return undefined;
  const db = await openDb();
  return new Promise<T | undefined>((resolve, reject) => {
    const tx = db.transaction(STORE, mode);
    const store = tx.objectStore(STORE);
    const request = handler(store);
    tx.oncomplete = () => {
      db.close();
      resolve(request ? (request.result as T) : undefined);
    };
    tx.onerror = () => {
      db.close();
      reject(tx.error);
    };
  });
}

/** إضافة عملية إلى الطابور المحلي */
export async function enqueueOperation(
  operation: Omit<PendingOperation, 'createdAt' | 'attempts'>,
): Promise<void> {
  await withStore('readwrite', (store) =>
    store.put({ ...operation, createdAt: Date.now(), attempts: 0 }),
  );
}

export async function listPendingOperations(): Promise<PendingOperation[]> {
  const result = await withStore<PendingOperation[]>('readonly', (store) => store.getAll());
  return (result ?? []).sort((a, b) => a.createdAt - b.createdAt);
}

export async function countPendingOperations(): Promise<number> {
  const result = await withStore<number>('readonly', (store) => store.count());
  return result ?? 0;
}

async function removeOperation(id: string): Promise<void> {
  await withStore('readwrite', (store) => store.delete(id));
}

async function markFailed(operation: PendingOperation, error: string): Promise<void> {
  await withStore('readwrite', (store) =>
    store.put({ ...operation, attempts: operation.attempts + 1, lastError: error }),
  );
}

/**
 * رفع العمليات المعلقة بالترتيب.
 * لا تُحذف العملية من التخزين المحلي إلا بعد نجاح رفعها.
 */
export async function syncPendingOperations(): Promise<{
  synced: number;
  failed: number;
}> {
  const operations = await listPendingOperations();
  let synced = 0;
  let failed = 0;

  for (const operation of operations) {
    try {
      const response = await fetch(operation.path, {
        method: operation.method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(operation.body ?? {}),
        credentials: 'same-origin',
      });

      // 409 يعني أن العملية نُفذت مسبقًا على الخادم — نعتبرها ناجحة
      if (response.ok || response.status === 409) {
        await removeOperation(operation.id);
        synced += 1;
        continue;
      }

      // أخطاء التحقق لا تُحل بإعادة المحاولة — نبقيها للمراجعة اليدوية
      const payload = await response.json().catch(() => null);
      await markFailed(
        operation,
        payload?.error?.message ?? `فشل الرفع (${response.status})`,
      );
      failed += 1;
    } catch (error) {
      await markFailed(
        operation,
        error instanceof Error ? error.message : 'انقطاع في الاتصال',
      );
      failed += 1;
    }
  }

  return { synced, failed };
}

/** حذف عملية بعد مراجعتها يدويًا (يستخدم من شاشة العمليات المعلقة فقط) */
export async function discardOperation(id: string): Promise<void> {
  await removeOperation(id);
}
