'use client';

/**
 * عميل HTTP موحد للواجهة.
 * يتعامل مع الاستجابات الموحدة، ويجدد رمز الدخول تلقائيًا عند انتهائه،
 * ويوجه المستخدم إلى صفحة الدخول عند فشل التجديد.
 */

export class ApiClientError extends Error {
  constructor(
    public status: number,
    message: string,
    public code = 'ERROR',
    public details?: unknown,
  ) {
    super(message);
    this.name = 'ApiClientError';
  }
}

interface ApiEnvelope<T> {
  success: boolean;
  data?: T;
  meta?: Record<string, unknown>;
  error?: { code: string; message: string; details?: unknown };
}

export interface ApiResult<T> {
  data: T;
  meta?: Record<string, unknown>;
}

let refreshing: Promise<boolean> | null = null;

async function tryRefresh(): Promise<boolean> {
  if (!refreshing) {
    refreshing = fetch('/api/auth/refresh', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: '{}',
    })
      .then((res) => res.ok)
      .catch(() => false)
      .finally(() => {
        // نسمح بمحاولة تجديد جديدة بعد انتهاء الحالية
        setTimeout(() => {
          refreshing = null;
        }, 0);
      });
  }
  return refreshing;
}

async function request<T>(
  path: string,
  init: RequestInit = {},
  retry = true,
): Promise<ApiResult<T>> {
  // مع FormData يضبط المتصفح الترويسة بنفسه (تتضمن حد الفصل boundary)،
  // فتحديدها يدويًا يفسد الطلب.
  const isFormData = typeof FormData !== 'undefined' && init.body instanceof FormData;
  const response = await fetch(path, {
    ...init,
    headers: {
      ...(init.body && !isFormData ? { 'Content-Type': 'application/json' } : {}),
      ...(init.headers ?? {}),
    },
    credentials: 'same-origin',
  });

  if (response.status === 401 && retry && !path.includes('/api/auth/')) {
    if (await tryRefresh()) return request<T>(path, init, false);
    if (typeof window !== 'undefined' && !window.location.pathname.startsWith('/login')) {
      window.location.href = '/login';
    }
    throw new ApiClientError(401, 'انتهت الجلسة — يرجى تسجيل الدخول مجددًا', 'UNAUTHORIZED');
  }

  let payload: ApiEnvelope<T> | null = null;
  try {
    payload = (await response.json()) as ApiEnvelope<T>;
  } catch {
    payload = null;
  }

  if (!response.ok || !payload?.success) {
    throw new ApiClientError(
      response.status,
      payload?.error?.message ?? `تعذر تنفيذ الطلب (${response.status})`,
      payload?.error?.code ?? 'ERROR',
      payload?.error?.details,
    );
  }

  return { data: payload.data as T, meta: payload.meta };
}

export const api = {
  get: <T>(path: string) => request<T>(path),
  post: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: 'POST', body: JSON.stringify(body ?? {}) }),
  put: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: 'PUT', body: JSON.stringify(body ?? {}) }),
  patch: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: 'PATCH', body: JSON.stringify(body ?? {}) }),
  delete: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: 'DELETE', body: JSON.stringify(body ?? {}) }),
  /** رفع ملف عبر multipart/form-data */
  upload: <T>(path: string, form: FormData) =>
    request<T>(path, { method: 'POST', body: form }),
};

/** بناء سلسلة استعلام من كائن، مع تجاهل القيم الفارغة */
export function qs(params: Record<string, string | number | boolean | undefined | null>) {
  const search = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== null && value !== '') {
      search.set(key, String(value));
    }
  }
  const text = search.toString();
  return text ? `?${text}` : '';
}
