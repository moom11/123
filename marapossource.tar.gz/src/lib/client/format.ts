/** دوال تنسيق مشتركة للواجهة العربية */

export function money(value: unknown, withCurrency = true): string {
  const num = Number(value ?? 0);
  const text = (Number.isFinite(num) ? num : 0).toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  return withCurrency ? `${text} ر.س` : text;
}

export function number(value: unknown, decimals = 0): string {
  const num = Number(value ?? 0);
  return (Number.isFinite(num) ? num : 0).toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

export function dateTime(value: string | Date | null | undefined): string {
  if (!value) return '—';
  const date = typeof value === 'string' ? new Date(value) : value;
  return new Intl.DateTimeFormat('ar-SA-u-nu-latn', {
    dateStyle: 'short',
    timeStyle: 'short',
    timeZone: 'Asia/Riyadh',
  }).format(date);
}

export function timeOnly(value: string | Date | null | undefined): string {
  if (!value) return '—';
  const date = typeof value === 'string' ? new Date(value) : value;
  return new Intl.DateTimeFormat('ar-SA-u-nu-latn', {
    timeStyle: 'short',
    timeZone: 'Asia/Riyadh',
  }).format(date);
}

export function dateOnly(value: string | Date | null | undefined): string {
  if (!value) return '—';
  const date = typeof value === 'string' ? new Date(value) : value;
  return date.toISOString().slice(0, 10);
}

export const ORDER_TYPE_LABELS: Record<string, string> = {
  DINE_IN: 'داخل المطعم',
  TAKEAWAY: 'سفري',
  PICKUP: 'استلام',
  DELIVERY: 'توصيل',
};

export const ORDER_STATUS_LABELS: Record<string, string> = {
  DRAFT: 'مسودة',
  HELD: 'معلقة',
  SENT_TO_PREP: 'مرسلة للتحضير',
  COMPLETED: 'مكتملة',
  PAID: 'مدفوعة',
  CANCELLED: 'ملغاة',
  PARTIALLY_REFUNDED: 'مرتجعة جزئيًا',
  REFUNDED: 'مرتجعة بالكامل',
};

export const TABLE_STATUS_LABELS: Record<string, string> = {
  AVAILABLE: 'متاحة',
  OCCUPIED: 'مشغولة',
  AWAITING_PAYMENT: 'بانتظار الدفع',
  RESERVED: 'محجوزة',
  NEEDS_CLEANING: 'تحتاج تنظيفًا',
};

export const TABLE_STATUS_STYLES: Record<string, string> = {
  AVAILABLE: 'bg-emerald-50 border-emerald-300 text-emerald-800',
  OCCUPIED: 'bg-red-50 border-red-300 text-red-800',
  AWAITING_PAYMENT: 'bg-amber-50 border-amber-300 text-amber-800',
  RESERVED: 'bg-blue-50 border-blue-300 text-blue-800',
  NEEDS_CLEANING: 'bg-neutral-100 border-neutral-300 text-neutral-700',
};

export const STATION_LABELS: Record<string, string> = {
  KITCHEN: 'المطبخ',
  BAR: 'البار',
  SHISHA: 'الشيشة',
  NONE: 'بدون تحضير',
};

export const SYNC_STATUS_LABELS: Record<string, string> = {
  PENDING: 'في الانتظار',
  IN_PROGRESS: 'جارٍ الإرسال',
  SYNCED: 'تمت المزامنة',
  FAILED: 'فشلت',
  NEEDS_REVIEW: 'تحتاج مراجعة',
};

export const SYNC_STATUS_STYLES: Record<string, string> = {
  PENDING: 'bg-neutral-100 text-neutral-700',
  IN_PROGRESS: 'bg-blue-100 text-blue-800',
  SYNCED: 'bg-emerald-100 text-emerald-800',
  FAILED: 'bg-red-100 text-red-800',
  NEEDS_REVIEW: 'bg-amber-100 text-amber-800',
};

export const INVOICE_STATUS_STYLES: Record<string, string> = {
  PAID: 'bg-emerald-100 text-emerald-800',
  CANCELLED: 'bg-neutral-200 text-neutral-700',
  PARTIALLY_REFUNDED: 'bg-amber-100 text-amber-800',
  REFUNDED: 'bg-red-100 text-red-800',
  DRAFT: 'bg-neutral-100 text-neutral-600',
};

export const CASH_MOVEMENT_LABELS: Record<string, string> = {
  OPENING_FLOAT: 'رصيد افتتاحي',
  SALE_CASH_IN: 'مبيعات نقدية',
  REFUND_CASH_OUT: 'استرداد نقدي',
  EXPENSE: 'مصروف من الصندوق',
  WITHDRAWAL: 'سحب نقدي',
  DEPOSIT_TO_MAIN_SAFE: 'إيداع في الصندوق الرئيسي',
  EMPLOYEE_ADVANCE: 'عهدة موظف',
  ADVANCE_SETTLEMENT: 'استرداد عهدة',
  DRAWER_OPEN: 'فتح درج النقد',
  CLOSING_COUNT: 'جرد الإغلاق',
};

export const ROLE_LABELS: Record<string, string> = {
  SYSTEM_ADMIN: 'مدير النظام',
  BRANCH_MANAGER: 'مدير الفرع',
  CASHIER: 'كاشير',
  WAITER: 'مقدم الطلب',
};
