'use client';

import { useCallback, useEffect, useState } from 'react';
import { api, qs } from '@/lib/client/api';
import { dateTime, money, number, STATION_LABELS } from '@/lib/client/format';
import { ErrorAlert, LoadingBlock, StatCard } from '@/components/ui';
import { useSession } from '@/components/session-provider';

type Tab = 'sales' | 'payments' | 'products' | 'employees' | 'shifts';

const TABS: { key: Tab; label: string; icon: string }[] = [
  { key: 'sales', label: 'المبيعات', icon: '💵' },
  { key: 'payments', label: 'طرق الدفع', icon: '💳' },
  { key: 'products', label: 'المنتجات', icon: '🍔' },
  { key: 'employees', label: 'الموظفون', icon: '👥' },
  { key: 'shifts', label: 'الورديات', icon: '🕔' },
];

function today() {
  return new Date().toISOString().slice(0, 10);
}

export default function ReportsPage() {
  const { can } = useSession();
  const [tab, setTab] = useState<Tab>('sales');
  const [from, setFrom] = useState(today());
  const [to, setTo] = useState(today());
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await api.get<any>(`/api/reports/${tab}${qs({ from, to })}`);
      setData(result.data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر تحميل التقرير');
    } finally {
      setLoading(false);
    }
  }, [tab, from, to]);

  useEffect(() => {
    void load();
  }, [load]);

  function exportReport(format: 'xlsx' | 'csv') {
    window.open(`/api/reports/export${qs({ report: tab, format, from, to })}`, '_blank');
  }

  return (
    <div className="space-y-5">
      <ErrorAlert message={error} />

      {/* الفلاتر والتصدير */}
      <div className="no-print flex flex-wrap items-end gap-3">
        <div>
          <label className="label" htmlFor="from">
            من يوم تشغيلي
          </label>
          <input
            id="from"
            type="date"
            className="input tabular"
            value={from}
            onChange={(event) => setFrom(event.target.value)}
          />
        </div>
        <div>
          <label className="label" htmlFor="to">
            إلى
          </label>
          <input
            id="to"
            type="date"
            className="input tabular"
            value={to}
            onChange={(event) => setTo(event.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <button type="button" className="btn-ghost" onClick={() => void load()}>
            تحديث
          </button>
          {can('reports.export') && (
            <>
              <button type="button" className="btn-ghost" onClick={() => exportReport('xlsx')}>
                ⬇️ Excel
              </button>
              <button type="button" className="btn-ghost" onClick={() => exportReport('csv')}>
                ⬇️ CSV
              </button>
            </>
          )}
          <button
            type="button"
            className="btn-ghost"
            onClick={() => window.print()}
            title="اطبع أو احفظ كملف PDF"
          >
            🖨️ PDF / طباعة
          </button>
        </div>
      </div>

      {/* التبويبات */}
      <div className="no-print flex gap-2 overflow-x-auto">
        {TABS.map((item) => (
          <button
            key={item.key}
            type="button"
            onClick={() => setTab(item.key)}
            className={`shrink-0 rounded-xl border px-4 py-2.5 text-sm font-semibold transition ${
              tab === item.key
                ? 'border-brand bg-brand text-white'
                : 'border-surface-border bg-white hover:bg-surface-muted'
            }`}
          >
            {item.icon} {item.label}
          </button>
        ))}
      </div>

      {loading ? (
        <LoadingBlock />
      ) : !data ? null : tab === 'sales' ? (
        <SalesReport data={data} />
      ) : tab === 'payments' ? (
        <PaymentsReport data={data} />
      ) : tab === 'products' ? (
        <ProductsReport data={data} />
      ) : tab === 'employees' ? (
        <EmployeesReport rows={data} />
      ) : (
        <ShiftsReport rows={data} />
      )}
    </div>
  );
}

function SalesReport({ data }: { data: any }) {
  return (
    <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-5">
      <StatCard label="إجمالي المبيعات" value={money(data.totalSales)} tone="brand" />
      <StatCard label="صافي المبيعات" value={money(data.netSales)} hint="بعد المرتجعات" />
      <StatCard label="المبيعات قبل الضريبة" value={money(data.salesBeforeTax)} />
      <StatCard label="ضريبة القيمة المضافة" value={money(data.vatTotal)} />
      <StatCard label="ضريبة التبغ" value={money(data.tobaccoTaxTotal)} hint="مستقلة عن ض.ق.م" />
      <StatCard label="الخصومات" value={money(data.discountTotal)} />
      <StatCard label="المرتجعات" value={money(data.refundTotal)} tone="danger" />
      <StatCard label="عدد الفواتير" value={number(data.invoiceCount)} />
      <StatCard label="متوسط قيمة الفاتورة" value={money(data.averageInvoice)} />
    </div>
  );
}

function PaymentsReport({ data }: { data: any }) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard label="إجمالي التحصيل" value={money(data.totalCollected)} tone="brand" />
        <StatCard label="إجمالي المبيعات" value={money(data.totalSales)} />
        <StatCard
          label="الفرق"
          value={money(data.variance)}
          tone={Math.abs(data.variance) > 0.01 ? 'warning' : 'success'}
        />
        <StatCard label="فواتير بدفع مختلط" value={number(data.mixedPaymentInvoices)} />
      </div>

      <div className="card overflow-hidden">
        <table className="table-base">
          <thead>
            <tr>
              <th>طريقة الدفع</th>
              <th>المبلغ</th>
              <th>عدد العمليات</th>
              <th>النسبة</th>
            </tr>
          </thead>
          <tbody>
            {data.rows.length === 0 ? (
              <tr>
                <td colSpan={4} className="py-8 text-center text-neutral-500">
                  لا توجد مدفوعات
                </td>
              </tr>
            ) : (
              data.rows.map((row: any) => (
                <tr key={row.methodId}>
                  <td className="font-medium">{row.methodName}</td>
                  <td className="tabular font-bold">{money(row.amount, false)}</td>
                  <td className="tabular">{number(row.count)}</td>
                  <td className="tabular">
                    {data.totalCollected > 0
                      ? `${((row.amount / data.totalCollected) * 100).toFixed(1)}%`
                      : '—'}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function ProductsReport({ data }: { data: any }) {
  return (
    <div className="space-y-4">
      <div className="grid gap-4 lg:grid-cols-2">
        <ProductTable title="الأكثر مبيعًا" rows={data.topProducts} />
        <ProductTable title="الأقل مبيعًا" rows={data.bottomProducts} />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="card overflow-hidden">
          <h3 className="border-b border-surface-border px-4 py-2.5 text-sm font-bold">
            المبيعات حسب التصنيف
          </h3>
          <table className="table-base">
            <thead>
              <tr>
                <th>التصنيف</th>
                <th>الكمية</th>
                <th>صافي المبيعات</th>
              </tr>
            </thead>
            <tbody>
              {data.byCategory.map((row: any) => (
                <tr key={row.categoryName}>
                  <td>{row.categoryName}</td>
                  <td className="tabular">{number(row.quantity)}</td>
                  <td className="tabular font-semibold">{money(row.netSales, false)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="card overflow-hidden">
          <h3 className="border-b border-surface-border px-4 py-2.5 text-sm font-bold">
            المبيعات حسب محطة التحضير
          </h3>
          <table className="table-base">
            <thead>
              <tr>
                <th>المحطة</th>
                <th>الكمية</th>
                <th>صافي المبيعات</th>
              </tr>
            </thead>
            <tbody>
              {data.byStation.map((row: any) => (
                <tr key={row.station}>
                  <td>{STATION_LABELS[row.station] ?? row.station}</td>
                  <td className="tabular">{number(row.quantity)}</td>
                  <td className="tabular font-semibold">{money(row.netSales, false)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function ProductTable({ title, rows }: { title: string; rows: any[] }) {
  return (
    <div className="card overflow-hidden">
      <h3 className="border-b border-surface-border px-4 py-2.5 text-sm font-bold">{title}</h3>
      <div className="max-h-[400px] overflow-y-auto">
        <table className="table-base">
          <thead>
            <tr>
              <th>المنتج</th>
              <th>الكمية</th>
              <th>صافي المبيعات</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr>
                <td colSpan={3} className="py-8 text-center text-neutral-500">
                  لا توجد بيانات
                </td>
              </tr>
            ) : (
              rows.map((row: any) => (
                <tr key={row.productId}>
                  <td>
                    <span className="block">{row.name}</span>
                    <span className="text-[11px] text-neutral-500">{row.categoryName}</span>
                  </td>
                  <td className="tabular">{number(row.quantity)}</td>
                  <td className="tabular font-semibold">{money(row.netSales, false)}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function EmployeesReport({ rows }: { rows: any[] }) {
  return (
    <div className="card overflow-hidden">
      <table className="table-base">
        <thead>
          <tr>
            <th>رقم الموظف</th>
            <th>الاسم</th>
            <th>المبيعات</th>
            <th>عدد الطلبات</th>
            <th>الخصومات</th>
            <th>الإلغاءات</th>
            <th>المرتجعات</th>
            <th>متوسط الفاتورة</th>
          </tr>
        </thead>
        <tbody>
          {rows.length === 0 ? (
            <tr>
              <td colSpan={8} className="py-8 text-center text-neutral-500">
                لا توجد بيانات
              </td>
            </tr>
          ) : (
            rows.map((row) => (
              <tr key={row.userId}>
                <td className="tabular">{row.employeeNo}</td>
                <td className="font-medium">{row.fullName}</td>
                <td className="tabular font-bold">{money(row.sales, false)}</td>
                <td className="tabular">{number(row.orderCount)}</td>
                <td className="tabular">{money(row.discountTotal, false)}</td>
                <td className="tabular">{number(row.cancelledCount)}</td>
                <td className="tabular">{money(row.refundTotal, false)}</td>
                <td className="tabular">{money(row.averageInvoice, false)}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

function ShiftsReport({ rows }: { rows: any[] }) {
  return (
    <div className="card overflow-hidden">
      <div className="overflow-x-auto">
        <table className="table-base">
          <thead>
            <tr>
              <th>الوردية</th>
              <th>الكاشير</th>
              <th>الفتح</th>
              <th>الإغلاق</th>
              <th>الافتتاحي</th>
              <th>مبيعات نقدية</th>
              <th>مصروفات</th>
              <th>مسحوبات</th>
              <th>إيداعات</th>
              <th>المتوقع</th>
              <th>الفعلي</th>
              <th>الفرق</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr>
                <td colSpan={12} className="py-8 text-center text-neutral-500">
                  لا توجد ورديات
                </td>
              </tr>
            ) : (
              rows.map((row) => (
                <tr key={row.shiftId}>
                  <td className="tabular font-semibold">{row.shiftNumber}</td>
                  <td>{row.cashierName}</td>
                  <td className="tabular text-xs">{dateTime(row.openedAt)}</td>
                  <td className="tabular text-xs">{dateTime(row.closedAt)}</td>
                  <td className="tabular">{money(row.openingFloat, false)}</td>
                  <td className="tabular">{money(row.cashSales, false)}</td>
                  <td className="tabular">{money(row.expenses, false)}</td>
                  <td className="tabular">{money(row.withdrawals, false)}</td>
                  <td className="tabular">{money(row.deposits, false)}</td>
                  <td className="tabular">{money(row.expectedCash, false)}</td>
                  <td className="tabular">
                    {row.countedCash != null ? money(row.countedCash, false) : '—'}
                  </td>
                  <td
                    className={`tabular font-bold ${
                      row.difference == null
                        ? ''
                        : row.difference < 0
                          ? 'text-red-600'
                          : row.difference > 0
                            ? 'text-amber-600'
                            : 'text-emerald-600'
                    }`}
                  >
                    {row.difference != null ? money(row.difference, false) : '—'}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
