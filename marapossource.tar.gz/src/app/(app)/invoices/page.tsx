'use client';

import { useCallback, useEffect, useState } from 'react';
import { api, ApiClientError, qs } from '@/lib/client/api';
import {
  dateTime,
  INVOICE_STATUS_STYLES,
  money,
  number,
  ORDER_STATUS_LABELS,
  ORDER_TYPE_LABELS,
  SYNC_STATUS_LABELS,
  SYNC_STATUS_STYLES,
} from '@/lib/client/format';
import { ConfirmDialog, ErrorAlert, LoadingBlock, Modal, Spinner, SuccessAlert } from '@/components/ui';
import { useSession } from '@/components/session-provider';
import { ReceiptModal } from '@/components/pos/receipt-modal';
import type { InvoiceDto } from '@/types/pos';

export default function InvoicesPage() {
  const { can } = useSession();
  const [invoices, setInvoices] = useState<InvoiceDto[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [busy, setBusy] = useState(false);

  const [detail, setDetail] = useState<InvoiceDto | null>(null);
  const [printing, setPrinting] = useState<InvoiceDto | null>(null);
  const [cancelling, setCancelling] = useState<InvoiceDto | null>(null);
  const [refunding, setRefunding] = useState<InvoiceDto | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await api.get<InvoiceDto[]>(
        `/api/invoices${qs({ search, status, pageSize: 50 })}`,
      );
      setInvoices(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر تحميل الفواتير');
    } finally {
      setLoading(false);
    }
  }, [search, status]);

  useEffect(() => {
    void load();
  }, [load]);

  async function openDetail(invoice: InvoiceDto) {
    try {
      const { data } = await api.get<InvoiceDto>(`/api/invoices/${invoice.id}`);
      setDetail(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر تحميل الفاتورة');
    }
  }

  async function cancelInvoice(reason: string, managerPin?: string) {
    if (!cancelling) return;
    setBusy(true);
    try {
      await api.post(`/api/invoices/${cancelling.id}/cancel`, { reason, managerPin });
      setCancelling(null);
      setNotice('تم إلغاء الفاتورة — الفاتورة الأصلية محفوظة بحالة «ملغاة»');
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'تعذر إلغاء الفاتورة');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-5">
      <ErrorAlert message={error} />
      <SuccessAlert message={notice} />

      <div className="flex flex-wrap gap-2">
        <input
          className="input max-w-xs"
          placeholder="بحث برقم الفاتورة أو اسم العميل…"
          value={search}
          onChange={(event) => setSearch(event.target.value)}
        />
        <select
          className="input max-w-[200px]"
          value={status}
          onChange={(event) => setStatus(event.target.value)}
        >
          <option value="">كل الحالات</option>
          <option value="PAID">مدفوعة</option>
          <option value="PARTIALLY_REFUNDED">مرتجعة جزئيًا</option>
          <option value="REFUNDED">مرتجعة بالكامل</option>
          <option value="CANCELLED">ملغاة</option>
        </select>
      </div>

      {loading ? (
        <LoadingBlock />
      ) : (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>رقم الفاتورة</th>
                  <th>التاريخ</th>
                  <th>النوع</th>
                  <th>الأصناف</th>
                  <th>ض.ق.م</th>
                  <th>ض.التبغ</th>
                  <th>الإجمالي</th>
                  <th>طرق الدفع</th>
                  <th>الحالة</th>
                  <th>Odoo</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {invoices.length === 0 ? (
                  <tr>
                    <td colSpan={11} className="py-10 text-center text-neutral-500">
                      لا توجد فواتير
                    </td>
                  </tr>
                ) : (
                  invoices.map((invoice) => (
                    <tr key={invoice.id}>
                      <td className="tabular font-semibold">{invoice.invoiceNumber}</td>
                      <td className="tabular whitespace-nowrap text-xs">
                        {dateTime(invoice.closedAt ?? invoice.createdAt)}
                      </td>
                      <td className="text-xs">{ORDER_TYPE_LABELS[invoice.type]}</td>
                      <td className="tabular text-xs">{number(invoice._count?.items ?? 0)}</td>
                      <td className="tabular text-xs">{money(invoice.vatTotal, false)}</td>
                      <td className="tabular text-xs">
                        {Number(invoice.tobaccoTaxTotal) > 0
                          ? money(invoice.tobaccoTaxTotal, false)
                          : '—'}
                      </td>
                      <td className="tabular font-bold">{money(invoice.grandTotal, false)}</td>
                      <td className="max-w-[160px] truncate text-xs">
                        {invoice.payments?.map((p) => p.paymentMethod.nameAr).join('، ') ?? '—'}
                      </td>
                      <td>
                        <span className={`badge ${INVOICE_STATUS_STYLES[invoice.status] ?? ''}`}>
                          {ORDER_STATUS_LABELS[invoice.status] ?? invoice.status}
                        </span>
                      </td>
                      <td>
                        <span className={`badge ${SYNC_STATUS_STYLES[invoice.syncStatus]}`}>
                          {SYNC_STATUS_LABELS[invoice.syncStatus]}
                        </span>
                      </td>
                      <td>
                        <div className="flex gap-1">
                          <button
                            type="button"
                            className="btn-ghost !px-2 !py-1 text-xs"
                            onClick={() => void openDetail(invoice)}
                          >
                            عرض
                          </button>
                          <button
                            type="button"
                            className="btn-ghost !px-2 !py-1 text-xs"
                            onClick={() => setPrinting(invoice)}
                          >
                            🖨️
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* تفاصيل الفاتورة */}
      {detail && (
        <Modal
          open
          onClose={() => setDetail(null)}
          title={`فاتورة ${detail.invoiceNumber}`}
          size="lg"
          footer={
            <>
              <button type="button" className="btn-ghost" onClick={() => setDetail(null)}>
                إغلاق
              </button>
              <button
                type="button"
                className="btn-ghost"
                onClick={() => {
                  setPrinting(detail);
                  setDetail(null);
                }}
              >
                🖨️ طباعة
              </button>
              {detail.status !== 'CANCELLED' && detail.status !== 'REFUNDED' && (
                <>
                  <button
                    type="button"
                    className="btn-ghost !text-amber-700"
                    onClick={() => {
                      setRefunding(detail);
                      setDetail(null);
                    }}
                  >
                    ↩️ مرتجع
                  </button>
                  <button
                    type="button"
                    className="btn-danger"
                    onClick={() => {
                      setCancelling(detail);
                      setDetail(null);
                    }}
                  >
                    إلغاء الفاتورة
                  </button>
                </>
              )}
            </>
          }
        >
          <InvoiceDetail invoice={detail} />
        </Modal>
      )}

      {printing && <ReceiptModal invoice={printing} onClose={() => setPrinting(null)} />}

      <ConfirmDialog
        open={cancelling !== null}
        title="إلغاء فاتورة مكتملة"
        message="لن تُحذف الفاتورة — ستتغير حالتها إلى «ملغاة» وتُعكس الحركات النقدية المرتبطة بها."
        danger
        requireReason
        reasonLabel="سبب الإلغاء"
        requireManagerPin={!can('invoices.cancel')}
        busy={busy}
        confirmLabel="تأكيد الإلغاء"
        onCancel={() => setCancelling(null)}
        onConfirm={({ reason, managerPin }) => void cancelInvoice(reason ?? '', managerPin)}
      />

      {refunding && (
        <RefundModal
          invoice={refunding}
          onClose={() => setRefunding(null)}
          onDone={async (message) => {
            setRefunding(null);
            setNotice(message);
            await load();
          }}
        />
      )}
    </div>
  );
}

function InvoiceDetail({ invoice }: { invoice: InvoiceDto & { changes?: unknown[] } }) {
  return (
    <div className="space-y-4 text-sm">
      <div className="grid gap-2 sm:grid-cols-3">
        <Field label="الحالة" value={ORDER_STATUS_LABELS[invoice.status] ?? invoice.status} />
        <Field label="نوع الطلب" value={ORDER_TYPE_LABELS[invoice.type]} />
        <Field label="الطاولة" value={invoice.tableNumber ?? '—'} />
        <Field label="الكاشير" value={invoice.user?.fullName ?? '—'} />
        <Field label="اليوم التشغيلي" value={invoice.businessDay.slice(0, 10)} />
        <Field label="وقت الإغلاق" value={dateTime(invoice.closedAt)} />
        <Field
          label="حالة المزامنة"
          value={SYNC_STATUS_LABELS[invoice.syncStatus] ?? invoice.syncStatus}
        />
        <Field label="رقم Odoo" value={invoice.odooRecordId ? String(invoice.odooRecordId) : '—'} />
        <Field label="المرجع الداخلي" value={invoice.reference.slice(0, 8)} />
      </div>

      <table className="table-base">
        <thead>
          <tr>
            <th>الصنف</th>
            <th>الكمية</th>
            <th>الصافي</th>
            <th>الخصم</th>
            <th>ض.ق.م</th>
            <th>ض.التبغ</th>
            <th>الإجمالي</th>
            <th>المرتجع</th>
          </tr>
        </thead>
        <tbody>
          {invoice.items?.map((item) => (
            <tr key={item.id}>
              <td>{item.nameAr}</td>
              <td className="tabular">{number(item.quantity)}</td>
              <td className="tabular">{money(item.netBeforeTax, false)}</td>
              <td className="tabular">{money(item.discountAmount, false)}</td>
              <td className="tabular">{money(item.vatAmount, false)}</td>
              <td className="tabular">{money(item.tobaccoTaxAmount, false)}</td>
              <td className="tabular font-semibold">{money(item.lineTotal, false)}</td>
              <td className="tabular">{number(item.refundedQuantity)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="grid gap-3 sm:grid-cols-2">
        <div className="space-y-1 rounded-xl bg-surface-muted p-3">
          <Row label="الإجمالي قبل الضريبة" value={money(invoice.netBeforeTax)} />
          <Row label="الخصومات" value={money(invoice.discountTotal)} />
          <Row label="ضريبة القيمة المضافة" value={money(invoice.vatTotal)} />
          <Row label="ضريبة التبغ" value={money(invoice.tobaccoTaxTotal)} />
          <Row label="الإجمالي" value={money(invoice.grandTotal)} strong />
          {Number(invoice.refundedTotal) > 0 && (
            <Row label="المرتجع" value={money(invoice.refundedTotal)} />
          )}
        </div>
        <div className="space-y-1 rounded-xl bg-surface-muted p-3">
          <p className="mb-1 text-xs font-semibold text-neutral-600">طرق الدفع</p>
          {invoice.payments?.map((payment) => (
            <Row
              key={payment.id}
              label={payment.paymentMethod.nameAr}
              value={money(payment.amount)}
            />
          ))}
          {Number(invoice.changeDue) > 0 && (
            <Row label="الباقي" value={money(invoice.changeDue)} />
          )}
        </div>
      </div>
    </div>
  );
}

/** نافذة المرتجع — كامل أو جزئي */
function RefundModal({
  invoice: initial,
  onClose,
  onDone,
}: {
  invoice: InvoiceDto;
  onClose: () => void;
  onDone: (message: string) => void | Promise<void>;
}) {
  const { can } = useSession();
  const [invoice, setInvoice] = useState<InvoiceDto | null>(initial.items ? initial : null);
  const [mode, setMode] = useState<'FULL' | 'PARTIAL'>('FULL');
  const [quantities, setQuantities] = useState<Record<string, number>>({});
  const [reason, setReason] = useState('');
  const [managerPin, setManagerPin] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [idempotencyKey] = useState(() => `refund:${initial.id}:${crypto.randomUUID()}`);

  useEffect(() => {
    if (invoice) return;
    api
      .get<InvoiceDto>(`/api/invoices/${initial.id}`)
      .then(({ data }) => setInvoice(data))
      .catch((err) => setError(err instanceof Error ? err.message : 'تعذر تحميل الفاتورة'));
  }, [invoice, initial.id]);

  async function submit() {
    setBusy(true);
    setError(null);
    try {
      await api.post(`/api/invoices/${initial.id}/refund`, {
        reason: reason.trim(),
        items:
          mode === 'PARTIAL'
            ? Object.entries(quantities)
                .filter(([, qty]) => qty > 0)
                .map(([invoiceItemId, quantity]) => ({ invoiceItemId, quantity }))
            : undefined,
        managerPin: managerPin.trim() || null,
        idempotencyKey,
      });
      await onDone('تم إنشاء المرتجع وإعادة المبلغ بنفس طرق الدفع الأصلية');
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'تعذر إنشاء المرتجع');
    } finally {
      setBusy(false);
    }
  }

  const needsPin = !can('refunds.create');
  const canSubmit =
    reason.trim().length > 0 &&
    (!needsPin || managerPin.trim().length >= 4) &&
    (mode === 'FULL' || Object.values(quantities).some((q) => q > 0));

  return (
    <Modal
      open
      onClose={onClose}
      title={`مرتجع فاتورة ${initial.invoiceNumber}`}
      size="lg"
      footer={
        <>
          <button type="button" className="btn-ghost" onClick={onClose} disabled={busy}>
            إلغاء
          </button>
          <button
            type="button"
            className="btn-danger"
            disabled={!canSubmit || busy}
            onClick={() => void submit()}
          >
            {busy && <Spinner className="h-4 w-4" />}
            تنفيذ المرتجع
          </button>
        </>
      }
    >
      {!invoice ? (
        <LoadingBlock />
      ) : (
        <div className="space-y-4">
          <ErrorAlert message={error} />

          <div className="grid grid-cols-2 gap-2">
            {[
              { key: 'FULL', label: 'إرجاع كامل الفاتورة' },
              { key: 'PARTIAL', label: 'إرجاع أصناف محددة' },
            ].map((item) => (
              <button
                key={item.key}
                type="button"
                onClick={() => setMode(item.key as typeof mode)}
                className={`btn-touch rounded-xl border text-sm font-semibold ${
                  mode === item.key
                    ? 'border-brand bg-brand/10 text-brand'
                    : 'border-surface-border bg-white'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          {mode === 'PARTIAL' && (
            <table className="table-base">
              <thead>
                <tr>
                  <th>الصنف</th>
                  <th>المباع</th>
                  <th>المرتجع سابقًا</th>
                  <th>المتاح</th>
                  <th>الكمية المرتجعة</th>
                </tr>
              </thead>
              <tbody>
                {invoice.items?.map((item) => {
                  const available =
                    Number(item.quantity) - Number(item.refundedQuantity);
                  return (
                    <tr key={item.id}>
                      <td>{item.nameAr}</td>
                      <td className="tabular">{number(item.quantity)}</td>
                      <td className="tabular">{number(item.refundedQuantity)}</td>
                      <td className="tabular">{number(available)}</td>
                      <td>
                        <input
                          type="number"
                          min="0"
                          max={available}
                          step="1"
                          className="input tabular w-24 text-center"
                          value={quantities[item.id] ?? 0}
                          disabled={available <= 0}
                          onChange={(event) =>
                            setQuantities((current) => ({
                              ...current,
                              [item.id]: Math.min(
                                Math.max(Number(event.target.value) || 0, 0),
                                available,
                              ),
                            }))
                          }
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}

          <div>
            <label className="label" htmlFor="refund-reason">
              سبب الإرجاع <span className="text-red-600">*</span>
            </label>
            <textarea
              id="refund-reason"
              className="input min-h-[68px]"
              value={reason}
              onChange={(event) => setReason(event.target.value)}
            />
          </div>

          {needsPin && (
            <div>
              <label className="label" htmlFor="refund-pin">
                رمز المدير <span className="text-red-600">*</span>
              </label>
              <input
                id="refund-pin"
                type="password"
                className="input tabular text-center tracking-[0.4em]"
                value={managerPin}
                onChange={(event) => setManagerPin(event.target.value)}
                maxLength={8}
              />
            </div>
          )}

          <p className="rounded-lg bg-blue-50 px-3 py-2 text-xs text-blue-800">
            ℹ️ سيُصدر مستند مرتجع مرتبط بالفاتورة الأصلية، ويُعاد المبلغ بنفس طرق الدفع
            الأصلية، ويُرحّل إلى Odoo كإشعار دائن.
          </p>
        </div>
      )}
    </Modal>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-surface-muted px-3 py-2">
      <p className="text-[11px] text-neutral-500">{label}</p>
      <p className="font-medium">{value}</p>
    </div>
  );
}

function Row({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className="flex justify-between">
      <span className="text-neutral-600">{label}</span>
      <span className={`tabular ${strong ? 'text-base font-bold' : ''}`}>{value}</span>
    </div>
  );
}
