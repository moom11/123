'use client';

import { useCallback, useEffect, useState } from 'react';
import { api, ApiClientError, qs } from '@/lib/client/api';
import { dateTime, SYNC_STATUS_LABELS, SYNC_STATUS_STYLES } from '@/lib/client/format';
import {
  ErrorAlert,
  LoadingBlock,
  Modal,
  Spinner,
  StatCard,
  SuccessAlert,
} from '@/components/ui';
import { useSession } from '@/components/session-provider';

interface OdooSettings {
  id: string;
  isEnabled: boolean;
  url: string;
  database: string;
  username: string;
  hasApiKey: boolean;
  protocol: 'JSON_RPC' | 'XML_RPC' | 'REST';
  companyId: number | null;
  analyticAccountId: number | null;
  salesJournalId: number | null;
  cashJournalId: number | null;
  bankJournalId: number | null;
  vatAccountId: number | null;
  tobaccoTaxAccountId: number | null;
  discountAccountId: number | null;
  refundAccountId: number | null;
  cashDiffAccountId: number | null;
  defaultPartnerId: number | null;
  postingMode: 'PER_INVOICE' | 'DAILY_SUMMARY';
  productSyncDirection: 'ODOO_TO_POS' | 'POS_TO_ODOO' | 'BIDIRECTIONAL';
  odooIsMasterOnConflict: boolean;
  maxSyncAttempts: number;
  lastConnectionCheckAt: string | null;
  lastConnectionOk: boolean | null;
  lastConnectionMessage: string | null;
}

interface SyncJob {
  id: string;
  entity: string;
  entityId: string;
  status: string;
  attempts: number;
  maxAttempts: number;
  lastError: string | null;
  odooRecordId: number | null;
  nextRetryAt: string | null;
  createdAt: string;
  logs?: { id: string; errorMessage: string | null; createdAt: string; durationMs: number | null }[];
}

const ENTITY_LABELS: Record<string, string> = {
  INVOICE: 'فاتورة',
  PAYMENT: 'دفعة',
  REFUND: 'مرتجع',
  PRODUCT: 'منتج',
  DAILY_SUMMARY: 'ملخص يومي',
  CASH_MOVEMENT: 'حركة صندوق',
  EXPENSE: 'مصروف',
};

export default function OdooPage() {
  const { can } = useSession();
  const [settings, setSettings] = useState<OdooSettings | null>(null);
  const [jobs, setJobs] = useState<SyncJob[]>([]);
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [filter, setFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [detail, setDetail] = useState<SyncJob | null>(null);

  const loadJobs = useCallback(async () => {
    const { data, meta } = await api.get<SyncJob[]>(
      `/api/odoo/sync-jobs${qs({ status: filter, pageSize: 50 })}`,
    );
    setJobs(data);
    setCounts((meta?.counts as Record<string, number>) ?? {});
  }, [filter]);

  const load = useCallback(async () => {
    try {
      if (can('odoo.configure')) {
        const { data } = await api.get<OdooSettings | null>('/api/odoo/settings');
        setSettings(data);
      }
      await loadJobs();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر تحميل بيانات المزامنة');
    } finally {
      setLoading(false);
    }
  }, [can, loadJobs]);

  useEffect(() => {
    void load();
  }, [load]);

  async function run(action: () => Promise<unknown>, message: string) {
    setBusy(true);
    setError(null);
    try {
      await action();
      setNotice(message);
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'تعذر تنفيذ العملية');
    } finally {
      setBusy(false);
    }
  }

  if (loading) return <LoadingBlock label="جارٍ تحميل حالة الربط…" />;

  return (
    <div className="space-y-5">
      <ErrorAlert message={error} />
      <SuccessAlert message={notice} />

      {/* حالة الربط */}
      <section className="card p-5">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold">حالة الربط مع Odoo</h2>
            {settings && (
              <p className="mt-1 text-xs text-neutral-500">
                {settings.isEnabled ? '🟢 الربط مفعّل' : '⚪ الربط معطّل'} ·{' '}
                {settings.postingMode === 'DAILY_SUMMARY'
                  ? 'وضع الملخص اليومي (افتراضي)'
                  : 'إرسال كل فاتورة'}
                {settings.lastConnectionCheckAt &&
                  ` · آخر فحص: ${dateTime(settings.lastConnectionCheckAt)}`}
              </p>
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            {can('odoo.configure') && (
              <>
                <button
                  type="button"
                  className="btn-ghost"
                  onClick={() => setShowSettings(true)}
                >
                  ⚙️ إعدادات الاتصال
                </button>
                <button
                  type="button"
                  className="btn-ghost"
                  disabled={busy}
                  onClick={() =>
                    void run(async () => {
                      const { data } = await api.post<{ ok: boolean; message?: string; version?: string }>(
                        '/api/odoo/test',
                      );
                      if (!data.ok) throw new ApiClientError(400, data.message ?? 'فشل الاتصال');
                    }, 'تم الاتصال بخادم Odoo بنجاح')
                  }
                >
                  🔌 اختبار الاتصال
                </button>
                <button
                  type="button"
                  className="btn-ghost"
                  disabled={busy}
                  onClick={() =>
                    void run(
                      () => api.post('/api/odoo/products/pull'),
                      'تمت مزامنة المنتجات من Odoo',
                    )
                  }
                >
                  ⬇️ جلب المنتجات
                </button>
              </>
            )}
            {can('odoo.retry_sync') && (
              <>
                <button
                  type="button"
                  className="btn-ghost"
                  disabled={busy}
                  onClick={() =>
                    void run(
                      () => api.post('/api/odoo/daily-summary', { close: false }),
                      'تم بناء الملخص اليومي وجدولة ترحيله',
                    )
                  }
                >
                  📅 ترحيل الملخص اليومي
                </button>
                <button
                  type="button"
                  className="btn-primary"
                  disabled={busy}
                  onClick={() =>
                    void run(
                      () => api.post('/api/odoo/sync-jobs/retry-all'),
                      'تمت إعادة جدولة العمليات الفاشلة',
                    )
                  }
                >
                  🔁 إعادة مزامنة الفاشلة
                </button>
              </>
            )}
          </div>
        </div>

        {settings?.lastConnectionMessage && (
          <p
            className={`mb-4 rounded-xl px-4 py-2.5 text-sm ${
              settings.lastConnectionOk
                ? 'bg-emerald-50 text-emerald-800'
                : 'bg-red-50 text-red-800'
            }`}
          >
            {settings.lastConnectionMessage}
          </p>
        )}

        <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
          <StatCard label="في الانتظار" value={String(counts.PENDING ?? 0)} />
          <StatCard label="جارٍ الإرسال" value={String(counts.IN_PROGRESS ?? 0)} />
          <StatCard label="تمت المزامنة" value={String(counts.SYNCED ?? 0)} tone="success" />
          <StatCard label="فشلت" value={String(counts.FAILED ?? 0)} tone="danger" />
          <StatCard
            label="تحتاج مراجعة"
            value={String(counts.NEEDS_REVIEW ?? 0)}
            tone="warning"
          />
        </div>
      </section>

      {/* سجل المزامنة */}
      <section className="card overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-surface-border px-5 py-3">
          <h2 className="text-sm font-bold">سجل عمليات المزامنة</h2>
          <select
            className="input max-w-[200px]"
            value={filter}
            onChange={(event) => setFilter(event.target.value)}
          >
            <option value="">كل الحالات</option>
            <option value="PENDING">في الانتظار</option>
            <option value="SYNCED">تمت المزامنة</option>
            <option value="FAILED,NEEDS_REVIEW">فشلت / تحتاج مراجعة</option>
          </select>
        </div>

        <div className="overflow-x-auto">
          <table className="table-base">
            <thead>
              <tr>
                <th>النوع</th>
                <th>الحالة</th>
                <th>المحاولات</th>
                <th>رقم Odoo</th>
                <th>آخر خطأ</th>
                <th>إعادة المحاولة</th>
                <th>التاريخ</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {jobs.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-10 text-center text-neutral-500">
                    لا توجد عمليات مزامنة
                  </td>
                </tr>
              ) : (
                jobs.map((job) => (
                  <tr key={job.id}>
                    <td className="font-medium">{ENTITY_LABELS[job.entity] ?? job.entity}</td>
                    <td>
                      <span className={`badge ${SYNC_STATUS_STYLES[job.status]}`}>
                        {SYNC_STATUS_LABELS[job.status]}
                      </span>
                    </td>
                    <td className="tabular text-xs">
                      {job.attempts} / {job.maxAttempts}
                    </td>
                    <td className="tabular text-xs">{job.odooRecordId ?? '—'}</td>
                    <td className="max-w-[280px] truncate text-xs text-red-700">
                      {job.lastError ?? '—'}
                    </td>
                    <td className="tabular text-xs">
                      {job.nextRetryAt ? dateTime(job.nextRetryAt) : '—'}
                    </td>
                    <td className="tabular whitespace-nowrap text-xs">
                      {dateTime(job.createdAt)}
                    </td>
                    <td>
                      <div className="flex gap-1">
                        <button
                          type="button"
                          className="btn-ghost !px-2 !py-1 text-xs"
                          onClick={() => setDetail(job)}
                        >
                          تفاصيل
                        </button>
                        {can('odoo.retry_sync') && job.status !== 'SYNCED' && (
                          <button
                            type="button"
                            className="btn-ghost !px-2 !py-1 text-xs"
                            disabled={busy}
                            onClick={() =>
                              void run(
                                () => api.post(`/api/odoo/sync-jobs/${job.id}/retry`),
                                'تمت إعادة جدولة العملية',
                              )
                            }
                          >
                            🔁
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>

      {detail && (
        <Modal open onClose={() => setDetail(null)} title="تفاصيل عملية المزامنة" size="lg">
          <div className="space-y-3 text-sm">
            <div className="grid gap-2 sm:grid-cols-2">
              <Field label="النوع" value={ENTITY_LABELS[detail.entity] ?? detail.entity} />
              <Field label="الحالة" value={SYNC_STATUS_LABELS[detail.status]} />
              <Field label="معرف السجل" value={detail.entityId} />
              <Field label="رقم Odoo" value={String(detail.odooRecordId ?? '—')} />
              <Field label="المحاولات" value={`${detail.attempts} / ${detail.maxAttempts}`} />
              <Field label="أُنشئت" value={dateTime(detail.createdAt)} />
            </div>
            {detail.lastError && (
              <div className="rounded-xl bg-red-50 p-3 text-xs text-red-800">
                <p className="mb-1 font-semibold">آخر خطأ</p>
                {detail.lastError}
              </div>
            )}
            {detail.logs && detail.logs.length > 0 && (
              <div>
                <p className="mb-2 text-xs font-semibold text-neutral-600">آخر المحاولات</p>
                <ul className="space-y-1.5">
                  {detail.logs.map((log) => (
                    <li key={log.id} className="rounded-lg bg-surface-muted px-3 py-2 text-xs">
                      <span className="tabular text-neutral-500">{dateTime(log.createdAt)}</span>
                      {log.durationMs != null && (
                        <span className="tabular mr-2 text-neutral-400">
                          ({log.durationMs} مللي ثانية)
                        </span>
                      )}
                      {log.errorMessage && (
                        <p className="mt-1 text-red-700">{log.errorMessage}</p>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            <p className="rounded-lg bg-blue-50 px-3 py-2 text-xs text-blue-800">
              ℹ️ لا تُخزَّن كلمات المرور أو مفاتيح API في سجلات المزامنة.
            </p>
          </div>
        </Modal>
      )}

      {showSettings && settings !== undefined && (
        <OdooSettingsModal
          settings={settings}
          onClose={() => setShowSettings(false)}
          onSaved={async () => {
            setShowSettings(false);
            setNotice('تم حفظ إعدادات الربط');
            await load();
          }}
        />
      )}
    </div>
  );
}

function OdooSettingsModal({
  settings,
  onClose,
  onSaved,
}: {
  settings: OdooSettings | null;
  onClose: () => void;
  onSaved: () => void | Promise<void>;
}) {
  const [form, setForm] = useState({
    isEnabled: settings?.isEnabled ?? false,
    url: settings?.url ?? '',
    database: settings?.database ?? '',
    username: settings?.username ?? '',
    apiKey: '',
    protocol: settings?.protocol ?? 'JSON_RPC',
    odooCompanyId: settings?.companyId ?? '',
    analyticAccountId: settings?.analyticAccountId ?? '',
    salesJournalId: settings?.salesJournalId ?? '',
    cashJournalId: settings?.cashJournalId ?? '',
    bankJournalId: settings?.bankJournalId ?? '',
    vatAccountId: settings?.vatAccountId ?? '',
    tobaccoTaxAccountId: settings?.tobaccoTaxAccountId ?? '',
    discountAccountId: settings?.discountAccountId ?? '',
    refundAccountId: settings?.refundAccountId ?? '',
    cashDiffAccountId: settings?.cashDiffAccountId ?? '',
    defaultPartnerId: settings?.defaultPartnerId ?? '',
    postingMode: settings?.postingMode ?? 'DAILY_SUMMARY',
    productSyncDirection: settings?.productSyncDirection ?? 'ODOO_TO_POS',
    odooIsMasterOnConflict: settings?.odooIsMasterOnConflict ?? true,
    maxSyncAttempts: settings?.maxSyncAttempts ?? 5,
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function update<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  const numberFields = [
    ['odooCompanyId', 'معرف الشركة في Odoo'],
    ['analyticAccountId', 'الفرع / مركز التكلفة (Analytic)'],
    ['salesJournalId', 'دفتر المبيعات'],
    ['cashJournalId', 'دفتر النقدية'],
    ['bankJournalId', 'دفتر البنك'],
    ['vatAccountId', 'حساب ضريبة القيمة المضافة'],
    ['tobaccoTaxAccountId', 'حساب ضريبة التبغ'],
    ['discountAccountId', 'حساب الخصومات'],
    ['refundAccountId', 'حساب المرتجعات'],
    ['cashDiffAccountId', 'حساب فروقات الصندوق'],
    ['defaultPartnerId', 'العميل النقدي الافتراضي'],
  ] as const;

  async function save() {
    setBusy(true);
    setError(null);
    try {
      const payload: Record<string, unknown> = {
        isEnabled: form.isEnabled,
        url: form.url.trim(),
        database: form.database.trim(),
        username: form.username.trim(),
        protocol: form.protocol,
        postingMode: form.postingMode,
        productSyncDirection: form.productSyncDirection,
        odooIsMasterOnConflict: form.odooIsMasterOnConflict,
        maxSyncAttempts: Number(form.maxSyncAttempts) || 5,
      };
      if (form.apiKey.trim()) payload.apiKey = form.apiKey.trim();
      for (const [key] of numberFields) {
        const raw = form[key];
        payload[key] = raw === '' || raw === null ? null : Number(raw);
      }
      await api.put('/api/odoo/settings', payload);
      await onSaved();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'تعذر حفظ الإعدادات');
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal
      open
      onClose={onClose}
      title="إعدادات الربط مع Odoo"
      size="lg"
      footer={
        <>
          <button type="button" className="btn-ghost" onClick={onClose} disabled={busy}>
            إلغاء
          </button>
          <button type="button" className="btn-primary" disabled={busy} onClick={() => void save()}>
            {busy && <Spinner className="h-4 w-4" />}
            حفظ
          </button>
        </>
      }
    >
      <div className="space-y-5">
        <ErrorAlert message={error} />

        <label className="flex cursor-pointer items-center gap-3 rounded-xl border border-surface-border p-3">
          <input
            type="checkbox"
            className="h-5 w-5 accent-brand"
            checked={form.isEnabled}
            onChange={(event) => update('isEnabled', event.target.checked)}
          />
          <div>
            <span className="text-sm font-semibold">تفعيل الربط مع Odoo</span>
            <p className="text-xs text-neutral-500">
              نقطة البيع تستمر في العمل حتى عند تعطل Odoo — تُخزَّن العمليات في الطابور.
            </p>
          </div>
        </label>

        <section className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="odoo-url">
              رابط Odoo
            </label>
            <input
              id="odoo-url"
              className="input"
              dir="ltr"
              value={form.url}
              onChange={(event) => update('url', event.target.value)}
              placeholder="https://mycompany.odoo.com"
            />
          </div>
          <div>
            <label className="label" htmlFor="odoo-db">
              اسم قاعدة البيانات
            </label>
            <input
              id="odoo-db"
              className="input"
              dir="ltr"
              value={form.database}
              onChange={(event) => update('database', event.target.value)}
            />
          </div>
          <div>
            <label className="label" htmlFor="odoo-user">
              اسم المستخدم
            </label>
            <input
              id="odoo-user"
              className="input"
              dir="ltr"
              value={form.username}
              onChange={(event) => update('username', event.target.value)}
            />
          </div>
          <div>
            <label className="label" htmlFor="odoo-key">
              مفتاح API أو كلمة المرور
            </label>
            <input
              id="odoo-key"
              type="password"
              className="input"
              dir="ltr"
              value={form.apiKey}
              onChange={(event) => update('apiKey', event.target.value)}
              placeholder={settings?.hasApiKey ? '•••••••• (محفوظ ومشفّر)' : ''}
            />
            <p className="mt-1 text-xs text-neutral-500">
              يُخزَّن مشفرًا بخوارزمية AES-256-GCM ولا يُعاد عرضه أبدًا.
            </p>
          </div>
          <div>
            <label className="label" htmlFor="protocol">
              بروتوكول الاتصال
            </label>
            <select
              id="protocol"
              className="input"
              value={form.protocol}
              onChange={(event) => update('protocol', event.target.value as typeof form.protocol)}
            >
              <option value="JSON_RPC">JSON-RPC (Odoo Online / Odoo.sh)</option>
              <option value="XML_RPC">XML-RPC (Community)</option>
            </select>
          </div>
          <div>
            <label className="label" htmlFor="attempts">
              أقصى عدد محاولات المزامنة
            </label>
            <input
              id="attempts"
              type="number"
              min="1"
              max="20"
              className="input tabular"
              value={form.maxSyncAttempts}
              onChange={(event) => update('maxSyncAttempts', Number(event.target.value))}
            />
          </div>
        </section>

        <section>
          <p className="label">وضع الترحيل المحاسبي</p>
          <div className="grid gap-2 sm:grid-cols-2">
            {[
              {
                key: 'DAILY_SUMMARY',
                title: 'ملخص يومي (موصى به)',
                desc: 'قيد واحد في نهاية اليوم التشغيلي — أقل عدد عمليات داخل Odoo.',
              },
              {
                key: 'PER_INVOICE',
                title: 'إرسال كل فاتورة',
                desc: 'فاتورة مستقلة في Odoo لكل عملية بيع.',
              },
            ].map((option) => (
              <button
                key={option.key}
                type="button"
                onClick={() => update('postingMode', option.key as typeof form.postingMode)}
                className={`rounded-xl border p-3 text-right transition ${
                  form.postingMode === option.key
                    ? 'border-brand bg-brand/10'
                    : 'border-surface-border bg-white hover:bg-surface-muted'
                }`}
              >
                <p className="text-sm font-semibold">{option.title}</p>
                <p className="mt-0.5 text-xs text-neutral-500">{option.desc}</p>
              </button>
            ))}
          </div>
        </section>

        <section className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="direction">
              اتجاه مزامنة المنتجات
            </label>
            <select
              id="direction"
              className="input"
              value={form.productSyncDirection}
              onChange={(event) =>
                update('productSyncDirection', event.target.value as typeof form.productSyncDirection)
              }
            >
              <option value="ODOO_TO_POS">من Odoo إلى نقطة البيع</option>
              <option value="POS_TO_ODOO">من نقطة البيع إلى Odoo</option>
              <option value="BIDIRECTIONAL">مزامنة ثنائية الاتجاه</option>
            </select>
          </div>
          <label className="flex cursor-pointer items-center gap-3 self-end rounded-xl border border-surface-border p-3">
            <input
              type="checkbox"
              className="h-5 w-5 accent-brand"
              checked={form.odooIsMasterOnConflict}
              onChange={(event) => update('odooIsMasterOnConflict', event.target.checked)}
            />
            <span className="text-sm">Odoo هو المصدر الأساسي عند التعارض</span>
          </label>
        </section>

        <section>
          <p className="label">الحسابات والدفاتر في Odoo (اختياري)</p>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {numberFields.map(([key, label]) => (
              <div key={key}>
                <label className="mb-1 block text-xs text-neutral-600" htmlFor={key}>
                  {label}
                </label>
                <input
                  id={key}
                  type="number"
                  className="input tabular"
                  value={form[key] as number | string}
                  onChange={(event) =>
                    update(key, (event.target.value === '' ? '' : Number(event.target.value)) as never)
                  }
                />
              </div>
            ))}
          </div>
        </section>
      </div>
    </Modal>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-surface-muted px-3 py-2">
      <p className="text-[11px] text-neutral-500">{label}</p>
      <p className="break-all font-medium">{value}</p>
    </div>
  );
}
