'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { api, ApiClientError, qs } from '@/lib/client/api';
import { money, number, ORDER_TYPE_LABELS } from '@/lib/client/format';
import { ConfirmDialog, ErrorAlert, LoadingBlock, Modal, Spinner } from '@/components/ui';
import { useSession } from '@/components/session-provider';
import { ProductOptionsModal } from '@/components/pos/product-options-modal';
import { PaymentModal } from '@/components/pos/payment-modal';
import { OrderTypeModal } from '@/components/pos/order-type-modal';
import { DiscountModal } from '@/components/pos/discount-modal';
import { ReceiptModal } from '@/components/pos/receipt-modal';
import type {
  CategoryDto,
  InvoiceDto,
  OrderDto,
  ProductDto,
  ShiftDto,
} from '@/types/pos';

export default function PosPage() {
  const { user, can } = useSession();

  const [categories, setCategories] = useState<CategoryDto[]>([]);
  const [products, setProducts] = useState<ProductDto[]>([]);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [order, setOrder] = useState<OrderDto | null>(null);
  const [heldOrders, setHeldOrders] = useState<OrderDto[]>([]);
  const [shift, setShift] = useState<ShiftDto | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const [optionsProduct, setOptionsProduct] = useState<ProductDto | null>(null);
  const [showPayment, setShowPayment] = useState(false);
  const [showOrderType, setShowOrderType] = useState(false);
  const [showDiscount, setShowDiscount] = useState(false);
  const [showHeld, setShowHeld] = useState(false);
  const [cancelTarget, setCancelTarget] = useState<'order' | { itemId: string } | null>(null);
  const [receipt, setReceipt] = useState<InvoiceDto | null>(null);

  const searchRef = useRef<HTMLInputElement>(null);

  // ---------------------------------------------------------------------------
  // تحميل البيانات
  // ---------------------------------------------------------------------------
  const loadShift = useCallback(async () => {
    const { data } = await api.get<ShiftDto | null>('/api/shifts/current');
    setShift(data);
  }, []);

  const loadHeld = useCallback(async () => {
    const { data } = await api.get<OrderDto[]>(`/api/orders${qs({ status: 'HELD' })}`);
    setHeldOrders(data);
  }, []);

  useEffect(() => {
    const load = async () => {
      try {
        const [cats, prods] = await Promise.all([
          api.get<CategoryDto[]>('/api/categories'),
          api.get<ProductDto[]>(`/api/products${qs({ posOnly: 'true', pageSize: 200 })}`),
        ]);
        setCategories(cats.data);
        setProducts(prods.data);
        await Promise.all([loadShift(), loadHeld()]);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'تعذر تحميل بيانات نقطة البيع');
      } finally {
        setLoading(false);
      }
    };
    void load();
  }, [loadShift, loadHeld]);

  // ---------------------------------------------------------------------------
  // اختصارات لوحة المفاتيح
  // ---------------------------------------------------------------------------
  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if (event.key === 'F2') {
        event.preventDefault();
        searchRef.current?.focus();
      } else if (event.key === 'F4' && order) {
        event.preventDefault();
        setShowPayment(true);
      } else if (event.key === 'F8' && order) {
        event.preventDefault();
        void holdOrder();
      } else if (event.key === 'F9') {
        event.preventDefault();
        setShowOrderType(true);
      } else if (event.key === 'F11') {
        event.preventDefault();
        void toggleFullscreen();
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [order]);

  async function toggleFullscreen() {
    if (document.fullscreenElement) await document.exitFullscreen();
    else await document.documentElement.requestFullscreen().catch(() => undefined);
  }

  // ---------------------------------------------------------------------------
  // عمليات الطلب
  // ---------------------------------------------------------------------------
  function handleError(err: unknown) {
    setError(err instanceof ApiClientError ? err.message : 'حدث خطأ غير متوقع');
    setTimeout(() => setError(null), 6000);
  }

  function flash(message: string) {
    setNotice(message);
    setTimeout(() => setNotice(null), 3000);
  }

  const createOrder = useCallback(
    async (payload: {
      type: string;
      tableId?: string | null;
      guestCount?: number | null;
      customerName?: string | null;
      customerPhone?: string | null;
    }) => {
      setBusy(true);
      try {
        const { data } = await api.post<OrderDto>('/api/orders', {
          ...payload,
          shiftId: shift?.id ?? null,
          clientUuid: crypto.randomUUID(),
        });
        setOrder(data);
        setShowOrderType(false);
        return data;
      } catch (err) {
        handleError(err);
        return null;
      } finally {
        setBusy(false);
      }
    },
    [shift],
  );

  /** إضافة منتج — ضغطة واحدة إذا لم يكن له خيارات */
  async function addProduct(
    product: ProductDto,
    options?: {
      variantId?: string | null;
      quantity?: number;
      note?: string | null;
      modifiers?: { modifierId: string; name: string; priceDelta: number; groupName?: string }[];
    },
  ) {
    let current = order;
    if (!current) {
      // لا يوجد طلب مفتوح — نفتح طلب سفري مباشرة لتسريع البيع
      current = await createOrder({ type: 'TAKEAWAY' });
      if (!current) return;
    }

    setBusy(true);
    try {
      const { data } = await api.post<OrderDto>(`/api/orders/${current.id}/items`, {
        productId: product.id,
        variantId: options?.variantId ?? null,
        quantity: options?.quantity ?? 1,
        note: options?.note ?? null,
        modifiers: options?.modifiers ?? [],
      });
      setOrder(data);
      setOptionsProduct(null);
    } catch (err) {
      handleError(err);
    } finally {
      setBusy(false);
    }
  }

  function onProductClick(product: ProductDto) {
    const hasOptions =
      (product.variants?.length ?? 0) > 0 || (product.modifierGroups?.length ?? 0) > 0;
    if (hasOptions) setOptionsProduct(product);
    else void addProduct(product);
  }

  async function changeQuantity(itemId: string, quantity: number) {
    if (!order) return;
    setBusy(true);
    try {
      const { data } = await api.patch<OrderDto>(
        `/api/orders/${order.id}/items/${itemId}`,
        { quantity },
      );
      setOrder(data);
    } catch (err) {
      handleError(err);
    } finally {
      setBusy(false);
    }
  }

  async function voidItem(itemId: string, reason: string) {
    if (!order) return;
    setBusy(true);
    try {
      const { data } = await api.delete<OrderDto>(
        `/api/orders/${order.id}/items/${itemId}`,
        { reason },
      );
      setOrder(data);
      setCancelTarget(null);
      flash('تم إلغاء الصنف');
    } catch (err) {
      handleError(err);
    } finally {
      setBusy(false);
    }
  }

  /** إلغاء تطبيق عرض على هذا الطلب (يبقى العرض فعالًا للطلبات الأخرى) */
  async function dismissOffer(offerId: string) {
    if (!order) return;
    setBusy(true);
    try {
      const { data } = await api.delete<OrderDto>(
        `/api/orders/${order.id}/offers/${offerId}`,
      );
      setOrder(data);
      flash('تم إلغاء العرض لهذا الطلب');
    } catch (err) {
      handleError(err);
    } finally {
      setBusy(false);
    }
  }

  async function holdOrder() {
    if (!order) return;
    setBusy(true);
    try {
      await api.post(`/api/orders/${order.id}/hold`);
      setOrder(null);
      await loadHeld();
      flash('تم تعليق الطلب');
    } catch (err) {
      handleError(err);
    } finally {
      setBusy(false);
    }
  }

  async function resumeOrder(orderId: string) {
    setBusy(true);
    try {
      const { data } = await api.post<OrderDto>(`/api/orders/${orderId}/resume`);
      setOrder(data);
      setShowHeld(false);
      await loadHeld();
    } catch (err) {
      handleError(err);
    } finally {
      setBusy(false);
    }
  }

  async function sendToPrep() {
    if (!order) return;
    setBusy(true);
    try {
      const { data } = await api.post<{ order: OrderDto }>(
        `/api/orders/${order.id}/send-to-prep`,
      );
      setOrder(data.order);
      flash('تم إرسال الطلب إلى محطات التحضير');
    } catch (err) {
      handleError(err);
    } finally {
      setBusy(false);
    }
  }

  async function cancelOrder(reason: string) {
    if (!order) return;
    setBusy(true);
    try {
      await api.post(`/api/orders/${order.id}/cancel`, { reason });
      setOrder(null);
      setCancelTarget(null);
      flash('تم إلغاء الطلب');
    } catch (err) {
      handleError(err);
    } finally {
      setBusy(false);
    }
  }

  function onPaid(invoice: InvoiceDto) {
    setShowPayment(false);
    setOrder(null);
    setReceipt(invoice);
    void loadShift();
    flash(`تم إصدار الفاتورة ${invoice.invoiceNumber}`);
  }

  // ---------------------------------------------------------------------------
  // العرض
  // ---------------------------------------------------------------------------
  const visibleProducts = useMemo(() => {
    const term = search.trim().toLowerCase();
    return products.filter((product) => {
      if (activeCategory && product.categoryId !== activeCategory) return false;
      if (!term) return true;
      return (
        product.nameAr.toLowerCase().includes(term) ||
        product.nameEn?.toLowerCase().includes(term) ||
        product.sku.toLowerCase().includes(term) ||
        product.barcode?.includes(term)
      );
    });
  }, [products, activeCategory, search]);

  const activeItems = order?.items.filter((item) => !item.isVoided) ?? [];
  const total = Number(order?.grandTotal ?? 0);

  // العروض المطبقة تلقائيًا — نجمعها من خصومات النوع OFFER
  const appliedOffers = useMemo(() => {
    const map = new Map<string, { id: string; name: string; savings: number }>();
    for (const discount of order?.discounts ?? []) {
      if (discount.type !== 'OFFER' || !discount.offerId) continue;
      const entry = map.get(discount.offerId) ?? {
        id: discount.offerId,
        name: discount.offer?.nameAr ?? 'عرض',
        savings: 0,
      };
      entry.savings += Number(discount.amount);
      map.set(discount.offerId, entry);
    }
    return Array.from(map.values());
  }, [order]);

  if (loading) return <LoadingBlock label="جارٍ تحميل شاشة البيع…" />;

  return (
    <div className="flex h-[calc(100vh-8rem)] flex-col gap-3 lg:h-[calc(100vh-7rem)] lg:flex-row">
      {/* ------------------------------ المنتجات ------------------------------ */}
      <section className="flex min-h-0 min-w-0 flex-1 flex-col gap-3">
        {!shift && (
          <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-2.5 text-sm text-amber-900">
            ⚠️ لا توجد وردية مفتوحة — لن تُربط المبيعات بأي وردية. افتح وردية من صفحة الورديات.
          </div>
        )}
        {error && <ErrorAlert message={error} />}
        {notice && (
          <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-sm text-emerald-800">
            {notice}
          </div>
        )}

        {/* البحث والتصنيفات */}
        <div className="flex gap-2">
          <input
            ref={searchRef}
            className="input flex-1"
            placeholder="بحث سريع بالاسم أو الكود أو الباركود… (F2)"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
          />
          <button
            type="button"
            className="btn-ghost"
            onClick={() => void toggleFullscreen()}
            title="ملء الشاشة (F11)"
          >
            ⛶
          </button>
        </div>

        <div className="flex w-full shrink-0 gap-2 overflow-x-auto pb-1">
          <CategoryChip
            label="الكل"
            active={activeCategory === null}
            onClick={() => setActiveCategory(null)}
          />
          {categories.map((category) => (
            <CategoryChip
              key={category.id}
              label={`${category.iconEmoji ?? ''} ${category.nameAr}`.trim()}
              count={category._count?.products}
              color={category.color}
              active={activeCategory === category.id}
              onClick={() => setActiveCategory(category.id)}
            />
          ))}
        </div>

        {/* شبكة المنتجات */}
        <div className="min-h-0 flex-1 overflow-y-auto rounded-2xl">
          {visibleProducts.length === 0 ? (
            <p className="py-16 text-center text-sm text-neutral-500">لا توجد منتجات مطابقة</p>
          ) : (
            <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5">
              {visibleProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  disabled={busy}
                  onClick={() => onProductClick(product)}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* ------------------------------- السلة ------------------------------- */}
      <aside className="flex min-h-0 w-full flex-col rounded-2xl border border-surface-border bg-white shadow-card lg:w-[400px]">
        <header className="border-b border-surface-border px-4 py-3">
          <div className="flex items-center justify-between gap-2">
            <div className="min-w-0">
              <p className="truncate text-sm font-bold text-ink">
                {order ? `طلب ${order.orderNumber}` : 'لا يوجد طلب مفتوح'}
              </p>
              <p className="truncate text-xs text-neutral-500">
                {user.fullName}
                {order && ` · ${ORDER_TYPE_LABELS[order.type]}`}
                {order?.table && ` · طاولة ${order.table.number}`}
                {order?.guestCount ? ` · ${order.guestCount} ضيف` : ''}
              </p>
            </div>
            <div className="flex gap-1.5">
              <button
                type="button"
                className="btn-ghost !px-2.5 !py-1.5 text-xs"
                onClick={() => setShowHeld(true)}
                title="الطلبات المعلقة"
              >
                📌 {heldOrders.length}
              </button>
              <button
                type="button"
                className="btn-ghost !px-2.5 !py-1.5 text-xs"
                onClick={() => setShowOrderType(true)}
                title="طلب جديد (F9)"
              >
                ＋ جديد
              </button>
            </div>
          </div>
        </header>

        {/* أصناف الطلب */}
        <div className="min-h-0 flex-1 overflow-y-auto p-3">
          {activeItems.length === 0 ? (
            <p className="py-12 text-center text-sm text-neutral-400">
              اضغط على المنتج لإضافته إلى الطلب
            </p>
          ) : (
            <ul className="space-y-2">
              {activeItems.map((item) => (
                <li key={item.id} className="rounded-xl border border-surface-border p-2.5">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold">{item.nameAr}</p>
                      {item.modifiers && item.modifiers.length > 0 && (
                        <p className="truncate text-[11px] text-neutral-500">
                          {item.modifiers.map((m) => m.name).join('، ')}
                        </p>
                      )}
                      {item.note && (
                        <p className="truncate text-[11px] text-amber-700">📝 {item.note}</p>
                      )}
                      {item.isTobacco && (
                        <span className="badge mt-1 bg-neutral-900 text-white">تبغ</span>
                      )}
                    </div>
                    <span className="tabular whitespace-nowrap text-sm font-bold">
                      {money(item.lineTotal, false)}
                    </span>
                  </div>

                  <div className="mt-2 flex items-center justify-between">
                    <div className="flex items-center gap-1">
                      <QtyButton
                        label="−"
                        disabled={busy}
                        onClick={() =>
                          void changeQuantity(item.id, Number(item.quantity) - 1)
                        }
                      />
                      <span className="tabular w-9 text-center text-sm font-bold">
                        {number(item.quantity)}
                      </span>
                      <QtyButton
                        label="+"
                        disabled={busy}
                        onClick={() =>
                          void changeQuantity(item.id, Number(item.quantity) + 1)
                        }
                      />
                    </div>
                    {can('orders.void_item') && (
                      <button
                        type="button"
                        className="rounded-lg px-2 py-1 text-xs text-red-600 hover:bg-red-50"
                        onClick={() => setCancelTarget({ itemId: item.id })}
                      >
                        إلغاء الصنف
                      </button>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* العروض المطبقة تلقائيًا */}
        {appliedOffers.length > 0 && (
          <div className="space-y-1.5 border-t border-surface-border bg-emerald-50 px-4 py-2.5">
            {appliedOffers.map((offer) => (
              <div key={offer.id} className="flex items-center justify-between gap-2 text-xs">
                <span className="flex min-w-0 items-center gap-1.5 text-emerald-900">
                  <span aria-hidden>🎁</span>
                  <span className="truncate font-semibold">{offer.name}</span>
                </span>
                <span className="flex shrink-0 items-center gap-2">
                  <span className="tabular font-bold text-emerald-700">
                    − {money(offer.savings, false)}
                  </span>
                  <button
                    type="button"
                    className="rounded px-1.5 py-0.5 text-[11px] text-neutral-500 underline hover:text-red-600"
                    disabled={busy}
                    onClick={() => void dismissOffer(offer.id)}
                    title="إلغاء العرض لهذا الطلب"
                  >
                    إلغاء
                  </button>
                </span>
              </div>
            ))}
          </div>
        )}

        {/* الإجماليات */}
        <div className="space-y-1.5 border-t border-surface-border px-4 py-3 text-sm">
          <TotalRow label="الإجمالي قبل الضريبة" value={money(Number(order?.subtotal ?? 0) - Number(order?.discountTotal ?? 0))} />
          {Number(order?.discountTotal ?? 0) > 0 && (
            <TotalRow
              label="الخصم"
              value={`− ${money(order?.discountTotal)}`}
              className="text-emerald-700"
            />
          )}
          <TotalRow label="ضريبة القيمة المضافة" value={money(order?.vatTotal ?? 0)} />
          {Number(order?.tobaccoTaxTotal ?? 0) > 0 && (
            <TotalRow label="ضريبة التبغ" value={money(order?.tobaccoTaxTotal)} />
          )}
          <div className="mt-2 flex items-center justify-between rounded-xl bg-brand px-3 py-2.5 text-white">
            <span className="text-sm font-semibold">الإجمالي النهائي</span>
            <span className="tabular text-xl font-bold">{money(total)}</span>
          </div>
        </div>

        {/* أزرار العمليات */}
        <div className="grid grid-cols-2 gap-2 border-t border-surface-border p-3">
          <button
            type="button"
            className="btn-ghost btn-touch"
            disabled={!order || activeItems.length === 0 || busy}
            onClick={() => void sendToPrep()}
          >
            👨‍🍳 إرسال للتحضير
          </button>
          <button
            type="button"
            className="btn-ghost btn-touch"
            disabled={!order || activeItems.length === 0 || busy}
            onClick={() => void holdOrder()}
          >
            📌 تعليق (F8)
          </button>
          {can('discounts.apply') && (
            <button
              type="button"
              className="btn-ghost btn-touch"
              disabled={!order || activeItems.length === 0 || busy}
              onClick={() => setShowDiscount(true)}
            >
              🏷️ خصم
            </button>
          )}
          {can('orders.cancel') && (
            <button
              type="button"
              className="btn-ghost btn-touch !text-red-600"
              disabled={!order || busy}
              onClick={() => setCancelTarget('order')}
            >
              ✕ إلغاء الطلب
            </button>
          )}
          <button
            type="button"
            className="btn-primary btn-touch col-span-2 text-lg"
            disabled={!order || activeItems.length === 0 || busy || !can('payments.collect')}
            onClick={() => setShowPayment(true)}
          >
            {busy ? <Spinner className="h-5 w-5" /> : '💳'} الدفع (F4) — {money(total)}
          </button>
        </div>
      </aside>

      {/* ------------------------------ النوافذ ------------------------------ */}
      {optionsProduct && (
        <ProductOptionsModal
          product={optionsProduct}
          busy={busy}
          onClose={() => setOptionsProduct(null)}
          onConfirm={(options) => void addProduct(optionsProduct, options)}
        />
      )}

      <OrderTypeModal
        open={showOrderType}
        busy={busy}
        onClose={() => setShowOrderType(false)}
        onConfirm={(payload) => void createOrder(payload)}
      />

      {order && (
        <PaymentModal
          open={showPayment}
          order={order}
          shiftId={shift?.id ?? null}
          onClose={() => setShowPayment(false)}
          onPaid={onPaid}
        />
      )}

      {order && (
        <DiscountModal
          open={showDiscount}
          order={order}
          onClose={() => setShowDiscount(false)}
          onApplied={(updated) => {
            setOrder(updated);
            setShowDiscount(false);
            flash('تم تطبيق الخصم');
          }}
        />
      )}

      <Modal open={showHeld} onClose={() => setShowHeld(false)} title="الطلبات المعلقة">
        {heldOrders.length === 0 ? (
          <p className="py-8 text-center text-sm text-neutral-500">لا توجد طلبات معلقة</p>
        ) : (
          <ul className="space-y-2">
            {heldOrders.map((held) => (
              <li
                key={held.id}
                className="flex items-center justify-between gap-3 rounded-xl border border-surface-border p-3"
              >
                <div className="min-w-0">
                  <p className="text-sm font-semibold">{held.orderNumber}</p>
                  <p className="text-xs text-neutral-500">
                    {ORDER_TYPE_LABELS[held.type]}
                    {held.table && ` · طاولة ${held.table.number}`} ·{' '}
                    {held.items.length} صنف
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="tabular text-sm font-bold">{money(held.grandTotal)}</span>
                  <button
                    type="button"
                    className="btn-primary !px-3 !py-1.5 text-xs"
                    onClick={() => void resumeOrder(held.id)}
                  >
                    استرجاع
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Modal>

      <ConfirmDialog
        open={cancelTarget !== null}
        title={cancelTarget === 'order' ? 'إلغاء الطلب' : 'إلغاء الصنف'}
        message={
          cancelTarget === 'order'
            ? 'سيتم إلغاء الطلب بالكامل. لا يمكن التراجع عن هذه العملية.'
            : 'سيتم إلغاء هذا الصنف من الطلب.'
        }
        danger
        requireReason
        reasonLabel="سبب الإلغاء"
        busy={busy}
        confirmLabel="تأكيد الإلغاء"
        onCancel={() => setCancelTarget(null)}
        onConfirm={({ reason }) => {
          if (cancelTarget === 'order') void cancelOrder(reason ?? '');
          else if (cancelTarget) void voidItem(cancelTarget.itemId, reason ?? '');
        }}
      />

      {receipt && <ReceiptModal invoice={receipt} onClose={() => setReceipt(null)} />}
    </div>
  );
}

// -----------------------------------------------------------------------------
// مكونات مساعدة
// -----------------------------------------------------------------------------

function CategoryChip({
  label,
  count,
  color,
  active,
  onClick,
}: {
  label: string;
  count?: number;
  color?: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`shrink-0 rounded-xl border px-4 py-2.5 text-sm font-semibold transition ${
        active
          ? 'border-transparent text-white'
          : 'border-surface-border bg-white text-ink hover:bg-surface-muted'
      }`}
      style={active ? { backgroundColor: color ?? 'var(--brand-primary)' } : undefined}
    >
      {label}
      {count !== undefined && (
        <span className={`tabular mr-1.5 text-xs ${active ? 'text-white/70' : 'text-neutral-400'}`}>
          {count}
        </span>
      )}
    </button>
  );
}

function ProductCard({
  product,
  disabled,
  onClick,
}: {
  product: ProductDto;
  disabled: boolean;
  onClick: () => void;
}) {
  const hasOptions =
    (product.variants?.length ?? 0) > 0 || (product.modifierGroups?.length ?? 0) > 0;

  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className="flex min-h-[104px] flex-col justify-between rounded-2xl border border-surface-border bg-white p-3 text-right shadow-card transition hover:border-brand hover:shadow-pop active:scale-[0.98] disabled:opacity-60"
    >
      <div className="flex w-full items-start justify-between gap-1">
        <span className="line-clamp-2 text-sm font-semibold leading-tight">
          {product.nameAr}
        </span>
        {product.isTobacco && <span className="shrink-0 text-xs">💨</span>}
      </div>
      <div className="mt-2 flex w-full items-end justify-between">
        <span className="tabular text-base font-bold text-brand">
          {money(product.price, false)}
        </span>
        {hasOptions && <span className="text-[10px] text-neutral-400">خيارات ⚙</span>}
      </div>
    </button>
  );
}

function QtyButton({
  label,
  onClick,
  disabled,
}: {
  label: string;
  onClick: () => void;
  disabled: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className="h-8 w-8 rounded-lg border border-surface-border text-base font-bold text-ink transition hover:bg-surface-muted disabled:opacity-50"
    >
      {label}
    </button>
  );
}

function TotalRow({
  label,
  value,
  className = '',
}: {
  label: string;
  value: string;
  className?: string;
}) {
  return (
    <div className={`flex items-center justify-between ${className}`}>
      <span className="text-neutral-600">{label}</span>
      <span className="tabular font-medium">{value}</span>
    </div>
  );
}
