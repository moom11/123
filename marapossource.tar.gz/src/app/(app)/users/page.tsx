'use client';

import { useCallback, useEffect, useState } from 'react';
import { api, ApiClientError } from '@/lib/client/api';
import { dateTime, ROLE_LABELS } from '@/lib/client/format';
import { ErrorAlert, LoadingBlock, Modal, Spinner, SuccessAlert } from '@/components/ui';
import { useSession } from '@/components/session-provider';

interface UserRow {
  id: string;
  employeeNo: string;
  email: string | null;
  fullName: string;
  phone: string | null;
  isActive: boolean;
  lastLoginAt: string | null;
  roles: { role: { code: string; nameAr: string } }[];
}

export default function UsersPage() {
  const { can } = useSession();
  const [users, setUsers] = useState<UserRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [editing, setEditing] = useState<UserRow | null>(null);
  const [creating, setCreating] = useState(false);

  const load = useCallback(async () => {
    try {
      const { data } = await api.get<UserRow[]>('/api/users');
      setUsers(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر تحميل المستخدمين');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  if (loading) return <LoadingBlock label="جارٍ تحميل المستخدمين…" />;

  return (
    <div className="space-y-5">
      <ErrorAlert message={error} />
      <SuccessAlert message={notice} />

      {can('users.manage') && (
        <div className="flex justify-end">
          <button type="button" className="btn-primary" onClick={() => setCreating(true)}>
            ＋ مستخدم جديد
          </button>
        </div>
      )}

      <div className="card overflow-hidden">
        <table className="table-base">
          <thead>
            <tr>
              <th>رقم الموظف</th>
              <th>الاسم</th>
              <th>البريد الإلكتروني</th>
              <th>الدور الوظيفي</th>
              <th>آخر دخول</th>
              <th>الحالة</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id}>
                <td className="tabular font-semibold">{user.employeeNo}</td>
                <td>{user.fullName}</td>
                <td dir="ltr" className="text-right text-xs">{user.email ?? '—'}</td>
                <td className="text-xs">
                  {user.roles.map((r) => ROLE_LABELS[r.role.code] ?? r.role.nameAr).join('، ')}
                </td>
                <td className="tabular text-xs">{dateTime(user.lastLoginAt)}</td>
                <td>
                  <span
                    className={`badge ${
                      user.isActive
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-neutral-200 text-neutral-600'
                    }`}
                  >
                    {user.isActive ? 'نشط' : 'معطل'}
                  </span>
                </td>
                <td>
                  {can('users.manage') && (
                    <button
                      type="button"
                      className="btn-ghost !px-2 !py-1 text-xs"
                      onClick={() => setEditing(user)}
                    >
                      تعديل
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {(editing || creating) && (
        <UserFormModal
          user={editing}
          onClose={() => {
            setEditing(null);
            setCreating(false);
          }}
          onSaved={async (message) => {
            setEditing(null);
            setCreating(false);
            setNotice(message);
            await load();
          }}
        />
      )}
    </div>
  );
}

function UserFormModal({
  user,
  onClose,
  onSaved,
}: {
  user: UserRow | null;
  onClose: () => void;
  onSaved: (message: string) => void | Promise<void>;
}) {
  const [form, setForm] = useState({
    employeeNo: user?.employeeNo ?? '',
    fullName: user?.fullName ?? '',
    email: user?.email ?? '',
    phone: user?.phone ?? '',
    password: '',
    managerPin: '',
    role: user?.roles[0]?.role.code ?? 'CASHIER',
    isActive: user?.isActive ?? true,
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function update<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  async function save() {
    setBusy(true);
    setError(null);
    try {
      if (user) {
        await api.patch(`/api/users/${user.id}`, {
          fullName: form.fullName,
          email: form.email || null,
          phone: form.phone || null,
          isActive: form.isActive,
          role: form.role,
          ...(form.password ? { password: form.password } : {}),
          ...(form.managerPin ? { managerPin: form.managerPin } : {}),
        });
        await onSaved('تم تحديث المستخدم');
      } else {
        await api.post('/api/users', {
          employeeNo: form.employeeNo,
          fullName: form.fullName,
          email: form.email || null,
          phone: form.phone || null,
          password: form.password,
          managerPin: form.managerPin || null,
          role: form.role,
          isActive: form.isActive,
        });
        await onSaved('تم إنشاء المستخدم');
      }
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'تعذر حفظ المستخدم');
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal
      open
      onClose={onClose}
      title={user ? `تعديل ${user.fullName}` : 'مستخدم جديد'}
      footer={
        <>
          <button type="button" className="btn-ghost" onClick={onClose} disabled={busy}>
            إلغاء
          </button>
          <button type="button" className="btn-primary" disabled={busy} onClick={() => void save()}>
            {busy && <Spinner className="h-4 w-4" />}
            حفظ
          </button>
        </>
      }
    >
      <div className="space-y-3">
        <ErrorAlert message={error} />
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="label">رقم الموظف *</label>
            <input
              className="input tabular"
              value={form.employeeNo}
              disabled={user != null}
              onChange={(event) => update('employeeNo', event.target.value)}
            />
          </div>
          <div>
            <label className="label">الاسم الكامل *</label>
            <input
              className="input"
              value={form.fullName}
              onChange={(event) => update('fullName', event.target.value)}
            />
          </div>
          <div>
            <label className="label">البريد الإلكتروني</label>
            <input
              className="input"
              dir="ltr"
              value={form.email}
              onChange={(event) => update('email', event.target.value)}
            />
          </div>
          <div>
            <label className="label">رقم الجوال</label>
            <input
              className="input tabular"
              value={form.phone}
              onChange={(event) => update('phone', event.target.value)}
            />
          </div>
          <div>
            <label className="label">
              كلمة المرور {user ? '(اتركها فارغة لعدم التغيير)' : '*'}
            </label>
            <input
              type="password"
              className="input"
              value={form.password}
              onChange={(event) => update('password', event.target.value)}
              placeholder="8 أحرف على الأقل مع حرف ورقم"
            />
          </div>
          <div>
            <label className="label">رمز المدير (للاعتمادات)</label>
            <input
              type="password"
              className="input tabular"
              value={form.managerPin}
              onChange={(event) => update('managerPin', event.target.value)}
              placeholder="4-8 أرقام"
              maxLength={8}
            />
          </div>
          <div>
            <label className="label">الدور الوظيفي</label>
            <select
              className="input"
              value={form.role}
              onChange={(event) => update('role', event.target.value)}
            >
              {Object.entries(ROLE_LABELS).map(([code, label]) => (
                <option key={code} value={code}>
                  {label}
                </option>
              ))}
            </select>
          </div>
          <label className="flex cursor-pointer items-center gap-3 self-end pb-2">
            <input
              type="checkbox"
              className="h-5 w-5 accent-brand"
              checked={form.isActive}
              onChange={(event) => update('isActive', event.target.checked)}
            />
            <span className="text-sm">الحساب نشط</span>
          </label>
        </div>
      </div>
    </Modal>
  );
}
