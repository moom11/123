'use client';

import { useCallback, useEffect, useState } from 'react';
import { api, ApiClientError } from '@/lib/client/api';
import { dateOnly, money } from '@/lib/client/format';
import { ErrorAlert, LoadingBlock, Modal, Spinner, SuccessAlert } from '@/components/ui';
import { useSession } from '@/components/session-provider';
import type { CategoryDto, OfferComponentDto, OfferDto, ProductDto } from '@/types/pos';

const WEEKDAYS = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

export default function OffersPage() {
  const { can } = useSession();
  const [offers, setOffers] = useState<OfferDto[]>([]);
  const [categories, setCategories] = useState<CategoryDto[]>([]);
  const [products, setProducts] = useState<ProductDto[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [editing, setEditing] = useState<OfferDto | null>(null);
  const [creating, setCreating] = useState(false);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const [offersRes, categoriesRes, productsRes] = await Promise.all([
        api.get<OfferDto[]>('/api/offers'),
        api.get<CategoryDto[]>('/api/categories'),
        api.get<ProductDto[]>('/api/products?includeInactive=true&pageSize=200'),
      ]);
      setOffers(offersRes.data);
      setCategories(categoriesRes.data);
      setProducts(productsRes.data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر تحميل العروض');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function toggleActive(offer: OfferDto) {
    setBusy(true);
    try {
      await api.patch(`/api/offers/${offer.id}`, { isActive: !offer.isActive });
      setNotice(offer.isActive ? 'تم تعطيل العرض' : 'تم تفعيل العرض');
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'تعذر تحديث العرض');
    } finally {
      setBusy(false);
    }
  }

  if (loading) return <LoadingBlock label="جارٍ تحميل العروض…" />;

  return (
    <div className="space-y-5">
      <ErrorAlert message={error} />
      <SuccessAlert message={notice} />

      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-neutral-600">
          العروض تُطبَّق <strong>تلقائيًا</strong> في شاشة البيع بمجرد اكتمال شروطها،
          ويمكن للكاشير إلغاء العرض لطلب معين.
        </p>
        {can('products.manage') && (
          <button type="button" className="btn-primary" onClick={() => setCreating(true)}>
            ＋ عرض جديد
          </button>
        )}
      </div>

      {offers.length === 0 ? (
        <div className="card px-6 py-16 text-center">
          <p className="text-4xl">🎁</p>
          <p className="mt-2 font-semibold text-neutral-700">لا توجد عروض بعد</p>
          <p className="mt-1 text-sm text-neutral-500">
            مثال: «أي مشروب أقل من 22 ر.س + أي معسل = 55 ر.س»
          </p>
        </div>
      ) : (
        <div className="grid gap-3 lg:grid-cols-2">
          {offers.map((offer) => (
            <article key={offer.id} className="card p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <h3 className="truncate text-base font-bold">{offer.nameAr}</h3>
                  {offer.description && (
                    <p className="mt-0.5 text-xs text-neutral-500">{offer.description}</p>
                  )}
                </div>
                <span
                  className={`badge shrink-0 ${
                    offer.isActive
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-neutral-200 text-neutral-600'
                  }`}
                >
                  {offer.isActive ? 'مفعّل' : 'معطّل'}
                </span>
              </div>

              <p className="tabular mt-3 text-2xl font-bold text-brand">
                {money(offer.fixedPrice)}
              </p>

              <ul className="mt-3 space-y-1.5">
                {offer.components.map((component) => (
                  <li
                    key={component.id}
                    className="flex items-start gap-2 rounded-lg bg-surface-muted px-3 py-2 text-xs"
                  >
                    <span className="tabular shrink-0 font-bold text-brand">
                      ×{component.quantity}
                    </span>
                    <span className="min-w-0">
                      <span className="block font-medium">{component.nameAr}</span>
                      <span className="block text-[11px] text-neutral-500">
                        {describeComponent(component, categories, products)}
                      </span>
                    </span>
                  </li>
                ))}
              </ul>

              <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-neutral-500">
                {offer.maxPerOrder > 0 && <span>حد أقصى {offer.maxPerOrder} لكل طلب</span>}
                {offer.daysOfWeek.length > 0 && (
                  <span>{offer.daysOfWeek.map((d) => WEEKDAYS[d]).join('، ')}</span>
                )}
                {offer.startTime && offer.endTime && (
                  <span className="tabular">
                    {offer.startTime} — {offer.endTime}
                  </span>
                )}
                {offer.startsAt && <span>من {dateOnly(offer.startsAt)}</span>}
                {offer.endsAt && <span>حتى {dateOnly(offer.endsAt)}</span>}
              </div>

              {can('products.manage') && (
                <div className="mt-3 flex gap-2 border-t border-surface-border pt-3">
                  <button
                    type="button"
                    className="btn-ghost flex-1 !py-1.5 text-xs"
                    onClick={() => setEditing(offer)}
                  >
                    تعديل
                  </button>
                  <button
                    type="button"
                    className="btn-ghost flex-1 !py-1.5 text-xs"
                    disabled={busy}
                    onClick={() => void toggleActive(offer)}
                  >
                    {offer.isActive ? 'تعطيل' : 'تفعيل'}
                  </button>
                </div>
              )}
            </article>
          ))}
        </div>
      )}

      {(editing || creating) && (
        <OfferFormModal
          offer={editing}
          categories={categories}
          products={products}
          onClose={() => {
            setEditing(null);
            setCreating(false);
          }}
          onSaved={async (message) => {
            setEditing(null);
            setCreating(false);
            setNotice(message);
            await load();
          }}
        />
      )}
    </div>
  );
}

/** وصف مقروء لشروط المكوّن */
function describeComponent(
  component: OfferComponentDto,
  categories: CategoryDto[],
  products: ProductDto[],
): string {
  const parts: string[] = [];

  if (component.productIds.length > 0) {
    const names = component.productIds
      .map((id) => products.find((p) => p.id === id)?.nameAr)
      .filter(Boolean);
    parts.push(`منتجات محددة: ${names.join('، ')}`);
  } else if (component.categoryIds.length > 0) {
    const names = component.categoryIds
      .map((id) => categories.find((c) => c.id === id)?.nameAr)
      .filter(Boolean);
    parts.push(`من: ${names.join('، ')}`);
  } else {
    parts.push('أي منتج');
  }

  if (component.maxUnitPrice != null) {
    parts.push(`السعر حتى ${Number(component.maxUnitPrice).toFixed(2)}`);
  }
  if (component.minUnitPrice != null) {
    parts.push(`السعر من ${Number(component.minUnitPrice).toFixed(2)}`);
  }
  if (component.tobaccoOnly === true) parts.push('منتجات التبغ فقط');
  if (component.tobaccoOnly === false) parts.push('بدون منتجات التبغ');

  return parts.join(' · ');
}

interface ComponentDraft {
  nameAr: string;
  quantity: number;
  categoryIds: string[];
  productIds: string[];
  maxUnitPrice: string;
  minUnitPrice: string;
  tobaccoOnly: 'any' | 'only' | 'none';
}

function OfferFormModal({
  offer,
  categories,
  products,
  onClose,
  onSaved,
}: {
  offer: OfferDto | null;
  categories: CategoryDto[];
  products: ProductDto[];
  onClose: () => void;
  onSaved: (message: string) => void | Promise<void>;
}) {
  const [nameAr, setNameAr] = useState(offer?.nameAr ?? '');
  const [description, setDescription] = useState(offer?.description ?? '');
  const [fixedPrice, setFixedPrice] = useState(Number(offer?.fixedPrice ?? 0));
  const [priority, setPriority] = useState(offer?.priority ?? 0);
  const [maxPerOrder, setMaxPerOrder] = useState(offer?.maxPerOrder ?? 0);
  const [isActive, setIsActive] = useState(offer?.isActive ?? true);
  const [daysOfWeek, setDaysOfWeek] = useState<number[]>(offer?.daysOfWeek ?? []);
  const [startTime, setStartTime] = useState(offer?.startTime ?? '');
  const [endTime, setEndTime] = useState(offer?.endTime ?? '');
  const [components, setComponents] = useState<ComponentDraft[]>(
    offer?.components.map((c) => ({
      nameAr: c.nameAr,
      quantity: c.quantity,
      categoryIds: c.categoryIds,
      productIds: c.productIds,
      maxUnitPrice: c.maxUnitPrice != null ? String(Number(c.maxUnitPrice)) : '',
      minUnitPrice: c.minUnitPrice != null ? String(Number(c.minUnitPrice)) : '',
      tobaccoOnly: c.tobaccoOnly === true ? 'only' : c.tobaccoOnly === false ? 'none' : 'any',
    })) ?? [
      { nameAr: '', quantity: 1, categoryIds: [], productIds: [], maxUnitPrice: '', minUnitPrice: '', tobaccoOnly: 'any' },
      { nameAr: '', quantity: 1, categoryIds: [], productIds: [], maxUnitPrice: '', minUnitPrice: '', tobaccoOnly: 'any' },
    ],
  );
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function updateComponent(index: number, patch: Partial<ComponentDraft>) {
    setComponents((current) =>
      current.map((c, i) => (i === index ? { ...c, ...patch } : c)),
    );
  }

  async function save() {
    setBusy(true);
    setError(null);
    try {
      const payload = {
        nameAr,
        description: description || null,
        fixedPrice,
        priority,
        maxPerOrder,
        isActive,
        daysOfWeek,
        startTime: startTime || null,
        endTime: endTime || null,
        components: components.map((c) => ({
          nameAr: c.nameAr,
          quantity: c.quantity,
          categoryIds: c.categoryIds,
          productIds: c.productIds,
          maxUnitPrice: c.maxUnitPrice === '' ? null : Number(c.maxUnitPrice),
          minUnitPrice: c.minUnitPrice === '' ? null : Number(c.minUnitPrice),
          tobaccoOnly:
            c.tobaccoOnly === 'only' ? true : c.tobaccoOnly === 'none' ? false : null,
        })),
      };

      if (offer) {
        await api.patch(`/api/offers/${offer.id}`, payload);
        await onSaved('تم تحديث العرض');
      } else {
        await api.post('/api/offers', payload);
        await onSaved('تم إنشاء العرض');
      }
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'تعذر حفظ العرض');
    } finally {
      setBusy(false);
    }
  }

  const canSave =
    nameAr.trim().length > 0 &&
    fixedPrice > 0 &&
    components.length >= 2 &&
    components.every((c) => c.nameAr.trim().length > 0);

  return (
    <Modal
      open
      onClose={onClose}
      title={offer ? `تعديل ${offer.nameAr}` : 'عرض جديد'}
      size="xl"
      footer={
        <>
          <button type="button" className="btn-ghost" onClick={onClose} disabled={busy}>
            إلغاء
          </button>
          <button
            type="button"
            className="btn-primary"
            disabled={!canSave || busy}
            onClick={() => void save()}
          >
            {busy && <Spinner className="h-4 w-4" />}
            حفظ
          </button>
        </>
      }
    >
      <div className="space-y-5">
        <ErrorAlert message={error} />

        <section className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="label">اسم العرض *</label>
            <input
              className="input"
              value={nameAr}
              onChange={(e) => setNameAr(e.target.value)}
              placeholder="مشروب + معسل بـ 55"
            />
          </div>
          <div>
            <label className="label">السعر النهائي للباقة (شامل الضرائب) *</label>
            <input
              type="number"
              min="0"
              step="0.01"
              className="input tabular text-lg font-bold"
              value={fixedPrice}
              onChange={(e) => setFixedPrice(Number(e.target.value))}
            />
          </div>
          <div className="sm:col-span-2">
            <label className="label">الوصف</label>
            <input
              className="input"
              value={description ?? ''}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>
        </section>

        <section>
          <div className="mb-2 flex items-center justify-between">
            <p className="label !mb-0">مكوّنات الباقة</p>
            <button
              type="button"
              className="btn-ghost !px-3 !py-1 text-xs"
              onClick={() =>
                setComponents((c) => [
                  ...c,
                  { nameAr: '', quantity: 1, categoryIds: [], productIds: [], maxUnitPrice: '', minUnitPrice: '', tobaccoOnly: 'any' },
                ])
              }
            >
              ＋ مكوّن
            </button>
          </div>

          <div className="space-y-3">
            {components.map((component, index) => (
              <div key={index} className="rounded-xl border border-surface-border p-3">
                <div className="mb-2 flex items-center justify-between">
                  <span className="text-xs font-bold text-neutral-500">
                    المكوّن {index + 1}
                  </span>
                  {components.length > 2 && (
                    <button
                      type="button"
                      className="text-xs text-red-600 hover:underline"
                      onClick={() =>
                        setComponents((c) => c.filter((_, i) => i !== index))
                      }
                    >
                      حذف
                    </button>
                  )}
                </div>

                <div className="grid gap-3 sm:grid-cols-4">
                  <div className="sm:col-span-2">
                    <label className="label !text-xs">الوصف الظاهر *</label>
                    <input
                      className="input"
                      value={component.nameAr}
                      onChange={(e) => updateComponent(index, { nameAr: e.target.value })}
                      placeholder="أي مشروب أقل من 22 ر.س"
                    />
                  </div>
                  <div>
                    <label className="label !text-xs">الكمية</label>
                    <input
                      type="number"
                      min="1"
                      className="input tabular"
                      value={component.quantity}
                      onChange={(e) =>
                        updateComponent(index, { quantity: Number(e.target.value) || 1 })
                      }
                    />
                  </div>
                  <div>
                    <label className="label !text-xs">نوع المنتج</label>
                    <select
                      className="input"
                      value={component.tobaccoOnly}
                      onChange={(e) =>
                        updateComponent(index, {
                          tobaccoOnly: e.target.value as ComponentDraft['tobaccoOnly'],
                        })
                      }
                    >
                      <option value="any">الكل</option>
                      <option value="only">التبغ فقط</option>
                      <option value="none">بدون التبغ</option>
                    </select>
                  </div>
                  <div>
                    <label className="label !text-xs">أعلى سعر للوحدة</label>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      className="input tabular"
                      value={component.maxUnitPrice}
                      onChange={(e) =>
                        updateComponent(index, { maxUnitPrice: e.target.value })
                      }
                      placeholder="بلا حد"
                    />
                  </div>
                  <div>
                    <label className="label !text-xs">أدنى سعر للوحدة</label>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      className="input tabular"
                      value={component.minUnitPrice}
                      onChange={(e) =>
                        updateComponent(index, { minUnitPrice: e.target.value })
                      }
                      placeholder="بلا حد"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="label !text-xs">التصنيفات المؤهلة</label>
                    <div className="flex flex-wrap gap-1.5">
                      {categories.map((category) => {
                        const selected = component.categoryIds.includes(category.id);
                        return (
                          <button
                            key={category.id}
                            type="button"
                            onClick={() =>
                              updateComponent(index, {
                                categoryIds: selected
                                  ? component.categoryIds.filter((id) => id !== category.id)
                                  : [...component.categoryIds, category.id],
                              })
                            }
                            className={`rounded-lg border px-2.5 py-1 text-xs ${
                              selected
                                ? 'border-brand bg-brand/10 font-semibold text-brand'
                                : 'border-surface-border bg-white'
                            }`}
                          >
                            {category.nameAr}
                          </button>
                        );
                      })}
                    </div>
                    <p className="mt-1 text-[11px] text-neutral-400">
                      بدون اختيار = كل التصنيفات
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="grid gap-3 sm:grid-cols-3">
          <div>
            <label className="label">الأولوية</label>
            <input
              type="number"
              className="input tabular"
              value={priority}
              onChange={(e) => setPriority(Number(e.target.value))}
            />
            <p className="mt-1 text-[11px] text-neutral-400">الأعلى يُطبق أولًا عند التداخل</p>
          </div>
          <div>
            <label className="label">حد التكرار في الطلب</label>
            <input
              type="number"
              min="0"
              className="input tabular"
              value={maxPerOrder}
              onChange={(e) => setMaxPerOrder(Number(e.target.value))}
            />
            <p className="mt-1 text-[11px] text-neutral-400">0 = بلا حد</p>
          </div>
          <label className="flex cursor-pointer items-center gap-3 self-end pb-2">
            <input
              type="checkbox"
              className="h-5 w-5 accent-brand"
              checked={isActive}
              onChange={(e) => setIsActive(e.target.checked)}
            />
            <span className="text-sm">العرض مفعّل</span>
          </label>
        </section>

        <section>
          <label className="label">أيام السريان (بدون اختيار = كل الأيام)</label>
          <div className="flex flex-wrap gap-1.5">
            {WEEKDAYS.map((day, index) => {
              const selected = daysOfWeek.includes(index);
              return (
                <button
                  key={day}
                  type="button"
                  onClick={() =>
                    setDaysOfWeek(
                      selected
                        ? daysOfWeek.filter((d) => d !== index)
                        : [...daysOfWeek, index],
                    )
                  }
                  className={`rounded-lg border px-3 py-1.5 text-xs ${
                    selected
                      ? 'border-brand bg-brand/10 font-semibold text-brand'
                      : 'border-surface-border bg-white'
                  }`}
                >
                  {day}
                </button>
              );
            })}
          </div>
        </section>

        <section className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="label">من الساعة</label>
            <input
              type="time"
              className="input tabular"
              value={startTime ?? ''}
              onChange={(e) => setStartTime(e.target.value)}
            />
          </div>
          <div>
            <label className="label">إلى الساعة</label>
            <input
              type="time"
              className="input tabular"
              value={endTime ?? ''}
              onChange={(e) => setEndTime(e.target.value)}
            />
          </div>
        </section>
      </div>
    </Modal>
  );
}
