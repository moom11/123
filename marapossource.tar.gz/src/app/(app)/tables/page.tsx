'use client';

import { useCallback, useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { api, ApiClientError } from '@/lib/client/api';
import { money, TABLE_STATUS_LABELS, TABLE_STATUS_STYLES, timeOnly } from '@/lib/client/format';
import { ErrorAlert, LoadingBlock, Modal, Spinner } from '@/components/ui';
import { useSession } from '@/components/session-provider';
import type { TableDto } from '@/types/pos';

type Action = 'transfer' | 'merge' | 'split' | null;

export default function TablesPage() {
  const router = useRouter();
  const { can } = useSession();
  const [tables, setTables] = useState<TableDto[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<TableDto | null>(null);
  const [action, setAction] = useState<Action>(null);
  const [targetTableId, setTargetTableId] = useState('');
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [managerPin, setManagerPin] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const { data } = await api.get<TableDto[]>('/api/tables');
      setTables(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر تحميل الطاولات');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
    const timer = setInterval(load, 20000);
    return () => clearInterval(timer);
  }, [load]);

  const activeOrder = selected?.orders?.[0];

  async function runAction(fn: () => Promise<unknown>, successMessage: string) {
    setBusy(true);
    setError(null);
    try {
      await fn();
      await load();
      setAction(null);
      setSelected(null);
      setManagerPin('');
      setSelectedItems([]);
      setTargetTableId('');
      alert(successMessage);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'تعذر تنفيذ العملية');
    } finally {
      setBusy(false);
    }
  }

  async function setStatus(table: TableDto, status: string) {
    await runAction(
      () => api.patch(`/api/tables/${table.id}`, { status }),
      'تم تحديث حالة الطاولة',
    );
  }

  if (loading) return <LoadingBlock label="جارٍ تحميل الطاولات…" />;

  const byFloor = new Map<string, TableDto[]>();
  for (const table of tables) {
    const key = table.floor?.nameAr ?? 'غير محدد';
    byFloor.set(key, [...(byFloor.get(key) ?? []), table]);
  }

  return (
    <div className="space-y-5">
      <ErrorAlert message={error} />

      {/* دليل الألوان */}
      <div className="flex flex-wrap gap-2">
        {Object.entries(TABLE_STATUS_LABELS).map(([status, label]) => (
          <span key={status} className={`badge border ${TABLE_STATUS_STYLES[status]}`}>
            {label}
          </span>
        ))}
      </div>

      {Array.from(byFloor.entries()).map(([floorName, floorTables]) => (
        <section key={floorName}>
          <h2 className="mb-3 text-sm font-bold text-ink">{floorName}</h2>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5 xl:grid-cols-6">
            {floorTables.map((table) => {
              const order = table.orders?.[0];
              return (
                <button
                  key={table.id}
                  type="button"
                  onClick={() => setSelected(table)}
                  className={`rounded-2xl border-2 p-3 text-right transition hover:shadow-pop ${
                    TABLE_STATUS_STYLES[table.status]
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <span className="tabular text-2xl font-bold">{table.number}</span>
                    <span className="text-[11px]">{table.seats} 🪑</span>
                  </div>
                  <p className="mt-1 text-xs font-semibold">
                    {TABLE_STATUS_LABELS[table.status]}
                  </p>
                  {table.area && (
                    <p className="truncate text-[10px] opacity-70">{table.area.nameAr}</p>
                  )}
                  {order && (
                    <div className="mt-2 border-t border-current/20 pt-1.5 text-[11px]">
                      <p className="tabular font-bold">{money(order.grandTotal)}</p>
                      <p className="opacity-70">{timeOnly(order.createdAt)}</p>
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </section>
      ))}

      {/* نافذة عمليات الطاولة */}
      <Modal
        open={selected !== null && action === null}
        onClose={() => setSelected(null)}
        title={`طاولة ${selected?.number ?? ''}`}
      >
        {selected && (
          <div className="space-y-4">
            <div className="rounded-xl bg-surface-muted p-3 text-sm">
              <div className="flex justify-between py-0.5">
                <span className="text-neutral-600">الحالة</span>
                <span className="font-semibold">{TABLE_STATUS_LABELS[selected.status]}</span>
              </div>
              <div className="flex justify-between py-0.5">
                <span className="text-neutral-600">المقاعد</span>
                <span className="tabular">{selected.seats}</span>
              </div>
              {activeOrder && (
                <>
                  <div className="flex justify-between py-0.5">
                    <span className="text-neutral-600">الطلب الحالي</span>
                    <span className="font-semibold">{activeOrder.orderNumber}</span>
                  </div>
                  <div className="flex justify-between py-0.5">
                    <span className="text-neutral-600">الإجمالي</span>
                    <span className="tabular font-bold">{money(activeOrder.grandTotal)}</span>
                  </div>
                </>
              )}
            </div>

            <div className="grid grid-cols-2 gap-2">
              {activeOrder ? (
                <>
                  <button
                    type="button"
                    className="btn-primary btn-touch col-span-2"
                    onClick={() => router.push('/pos')}
                  >
                    فتح الطلب في شاشة البيع
                  </button>
                  {can('orders.transfer_table') && (
                    <button
                      type="button"
                      className="btn-ghost btn-touch"
                      onClick={() => setAction('transfer')}
                    >
                      ↔️ نقل الطلب
                    </button>
                  )}
                  {can('orders.split') && (
                    <button
                      type="button"
                      className="btn-ghost btn-touch"
                      onClick={() => setAction('split')}
                    >
                      ✂️ تقسيم الفاتورة
                    </button>
                  )}
                  <button
                    type="button"
                    className="btn-ghost btn-touch col-span-2"
                    onClick={() => setAction('merge')}
                  >
                    🔗 دمج طلب آخر في هذه الطاولة
                  </button>
                </>
              ) : (
                <button
                  type="button"
                  className="btn-primary btn-touch col-span-2"
                  onClick={() => router.push('/pos')}
                >
                  فتح طلب جديد على الطاولة
                </button>
              )}

              <button
                type="button"
                className="btn-ghost btn-touch"
                onClick={() => void setStatus(selected, 'AVAILABLE')}
              >
                ✅ إتاحة
              </button>
              <button
                type="button"
                className="btn-ghost btn-touch"
                onClick={() => void setStatus(selected, 'NEEDS_CLEANING')}
              >
                🧹 تحتاج تنظيفًا
              </button>
              <button
                type="button"
                className="btn-ghost btn-touch"
                onClick={() => void setStatus(selected, 'RESERVED')}
              >
                📅 حجز
              </button>
              <button
                type="button"
                className="btn-ghost btn-touch"
                onClick={() => void setStatus(selected, 'AWAITING_PAYMENT')}
              >
                ⏳ بانتظار الدفع
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* نقل الطلب */}
      <Modal
        open={action === 'transfer'}
        onClose={() => setAction(null)}
        title="نقل الطلب إلى طاولة أخرى"
        size="sm"
        footer={
          <>
            <button type="button" className="btn-ghost" onClick={() => setAction(null)}>
              إلغاء
            </button>
            <button
              type="button"
              className="btn-primary"
              disabled={!targetTableId || busy}
              onClick={() =>
                void runAction(
                  () =>
                    api.post(`/api/orders/${activeOrder!.id}/transfer`, {
                      targetTableId,
                    }),
                  'تم نقل الطلب',
                )
              }
            >
              {busy && <Spinner className="h-4 w-4" />}
              نقل
            </button>
          </>
        }
      >
        <label className="label" htmlFor="target-table">
          الطاولة الهدف
        </label>
        <select
          id="target-table"
          className="input"
          value={targetTableId}
          onChange={(event) => setTargetTableId(event.target.value)}
        >
          <option value="">— اختر —</option>
          {tables
            .filter((table) => table.id !== selected?.id)
            .map((table) => (
              <option key={table.id} value={table.id}>
                طاولة {table.number} — {TABLE_STATUS_LABELS[table.status]}
              </option>
            ))}
        </select>
        <ErrorAlert message={error} />
      </Modal>

      {/* دمج الطلبات */}
      <Modal
        open={action === 'merge'}
        onClose={() => setAction(null)}
        title="دمج طلبين"
        size="sm"
        footer={
          <>
            <button type="button" className="btn-ghost" onClick={() => setAction(null)}>
              إلغاء
            </button>
            <button
              type="button"
              className="btn-primary"
              disabled={!targetTableId || busy}
              onClick={() =>
                void runAction(
                  () =>
                    api.post(`/api/orders/${activeOrder!.id}/merge`, {
                      sourceOrderId: targetTableId,
                      managerPin: managerPin.trim() || undefined,
                    }),
                  'تم دمج الطلبين',
                )
              }
            >
              {busy && <Spinner className="h-4 w-4" />}
              دمج
            </button>
          </>
        }
      >
        <div className="space-y-3">
          <p className="text-sm text-neutral-600">
            ستنتقل أصناف الطلب المختار إلى طلب طاولة {selected?.number}. تحتاج هذه العملية
            اعتماد المدير.
          </p>
          <div>
            <label className="label" htmlFor="source-order">
              الطلب المراد دمجه
            </label>
            <select
              id="source-order"
              className="input"
              value={targetTableId}
              onChange={(event) => setTargetTableId(event.target.value)}
            >
              <option value="">— اختر —</option>
              {tables
                .filter((table) => table.id !== selected?.id && (table.orders?.length ?? 0) > 0)
                .map((table) => (
                  <option key={table.id} value={table.orders![0].id}>
                    طاولة {table.number} — {table.orders![0].orderNumber} (
                    {money(table.orders![0].grandTotal)})
                  </option>
                ))}
            </select>
          </div>
          {!can('orders.merge') && (
            <div>
              <label className="label" htmlFor="merge-pin">
                رمز المدير
              </label>
              <input
                id="merge-pin"
                type="password"
                className="input tabular text-center tracking-[0.4em]"
                value={managerPin}
                onChange={(event) => setManagerPin(event.target.value)}
                maxLength={8}
              />
            </div>
          )}
          <ErrorAlert message={error} />
        </div>
      </Modal>

      {/* تقسيم الفاتورة */}
      <Modal
        open={action === 'split'}
        onClose={() => setAction(null)}
        title="تقسيم الفاتورة"
        footer={
          <>
            <button type="button" className="btn-ghost" onClick={() => setAction(null)}>
              إلغاء
            </button>
            <button
              type="button"
              className="btn-primary"
              disabled={selectedItems.length === 0 || busy}
              onClick={() =>
                void runAction(
                  () =>
                    api.post(`/api/orders/${activeOrder!.id}/split`, {
                      itemIds: selectedItems,
                    }),
                  'تم تقسيم الفاتورة — أُنشئ طلب جديد بالأصناف المحددة',
                )
              }
            >
              {busy && <Spinner className="h-4 w-4" />}
              تقسيم
            </button>
          </>
        }
      >
        <SplitItemsPicker
          orderId={activeOrder?.id}
          selected={selectedItems}
          onChange={setSelectedItems}
        />
        <ErrorAlert message={error} />
      </Modal>
    </div>
  );
}

/** يعرض أصناف الطلب لاختيار ما يُنقل إلى فاتورة منفصلة */
function SplitItemsPicker({
  orderId,
  selected,
  onChange,
}: {
  orderId?: string;
  selected: string[];
  onChange: (ids: string[]) => void;
}) {
  const [items, setItems] = useState<
    { id: string; nameAr: string; quantity: string | number; lineTotal: string | number }[]
  >([]);

  useEffect(() => {
    if (!orderId) return;
    api
      .get<{ items: typeof items }>(`/api/orders/${orderId}`)
      .then(({ data }) => setItems(data.items))
      .catch(() => setItems([]));
  }, [orderId]);

  if (items.length === 0) return <LoadingBlock label="جارٍ تحميل الأصناف…" />;

  return (
    <ul className="space-y-2">
      {items.map((item) => (
        <li key={item.id}>
          <label className="flex cursor-pointer items-center gap-3 rounded-xl border border-surface-border p-3 hover:bg-surface-muted">
            <input
              type="checkbox"
              className="h-5 w-5 accent-brand"
              checked={selected.includes(item.id)}
              onChange={(event) =>
                onChange(
                  event.target.checked
                    ? [...selected, item.id]
                    : selected.filter((id) => id !== item.id),
                )
              }
            />
            <span className="flex-1 text-sm">{item.nameAr}</span>
            <span className="tabular text-xs text-neutral-500">× {Number(item.quantity)}</span>
            <span className="tabular text-sm font-bold">{money(item.lineTotal, false)}</span>
          </label>
        </li>
      ))}
    </ul>
  );
}
