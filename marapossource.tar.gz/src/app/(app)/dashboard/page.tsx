'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { api } from '@/lib/client/api';
import { money, number, timeOnly } from '@/lib/client/format';
import { ErrorAlert, LoadingBlock, StatCard } from '@/components/ui';
import { useSession } from '@/components/session-provider';

interface Dashboard {
  businessDay: string;
  sales: {
    totalSales: number;
    netSales: number;
    salesBeforeTax: number;
    vatTotal: number;
    tobaccoTaxTotal: number;
    discountTotal: number;
    refundTotal: number;
    invoiceCount: number;
    averageInvoice: number;
  };
  cashSales: number;
  cardSales: number;
  expenses: number;
  deposits: number;
  currentShift: {
    id: string;
    shiftNumber: string;
    cashierName: string;
    openedAt: string;
    expectedCash: number;
  } | null;
  topProducts: { name: string; quantity: number; netSales: number }[];
  failedSyncCount: number;
  pendingSyncCount: number;
}

export default function DashboardPage() {
  const { can } = useSession();
  const [data, setData] = useState<Dashboard | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    const load = async () => {
      try {
        const result = await api.get<Dashboard>('/api/reports/dashboard');
        if (active) setData(result.data);
      } catch (err) {
        if (active) setError(err instanceof Error ? err.message : 'تعذر تحميل اللوحة');
      }
    };
    void load();
    const timer = setInterval(load, 30000);
    return () => {
      active = false;
      clearInterval(timer);
    };
  }, []);

  if (error) return <ErrorAlert message={error} />;
  if (!data) return <LoadingBlock />;

  const { sales } = data;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-sm text-neutral-500">
            اليوم التشغيلي <span className="tabular font-semibold">{data.businessDay}</span>
            <span className="mr-2 text-xs text-neutral-400">(من 5:00 صباحًا إلى 5:00 صباحًا)</span>
          </p>
        </div>
        <div className="flex gap-2">
          {can('pos.use') && (
            <Link href="/pos" className="btn-primary">
              فتح شاشة البيع
            </Link>
          )}
          {can('reports.view') && (
            <Link href="/reports" className="btn-ghost">
              التقارير التفصيلية
            </Link>
          )}
        </div>
      </div>

      <section className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard label="مبيعات اليوم" value={money(sales.totalSales)} tone="brand" icon="💵" />
        <StatCard label="صافي المبيعات" value={money(sales.netSales)} icon="📊" hint="بعد المرتجعات" />
        <StatCard label="عدد الفواتير" value={number(sales.invoiceCount)} icon="🧾" />
        <StatCard label="متوسط الفاتورة" value={money(sales.averageInvoice)} icon="📐" />
      </section>

      <section className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard label="مبيعات نقدية" value={money(data.cashSales)} tone="success" icon="💰" />
        <StatCard label="مبيعات الشبكة" value={money(data.cardSales)} icon="💳" />
        <StatCard label="ضريبة القيمة المضافة" value={money(sales.vatTotal)} icon="🧮" />
        <StatCard
          label="ضريبة التبغ"
          value={money(sales.tobaccoTaxTotal)}
          icon="💨"
          hint="محتسبة بشكل مستقل"
        />
      </section>

      <section className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard label="المصروفات" value={money(data.expenses)} tone="warning" icon="📤" />
        <StatCard
          label="المودع في الصندوق الرئيسي"
          value={money(data.deposits)}
          icon="🏦"
          hint="لا يُحتسب مصروفًا"
        />
        <StatCard label="الخصومات" value={money(sales.discountTotal)} icon="🏷️" />
        <StatCard label="المرتجعات" value={money(sales.refundTotal)} tone="danger" icon="↩️" />
      </section>

      <div className="grid gap-4 lg:grid-cols-3">
        {/* الوردية الحالية */}
        <div className="card p-5">
          <h2 className="mb-3 text-sm font-bold text-ink">الوردية الحالية</h2>
          {data.currentShift ? (
            <div className="space-y-2 text-sm">
              <Row label="رقم الوردية" value={data.currentShift.shiftNumber} mono />
              <Row label="الكاشير" value={data.currentShift.cashierName} />
              <Row label="وقت الفتح" value={timeOnly(data.currentShift.openedAt)} />
              <Row
                label="النقد المتوقع"
                value={money(data.currentShift.expectedCash)}
                mono
                strong
              />
              <Link href="/shifts" className="btn-ghost mt-3 w-full">
                إدارة الوردية
              </Link>
            </div>
          ) : (
            <div className="py-6 text-center">
              <p className="mb-3 text-sm text-neutral-500">لا توجد وردية مفتوحة</p>
              {can('shifts.open') && (
                <Link href="/shifts" className="btn-primary">
                  فتح وردية
                </Link>
              )}
            </div>
          )}
        </div>

        {/* المنتجات الأكثر مبيعًا */}
        <div className="card p-5">
          <h2 className="mb-3 text-sm font-bold text-ink">المنتجات الأكثر مبيعًا</h2>
          {data.topProducts.length === 0 ? (
            <p className="py-6 text-center text-sm text-neutral-500">لا توجد مبيعات بعد</p>
          ) : (
            <ol className="space-y-2">
              {data.topProducts.map((product, index) => (
                <li
                  key={product.name}
                  className="flex items-center gap-3 rounded-xl bg-surface-muted px-3 py-2"
                >
                  <span className="tabular flex h-6 w-6 items-center justify-center rounded-lg bg-brand text-xs font-bold text-white">
                    {index + 1}
                  </span>
                  <span className="flex-1 truncate text-sm">{product.name}</span>
                  <span className="tabular text-xs text-neutral-500">
                    {number(product.quantity)} × {money(product.netSales, false)}
                  </span>
                </li>
              ))}
            </ol>
          )}
        </div>

        {/* حالة المزامنة مع Odoo */}
        <div className="card p-5">
          <h2 className="mb-3 text-sm font-bold text-ink">المزامنة مع Odoo</h2>
          <div className="space-y-3">
            <div
              className={`rounded-xl border p-3 ${
                data.failedSyncCount > 0
                  ? 'border-red-200 bg-red-50'
                  : 'border-emerald-200 bg-emerald-50'
              }`}
            >
              <p className="text-xs text-neutral-600">عمليات فشل إرسالها</p>
              <p className="tabular text-2xl font-bold">{number(data.failedSyncCount)}</p>
            </div>
            <div className="rounded-xl border border-surface-border p-3">
              <p className="text-xs text-neutral-600">في انتظار الإرسال</p>
              <p className="tabular text-2xl font-bold">{number(data.pendingSyncCount)}</p>
            </div>
            {can('odoo.view_sync') && (
              <Link href="/odoo" className="btn-ghost w-full">
                شاشة سجل المزامنة
              </Link>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function Row({
  label,
  value,
  mono,
  strong,
}: {
  label: string;
  value: string;
  mono?: boolean;
  strong?: boolean;
}) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="text-neutral-500">{label}</span>
      <span className={`${mono ? 'tabular' : ''} ${strong ? 'font-bold' : 'font-medium'}`}>
        {value}
      </span>
    </div>
  );
}
