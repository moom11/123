'use client';

import { useCallback, useEffect, useState } from 'react';
import { api, ApiClientError } from '@/lib/client/api';
import { ErrorAlert, LoadingBlock, Spinner, SuccessAlert } from '@/components/ui';
import { useSession } from '@/components/session-provider';

interface SettingsPayload {
  settings: {
    id: string;
    businessDayStartHour: number;
    timezone: string;
    paymentRoundingTolerance: string | number;
    cashDiffTolerance: string | number;
    enableDelivery: boolean;
    enableCreditPayment: boolean;
    maxDiscountPercent: string | number;
    requireManagerForDiscount: boolean;
    invoicePrefix: string;
    orderPrefix: string;
    primaryColor: string;
    secondaryColor: string;
    accentColor: string;
    showQrOnInvoice: boolean;
  };
  branch: {
    nameAr: string;
    code: string;
    company: { nameAr: string; vatNumber: string | null; crNumber: string | null };
  };
}

export default function SettingsPage() {
  const { refresh } = useSession();
  const [data, setData] = useState<SettingsPayload | null>(null);
  const [form, setForm] = useState<SettingsPayload['settings'] | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const { data: payload } = await api.get<SettingsPayload>('/api/settings');
      setData(payload);
      setForm(payload.settings);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر تحميل الإعدادات');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  function update<K extends keyof SettingsPayload['settings']>(
    key: K,
    value: SettingsPayload['settings'][K],
  ) {
    setForm((current) => (current ? { ...current, [key]: value } : current));
  }

  async function save() {
    if (!form) return;
    setBusy(true);
    setError(null);
    try {
      await api.put('/api/settings', {
        businessDayStartHour: Number(form.businessDayStartHour),
        timezone: form.timezone,
        paymentRoundingTolerance: Number(form.paymentRoundingTolerance),
        cashDiffTolerance: Number(form.cashDiffTolerance),
        enableDelivery: form.enableDelivery,
        enableCreditPayment: form.enableCreditPayment,
        maxDiscountPercent: Number(form.maxDiscountPercent),
        requireManagerForDiscount: form.requireManagerForDiscount,
        invoicePrefix: form.invoicePrefix,
        orderPrefix: form.orderPrefix,
        primaryColor: form.primaryColor,
        secondaryColor: form.secondaryColor,
        accentColor: form.accentColor,
        showQrOnInvoice: form.showQrOnInvoice,
      });
      setNotice('تم حفظ الإعدادات');
      await refresh();
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'تعذر حفظ الإعدادات');
    } finally {
      setBusy(false);
    }
  }

  if (loading || !form || !data) return <LoadingBlock label="جارٍ تحميل الإعدادات…" />;

  return (
    <div className="max-w-4xl space-y-5">
      <ErrorAlert message={error} />
      <SuccessAlert message={notice} />

      <section className="card p-5">
        <h2 className="mb-3 text-base font-bold">بيانات الفرع</h2>
        <div className="grid gap-3 text-sm sm:grid-cols-3">
          <Info label="الشركة" value={data.branch.company.nameAr} />
          <Info label="الفرع" value={`${data.branch.nameAr} (${data.branch.code})`} />
          <Info label="الرقم الضريبي" value={data.branch.company.vatNumber ?? '—'} />
        </div>
      </section>

      <section className="card space-y-4 p-5">
        <h2 className="text-base font-bold">اليوم التشغيلي</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="startHour">
              ساعة بداية اليوم التشغيلي
            </label>
            <select
              id="startHour"
              className="input tabular"
              value={form.businessDayStartHour}
              onChange={(event) => update('businessDayStartHour', Number(event.target.value))}
            >
              {Array.from({ length: 24 }, (_, hour) => (
                <option key={hour} value={hour}>
                  {String(hour).padStart(2, '0')}:00
                </option>
              ))}
            </select>
            <p className="mt-1 text-xs text-neutral-500">
              اليوم التشغيلي يمتد من هذه الساعة حتى نفس الساعة من اليوم التالي. الافتراضي 5:00 صباحًا.
            </p>
          </div>
          <div>
            <label className="label" htmlFor="tz">
              المنطقة الزمنية
            </label>
            <input
              id="tz"
              className="input"
              dir="ltr"
              value={form.timezone}
              onChange={(event) => update('timezone', event.target.value)}
            />
          </div>
        </div>
      </section>

      <section className="card space-y-4 p-5">
        <h2 className="text-base font-bold">المدفوعات والصندوق</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="tolerance">
              سماحية تقريب المدفوعات (ر.س)
            </label>
            <input
              id="tolerance"
              type="number"
              min="0"
              step="0.01"
              className="input tabular"
              value={Number(form.paymentRoundingTolerance)}
              onChange={(event) => update('paymentRoundingTolerance', Number(event.target.value))}
            />
            <p className="mt-1 text-xs text-neutral-500">
              أقصى فرق مسموح بين مجموع المدفوعات وإجمالي الفاتورة.
            </p>
          </div>
          <div>
            <label className="label" htmlFor="cashTolerance">
              سماحية فرق الصندوق (ر.س)
            </label>
            <input
              id="cashTolerance"
              type="number"
              min="0"
              step="0.01"
              className="input tabular"
              value={Number(form.cashDiffTolerance)}
              onChange={(event) => update('cashDiffTolerance', Number(event.target.value))}
            />
            <p className="mt-1 text-xs text-neutral-500">
              الفرق الأكبر من هذه القيمة يتطلب اعتماد المدير.
            </p>
          </div>
        </div>
        <Toggle
          label="تفعيل خدمة التوصيل"
          checked={form.enableDelivery}
          onChange={(v) => update('enableDelivery', v)}
        />
        <Toggle
          label="تفعيل الدفع الآجل"
          checked={form.enableCreditPayment}
          onChange={(v) => update('enableCreditPayment', v)}
        />
      </section>

      <section className="card space-y-4 p-5">
        <h2 className="text-base font-bold">الخصومات</h2>
        <div>
          <label className="label" htmlFor="maxDiscount">
            الحد الأعلى للخصم (%)
          </label>
          <input
            id="maxDiscount"
            type="number"
            min="0"
            max="100"
            className="input tabular max-w-[160px]"
            value={Number(form.maxDiscountPercent)}
            onChange={(event) => update('maxDiscountPercent', Number(event.target.value))}
          />
        </div>
        <Toggle
          label="الخصومات تحتاج اعتماد المدير"
          checked={form.requireManagerForDiscount}
          onChange={(v) => update('requireManagerForDiscount', v)}
        />
      </section>

      <section className="card space-y-4 p-5">
        <h2 className="text-base font-bold">الترقيم والفواتير</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="invoicePrefix">
              بادئة رقم الفاتورة
            </label>
            <input
              id="invoicePrefix"
              className="input"
              dir="ltr"
              value={form.invoicePrefix}
              onChange={(event) => update('invoicePrefix', event.target.value)}
            />
          </div>
          <div>
            <label className="label" htmlFor="orderPrefix">
              بادئة رقم الطلب
            </label>
            <input
              id="orderPrefix"
              className="input"
              dir="ltr"
              value={form.orderPrefix}
              onChange={(event) => update('orderPrefix', event.target.value)}
            />
          </div>
        </div>
        <Toggle
          label="إظهار رمز QR على الفاتورة (ZATCA)"
          checked={form.showQrOnInvoice}
          onChange={(v) => update('showQrOnInvoice', v)}
        />
      </section>

      <section className="card space-y-4 p-5">
        <h2 className="text-base font-bold">الهوية اللونية</h2>
        <div className="grid gap-3 sm:grid-cols-3">
          <Color
            label="اللون الأساسي"
            value={form.primaryColor}
            onChange={(v) => update('primaryColor', v)}
          />
          <Color
            label="اللون الثانوي"
            value={form.secondaryColor}
            onChange={(v) => update('secondaryColor', v)}
          />
          <Color
            label="لون التمييز"
            value={form.accentColor}
            onChange={(v) => update('accentColor', v)}
          />
        </div>
      </section>

      <div className="sticky bottom-4 flex justify-end">
        <button type="button" className="btn-primary btn-touch" disabled={busy} onClick={() => void save()}>
          {busy && <Spinner className="h-4 w-4" />}
          حفظ الإعدادات
        </button>
      </div>
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-surface-muted px-3 py-2">
      <p className="text-xs text-neutral-500">{label}</p>
      <p className="font-semibold">{value}</p>
    </div>
  );
}

function Toggle({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (value: boolean) => void;
}) {
  return (
    <label className="flex cursor-pointer items-center gap-3">
      <input
        type="checkbox"
        className="h-5 w-5 accent-brand"
        checked={checked}
        onChange={(event) => onChange(event.target.checked)}
      />
      <span className="text-sm">{label}</span>
    </label>
  );
}

function Color({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <div>
      <label className="label">{label}</label>
      <div className="flex gap-2">
        <input
          type="color"
          className="h-11 w-14 cursor-pointer rounded-lg border border-surface-border"
          value={value}
          onChange={(event) => onChange(event.target.value)}
        />
        <input
          className="input tabular flex-1"
          dir="ltr"
          value={value}
          onChange={(event) => onChange(event.target.value)}
        />
      </div>
    </div>
  );
}
