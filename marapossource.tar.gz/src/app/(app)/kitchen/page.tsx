'use client';

import { useCallback, useEffect, useState } from 'react';
import { api, qs } from '@/lib/client/api';
import { ORDER_TYPE_LABELS, STATION_LABELS, timeOnly } from '@/lib/client/format';
import { EmptyState, ErrorAlert, LoadingBlock } from '@/components/ui';

interface Ticket {
  id: string;
  station: string;
  ticketNo: string;
  status: string;
  createdAt: string;
  payload: {
    orderNumber: string;
    orderType: string;
    tableNumber: string | null;
    guestCount: number | null;
    note: string | null;
    items: { name: string; quantity: number; note: string | null; modifiers: unknown }[];
  };
  order?: { orderNumber: string; type: string; table: { number: string } | null };
}

const STATIONS = ['KITCHEN', 'BAR', 'SHISHA'] as const;

/**
 * شاشة محطات التحضير — تعرض تذاكر المطبخ والبار والشيشة.
 * تُحدَّث تلقائيًا كل عشر ثوانٍ.
 */
export default function KitchenPage() {
  const [station, setStation] = useState<string>('KITCHEN');
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const { data } = await api.get<Ticket[]>(`/api/kitchen-tickets${qs({ station })}`);
      setTickets(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر تحميل تذاكر التحضير');
    } finally {
      setLoading(false);
    }
  }, [station]);

  useEffect(() => {
    void load();
    const timer = setInterval(load, 10000);
    return () => clearInterval(timer);
  }, [load]);

  return (
    <div className="space-y-4">
      <ErrorAlert message={error} />

      <div className="flex gap-2">
        {STATIONS.map((item) => (
          <button
            key={item}
            type="button"
            onClick={() => setStation(item)}
            className={`btn-touch rounded-xl border px-6 text-sm font-semibold ${
              station === item
                ? 'border-brand bg-brand text-white'
                : 'border-surface-border bg-white'
            }`}
          >
            {STATION_LABELS[item]}
          </button>
        ))}
      </div>

      {loading ? (
        <LoadingBlock />
      ) : tickets.length === 0 ? (
        <EmptyState
          icon="✅"
          title="لا توجد طلبات قيد التحضير"
          description={`لا توجد تذاكر معلقة في ${STATION_LABELS[station]}.`}
        />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {tickets.map((ticket) => (
            <article key={ticket.id} className="card overflow-hidden">
              <header className="flex items-center justify-between bg-ink px-3 py-2 text-white">
                <span className="tabular text-sm font-bold">{ticket.payload.orderNumber}</span>
                <span className="text-xs opacity-80">{timeOnly(ticket.createdAt)}</span>
              </header>
              <div className="border-b border-surface-border bg-surface-muted px-3 py-1.5 text-xs">
                {ORDER_TYPE_LABELS[ticket.payload.orderType] ?? ticket.payload.orderType}
                {ticket.payload.tableNumber && ` · طاولة ${ticket.payload.tableNumber}`}
                {ticket.payload.guestCount ? ` · ${ticket.payload.guestCount} ضيف` : ''}
              </div>
              <ul className="divide-y divide-surface-border">
                {ticket.payload.items.map((item, index) => (
                  <li key={index} className="flex items-start gap-2 px-3 py-2">
                    <span className="tabular flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-brand text-xs font-bold text-white">
                      {item.quantity}
                    </span>
                    <div className="min-w-0">
                      <p className="text-sm font-medium">{item.name}</p>
                      {item.note && <p className="text-xs text-amber-700">📝 {item.note}</p>}
                    </div>
                  </li>
                ))}
              </ul>
              {ticket.payload.note && (
                <p className="border-t border-surface-border bg-amber-50 px-3 py-2 text-xs text-amber-900">
                  ملاحظة الطلب: {ticket.payload.note}
                </p>
              )}
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
