'use client';

import { useCallback, useEffect, useState } from 'react';
import { api, ApiClientError } from '@/lib/client/api';
import { CASH_MOVEMENT_LABELS, dateTime, money } from '@/lib/client/format';
import { ErrorAlert, LoadingBlock, Modal, Spinner, SuccessAlert } from '@/components/ui';
import { useSession } from '@/components/session-provider';
import type { ShiftDto } from '@/types/pos';

interface MovementDto {
  id: string;
  type: string;
  amount: string | number;
  note: string | null;
  createdAt: string;
  user?: { fullName: string };
  shift?: { shiftNumber: string } | null;
  expense?: { id: string; status: string; category?: { nameAr: string } | null } | null;
}

interface ExpenseCategoryDto {
  id: string;
  nameAr: string;
}

/** الأنواع القابلة للتسجيل يدويًا من هذه الشاشة */
const MANUAL_TYPES = [
  { value: 'EXPENSE', label: 'مصروف من الصندوق', icon: '📤' },
  { value: 'WITHDRAWAL', label: 'سحب نقدي', icon: '💸' },
  { value: 'DEPOSIT_TO_MAIN_SAFE', label: 'إيداع في الصندوق الرئيسي', icon: '🏛️' },
  { value: 'EMPLOYEE_ADVANCE', label: 'عهدة موظف', icon: '🧑‍💼' },
  { value: 'ADVANCE_SETTLEMENT', label: 'استرداد عهدة', icon: '↩️' },
];

export default function CashPage() {
  const { can } = useSession();
  const [movements, setMovements] = useState<MovementDto[]>([]);
  const [categories, setCategories] = useState<ExpenseCategoryDto[]>([]);
  const [shift, setShift] = useState<ShiftDto | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const [showForm, setShowForm] = useState(false);
  const [type, setType] = useState('EXPENSE');
  const [amount, setAmount] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [note, setNote] = useState('');
  const [documentUrl, setDocumentUrl] = useState('');

  const load = useCallback(async () => {
    try {
      const [movementsRes, categoriesRes, shiftRes] = await Promise.all([
        api.get<MovementDto[]>('/api/cash-movements'),
        api.get<ExpenseCategoryDto[]>('/api/expense-categories'),
        api.get<ShiftDto | null>('/api/shifts/current'),
      ]);
      setMovements(movementsRes.data);
      setCategories(categoriesRes.data);
      setShift(shiftRes.data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر تحميل حركات الصندوق');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function submit() {
    setBusy(true);
    setError(null);
    try {
      await api.post('/api/cash-movements', {
        type,
        amount: Number(amount) || 0,
        shiftId: shift?.id ?? null,
        note: note.trim() || null,
        categoryId: categoryId || null,
        documentUrl: documentUrl.trim() || null,
      });
      setShowForm(false);
      setAmount('');
      setNote('');
      setDocumentUrl('');
      setNotice('تم تسجيل العملية');
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'تعذر تسجيل العملية');
    } finally {
      setBusy(false);
    }
  }

  async function approveExpense(expenseId: string, status: 'APPROVED' | 'REJECTED') {
    setBusy(true);
    try {
      await api.patch(`/api/expenses/${expenseId}`, { status });
      setNotice(status === 'APPROVED' ? 'تم اعتماد المصروف' : 'تم رفض المصروف');
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'تعذر تنفيذ العملية');
    } finally {
      setBusy(false);
    }
  }

  if (loading) return <LoadingBlock label="جارٍ تحميل الصندوق…" />;

  return (
    <div className="space-y-5">
      <ErrorAlert message={error} />
      <SuccessAlert message={notice} />

      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-neutral-600">
          {shift
            ? `الوردية الحالية: ${shift.shiftNumber}`
            : 'لا توجد وردية مفتوحة — ستُسجل العمليات بدون ربط بوردية.'}
        </p>
        <div className="flex gap-2">
          <button type="button" className="btn-primary" onClick={() => setShowForm(true)}>
            ＋ تسجيل عملية
          </button>
          {shift && (
            <button
              type="button"
              className="btn-ghost"
              disabled={busy}
              onClick={async () => {
                await api
                  .post('/api/cash-movements', {
                    type: 'DRAWER_OPEN',
                    amount: 0,
                    shiftId: shift.id,
                    note: 'فتح درج يدوي',
                  })
                  .catch(() => undefined);
                setNotice('تم تسجيل فتح الدرج');
                await load();
              }}
            >
              🗄️ فتح الدرج
            </button>
          )}
        </div>
      </div>

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="table-base">
            <thead>
              <tr>
                <th>النوع</th>
                <th>المبلغ</th>
                <th>التصنيف</th>
                <th>البيان</th>
                <th>الموظف</th>
                <th>الوردية</th>
                <th>التاريخ</th>
                <th>الاعتماد</th>
              </tr>
            </thead>
            <tbody>
              {movements.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-10 text-center text-neutral-500">
                    لا توجد حركات مسجلة
                  </td>
                </tr>
              ) : (
                movements.map((movement) => {
                  const value = Number(movement.amount);
                  return (
                    <tr key={movement.id}>
                      <td className="whitespace-nowrap font-medium">
                        {CASH_MOVEMENT_LABELS[movement.type] ?? movement.type}
                      </td>
                      <td
                        className={`tabular font-bold ${
                          value < 0 ? 'text-red-600' : 'text-emerald-700'
                        }`}
                      >
                        {money(value, false)}
                      </td>
                      <td className="text-xs">{movement.expense?.category?.nameAr ?? '—'}</td>
                      <td className="max-w-[240px] truncate text-xs">{movement.note ?? '—'}</td>
                      <td className="text-xs">{movement.user?.fullName ?? '—'}</td>
                      <td className="tabular text-xs">{movement.shift?.shiftNumber ?? '—'}</td>
                      <td className="tabular whitespace-nowrap text-xs">
                        {dateTime(movement.createdAt)}
                      </td>
                      <td>
                        {movement.expense ? (
                          movement.expense.status === 'PENDING' ? (
                            can('cash.approve') ? (
                              <div className="flex gap-1">
                                <button
                                  type="button"
                                  className="btn-ghost !px-2 !py-1 text-xs !text-emerald-700"
                                  disabled={busy}
                                  onClick={() =>
                                    void approveExpense(movement.expense!.id, 'APPROVED')
                                  }
                                >
                                  اعتماد
                                </button>
                                <button
                                  type="button"
                                  className="btn-ghost !px-2 !py-1 text-xs !text-red-600"
                                  disabled={busy}
                                  onClick={() =>
                                    void approveExpense(movement.expense!.id, 'REJECTED')
                                  }
                                >
                                  رفض
                                </button>
                              </div>
                            ) : (
                              <span className="badge bg-amber-100 text-amber-800">
                                بانتظار الاعتماد
                              </span>
                            )
                          ) : (
                            <span
                              className={`badge ${
                                movement.expense.status === 'APPROVED'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-red-100 text-red-800'
                              }`}
                            >
                              {movement.expense.status === 'APPROVED' ? 'معتمد' : 'مرفوض'}
                            </span>
                          )
                        ) : (
                          '—'
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      <Modal
        open={showForm}
        onClose={() => setShowForm(false)}
        title="تسجيل عملية صندوق"
        footer={
          <>
            <button type="button" className="btn-ghost" onClick={() => setShowForm(false)}>
              إلغاء
            </button>
            <button
              type="button"
              className="btn-primary"
              disabled={busy || !amount || Number(amount) <= 0}
              onClick={() => void submit()}
            >
              {busy && <Spinner className="h-4 w-4" />}
              حفظ
            </button>
          </>
        }
      >
        <div className="space-y-4">
          <section>
            <p className="label">نوع العملية</p>
            <div className="grid grid-cols-2 gap-2">
              {MANUAL_TYPES.map((item) => (
                <button
                  key={item.value}
                  type="button"
                  onClick={() => setType(item.value)}
                  className={`btn-touch rounded-xl border text-sm ${
                    type === item.value
                      ? 'border-brand bg-brand/10 font-semibold text-brand'
                      : 'border-surface-border bg-white'
                  }`}
                >
                  <span>{item.icon}</span> {item.label}
                </button>
              ))}
            </div>
            {type === 'DEPOSIT_TO_MAIN_SAFE' && (
              <p className="mt-2 rounded-lg bg-blue-50 px-3 py-2 text-xs text-blue-800">
                ℹ️ الإيداع في الصندوق الرئيسي ليس مصروفًا — يُعرض في التقارير بشكل منفصل
                ولا يُخصم من الأرباح.
              </p>
            )}
          </section>

          <div>
            <label className="label" htmlFor="amount">
              المبلغ (ر.س) <span className="text-red-600">*</span>
            </label>
            <input
              id="amount"
              type="number"
              min="0"
              step="0.01"
              className="input tabular text-lg"
              value={amount}
              onChange={(event) => setAmount(event.target.value)}
              autoFocus
            />
          </div>

          <div>
            <label className="label" htmlFor="category">
              التصنيف
            </label>
            <select
              id="category"
              className="input"
              value={categoryId}
              onChange={(event) => setCategoryId(event.target.value)}
            >
              <option value="">— بدون تصنيف —</option>
              {categories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.nameAr}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="label" htmlFor="note">
              البيان
            </label>
            <textarea
              id="note"
              className="input min-h-[68px]"
              value={note}
              onChange={(event) => setNote(event.target.value)}
              placeholder="وصف العملية…"
            />
          </div>

          <div>
            <label className="label" htmlFor="doc">
              رابط صورة المستند أو الفاتورة (اختياري)
            </label>
            <input
              id="doc"
              className="input"
              value={documentUrl}
              onChange={(event) => setDocumentUrl(event.target.value)}
              placeholder="https://…"
            />
          </div>
        </div>
      </Modal>
    </div>
  );
}
