'use client';

import { useCallback, useEffect, useState } from 'react';
import { api, qs } from '@/lib/client/api';
import { dateTime } from '@/lib/client/format';
import { ErrorAlert, LoadingBlock, Modal } from '@/components/ui';

interface AuditRow {
  id: string;
  action: string;
  entity: string;
  entityId: string | null;
  oldValue: unknown;
  newValue: unknown;
  ip: string | null;
  userAgent: string | null;
  createdAt: string;
  user?: { fullName: string; employeeNo: string } | null;
}

const ACTION_LABELS: Record<string, string> = {
  LOGIN: 'تسجيل الدخول',
  LOGIN_FAILED: 'محاولة دخول فاشلة',
  LOGOUT: 'تسجيل الخروج',
  SHIFT_OPEN: 'فتح وردية',
  SHIFT_CLOSE: 'إغلاق وردية',
  SHIFT_APPROVE_DIFF: 'اعتماد فرق صندوق',
  PRICE_CHANGE: 'تغيير سعر',
  DISCOUNT_APPLIED: 'تطبيق خصم',
  ITEM_VOIDED: 'إلغاء منتج',
  ORDER_CANCELLED: 'إلغاء طلب',
  INVOICE_CANCELLED: 'إلغاء فاتورة',
  INVOICE_CLOSED: 'إغلاق فاتورة',
  REFUND_CREATED: 'إنشاء مرتجع',
  TAX_UPDATED: 'تعديل ضريبة',
  ODOO_SETTINGS_UPDATED: 'تعديل إعدادات Odoo',
  SYNC_RETRY: 'إعادة مزامنة',
  USER_CREATED: 'إنشاء مستخدم',
  USER_UPDATED: 'تعديل مستخدم',
  PRODUCT_CREATED: 'إنشاء منتج',
  PRODUCT_UPDATED: 'تعديل منتج',
  SETTINGS_UPDATED: 'تعديل الإعدادات',
  CASH_MOVEMENT: 'حركة صندوق',
  EXPENSE_CREATED: 'تسجيل مصروف',
  TABLE_TRANSFER: 'نقل طاولة',
  ORDER_MERGED: 'دمج طلبات',
  INVOICE_SPLIT: 'تقسيم فاتورة',
};

export default function AuditPage() {
  const [rows, setRows] = useState<AuditRow[]>([]);
  const [action, setAction] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [detail, setDetail] = useState<AuditRow | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await api.get<AuditRow[]>(`/api/audit-logs${qs({ action, pageSize: 100 })}`);
      setRows(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر تحميل سجل التدقيق');
    } finally {
      setLoading(false);
    }
  }, [action]);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <div className="space-y-4">
      <ErrorAlert message={error} />

      <select
        className="input max-w-xs"
        value={action}
        onChange={(event) => setAction(event.target.value)}
      >
        <option value="">كل العمليات</option>
        {Object.entries(ACTION_LABELS).map(([code, label]) => (
          <option key={code} value={code}>
            {label}
          </option>
        ))}
      </select>

      {loading ? (
        <LoadingBlock />
      ) : (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>التاريخ والوقت</th>
                  <th>المستخدم</th>
                  <th>العملية</th>
                  <th>السجل المتأثر</th>
                  <th>عنوان IP</th>
                  <th>الجهاز</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {rows.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-10 text-center text-neutral-500">
                      لا توجد سجلات
                    </td>
                  </tr>
                ) : (
                  rows.map((row) => (
                    <tr key={row.id}>
                      <td className="tabular whitespace-nowrap text-xs">
                        {dateTime(row.createdAt)}
                      </td>
                      <td className="text-xs">
                        {row.user ? `${row.user.fullName} (${row.user.employeeNo})` : 'النظام'}
                      </td>
                      <td className="font-medium">{ACTION_LABELS[row.action] ?? row.action}</td>
                      <td className="text-xs">
                        {row.entity}
                        {row.entityId && (
                          <span className="tabular text-neutral-400"> · {row.entityId.slice(0, 8)}</span>
                        )}
                      </td>
                      <td className="tabular text-xs">{row.ip ?? '—'}</td>
                      <td className="max-w-[200px] truncate text-[11px] text-neutral-500">
                        {row.userAgent ?? '—'}
                      </td>
                      <td>
                        <button
                          type="button"
                          className="btn-ghost !px-2 !py-1 text-xs"
                          onClick={() => setDetail(row)}
                        >
                          تفاصيل
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {detail && (
        <Modal open onClose={() => setDetail(null)} title="تفاصيل السجل" size="lg">
          <div className="space-y-3 text-sm">
            <p>
              <span className="text-neutral-500">العملية: </span>
              <span className="font-semibold">{ACTION_LABELS[detail.action] ?? detail.action}</span>
            </p>
            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <p className="mb-1 text-xs font-semibold text-neutral-600">القيمة القديمة</p>
                <pre dir="ltr" className="max-h-64 overflow-auto rounded-xl bg-neutral-900 p-3 text-left text-[11px] text-neutral-100">
                  {JSON.stringify(detail.oldValue ?? null, null, 2)}
                </pre>
              </div>
              <div>
                <p className="mb-1 text-xs font-semibold text-neutral-600">القيمة الجديدة</p>
                <pre dir="ltr" className="max-h-64 overflow-auto rounded-xl bg-neutral-900 p-3 text-left text-[11px] text-neutral-100">
                  {JSON.stringify(detail.newValue ?? null, null, 2)}
                </pre>
              </div>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
