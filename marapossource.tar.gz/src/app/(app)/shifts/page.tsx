'use client';

import { useCallback, useEffect, useState } from 'react';
import { api, ApiClientError } from '@/lib/client/api';
import { dateTime, money, number } from '@/lib/client/format';
import { ErrorAlert, LoadingBlock, Modal, StatCard, SuccessAlert, Spinner } from '@/components/ui';
import { useSession } from '@/components/session-provider';
import type { ShiftDto, ShiftSummaryDto } from '@/types/pos';

const STATUS_LABELS: Record<string, string> = {
  OPEN: 'مفتوحة',
  CLOSED: 'مغلقة',
  PENDING_APPROVAL: 'بانتظار اعتماد المدير',
};

const STATUS_STYLES: Record<string, string> = {
  OPEN: 'bg-emerald-100 text-emerald-800',
  CLOSED: 'bg-neutral-200 text-neutral-700',
  PENDING_APPROVAL: 'bg-amber-100 text-amber-800',
};

export default function ShiftsPage() {
  const { can } = useSession();
  const [current, setCurrent] = useState<(ShiftDto & { summary?: ShiftSummaryDto }) | null>(null);
  const [history, setHistory] = useState<ShiftDto[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const [showOpen, setShowOpen] = useState(false);
  const [openingFloat, setOpeningFloat] = useState('0');
  const [openNote, setOpenNote] = useState('');

  const [showClose, setShowClose] = useState(false);
  const [countedCash, setCountedCash] = useState('');
  const [differenceReason, setDifferenceReason] = useState('');
  const [managerPin, setManagerPin] = useState('');
  const [closeReport, setCloseReport] = useState<ShiftSummaryDto | null>(null);

  const load = useCallback(async () => {
    try {
      const [currentRes, historyRes] = await Promise.all([
        api.get<(ShiftDto & { summary?: ShiftSummaryDto }) | null>('/api/shifts/current'),
        api.get<ShiftDto[]>('/api/shifts?pageSize=25'),
      ]);
      setCurrent(currentRes.data);
      setHistory(historyRes.data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر تحميل الورديات');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function openShift() {
    setBusy(true);
    setError(null);
    try {
      await api.post('/api/shifts', {
        openingFloat: Number(openingFloat) || 0,
        note: openNote.trim() || null,
      });
      setShowOpen(false);
      setOpeningFloat('0');
      setOpenNote('');
      setNotice('تم فتح الوردية بنجاح');
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'تعذر فتح الوردية');
    } finally {
      setBusy(false);
    }
  }

  async function closeShift() {
    if (!current) return;
    setBusy(true);
    setError(null);
    try {
      const { data } = await api.post<{ shift: ShiftDto; summary: ShiftSummaryDto }>(
        `/api/shifts/${current.id}/close`,
        {
          countedCash: Number(countedCash) || 0,
          differenceReason: differenceReason.trim() || null,
          managerPin: managerPin.trim() || null,
        },
      );
      setShowClose(false);
      setCloseReport(data.summary);
      setCountedCash('');
      setDifferenceReason('');
      setManagerPin('');
      setNotice(
        data.shift.status === 'PENDING_APPROVAL'
          ? 'أُغلقت الوردية وتنتظر اعتماد المدير بسبب وجود فرق'
          : 'تم إغلاق الوردية',
      );
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'تعذر إغلاق الوردية');
    } finally {
      setBusy(false);
    }
  }

  async function approve(shiftId: string) {
    setBusy(true);
    try {
      await api.post(`/api/shifts/${shiftId}/approve`, {});
      setNotice('تم اعتماد فرق الصندوق');
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'تعذر الاعتماد');
    } finally {
      setBusy(false);
    }
  }

  if (loading) return <LoadingBlock label="جارٍ تحميل الورديات…" />;

  const summary = current?.summary;
  const expected = summary?.expectedCash ?? 0;
  const counted = Number(countedCash) || 0;
  const liveDifference = Math.round((counted - expected) * 100) / 100;

  return (
    <div className="space-y-6">
      <ErrorAlert message={error} />
      <SuccessAlert message={notice} />

      {/* الوردية الحالية */}
      <section className="card p-5">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-base font-bold">الوردية الحالية</h2>
          {current ? (
            can('shifts.close') && (
              <button
                type="button"
                className="btn-danger"
                onClick={() => {
                  setCountedCash(String(summary?.expectedCash ?? 0));
                  setShowClose(true);
                }}
              >
                إغلاق الوردية
              </button>
            )
          ) : (
            can('shifts.open') && (
              <button type="button" className="btn-primary" onClick={() => setShowOpen(true)}>
                فتح وردية جديدة
              </button>
            )
          )}
        </div>

        {!current ? (
          <p className="py-8 text-center text-sm text-neutral-500">
            لا توجد وردية مفتوحة حاليًا.
          </p>
        ) : (
          <>
            <div className="mb-4 grid gap-3 text-sm sm:grid-cols-4">
              <Info label="رقم الوردية" value={current.shiftNumber} />
              <Info label="الكاشير" value={current.user?.fullName ?? '—'} />
              <Info label="وقت الفتح" value={dateTime(current.openedAt)} />
              <Info label="الجهاز" value={current.device?.name ?? 'غير محدد'} />
            </div>

            {summary && (
              <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
                <StatCard label="الرصيد الافتتاحي" value={money(summary.openingFloat)} icon="🏦" />
                <StatCard label="مبيعات نقدية" value={money(summary.cashSales)} tone="success" icon="💵" />
                <StatCard label="مبيعات شبكة" value={money(summary.cardSales)} icon="💳" />
                <StatCard label="عدد الفواتير" value={number(summary.invoiceCount)} icon="🧾" />
                <StatCard label="المصروفات" value={money(summary.expenses)} tone="warning" icon="📤" />
                <StatCard label="المسحوبات" value={money(summary.withdrawals)} icon="💸" />
                <StatCard label="الإيداعات للصندوق الرئيسي" value={money(summary.deposits)} icon="🏛️" />
                <StatCard
                  label="النقد المتوقع"
                  value={money(summary.expectedCash)}
                  tone="brand"
                  icon="🧮"
                />
                <StatCard label="المرتجعات" value={money(summary.refunds)} icon="↩️" />
                <StatCard label="ضريبة القيمة المضافة" value={money(summary.vatTotal)} icon="🧾" />
                <StatCard label="ضريبة التبغ" value={money(summary.tobaccoTaxTotal)} icon="💨" />
                <StatCard label="مرات فتح الدرج" value={number(summary.drawerOpenCount)} icon="🗄️" />
              </div>
            )}
          </>
        )}
      </section>

      {/* سجل الورديات */}
      <section className="card overflow-hidden">
        <h2 className="border-b border-surface-border px-5 py-3 text-sm font-bold">
          سجل الورديات
        </h2>
        <div className="overflow-x-auto">
          <table className="table-base">
            <thead>
              <tr>
                <th>رقم الوردية</th>
                <th>الكاشير</th>
                <th>الفتح</th>
                <th>الإغلاق</th>
                <th>الافتتاحي</th>
                <th>المتوقع</th>
                <th>الفعلي</th>
                <th>الفرق</th>
                <th>الحالة</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {history.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-8 text-center text-neutral-500">
                    لا توجد ورديات
                  </td>
                </tr>
              ) : (
                history.map((shift) => {
                  const diff = shift.cashDifference != null ? Number(shift.cashDifference) : null;
                  return (
                    <tr key={shift.id}>
                      <td className="tabular font-semibold">{shift.shiftNumber}</td>
                      <td>{shift.user?.fullName}</td>
                      <td className="tabular text-xs">{dateTime(shift.openedAt)}</td>
                      <td className="tabular text-xs">{dateTime(shift.closedAt)}</td>
                      <td className="tabular">{money(shift.openingFloat, false)}</td>
                      <td className="tabular">
                        {shift.expectedCash != null ? money(shift.expectedCash, false) : '—'}
                      </td>
                      <td className="tabular">
                        {shift.countedCash != null ? money(shift.countedCash, false) : '—'}
                      </td>
                      <td
                        className={`tabular font-bold ${
                          diff == null ? '' : diff < 0 ? 'text-red-600' : diff > 0 ? 'text-amber-600' : 'text-emerald-600'
                        }`}
                      >
                        {diff != null ? money(diff, false) : '—'}
                      </td>
                      <td>
                        <span className={`badge ${STATUS_STYLES[shift.status]}`}>
                          {STATUS_LABELS[shift.status]}
                        </span>
                      </td>
                      <td>
                        {shift.status === 'PENDING_APPROVAL' &&
                          can('shifts.approve_difference') && (
                            <button
                              type="button"
                              className="btn-ghost !px-2 !py-1 text-xs"
                              disabled={busy}
                              onClick={() => void approve(shift.id)}
                            >
                              اعتماد
                            </button>
                          )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* نافذة فتح وردية */}
      <Modal
        open={showOpen}
        onClose={() => setShowOpen(false)}
        title="فتح وردية جديدة"
        size="sm"
        footer={
          <>
            <button type="button" className="btn-ghost" onClick={() => setShowOpen(false)}>
              إلغاء
            </button>
            <button
              type="button"
              className="btn-primary"
              disabled={busy}
              onClick={() => void openShift()}
            >
              {busy && <Spinner className="h-4 w-4" />}
              فتح الوردية
            </button>
          </>
        }
      >
        <div className="space-y-3">
          <div>
            <label className="label" htmlFor="opening-float">
              الرصيد الافتتاحي (ر.س)
            </label>
            <input
              id="opening-float"
              type="number"
              min="0"
              step="0.01"
              className="input tabular text-lg"
              value={openingFloat}
              onChange={(event) => setOpeningFloat(event.target.value)}
            />
          </div>
          <div>
            <label className="label" htmlFor="open-note">
              ملاحظة (اختياري)
            </label>
            <textarea
              id="open-note"
              className="input min-h-[68px]"
              value={openNote}
              onChange={(event) => setOpenNote(event.target.value)}
            />
          </div>
        </div>
      </Modal>

      {/* نافذة إغلاق وردية */}
      <Modal
        open={showClose}
        onClose={() => setShowClose(false)}
        title="إغلاق الوردية وجرد الصندوق"
        footer={
          <>
            <button type="button" className="btn-ghost" onClick={() => setShowClose(false)}>
              إلغاء
            </button>
            <button
              type="button"
              className="btn-danger"
              disabled={busy || countedCash === ''}
              onClick={() => void closeShift()}
            >
              {busy && <Spinner className="h-4 w-4" />}
              تأكيد الإغلاق
            </button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="rounded-xl bg-surface-muted p-4 text-sm">
            <div className="flex justify-between py-1">
              <span className="text-neutral-600">النقد المتوقع في الصندوق</span>
              <span className="tabular text-lg font-bold">{money(expected)}</span>
            </div>
            <p className="text-xs text-neutral-500">
              الرصيد الافتتاحي + المبيعات النقدية − المصروفات − المسحوبات − الإيداعات −
              المرتجعات النقدية
            </p>
          </div>

          <div>
            <label className="label" htmlFor="counted">
              النقد الفعلي المعدود <span className="text-red-600">*</span>
            </label>
            <input
              id="counted"
              type="number"
              min="0"
              step="0.01"
              className="input tabular text-lg"
              value={countedCash}
              onChange={(event) => setCountedCash(event.target.value)}
              autoFocus
            />
          </div>

          <div
            className={`rounded-xl px-4 py-3 text-sm ${
              liveDifference === 0
                ? 'bg-emerald-50 text-emerald-800'
                : liveDifference < 0
                  ? 'bg-red-50 text-red-800'
                  : 'bg-amber-50 text-amber-900'
            }`}
          >
            <div className="flex justify-between">
              <span>الفرق</span>
              <span className="tabular font-bold">{money(liveDifference)}</span>
            </div>
            {liveDifference !== 0 && (
              <p className="mt-1 text-xs">
                {liveDifference < 0 ? 'عجز في الصندوق' : 'زيادة في الصندوق'} — يجب إدخال
                السبب واعتماد المدير.
              </p>
            )}
          </div>

          {liveDifference !== 0 && (
            <>
              <div>
                <label className="label" htmlFor="diff-reason">
                  سبب الفرق <span className="text-red-600">*</span>
                </label>
                <textarea
                  id="diff-reason"
                  className="input min-h-[68px]"
                  value={differenceReason}
                  onChange={(event) => setDifferenceReason(event.target.value)}
                />
              </div>
              <div>
                <label className="label" htmlFor="close-pin">
                  رمز المدير للاعتماد الفوري (اختياري)
                </label>
                <input
                  id="close-pin"
                  type="password"
                  className="input tabular text-center tracking-[0.4em]"
                  value={managerPin}
                  onChange={(event) => setManagerPin(event.target.value)}
                  maxLength={8}
                />
                <p className="mt-1 text-xs text-neutral-500">
                  بدون الرمز ستُغلق الوردية بحالة «بانتظار اعتماد المدير».
                </p>
              </div>
            </>
          )}
        </div>
      </Modal>

      {/* تقرير الإغلاق القابل للطباعة */}
      {closeReport && (
        <Modal
          open
          onClose={() => setCloseReport(null)}
          title="تقرير إغلاق الوردية"
          size="sm"
          footer={
            <>
              <button
                type="button"
                className="btn-ghost no-print"
                onClick={() => setCloseReport(null)}
              >
                إغلاق
              </button>
              <button type="button" className="btn-primary no-print" onClick={() => window.print()}>
                🖨️ طباعة
              </button>
            </>
          }
        >
          <div className="print-receipt mx-auto max-w-[300px] text-xs">
            <p className="text-center text-base font-bold">تقرير إغلاق الوردية</p>
            <p className="mb-2 text-center">{closeReport.shiftNumber}</p>
            <div className="space-y-1 border-y border-dashed border-neutral-400 py-2">
              <ReportRow label="الكاشير" value={closeReport.cashierName} />
              <ReportRow label="الفتح" value={dateTime(closeReport.openedAt)} />
              <ReportRow label="الإغلاق" value={dateTime(new Date())} />
            </div>
            <div className="space-y-1 py-2">
              <ReportRow label="الرصيد الافتتاحي" value={money(closeReport.openingFloat, false)} />
              <ReportRow label="مبيعات نقدية" value={money(closeReport.cashSales, false)} />
              <ReportRow label="مبيعات شبكة" value={money(closeReport.cardSales, false)} />
              <ReportRow label="مصروفات" value={money(closeReport.expenses, false)} />
              <ReportRow label="مسحوبات" value={money(closeReport.withdrawals, false)} />
              <ReportRow label="إيداعات" value={money(closeReport.deposits, false)} />
              <ReportRow label="مرتجعات" value={money(closeReport.refunds, false)} />
              <ReportRow label="عدد الفواتير" value={number(closeReport.invoiceCount)} />
            </div>
            <div className="space-y-1 border-t border-dashed border-neutral-400 pt-2 font-semibold">
              <ReportRow label="النقد المتوقع" value={money(closeReport.expectedCash, false)} />
              <ReportRow label="النقد الفعلي" value={money(closeReport.countedCash ?? 0, false)} />
              <ReportRow label="الفرق" value={money(closeReport.cashDifference ?? 0, false)} />
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-surface-muted px-3 py-2">
      <p className="text-xs text-neutral-500">{label}</p>
      <p className="mt-0.5 font-semibold">{value}</p>
    </div>
  );
}

function ReportRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-2">
      <span className="text-neutral-600">{label}</span>
      <span className="tabular">{value}</span>
    </div>
  );
}
