'use client';

import { useCallback, useEffect, useState } from 'react';
import { api, ApiClientError, qs } from '@/lib/client/api';
import { money, STATION_LABELS, SYNC_STATUS_LABELS, SYNC_STATUS_STYLES } from '@/lib/client/format';
import { ErrorAlert, LoadingBlock, Modal, Spinner, SuccessAlert } from '@/components/ui';
import { useSession } from '@/components/session-provider';
import { ImageUpload } from '@/components/image-upload';
import type { CategoryDto, ProductDto } from '@/types/pos';

interface TaxDto {
  id: string;
  code: string;
  nameAr: string;
  type: 'VAT' | 'TOBACCO';
  rate: string | number;
  tobaccoBase: string | null;
  fixedAmount: string | number | null;
  minAmountPerUnit: string | number | null;
  isActive: boolean;
}

export default function ProductsPage() {
  const { can } = useSession();
  const [tab, setTab] = useState<'products' | 'categories' | 'taxes'>('products');
  const [products, setProducts] = useState<ProductDto[]>([]);
  const [categories, setCategories] = useState<CategoryDto[]>([]);
  const [taxes, setTaxes] = useState<TaxDto[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [editing, setEditing] = useState<ProductDto | null>(null);
  const [creating, setCreating] = useState(false);
  const [editingTax, setEditingTax] = useState<TaxDto | null>(null);

  const load = useCallback(async () => {
    try {
      const [productsRes, categoriesRes] = await Promise.all([
        api.get<ProductDto[]>(`/api/products${qs({ search, includeInactive: 'true', pageSize: 200 })}`),
        api.get<CategoryDto[]>('/api/categories'),
      ]);
      setProducts(productsRes.data);
      setCategories(categoriesRes.data);
      if (can('taxes.view')) {
        const taxesRes = await api.get<TaxDto[]>('/api/taxes');
        setTaxes(taxesRes.data);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر تحميل المنتجات');
    } finally {
      setLoading(false);
    }
  }, [search, can]);

  useEffect(() => {
    void load();
  }, [load]);

  if (loading) return <LoadingBlock label="جارٍ تحميل المنتجات…" />;

  return (
    <div className="space-y-5">
      <ErrorAlert message={error} />
      <SuccessAlert message={notice} />

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex gap-2">
          {[
            { key: 'products', label: 'المنتجات' },
            { key: 'categories', label: 'التصنيفات' },
            { key: 'taxes', label: 'الضرائب' },
          ].map((item) => (
            <button
              key={item.key}
              type="button"
              onClick={() => setTab(item.key as typeof tab)}
              className={`rounded-xl border px-4 py-2 text-sm font-semibold ${
                tab === item.key
                  ? 'border-brand bg-brand text-white'
                  : 'border-surface-border bg-white'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
        {tab === 'products' && can('products.manage') && (
          <button type="button" className="btn-primary" onClick={() => setCreating(true)}>
            ＋ منتج جديد
          </button>
        )}
      </div>

      {tab === 'products' && (
        <>
          <input
            className="input max-w-sm"
            placeholder="بحث بالاسم أو الكود…"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
          />
          <div className="card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="table-base">
                <thead>
                  <tr>
                    <th>المنتج</th>
                    <th>الكود</th>
                    <th>التصنيف</th>
                    <th>السعر</th>
                    <th>شامل الضريبة</th>
                    <th>تبغ</th>
                    <th>المحطة</th>
                    <th>الحالة</th>
                    <th>Odoo</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {products.map((product) => (
                    <tr key={product.id}>
                      <td className="font-medium">{product.nameAr}</td>
                      <td className="tabular text-xs">{product.sku}</td>
                      <td className="text-xs">{product.category?.nameAr}</td>
                      <td className="tabular font-bold">{money(product.price, false)}</td>
                      <td className="text-xs">{product.priceIncludesVat ? 'نعم' : 'لا'}</td>
                      <td className="text-xs">{product.isTobacco ? '💨 نعم' : '—'}</td>
                      <td className="text-xs">{STATION_LABELS[product.prepStation]}</td>
                      <td>
                        <span
                          className={`badge ${
                            product.isActive
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-neutral-200 text-neutral-600'
                          }`}
                        >
                          {product.isActive ? 'نشط' : 'غير نشط'}
                        </span>
                      </td>
                      <td>
                        <span className={`badge ${SYNC_STATUS_STYLES[product.syncStatus] ?? ''}`}>
                          {product.odooProductId ?? SYNC_STATUS_LABELS[product.syncStatus]}
                        </span>
                      </td>
                      <td>
                        {can('products.manage') && (
                          <button
                            type="button"
                            className="btn-ghost !px-2 !py-1 text-xs"
                            onClick={() => setEditing(product)}
                          >
                            تعديل
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {tab === 'categories' && (
        <div className="card overflow-hidden">
          <table className="table-base">
            <thead>
              <tr>
                <th>التصنيف</th>
                <th>عدد المنتجات</th>
                <th>اللون</th>
                <th>الترتيب</th>
              </tr>
            </thead>
            <tbody>
              {categories.map((category) => (
                <tr key={category.id}>
                  <td className="font-medium">
                    {category.iconEmoji} {category.nameAr}
                  </td>
                  <td className="tabular">{category._count?.products ?? 0}</td>
                  <td>
                    <span
                      className="inline-block h-5 w-10 rounded"
                      style={{ backgroundColor: category.color }}
                    />
                  </td>
                  <td className="tabular">{category.sortOrder}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'taxes' && (
        <div className="card overflow-hidden">
          <table className="table-base">
            <thead>
              <tr>
                <th>الضريبة</th>
                <th>النوع</th>
                <th>النسبة</th>
                <th>قاعدة الاحتساب</th>
                <th>مبلغ ثابت / وحدة</th>
                <th>الحد الأدنى</th>
                <th>الحالة</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {taxes.map((tax) => (
                <tr key={tax.id}>
                  <td className="font-medium">{tax.nameAr}</td>
                  <td className="text-xs">
                    {tax.type === 'VAT' ? 'القيمة المضافة' : 'ضريبة التبغ'}
                  </td>
                  <td className="tabular font-bold">{Number(tax.rate)}%</td>
                  <td className="text-xs">
                    {tax.tobaccoBase === 'FIXED_PER_UNIT'
                      ? 'مبلغ ثابت لكل وحدة'
                      : tax.tobaccoBase === 'PERCENT_OF_PRICE'
                        ? 'نسبة من السعر'
                        : '—'}
                  </td>
                  <td className="tabular text-xs">
                    {tax.fixedAmount != null ? money(tax.fixedAmount, false) : '—'}
                  </td>
                  <td className="tabular text-xs">
                    {tax.minAmountPerUnit != null ? money(tax.minAmountPerUnit, false) : '—'}
                  </td>
                  <td>
                    <span
                      className={`badge ${
                        tax.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-neutral-200'
                      }`}
                    >
                      {tax.isActive ? 'مفعّلة' : 'معطّلة'}
                    </span>
                  </td>
                  <td>
                    {can('taxes.manage') && (
                      <button
                        type="button"
                        className="btn-ghost !px-2 !py-1 text-xs"
                        onClick={() => setEditingTax(tax)}
                      >
                        تعديل
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="border-t border-surface-border bg-blue-50 px-4 py-2.5 text-xs text-blue-800">
            ℹ️ تعديل النسب لا يؤثر على الفواتير السابقة — كل فاتورة تحفظ نسخة ثابتة من
            ضرائبها وقت البيع.
          </p>
        </div>
      )}

      {(editing || creating) && (
        <ProductFormModal
          product={editing}
          categories={categories}
          taxes={taxes}
          onClose={() => {
            setEditing(null);
            setCreating(false);
          }}
          onSaved={async (message) => {
            setEditing(null);
            setCreating(false);
            setNotice(message);
            await load();
          }}
        />
      )}

      {editingTax && (
        <TaxFormModal
          tax={editingTax}
          onClose={() => setEditingTax(null)}
          onSaved={async () => {
            setEditingTax(null);
            setNotice('تم تحديث الضريبة');
            await load();
          }}
        />
      )}
    </div>
  );
}

function ProductFormModal({
  product,
  categories,
  taxes,
  onClose,
  onSaved,
}: {
  product: ProductDto | null;
  categories: CategoryDto[];
  taxes: TaxDto[];
  onClose: () => void;
  onSaved: (message: string) => void | Promise<void>;
}) {
  const { can } = useSession();
  const vatTaxes = taxes.filter((t) => t.type === 'VAT');
  const tobaccoTaxes = taxes.filter((t) => t.type === 'TOBACCO');

  const [form, setForm] = useState({
    nameAr: product?.nameAr ?? '',
    nameEn: product?.nameEn ?? '',
    sku: product?.sku ?? '',
    barcode: product?.barcode ?? '',
    categoryId: product?.categoryId ?? categories[0]?.id ?? '',
    price: Number(product?.price ?? 0),
    priceIncludesVat: product?.priceIncludesVat ?? true,
    vatTaxId: product?.vatTax?.id ?? vatTaxes[0]?.id ?? '',
    isTobacco: product?.isTobacco ?? false,
    tobaccoTaxId: product?.tobaccoTax?.id ?? tobaccoTaxes[0]?.id ?? '',
    unit: product?.unit ?? 'PCS',
    prepStation: product?.prepStation ?? 'KITCHEN',
    isActive: product?.isActive ?? true,
    showInPos: product?.showInPos ?? true,
    sortOrder: product?.sortOrder ?? 0,
    imageUrl: product?.imageUrl ?? '',
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function update<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  async function save() {
    setBusy(true);
    setError(null);
    try {
      const payload = {
        ...form,
        nameEn: form.nameEn || null,
        barcode: form.barcode || null,
        imageUrl: form.imageUrl || null,
        vatTaxId: form.vatTaxId || null,
        tobaccoTaxId: form.isTobacco ? form.tobaccoTaxId || null : null,
      };
      if (product) {
        const { sku, ...rest } = payload;
        await api.patch(`/api/products/${product.id}`, rest);
        await onSaved('تم تحديث المنتج');
      } else {
        await api.post('/api/products', payload);
        await onSaved('تم إنشاء المنتج');
      }
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'تعذر حفظ المنتج');
    } finally {
      setBusy(false);
    }
  }

  const priceLocked = product != null && !can('products.change_price');

  return (
    <Modal
      open
      onClose={onClose}
      title={product ? `تعديل ${product.nameAr}` : 'منتج جديد'}
      size="lg"
      footer={
        <>
          <button type="button" className="btn-ghost" onClick={onClose} disabled={busy}>
            إلغاء
          </button>
          <button type="button" className="btn-primary" disabled={busy} onClick={() => void save()}>
            {busy && <Spinner className="h-4 w-4" />}
            حفظ
          </button>
        </>
      }
    >
      <div className="space-y-4">
        <ErrorAlert message={error} />
        <div className="grid gap-3 sm:grid-cols-2">
          <Text label="الاسم بالعربية *" value={form.nameAr} onChange={(v) => update('nameAr', v)} />
          <Text label="الاسم بالإنجليزية" value={form.nameEn ?? ''} onChange={(v) => update('nameEn', v)} />
          <Text
            label="كود المنتج الداخلي *"
            value={form.sku}
            onChange={(v) => update('sku', v)}
            disabled={product != null}
          />
          <Text label="الباركود" value={form.barcode ?? ''} onChange={(v) => update('barcode', v)} />
          <div>
            <label className="label">التصنيف</label>
            <select
              className="input"
              value={form.categoryId}
              onChange={(event) => update('categoryId', event.target.value)}
            >
              {categories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.nameAr}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">
              سعر البيع {priceLocked && <span className="text-xs text-red-600">(تحتاج صلاحية تعديل الأسعار)</span>}
            </label>
            <input
              type="number"
              min="0"
              step="0.01"
              className="input tabular"
              value={form.price}
              disabled={priceLocked}
              onChange={(event) => update('price', Number(event.target.value))}
            />
          </div>
          <div>
            <label className="label">هل السعر شامل ضريبة القيمة المضافة؟</label>
            <select
              className="input"
              value={form.priceIncludesVat ? 'yes' : 'no'}
              onChange={(event) => update('priceIncludesVat', event.target.value === 'yes')}
            >
              <option value="yes">شامل الضريبة</option>
              <option value="no">غير شامل الضريبة</option>
            </select>
          </div>
          <div>
            <label className="label">ضريبة القيمة المضافة</label>
            <select
              className="input"
              value={form.vatTaxId}
              onChange={(event) => update('vatTaxId', event.target.value)}
            >
              <option value="">بدون ضريبة</option>
              {vatTaxes.map((tax) => (
                <option key={tax.id} value={tax.id}>
                  {tax.nameAr} ({Number(tax.rate)}%)
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">محطة التحضير</label>
            <select
              className="input"
              value={form.prepStation}
              onChange={(event) => update('prepStation', event.target.value as typeof form.prepStation)}
            >
              <option value="KITCHEN">المطبخ</option>
              <option value="BAR">البار</option>
              <option value="SHISHA">الشيشة</option>
              <option value="NONE">بدون تحضير</option>
            </select>
          </div>
          <Text label="الوحدة" value={form.unit} onChange={(v) => update('unit', v)} />
          <div>
            <label className="label">الترتيب في شاشة البيع</label>
            <input
              type="number"
              className="input tabular"
              value={form.sortOrder}
              onChange={(event) => update('sortOrder', Number(event.target.value))}
            />
          </div>
        </div>

        <ImageUpload
          label="صورة المنتج"
          value={form.imageUrl ?? ''}
          onChange={(url) => update('imageUrl', url)}
        />

        <div className="space-y-2 rounded-xl border border-surface-border p-3">
          <Check
            label="منتج تبغ (تُطبق عليه ضريبة التبغ الانتقائية)"
            checked={form.isTobacco}
            onChange={(v) => update('isTobacco', v)}
          />
          {form.isTobacco && (
            <div className="pr-8">
              <label className="label">ضريبة التبغ المطبقة</label>
              <select
                className="input"
                value={form.tobaccoTaxId}
                onChange={(event) => update('tobaccoTaxId', event.target.value)}
              >
                {tobaccoTaxes.map((tax) => (
                  <option key={tax.id} value={tax.id}>
                    {tax.nameAr} ({Number(tax.rate)}%)
                  </option>
                ))}
              </select>
            </div>
          )}
          <Check label="المنتج نشط" checked={form.isActive} onChange={(v) => update('isActive', v)} />
          <Check
            label="يظهر في شاشة نقاط البيع"
            checked={form.showInPos}
            onChange={(v) => update('showInPos', v)}
          />
        </div>
      </div>
    </Modal>
  );
}

function TaxFormModal({
  tax,
  onClose,
  onSaved,
}: {
  tax: TaxDto;
  onClose: () => void;
  onSaved: () => void | Promise<void>;
}) {
  const [rate, setRate] = useState(Number(tax.rate));
  const [tobaccoBase, setTobaccoBase] = useState(tax.tobaccoBase ?? 'PERCENT_OF_PRICE');
  const [fixedAmount, setFixedAmount] = useState(Number(tax.fixedAmount ?? 0));
  const [minAmount, setMinAmount] = useState(Number(tax.minAmountPerUnit ?? 0));
  const [isActive, setIsActive] = useState(tax.isActive);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function save() {
    setBusy(true);
    setError(null);
    try {
      await api.patch(`/api/taxes/${tax.id}`, {
        rate,
        isActive,
        ...(tax.type === 'TOBACCO'
          ? {
              tobaccoBase,
              fixedAmount: tobaccoBase === 'FIXED_PER_UNIT' ? fixedAmount : null,
              minAmountPerUnit: minAmount > 0 ? minAmount : null,
            }
          : {}),
      });
      await onSaved();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'تعذر حفظ الضريبة');
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal
      open
      onClose={onClose}
      title={`تعديل ${tax.nameAr}`}
      size="sm"
      footer={
        <>
          <button type="button" className="btn-ghost" onClick={onClose} disabled={busy}>
            إلغاء
          </button>
          <button type="button" className="btn-primary" disabled={busy} onClick={() => void save()}>
            {busy && <Spinner className="h-4 w-4" />}
            حفظ
          </button>
        </>
      }
    >
      <div className="space-y-3">
        <ErrorAlert message={error} />
        <div>
          <label className="label">النسبة (%)</label>
          <input
            type="number"
            min="0"
            step="0.01"
            className="input tabular text-lg"
            value={rate}
            onChange={(event) => setRate(Number(event.target.value))}
          />
        </div>

        {tax.type === 'TOBACCO' && (
          <>
            <div>
              <label className="label">قاعدة الاحتساب</label>
              <select
                className="input"
                value={tobaccoBase}
                onChange={(event) => setTobaccoBase(event.target.value)}
              >
                <option value="PERCENT_OF_PRICE">نسبة من السعر الصافي</option>
                <option value="FIXED_PER_UNIT">مبلغ ثابت لكل وحدة</option>
              </select>
            </div>
            {tobaccoBase === 'FIXED_PER_UNIT' && (
              <div>
                <label className="label">المبلغ الثابت لكل وحدة (ر.س)</label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  className="input tabular"
                  value={fixedAmount}
                  onChange={(event) => setFixedAmount(Number(event.target.value))}
                />
              </div>
            )}
            <div>
              <label className="label">الحد الأدنى للضريبة لكل وحدة (0 = بدون حد)</label>
              <input
                type="number"
                min="0"
                step="0.01"
                className="input tabular"
                value={minAmount}
                onChange={(event) => setMinAmount(Number(event.target.value))}
              />
            </div>
          </>
        )}

        <Check label="الضريبة مفعّلة" checked={isActive} onChange={setIsActive} />

        <p className="rounded-lg bg-amber-50 px-3 py-2 text-xs text-amber-900">
          ⚠️ التعديل يسري على المبيعات الجديدة فقط. الفواتير السابقة تحتفظ بنسختها الضريبية.
        </p>
      </div>
    </Modal>
  );
}

function Text({
  label,
  value,
  onChange,
  disabled,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  disabled?: boolean;
}) {
  return (
    <div>
      <label className="label">{label}</label>
      <input
        className="input"
        value={value}
        disabled={disabled}
        onChange={(event) => onChange(event.target.value)}
      />
    </div>
  );
}

function Check({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (value: boolean) => void;
}) {
  return (
    <label className="flex cursor-pointer items-center gap-3 py-1">
      <input
        type="checkbox"
        className="h-5 w-5 accent-brand"
        checked={checked}
        onChange={(event) => onChange(event.target.checked)}
      />
      <span className="text-sm">{label}</span>
    </label>
  );
}
