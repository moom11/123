import { redirect } from 'next/navigation';
import { cookies } from 'next/headers';
import { ACCESS_COOKIE } from '@/lib/auth/tokens';

/** الصفحة الجذر — تحوّل إلى لوحة التحكم أو صفحة الدخول */
export default async function HomePage() {
  const cookieStore = await cookies();
  redirect(cookieStore.get(ACCESS_COOKIE) ? '/dashboard' : '/login');
}
