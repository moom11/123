import type { Metadata, Viewport } from 'next';
import './globals.css';
import { ServiceWorkerRegister } from '@/components/service-worker-register';

export const metadata: Metadata = {
  title: 'مارا — نظام نقاط البيع والمحاسبة',
  description: 'نظام نقاط بيع ومحاسبة للمطاعم والمقاهي مع ربط Odoo',
  manifest: '/manifest.webmanifest',
  appleWebApp: { capable: true, title: 'مارا POS', statusBarStyle: 'black-translucent' },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: '#C8102E',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body>
        {children}
        <ServiceWorkerRegister />
      </body>
    </html>
  );
}
