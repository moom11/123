import { NextResponse, type NextRequest } from 'next/server';
import { ok, route } from '@/lib/api/handler';
import { runSyncCycle } from '@/lib/odoo/integration-service';
import { Unauthorized } from '@/lib/api/errors';

export const dynamic = 'force-dynamic';
export const maxDuration = 60;

/**
 * POST /api/cron/sync — تشغيل دورة معالجة طابور المزامنة.
 * يُستدعى من مجدول خارجي (cron) أو من العامل الداخلي.
 * محمي برمز سري في ترويسة x-cron-secret.
 */
export const POST = route(async (request: NextRequest) => {
  const secret = process.env.CRON_SECRET;
  const provided =
    request.headers.get('x-cron-secret') ??
    request.headers.get('authorization')?.replace(/^Bearer\s+/i, '');

  if (!secret || provided !== secret) {
    throw Unauthorized('رمز المجدول غير صحيح');
  }

  const batchSize = Number(process.env.SYNC_WORKER_BATCH_SIZE ?? 20);
  const result = await runSyncCycle(`cron-${process.pid}`, batchSize);
  return ok(result);
});

/** GET — فحص جاهزية المسار */
export function GET() {
  return NextResponse.json({
    success: true,
    data: { message: 'مسار المزامنة جاهز — استخدم POST مع الرمز السري' },
  });
}
