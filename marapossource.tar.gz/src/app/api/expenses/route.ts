import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { ApprovalStatus, CashMovementType } from '@prisma/client';
import { ok, parseQuery, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';

const querySchema = z.object({
  status: z.nativeEnum(ApprovalStatus).optional(),
  type: z.nativeEnum(CashMovementType).optional(),
  shiftId: z.string().uuid().optional(),
  from: z.string().optional(),
  to: z.string().optional(),
});

/** GET /api/expenses — المصروفات والمسحوبات والعُهد */
export const GET = route(async (request: NextRequest) => {
  const session = await requirePermission('cash.manage', request);
  const branchId = requireBranch(session);
  const query = parseQuery(request, querySchema);

  const expenses = await prisma.expense.findMany({
    where: {
      branchId,
      ...(query.status ? { status: query.status } : {}),
      ...(query.type ? { type: query.type } : {}),
      ...(query.shiftId ? { shiftId: query.shiftId } : {}),
      ...(query.from || query.to
        ? {
            businessDay: {
              ...(query.from ? { gte: new Date(`${query.from}T00:00:00Z`) } : {}),
              ...(query.to ? { lte: new Date(`${query.to}T00:00:00Z`) } : {}),
            },
          }
        : {}),
    },
    include: {
      user: { select: { fullName: true } },
      category: true,
      shift: { select: { shiftNumber: true } },
    },
    orderBy: { createdAt: 'desc' },
    take: 200,
  });

  return ok(expenses);
});
