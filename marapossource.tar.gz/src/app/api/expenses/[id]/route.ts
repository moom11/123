import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { ApprovalStatus } from '@prisma/client';
import { ok, parseBody, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';
import { NotFound } from '@/lib/api/errors';
import { writeAudit } from '@/lib/audit';

type Ctx = { params: Promise<{ id: string }> };

const schema = z.object({
  status: z.nativeEnum(ApprovalStatus),
  note: z.string().optional(),
});

/** PATCH /api/expenses/:id — اعتماد أو رفض المصروف */
export const PATCH = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requirePermission('cash.approve', request);
  const branchId = requireBranch(session);
  const { id } = await params;
  const body = await parseBody(request, schema);

  const existing = await prisma.expense.findFirst({ where: { id, branchId } });
  if (!existing) throw NotFound('المصروف غير موجود');

  const expense = await prisma.expense.update({
    where: { id },
    data: {
      status: body.status,
      approvedById: session.sub,
      approvedAt: new Date(),
    },
  });

  await writeAudit({
    action: 'EXPENSE_CREATED',
    entity: 'Expense',
    entityId: id,
    userId: session.sub,
    branchId,
    oldValue: { status: existing.status },
    newValue: { status: body.status, note: body.note },
    request,
  });

  return ok(expense);
});
