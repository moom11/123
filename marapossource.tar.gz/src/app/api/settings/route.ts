import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { Prisma } from '@prisma/client';
import { ok, parseBody, route } from '@/lib/api/handler';
import { requireBranch, requirePermission, requireSession } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';
import { getBranchSettings } from '@/lib/settings';
import { writeAudit } from '@/lib/audit';

/** GET /api/settings — إعدادات الفرع الحالية */
export const GET = route(async (request: NextRequest) => {
  const session = await requireSession(request);
  const branchId = requireBranch(session);

  const [settings, branch] = await Promise.all([
    getBranchSettings(branchId),
    prisma.branch.findUnique({ where: { id: branchId }, include: { company: true } }),
  ]);

  return ok({ settings, branch });
});

const schema = z.object({
  businessDayStartHour: z.number().int().min(0).max(23).optional(),
  timezone: z.string().optional(),
  paymentRoundingTolerance: z.number().min(0).max(5).optional(),
  cashDiffTolerance: z.number().min(0).optional(),
  enableDelivery: z.boolean().optional(),
  enableCreditPayment: z.boolean().optional(),
  maxDiscountPercent: z.number().min(0).max(100).optional(),
  requireManagerForDiscount: z.boolean().optional(),
  invoicePrefix: z.string().min(1).max(10).optional(),
  orderPrefix: z.string().min(1).max(10).optional(),
  primaryColor: z.string().optional(),
  secondaryColor: z.string().optional(),
  accentColor: z.string().optional(),
  showQrOnInvoice: z.boolean().optional(),
});

/** PUT /api/settings — تعديل إعدادات الفرع (اليوم التشغيلي، السماحيات، الألوان) */
export const PUT = route(async (request: NextRequest) => {
  const session = await requirePermission('settings.manage', request);
  const branchId = requireBranch(session);
  const body = await parseBody(request, schema);

  const existing = await getBranchSettings(branchId);
  const settings = await prisma.branchSetting.update({
    where: { branchId },
    data: {
      ...body,
      ...(body.paymentRoundingTolerance !== undefined
        ? {
            paymentRoundingTolerance: new Prisma.Decimal(
              body.paymentRoundingTolerance.toFixed(4),
            ),
          }
        : {}),
      ...(body.cashDiffTolerance !== undefined
        ? { cashDiffTolerance: new Prisma.Decimal(body.cashDiffTolerance.toFixed(4)) }
        : {}),
      ...(body.maxDiscountPercent !== undefined
        ? { maxDiscountPercent: new Prisma.Decimal(body.maxDiscountPercent.toFixed(2)) }
        : {}),
    },
  });

  await writeAudit({
    action: 'SETTINGS_UPDATED',
    entity: 'BranchSetting',
    entityId: settings.id,
    userId: session.sub,
    branchId,
    oldValue: existing,
    newValue: body,
    request,
  });

  return ok(settings);
});
