import { NextResponse } from 'next/server';

/**
 * GET /api/docs — واجهة Swagger UI.
 * الملفات الثابتة تُنسخ محليًا من swagger-ui-dist إلى /public/swagger
 * حتى يعمل التوثيق دون إنترنت.
 */
export function GET() {
  const html = `<!doctype html>
<html lang="ar" dir="rtl">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>توثيق واجهات Mara POS</title>
    <link rel="stylesheet" href="/swagger/swagger-ui.css" />
    <style>
      body { margin: 0; font-family: Tahoma, Arial, sans-serif; }
      .topbar { display: none; }
      .swagger-ui .info .title { font-size: 26px; }
    </style>
  </head>
  <body>
    <div id="swagger-ui"></div>
    <script src="/swagger/swagger-ui-bundle.js" crossorigin></script>
    <script>
      window.onload = function () {
        window.ui = SwaggerUIBundle({
          url: '/api/docs/openapi.json',
          dom_id: '#swagger-ui',
          deepLinking: true,
          persistAuthorization: true,
          docExpansion: 'none',
          filter: true,
        });
      };
    </script>
  </body>
</html>`;

  return new NextResponse(html, {
    headers: { 'Content-Type': 'text/html; charset=utf-8' },
  });
}
