import { NextResponse } from 'next/server';
import { buildOpenApiSpec } from '@/lib/api/openapi';

/** GET /api/docs/openapi.json — مواصفة OpenAPI */
export function GET() {
  return NextResponse.json(buildOpenApiSpec());
}
