import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { TableStatus } from '@prisma/client';
import { ok, parseBody, route } from '@/lib/api/handler';
import { requireBranch, requireSession } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';
import { NotFound } from '@/lib/api/errors';

type Ctx = { params: Promise<{ id: string }> };

const updateSchema = z.object({
  status: z.nativeEnum(TableStatus).optional(),
  seats: z.number().int().min(1).optional(),
  nameAr: z.string().optional().nullable(),
});

/** PATCH /api/tables/:id — تحديث حالة الطاولة (تنظيف، حجز، إتاحة) */
export const PATCH = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requireSession(request);
  const branchId = requireBranch(session);
  const { id } = await params;
  const body = await parseBody(request, updateSchema);

  const table = await prisma.restaurantTable.findFirst({ where: { id, branchId } });
  if (!table) throw NotFound('الطاولة غير موجودة');

  return ok(await prisma.restaurantTable.update({ where: { id }, data: body }));
});
