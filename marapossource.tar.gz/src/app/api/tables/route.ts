import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { TableStatus } from '@prisma/client';
import { ok, parseQuery, route } from '@/lib/api/handler';
import { requireBranch, requireSession } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';

const querySchema = z.object({
  floorId: z.string().uuid().optional(),
  status: z.nativeEnum(TableStatus).optional(),
});

/** GET /api/tables — الطاولات مع الطلبات النشطة على كل طاولة */
export const GET = route(async (request: NextRequest) => {
  const session = await requireSession(request);
  const branchId = requireBranch(session);
  const query = parseQuery(request, querySchema);

  const tables = await prisma.restaurantTable.findMany({
    where: {
      branchId,
      isActive: true,
      ...(query.floorId ? { floorId: query.floorId } : {}),
      ...(query.status ? { status: query.status } : {}),
    },
    orderBy: { number: 'asc' },
    include: {
      floor: { select: { id: true, nameAr: true } },
      area: { select: { id: true, nameAr: true } },
      orders: {
        where: { status: { in: ['DRAFT', 'HELD', 'SENT_TO_PREP'] } },
        select: {
          id: true,
          orderNumber: true,
          status: true,
          grandTotal: true,
          guestCount: true,
          createdAt: true,
          user: { select: { fullName: true } },
        },
      },
    },
  });

  return ok(tables);
});
