import type { NextRequest } from 'next/server';
import { ok, route } from '@/lib/api/handler';
import { requireBranch, requireSession } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';
import { getBranchSettings } from '@/lib/settings';

/** GET /api/payment-methods — طرق الدفع المتاحة (يُخفى الآجل عند تعطيله) */
export const GET = route(async (request: NextRequest) => {
  const session = await requireSession(request);
  const branchId = requireBranch(session);
  const settings = await getBranchSettings(branchId);

  const methods = await prisma.paymentMethod.findMany({
    where: {
      isActive: true,
      ...(settings.enableCreditPayment ? {} : { type: { not: 'CREDIT' } }),
    },
    orderBy: { sortOrder: 'asc' },
  });
  return ok(methods);
});
