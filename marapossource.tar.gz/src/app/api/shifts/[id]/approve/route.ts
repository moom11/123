import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { ok, parseBody, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { approveShiftDifference } from '@/lib/pos/shift-service';
import { writeAudit } from '@/lib/audit';

type Ctx = { params: Promise<{ id: string }> };

const schema = z.object({ note: z.string().optional() });

/** POST /api/shifts/:id/approve — اعتماد المدير لفرق الصندوق */
export const POST = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requirePermission('shifts.approve_difference', request);
  const branchId = requireBranch(session);
  const { id } = await params;
  const body = await parseBody(request, schema);

  const shift = await approveShiftDifference(id, session.sub, body.note);

  await writeAudit({
    action: 'SHIFT_APPROVE_DIFF',
    entity: 'Shift',
    entityId: id,
    userId: session.sub,
    branchId,
    newValue: { note: body.note },
    request,
  });

  return ok(shift);
});
