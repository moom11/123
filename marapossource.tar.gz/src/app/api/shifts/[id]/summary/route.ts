import type { NextRequest } from 'next/server';
import { ok, route } from '@/lib/api/handler';
import { requireBranch, requireSession } from '@/lib/api/session';
import { getShiftSummary } from '@/lib/pos/shift-service';
import { prisma } from '@/lib/prisma';
import { Forbidden, NotFound } from '@/lib/api/errors';
import { hasPermission } from '@/lib/auth/permissions';

type Ctx = { params: Promise<{ id: string }> };

/** GET /api/shifts/:id/summary — تقرير إغلاق الوردية (قابل للطباعة) */
export const GET = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requireSession(request);
  const branchId = requireBranch(session);
  const { id } = await params;

  const shift = await prisma.shift.findFirst({ where: { id, branchId } });
  if (!shift) throw NotFound('الوردية غير موجودة');
  if (shift.userId !== session.sub && !hasPermission(session.permissions, 'shifts.view_all')) {
    throw Forbidden('لا تملك صلاحية عرض ورديات الآخرين');
  }

  return ok(await getShiftSummary(id));
});
