import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { ok, parseBody, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { closeShift } from '@/lib/pos/shift-service';
import { verifyManagerPin } from '@/lib/auth/auth-service';
import { writeAudit } from '@/lib/audit';

type Ctx = { params: Promise<{ id: string }> };

const schema = z.object({
  countedCash: z.number().min(0),
  differenceReason: z.string().optional().nullable(),
  note: z.string().optional().nullable(),
  /** رمز المدير لاعتماد الفرق مباشرة عند الإغلاق */
  managerPin: z.string().optional().nullable(),
});

/** POST /api/shifts/:id/close — إغلاق الوردية واحتساب فرق الصندوق */
export const POST = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requirePermission('shifts.close', request);
  const branchId = requireBranch(session);
  const { id } = await params;
  const body = await parseBody(request, schema);

  let approvedById: string | null = null;
  if (body.managerPin) {
    const manager = await verifyManagerPin(
      branchId,
      body.managerPin,
      'shifts.approve_difference',
    );
    approvedById = manager.id;
  }

  const result = await closeShift({
    shiftId: id,
    countedCash: body.countedCash,
    differenceReason: body.differenceReason,
    note: body.note,
    approvedById,
  });

  await writeAudit({
    action: 'SHIFT_CLOSE',
    entity: 'Shift',
    entityId: id,
    userId: session.sub,
    branchId,
    newValue: {
      countedCash: body.countedCash,
      expectedCash: result.summary.expectedCash,
      difference: result.summary.cashDifference,
      reason: body.differenceReason,
      status: result.shift.status,
    },
    request,
  });

  return ok(result);
});
