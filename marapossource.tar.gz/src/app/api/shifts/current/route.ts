import type { NextRequest } from 'next/server';
import { ok, route } from '@/lib/api/handler';
import { requireBranch, requireSession } from '@/lib/api/session';
import { getCurrentShift, getShiftSummary } from '@/lib/pos/shift-service';

/** GET /api/shifts/current — الوردية المفتوحة للمستخدم الحالي مع ملخصها */
export const GET = route(async (request: NextRequest) => {
  const session = await requireSession(request);
  const branchId = requireBranch(session);

  const shift = await getCurrentShift(branchId, session.sub);
  if (!shift) return ok(null);

  return ok({ ...shift, summary: await getShiftSummary(shift.id) });
});
