import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { ShiftStatus } from '@prisma/client';
import { created, ok, parseBody, parseQuery, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';
import { openShift } from '@/lib/pos/shift-service';
import { hasPermission } from '@/lib/auth/permissions';
import { writeAudit } from '@/lib/audit';

const querySchema = z.object({
  status: z.nativeEnum(ShiftStatus).optional(),
  from: z.string().optional(),
  to: z.string().optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(25),
});

/** GET /api/shifts — قائمة الورديات (الكاشير يرى ورديّاته فقط) */
export const GET = route(async (request: NextRequest) => {
  const session = await requirePermission('shifts.open', request);
  const branchId = requireBranch(session);
  const query = parseQuery(request, querySchema);
  const canSeeAll = hasPermission(session.permissions, 'shifts.view_all');

  const where = {
    branchId,
    ...(canSeeAll ? {} : { userId: session.sub }),
    ...(query.status ? { status: query.status } : {}),
    ...(query.from || query.to
      ? {
          businessDay: {
            ...(query.from ? { gte: new Date(`${query.from}T00:00:00Z`) } : {}),
            ...(query.to ? { lte: new Date(`${query.to}T00:00:00Z`) } : {}),
          },
        }
      : {}),
  };

  const [items, total] = await Promise.all([
    prisma.shift.findMany({
      where,
      include: {
        user: { select: { fullName: true, employeeNo: true } },
        device: { select: { name: true } },
        _count: { select: { invoices: true } },
      },
      orderBy: { openedAt: 'desc' },
      skip: (query.page - 1) * query.pageSize,
      take: query.pageSize,
    }),
    prisma.shift.count({ where }),
  ]);

  return ok(items, { total, page: query.page, pageSize: query.pageSize });
});

const openSchema = z.object({
  openingFloat: z.number().min(0),
  deviceId: z.string().uuid().optional().nullable(),
  note: z.string().optional().nullable(),
});

/** POST /api/shifts — فتح وردية جديدة */
export const POST = route(async (request: NextRequest) => {
  const session = await requirePermission('shifts.open', request);
  const branchId = requireBranch(session);
  const body = await parseBody(request, openSchema);

  const shift = await openShift({
    branchId,
    userId: session.sub,
    deviceId: body.deviceId,
    openingFloat: body.openingFloat,
    note: body.note,
  });

  await writeAudit({
    action: 'SHIFT_OPEN',
    entity: 'Shift',
    entityId: shift.id,
    userId: session.sub,
    branchId,
    newValue: { shiftNumber: shift.shiftNumber, openingFloat: body.openingFloat },
    request,
  });

  return created(shift);
});
