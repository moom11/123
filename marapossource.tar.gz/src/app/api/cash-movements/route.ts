import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { CashMovementType } from '@prisma/client';
import { created, ok, parseBody, parseQuery, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';
import { recordCashMovement, recordDrawerOpen } from '@/lib/pos/shift-service';
import { writeAudit } from '@/lib/audit';

const querySchema = z.object({
  shiftId: z.string().uuid().optional(),
  type: z.nativeEnum(CashMovementType).optional(),
  businessDay: z.string().optional(),
});

/** GET /api/cash-movements — حركات الصندوق */
export const GET = route(async (request: NextRequest) => {
  const session = await requirePermission('cash.manage', request);
  const branchId = requireBranch(session);
  const query = parseQuery(request, querySchema);

  const movements = await prisma.cashMovement.findMany({
    where: {
      branchId,
      ...(query.shiftId ? { shiftId: query.shiftId } : {}),
      ...(query.type ? { type: query.type } : {}),
      ...(query.businessDay
        ? { businessDay: new Date(`${query.businessDay}T00:00:00Z`) }
        : {}),
    },
    include: {
      user: { select: { fullName: true } },
      shift: { select: { shiftNumber: true } },
      expense: { include: { category: true } },
    },
    orderBy: { createdAt: 'desc' },
    take: 200,
  });

  return ok(movements);
});

const createSchema = z.object({
  type: z.nativeEnum(CashMovementType),
  amount: z.number().min(0),
  shiftId: z.string().uuid().optional().nullable(),
  note: z.string().optional().nullable(),
  categoryId: z.string().uuid().optional().nullable(),
  documentUrl: z.string().optional().nullable(),
});

/**
 * POST /api/cash-movements — تسجيل حركة صندوق.
 * الإيداع في الصندوق الرئيسي يُسجل بنوعه المستقل ولا يُعد مصروفًا.
 */
export const POST = route(async (request: NextRequest) => {
  const session = await requirePermission('cash.manage', request);
  const branchId = requireBranch(session);
  const body = await parseBody(request, createSchema);

  if (body.type === CashMovementType.DRAWER_OPEN) {
    if (!body.shiftId) {
      return created(
        await prisma.cashMovement.create({
          data: {
            branchId,
            userId: session.sub,
            type: CashMovementType.DRAWER_OPEN,
            amount: 0,
            businessDay: new Date(new Date().toISOString().slice(0, 10)),
            note: body.note ?? 'فتح درج',
          },
        }),
      );
    }
    return created(
      await recordDrawerOpen(branchId, body.shiftId, session.sub, body.note ?? 'فتح درج'),
    );
  }

  const result = await recordCashMovement({
    branchId,
    shiftId: body.shiftId,
    userId: session.sub,
    type: body.type,
    amount: body.amount,
    note: body.note,
    categoryId: body.categoryId,
    documentUrl: body.documentUrl,
  });

  await writeAudit({
    action: body.type === CashMovementType.EXPENSE ? 'EXPENSE_CREATED' : 'CASH_MOVEMENT',
    entity: 'CashMovement',
    entityId: result.movement.id,
    userId: session.sub,
    branchId,
    newValue: { type: body.type, amount: body.amount, note: body.note },
    request,
  });

  return created(result);
});
