import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { RoleCode } from '@prisma/client';
import { ok, parseBody, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';
import { hashPassword, isStrongPassword } from '@/lib/auth/password';
import { BadRequest, NotFound } from '@/lib/api/errors';
import { writeAudit } from '@/lib/audit';

type Ctx = { params: Promise<{ id: string }> };

const schema = z.object({
  fullName: z.string().min(1).optional(),
  email: z.string().email().optional().nullable(),
  phone: z.string().optional().nullable(),
  password: z.string().min(8).optional(),
  managerPin: z.string().min(4).max(8).optional().nullable(),
  isActive: z.boolean().optional(),
  role: z.nativeEnum(RoleCode).optional(),
});

/** PATCH /api/users/:id — تعديل مستخدم أو دوره أو كلمة مروره */
export const PATCH = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requirePermission('users.manage', request);
  const branchId = requireBranch(session);
  const { id } = await params;
  const body = await parseBody(request, schema);

  const existing = await prisma.user.findFirst({ where: { id, branchId } });
  if (!existing) throw NotFound('المستخدم غير موجود');

  if (body.password && !isStrongPassword(body.password)) {
    throw BadRequest('كلمة المرور يجب أن تحتوي على 8 أحرف على الأقل مع حرف ورقم');
  }

  const user = await prisma.$transaction(async (tx) => {
    const updated = await tx.user.update({
      where: { id },
      data: {
        ...(body.fullName ? { fullName: body.fullName } : {}),
        ...(body.email !== undefined ? { email: body.email?.toLowerCase() ?? null } : {}),
        ...(body.phone !== undefined ? { phone: body.phone } : {}),
        ...(body.isActive !== undefined ? { isActive: body.isActive } : {}),
        ...(body.password ? { passwordHash: await hashPassword(body.password) } : {}),
        ...(body.managerPin !== undefined
          ? {
              managerPinHash: body.managerPin
                ? await hashPassword(body.managerPin)
                : null,
            }
          : {}),
      },
      select: { id: true, employeeNo: true, fullName: true, email: true, isActive: true },
    });

    if (body.role) {
      const role = await tx.role.findUnique({ where: { code: body.role } });
      if (!role) throw NotFound('الدور الوظيفي غير موجود');
      await tx.userRole.deleteMany({ where: { userId: id } });
      await tx.userRole.create({ data: { userId: id, roleId: role.id } });
    }

    return updated;
  });

  await writeAudit({
    action: 'USER_UPDATED',
    entity: 'User',
    entityId: id,
    userId: session.sub,
    branchId,
    oldValue: { fullName: existing.fullName, isActive: existing.isActive },
    newValue: { ...body, password: undefined, managerPin: undefined },
    request,
  });

  return ok(user);
});
