import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { RoleCode } from '@prisma/client';
import { created, ok, parseBody, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';
import { hashPassword, isStrongPassword } from '@/lib/auth/password';
import { BadRequest, NotFound } from '@/lib/api/errors';
import { writeAudit } from '@/lib/audit';

/** GET /api/users — قائمة مستخدمي الفرع مع أدوارهم */
export const GET = route(async (request: NextRequest) => {
  const session = await requirePermission('users.view', request);
  const branchId = requireBranch(session);

  const users = await prisma.user.findMany({
    where: { branchId },
    select: {
      id: true,
      employeeNo: true,
      email: true,
      fullName: true,
      phone: true,
      isActive: true,
      lastLoginAt: true,
      createdAt: true,
      roles: { include: { role: { select: { code: true, nameAr: true } } } },
    },
    orderBy: { employeeNo: 'asc' },
  });
  return ok(users);
});

const createSchema = z.object({
  employeeNo: z.string().min(1),
  email: z.string().email().optional().nullable(),
  fullName: z.string().min(1),
  password: z.string().min(8, 'كلمة المرور 8 أحرف على الأقل'),
  managerPin: z.string().min(4).max(8).optional().nullable(),
  phone: z.string().optional().nullable(),
  role: z.nativeEnum(RoleCode),
  isActive: z.boolean().default(true),
});

/** POST /api/users — إنشاء مستخدم وربطه بدور وظيفي */
export const POST = route(async (request: NextRequest) => {
  const session = await requirePermission('users.manage', request);
  const branchId = requireBranch(session);
  const body = await parseBody(request, createSchema);

  if (!isStrongPassword(body.password)) {
    throw BadRequest('كلمة المرور يجب أن تحتوي على 8 أحرف على الأقل مع حرف ورقم');
  }

  const role = await prisma.role.findUnique({ where: { code: body.role } });
  if (!role) throw NotFound('الدور الوظيفي غير موجود');

  const user = await prisma.user.create({
    data: {
      branchId,
      employeeNo: body.employeeNo,
      email: body.email?.toLowerCase() ?? null,
      fullName: body.fullName,
      phone: body.phone ?? null,
      isActive: body.isActive,
      passwordHash: await hashPassword(body.password),
      managerPinHash: body.managerPin ? await hashPassword(body.managerPin) : null,
      roles: { create: { roleId: role.id } },
    },
    select: { id: true, employeeNo: true, fullName: true, email: true, isActive: true },
  });

  await writeAudit({
    action: 'USER_CREATED',
    entity: 'User',
    entityId: user.id,
    userId: session.sub,
    branchId,
    newValue: { employeeNo: body.employeeNo, fullName: body.fullName, role: body.role },
    request,
  });

  return created(user);
});
