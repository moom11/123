import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { OrderStatus, OrderType, Prisma } from '@prisma/client';
import { created, ok, parseBody, parseQuery, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';
import { ORDER_INCLUDE, createOrder } from '@/lib/pos/order-service';
import { currentBusinessDay } from '@/lib/settings';

const querySchema = z.object({
  status: z.string().optional(),
  tableId: z.string().uuid().optional(),
  type: z.nativeEnum(OrderType).optional(),
  mine: z.enum(['true', 'false']).optional(),
  businessDay: z.string().optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(50),
});

/** GET /api/orders — قائمة الطلبات مع فلاتر */
export const GET = route(async (request: NextRequest) => {
  const session = await requirePermission('orders.create', request);
  const branchId = requireBranch(session);
  const query = parseQuery(request, querySchema);

  const statuses = query.status
    ? (query.status.split(',').filter(Boolean) as OrderStatus[])
    : undefined;

  const where: Prisma.OrderWhereInput = {
    branchId,
    ...(statuses ? { status: { in: statuses } } : {}),
    ...(query.tableId ? { tableId: query.tableId } : {}),
    ...(query.type ? { type: query.type } : {}),
    ...(query.mine === 'true' ? { userId: session.sub } : {}),
    ...(query.businessDay ? { businessDay: new Date(`${query.businessDay}T00:00:00Z`) } : {}),
  };

  const [items, total] = await Promise.all([
    prisma.order.findMany({
      where,
      include: ORDER_INCLUDE,
      orderBy: { createdAt: 'desc' },
      skip: (query.page - 1) * query.pageSize,
      take: query.pageSize,
    }),
    prisma.order.count({ where }),
  ]);

  return ok(items, { total, page: query.page, pageSize: query.pageSize });
});

const modifierSchema = z.object({
  groupId: z.string().optional(),
  groupName: z.string().optional(),
  modifierId: z.string(),
  name: z.string(),
  priceDelta: z.number().default(0),
});

const itemSchema = z.object({
  productId: z.string().uuid(),
  variantId: z.string().uuid().optional().nullable(),
  quantity: z.number().positive(),
  note: z.string().optional().nullable(),
  modifiers: z.array(modifierSchema).optional(),
  lineDiscount: z.number().min(0).optional(),
});

const createSchema = z.object({
  type: z.nativeEnum(OrderType).default(OrderType.DINE_IN),
  tableId: z.string().uuid().optional().nullable(),
  guestCount: z.number().int().min(0).optional().nullable(),
  customerName: z.string().optional().nullable(),
  customerPhone: z.string().optional().nullable(),
  note: z.string().optional().nullable(),
  shiftId: z.string().uuid().optional().nullable(),
  clientUuid: z.string().uuid().optional().nullable(),
  items: z.array(itemSchema).optional(),
});

/** POST /api/orders — فتح طلب جديد (يدعم clientUuid لمنع التكرار عند العمل دون اتصال) */
export const POST = route(async (request: NextRequest) => {
  const session = await requirePermission('orders.create', request);
  const branchId = requireBranch(session);
  const body = await parseBody(request, createSchema);

  // نربط الطلب تلقائيًا بالوردية المفتوحة للمستخدم
  const shift =
    body.shiftId ??
    (
      await prisma.shift.findFirst({
        where: { branchId, userId: session.sub, status: 'OPEN' },
        orderBy: { openedAt: 'desc' },
        select: { id: true },
      })
    )?.id ??
    null;

  await currentBusinessDay(branchId);

  const order = await createOrder({
    branchId,
    userId: session.sub,
    type: body.type,
    tableId: body.tableId,
    guestCount: body.guestCount,
    customerName: body.customerName,
    customerPhone: body.customerPhone,
    note: body.note,
    shiftId: shift,
    clientUuid: body.clientUuid,
    items: body.items,
  });

  return created(order);
});
