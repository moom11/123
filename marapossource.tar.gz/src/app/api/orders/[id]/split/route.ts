import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { ok, parseBody, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { splitOrder } from '@/lib/pos/order-service';
import { writeAudit } from '@/lib/audit';

type Ctx = { params: Promise<{ id: string }> };

const schema = z.object({ itemIds: z.array(z.string().uuid()).min(1) });

/**
 * POST /api/orders/:id/split — تقسيم الفاتورة: نقل أصناف محددة إلى طلب جديد
 * على نفس الطاولة ليُدفع بشكل منفصل.
 */
export const POST = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requirePermission('orders.split', request);
  const branchId = requireBranch(session);
  const { id } = await params;
  const body = await parseBody(request, schema);

  const result = await splitOrder(id, body.itemIds, session.sub);

  await writeAudit({
    action: 'INVOICE_SPLIT',
    entity: 'Order',
    entityId: id,
    userId: session.sub,
    branchId,
    newValue: { itemIds: body.itemIds, newOrderId: result.target.id },
    request,
  });

  return ok(result);
});
