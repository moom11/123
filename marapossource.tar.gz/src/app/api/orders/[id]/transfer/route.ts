import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { ok, parseBody, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { transferOrderTable } from '@/lib/pos/order-service';
import { writeAudit } from '@/lib/audit';

type Ctx = { params: Promise<{ id: string }> };

const schema = z.object({ targetTableId: z.string().uuid() });

/** POST /api/orders/:id/transfer — نقل الطلب إلى طاولة أخرى */
export const POST = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requirePermission('orders.transfer_table', request);
  const branchId = requireBranch(session);
  const { id } = await params;
  const body = await parseBody(request, schema);

  const order = await transferOrderTable(id, body.targetTableId);

  await writeAudit({
    action: 'TABLE_TRANSFER',
    entity: 'Order',
    entityId: id,
    userId: session.sub,
    branchId,
    newValue: { targetTableId: body.targetTableId },
    request,
  });

  return ok(order);
});
