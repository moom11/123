import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { ok, parseBody, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { mergeOrders } from '@/lib/pos/order-service';
import { verifyManagerPin } from '@/lib/auth/auth-service';
import { hasPermission } from '@/lib/auth/permissions';
import { Forbidden } from '@/lib/api/errors';
import { writeAudit } from '@/lib/audit';

type Ctx = { params: Promise<{ id: string }> };

const schema = z.object({
  sourceOrderId: z.string().uuid(),
  /** رمز المدير — مطلوب عندما لا يملك المستخدم صلاحية الدمج */
  managerPin: z.string().optional(),
});

/**
 * POST /api/orders/:id/merge — دمج طلب آخر في هذا الطلب.
 * يتطلب صلاحية الدمج أو اعتماد المدير برمزه.
 */
export const POST = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requirePermission('orders.create', request);
  const branchId = requireBranch(session);
  const { id } = await params;
  const body = await parseBody(request, schema);

  let approvedBy = session.sub;
  if (!hasPermission(session.permissions, 'orders.merge')) {
    if (!body.managerPin) throw Forbidden('دمج الطلبات يحتاج اعتماد المدير');
    const manager = await verifyManagerPin(branchId, body.managerPin, 'orders.merge');
    approvedBy = manager.id;
  }

  const order = await mergeOrders(body.sourceOrderId, id);

  await writeAudit({
    action: 'ORDER_MERGED',
    entity: 'Order',
    entityId: id,
    userId: session.sub,
    branchId,
    newValue: { sourceOrderId: body.sourceOrderId, approvedBy },
    request,
  });

  return ok(order);
});
