import type { NextRequest } from 'next/server';
import { ok, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';
import { NotFound } from '@/lib/api/errors';
import { dismissOffer, restoreOffer } from '@/lib/pos/offer-service';
import { assertEditable, recalculateOrder } from '@/lib/pos/order-service';
import { writeAudit } from '@/lib/audit';

type Ctx = { params: Promise<{ id: string; offerId: string }> };

/** DELETE /api/orders/:id/offers/:offerId — إلغاء تطبيق عرض على هذا الطلب */
export const DELETE = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requirePermission('discounts.apply', request);
  const branchId = requireBranch(session);
  const { id, offerId } = await params;

  const order = await prisma.order.findFirst({ where: { id, branchId } });
  if (!order) throw NotFound('الطلب غير موجود');
  assertEditable(order);

  const updated = await prisma.$transaction(async (tx) => {
    await dismissOffer(tx, id, offerId);
    return recalculateOrder(tx, id);
  });

  await writeAudit({
    action: 'DISCOUNT_APPLIED',
    entity: 'Order',
    entityId: id,
    userId: session.sub,
    branchId,
    newValue: { dismissedOfferId: offerId },
    request,
  });

  return ok(updated);
});

/** POST /api/orders/:id/offers/:offerId — إعادة تفعيل عرض أُلغي */
export const POST = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requirePermission('discounts.apply', request);
  const branchId = requireBranch(session);
  const { id, offerId } = await params;

  const order = await prisma.order.findFirst({ where: { id, branchId } });
  if (!order) throw NotFound('الطلب غير موجود');
  assertEditable(order);

  const updated = await prisma.$transaction(async (tx) => {
    await restoreOffer(tx, id, offerId);
    return recalculateOrder(tx, id);
  });

  return ok(updated);
});
