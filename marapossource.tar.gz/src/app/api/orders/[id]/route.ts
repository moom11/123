import type { NextRequest } from 'next/server';
import { ok, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';
import { NotFound } from '@/lib/api/errors';
import { ORDER_INCLUDE } from '@/lib/pos/order-service';

type Ctx = { params: Promise<{ id: string }> };

/** GET /api/orders/:id */
export const GET = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requirePermission('orders.create', request);
  const branchId = requireBranch(session);
  const { id } = await params;

  const order = await prisma.order.findFirst({
    where: { id, branchId },
    include: { ...ORDER_INCLUDE, invoices: true, kitchenTickets: true },
  });
  if (!order) throw NotFound('الطلب غير موجود');
  return ok(order);
});
