import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { DiscountType } from '@prisma/client';
import { ok, parseBody, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { applyDiscount, removeDiscount } from '@/lib/pos/discount-service';
import { verifyManagerPin } from '@/lib/auth/auth-service';
import { writeAudit } from '@/lib/audit';

type Ctx = { params: Promise<{ id: string }> };

const schema = z.object({
  orderItemId: z.string().uuid().optional().nullable(),
  type: z.nativeEnum(DiscountType).default(DiscountType.PERCENT),
  value: z.number().positive(),
  reason: z.string().optional().nullable(),
  couponCode: z.string().optional().nullable(),
  /** رمز المدير عند الحاجة لاعتماد الخصم */
  managerPin: z.string().optional().nullable(),
});

/** POST /api/orders/:id/discount — تطبيق خصم على صنف أو على كامل الفاتورة */
export const POST = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requirePermission('discounts.apply', request);
  const branchId = requireBranch(session);
  const { id } = await params;
  const body = await parseBody(request, schema);

  let approvedById: string | null = null;
  if (body.managerPin) {
    const manager = await verifyManagerPin(branchId, body.managerPin, 'discounts.approve');
    approvedById = manager.id;
  }

  const result = await applyDiscount({
    orderId: id,
    orderItemId: body.orderItemId,
    type: body.type,
    value: body.value,
    reason: body.reason,
    couponCode: body.couponCode,
    userId: session.sub,
    userPermissions: session.permissions,
    approvedById,
  });

  await writeAudit({
    action: 'DISCOUNT_APPLIED',
    entity: 'Order',
    entityId: id,
    userId: session.sub,
    branchId,
    newValue: {
      type: body.type,
      value: body.value,
      reason: body.reason,
      approvedById,
    },
    request,
  });

  return ok(result);
});

const deleteSchema = z.object({ discountId: z.string().uuid() });

/** DELETE /api/orders/:id/discount — إزالة خصم */
export const DELETE = route<Ctx>(async (request: NextRequest, { params }) => {
  await requirePermission('discounts.apply', request);
  const { id } = await params;
  const body = await parseBody(request, deleteSchema);
  return ok(await removeDiscount(id, body.discountId));
});
