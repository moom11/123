import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { ok, parseBody, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { cancelOrder } from '@/lib/pos/order-service';
import { writeAudit } from '@/lib/audit';

type Ctx = { params: Promise<{ id: string }> };

const schema = z.object({ reason: z.string().min(1, 'سبب الإلغاء مطلوب') });

/** POST /api/orders/:id/cancel — إلغاء الطلب قبل الدفع */
export const POST = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requirePermission('orders.cancel', request);
  const branchId = requireBranch(session);
  const { id } = await params;
  const body = await parseBody(request, schema);

  const order = await cancelOrder(id, body.reason);

  await writeAudit({
    action: 'ORDER_CANCELLED',
    entity: 'Order',
    entityId: id,
    userId: session.sub,
    branchId,
    newValue: { reason: body.reason },
    request,
  });

  return ok(order);
});
