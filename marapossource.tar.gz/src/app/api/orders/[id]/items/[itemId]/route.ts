import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { ok, parseBody, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { updateItemQuantity, voidOrderItem } from '@/lib/pos/order-service';
import { writeAudit } from '@/lib/audit';

type Ctx = { params: Promise<{ id: string; itemId: string }> };

const patchSchema = z.object({ quantity: z.number().min(0) });

/** PATCH /api/orders/:id/items/:itemId — تعديل الكمية */
export const PATCH = route<Ctx>(async (request: NextRequest, { params }) => {
  await requirePermission('orders.create', request);
  const { id, itemId } = await params;
  const body = await parseBody(request, patchSchema);
  return ok(await updateItemQuantity(id, itemId, body.quantity));
});

const deleteSchema = z.object({ reason: z.string().min(1, 'سبب الإلغاء مطلوب') });

/** DELETE /api/orders/:id/items/:itemId — إلغاء صنف مع تسجيل السبب */
export const DELETE = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requirePermission('orders.void_item', request);
  const branchId = requireBranch(session);
  const { id, itemId } = await params;
  const body = await parseBody(request, deleteSchema);

  const order = await voidOrderItem(id, itemId, body.reason);

  await writeAudit({
    action: 'ITEM_VOIDED',
    entity: 'OrderItem',
    entityId: itemId,
    userId: session.sub,
    branchId,
    newValue: { reason: body.reason, orderId: id },
    request,
  });

  return ok(order);
});
