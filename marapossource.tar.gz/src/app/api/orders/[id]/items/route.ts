import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { created, parseBody, route } from '@/lib/api/handler';
import { requirePermission } from '@/lib/api/session';
import { addItemToOrder } from '@/lib/pos/order-service';

type Ctx = { params: Promise<{ id: string }> };

const schema = z.object({
  productId: z.string().uuid(),
  variantId: z.string().uuid().optional().nullable(),
  quantity: z.number().positive(),
  note: z.string().optional().nullable(),
  modifiers: z
    .array(
      z.object({
        groupId: z.string().optional(),
        groupName: z.string().optional(),
        modifierId: z.string(),
        name: z.string(),
        priceDelta: z.number().default(0),
      }),
    )
    .optional(),
  lineDiscount: z.number().min(0).optional(),
});

/** POST /api/orders/:id/items — إضافة صنف إلى الطلب */
export const POST = route<Ctx>(async (request: NextRequest, { params }) => {
  await requirePermission('orders.create', request);
  const { id } = await params;
  const body = await parseBody(request, schema);
  return created(await addItemToOrder(id, body));
});
