import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { created, parseBody, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { checkoutOrder } from '@/lib/pos/checkout-service';
import { writeAudit } from '@/lib/audit';
import { toNumber } from '@/lib/money';

type Ctx = { params: Promise<{ id: string }> };

const schema = z.object({
  payments: z
    .array(
      z.object({
        paymentMethodId: z.string().uuid(),
        amount: z.number().positive(),
        receivedAmount: z.number().positive().optional().nullable(),
        reference: z.string().optional().nullable(),
      }),
    )
    .min(1, 'حدد طريقة دفع واحدة على الأقل'),
  shiftId: z.string().uuid().optional().nullable(),
  customerName: z.string().optional().nullable(),
  customerPhone: z.string().optional().nullable(),
  /** مفتاح منع التكرار من الجهاز — يضمن عدم إغلاق الفاتورة مرتين */
  idempotencyKey: z.string().optional().nullable(),
});

/**
 * POST /api/orders/:id/checkout — تحصيل الدفع وإغلاق الفاتورة.
 * يدعم الدفع المختلط ويمنع الإغلاق عند عدم تطابق المبالغ.
 */
export const POST = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requirePermission('payments.collect', request);
  const branchId = requireBranch(session);
  const { id } = await params;
  const body = await parseBody(request, schema);

  const invoice = await checkoutOrder({
    orderId: id,
    userId: session.sub,
    shiftId: body.shiftId,
    payments: body.payments,
    customerName: body.customerName,
    customerPhone: body.customerPhone,
    idempotencyKey: body.idempotencyKey,
  });

  await writeAudit({
    action: 'INVOICE_CLOSED',
    entity: 'Invoice',
    entityId: invoice.id,
    userId: session.sub,
    branchId,
    newValue: {
      invoiceNumber: invoice.invoiceNumber,
      grandTotal: toNumber(invoice.grandTotal),
      paymentCount: invoice.payments.length,
    },
    request,
  });

  return created(invoice);
});
