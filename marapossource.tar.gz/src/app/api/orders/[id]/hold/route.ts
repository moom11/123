import type { NextRequest } from 'next/server';
import { ok, route } from '@/lib/api/handler';
import { requirePermission } from '@/lib/api/session';
import { holdOrder } from '@/lib/pos/order-service';

type Ctx = { params: Promise<{ id: string }> };

/** POST /api/orders/:id/hold — تعليق الطلب */
export const POST = route<Ctx>(async (request: NextRequest, { params }) => {
  await requirePermission('orders.hold', request);
  const { id } = await params;
  return ok(await holdOrder(id));
});
