import { z } from 'zod';
import { NextResponse, type NextRequest } from 'next/server';
import { parseQuery, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { BadRequest } from '@/lib/api/errors';
import {
  getEmployeesReport,
  getPaymentsReport,
  getProductsReport,
  getSalesReport,
  getShiftsReport,
  parseRange,
} from '@/lib/reports/report-service';
import {
  buildCsv,
  buildExcel,
  type ExportColumn,
  type ExportRow,
} from '@/lib/reports/exporters';

const schema = z.object({
  report: z.enum(['sales', 'payments', 'products', 'employees', 'shifts']),
  format: z.enum(['xlsx', 'csv']).default('xlsx'),
  from: z.string().optional(),
  to: z.string().optional(),
});

const REPORT_TITLES: Record<string, string> = {
  sales: 'تقرير المبيعات',
  payments: 'تقرير طرق الدفع',
  products: 'تقرير المنتجات',
  employees: 'تقرير الموظفين',
  shifts: 'تقرير الورديات',
};

/**
 * GET /api/reports/export?report=sales&format=xlsx&from=...&to=...
 * تصدير التقارير إلى Excel أو CSV.
 * تصدير PDF متاح من صفحة التقارير عبر الطباعة إلى PDF (دعم كامل للعربية).
 */
export const GET = route(async (request: NextRequest) => {
  const session = await requirePermission('reports.export', request);
  const branchId = requireBranch(session);
  const query = parseQuery(request, schema);
  const range = parseRange(branchId, query.from, query.to);

  let columns: ExportColumn[];
  let rows: ExportRow[];

  switch (query.report) {
    case 'sales': {
      const report = await getSalesReport(range);
      columns = [
        { key: 'metric', header: 'البيان', width: 28 },
        { key: 'value', header: 'القيمة', money: true, width: 16 },
      ];
      rows = [
        { metric: 'إجمالي المبيعات', value: report.totalSales },
        { metric: 'صافي المبيعات', value: report.netSales },
        { metric: 'المبيعات قبل الضريبة', value: report.salesBeforeTax },
        { metric: 'ضريبة القيمة المضافة', value: report.vatTotal },
        { metric: 'ضريبة التبغ', value: report.tobaccoTaxTotal },
        { metric: 'الخصومات', value: report.discountTotal },
        { metric: 'المرتجعات', value: report.refundTotal },
        { metric: 'عدد الفواتير', value: report.invoiceCount },
        { metric: 'متوسط قيمة الفاتورة', value: report.averageInvoice },
      ];
      break;
    }
    case 'payments': {
      const report = await getPaymentsReport(range);
      columns = [
        { key: 'methodName', header: 'طريقة الدفع', width: 22 },
        { key: 'amount', header: 'المبلغ', money: true },
        { key: 'count', header: 'عدد العمليات' },
      ];
      rows = [
        ...report.rows,
        { methodName: '— إجمالي التحصيل', amount: report.totalCollected, count: '' },
        { methodName: '— إجمالي المبيعات', amount: report.totalSales, count: '' },
        { methodName: '— الفرق', amount: report.variance, count: '' },
      ];
      break;
    }
    case 'products': {
      const report = await getProductsReport(range);
      columns = [
        { key: 'name', header: 'المنتج', width: 28 },
        { key: 'sku', header: 'الكود' },
        { key: 'categoryName', header: 'التصنيف', width: 20 },
        { key: 'prepStation', header: 'محطة التحضير' },
        { key: 'quantity', header: 'الكمية المباعة' },
        { key: 'netSales', header: 'صافي المبيعات', money: true },
      ];
      rows = report.topProducts;
      break;
    }
    case 'employees': {
      const report = await getEmployeesReport(range);
      columns = [
        { key: 'employeeNo', header: 'رقم الموظف' },
        { key: 'fullName', header: 'الاسم', width: 24 },
        { key: 'sales', header: 'المبيعات', money: true },
        { key: 'orderCount', header: 'عدد الطلبات' },
        { key: 'discountTotal', header: 'الخصومات', money: true },
        { key: 'cancelledCount', header: 'الإلغاءات' },
        { key: 'refundTotal', header: 'المرتجعات', money: true },
        { key: 'averageInvoice', header: 'متوسط الفاتورة', money: true },
      ];
      rows = report;
      break;
    }
    case 'shifts': {
      const report = await getShiftsReport(range);
      columns = [
        { key: 'shiftNumber', header: 'رقم الوردية' },
        { key: 'cashierName', header: 'الكاشير', width: 22 },
        { key: 'openedAt', header: 'وقت الفتح', width: 20 },
        { key: 'closedAt', header: 'وقت الإغلاق', width: 20 },
        { key: 'openingFloat', header: 'الرصيد الافتتاحي', money: true },
        { key: 'cashSales', header: 'المبيعات النقدية', money: true },
        { key: 'expenses', header: 'المصروفات', money: true },
        { key: 'withdrawals', header: 'المسحوبات', money: true },
        { key: 'deposits', header: 'الإيداعات', money: true },
        { key: 'expectedCash', header: 'النقد المتوقع', money: true },
        { key: 'countedCash', header: 'النقد الفعلي', money: true },
        { key: 'difference', header: 'الفرق', money: true },
      ];
      rows = report;
      break;
    }
    default:
      throw BadRequest('نوع تقرير غير مدعوم');
  }

  const title = `${REPORT_TITLES[query.report]} — من ${range.from
    .toISOString()
    .slice(0, 10)} إلى ${range.to.toISOString().slice(0, 10)}`;
  const filename = `${query.report}-${range.from.toISOString().slice(0, 10)}`;

  if (query.format === 'csv') {
    return new NextResponse(buildCsv(columns, rows), {
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="${filename}.csv"`,
      },
    });
  }

  const buffer = await buildExcel(REPORT_TITLES[query.report], columns, rows, title);
  return new NextResponse(new Uint8Array(buffer), {
    headers: {
      'Content-Type':
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': `attachment; filename="${filename}.xlsx"`,
    },
  });
});
