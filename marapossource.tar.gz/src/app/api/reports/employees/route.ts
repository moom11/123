import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { ok, parseQuery, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { getEmployeesReport, parseRange } from '@/lib/reports/report-service';

const schema = z.object({ from: z.string().optional(), to: z.string().optional() });

/** GET /api/reports/employees — مبيعات وخصومات وإلغاءات كل موظف */
export const GET = route(async (request: NextRequest) => {
  const session = await requirePermission('reports.view', request);
  const branchId = requireBranch(session);
  const query = parseQuery(request, schema);
  return ok(await getEmployeesReport(parseRange(branchId, query.from, query.to)));
});
