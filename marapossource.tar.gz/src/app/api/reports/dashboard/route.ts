import type { NextRequest } from 'next/server';
import { ok, route } from '@/lib/api/handler';
import { requireBranch, requireSession } from '@/lib/api/session';
import { getDashboard } from '@/lib/reports/report-service';
import { currentBusinessDay } from '@/lib/settings';

/** GET /api/reports/dashboard — مؤشرات اليوم التشغيلي الحالي */
export const GET = route(async (request: NextRequest) => {
  const session = await requireSession(request);
  const branchId = requireBranch(session);
  const businessDay = await currentBusinessDay(branchId);
  return ok(await getDashboard(branchId, businessDay, session.sub));
});
