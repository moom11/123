import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { Prisma } from '@prisma/client';
import { ok, parseBody, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';
import { NotFound } from '@/lib/api/errors';
import { writeAudit } from '@/lib/audit';

type Ctx = { params: Promise<{ id: string }> };

const componentSchema = z.object({
  nameAr: z.string().min(1),
  quantity: z.number().int().min(1).default(1),
  categoryIds: z.array(z.string().uuid()).default([]),
  productIds: z.array(z.string().uuid()).default([]),
  maxUnitPrice: z.number().min(0).optional().nullable(),
  minUnitPrice: z.number().min(0).optional().nullable(),
  tobaccoOnly: z.boolean().optional().nullable(),
});

const updateSchema = z.object({
  nameAr: z.string().min(1).optional(),
  description: z.string().optional().nullable(),
  fixedPrice: z.number().positive().optional(),
  isActive: z.boolean().optional(),
  priority: z.number().int().optional(),
  startsAt: z.string().datetime().optional().nullable(),
  endsAt: z.string().datetime().optional().nullable(),
  daysOfWeek: z.array(z.number().int().min(0).max(6)).optional(),
  startTime: z.string().regex(/^\d{2}:\d{2}$/).optional().nullable(),
  endTime: z.string().regex(/^\d{2}:\d{2}$/).optional().nullable(),
  maxPerOrder: z.number().int().min(0).optional(),
  /** عند إرسالها تُستبدل المكونات بالكامل */
  components: z.array(componentSchema).min(2).optional(),
});

/** PATCH /api/offers/:id — تعديل عرض */
export const PATCH = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requirePermission('products.manage', request);
  const branchId = requireBranch(session);
  const { id } = await params;
  const body = await parseBody(request, updateSchema);

  const existing = await prisma.offer.findFirst({ where: { id, branchId } });
  if (!existing) throw NotFound('العرض غير موجود');

  const { components, fixedPrice, startsAt, endsAt, ...rest } = body;

  const offer = await prisma.$transaction(async (tx) => {
    if (components) {
      await tx.offerComponent.deleteMany({ where: { offerId: id } });
      await tx.offerComponent.createMany({
        data: components.map((component, index) => ({
          offerId: id,
          nameAr: component.nameAr,
          quantity: component.quantity,
          categoryIds: component.categoryIds,
          productIds: component.productIds,
          maxUnitPrice:
            component.maxUnitPrice != null
              ? new Prisma.Decimal(component.maxUnitPrice.toFixed(4))
              : null,
          minUnitPrice:
            component.minUnitPrice != null
              ? new Prisma.Decimal(component.minUnitPrice.toFixed(4))
              : null,
          tobaccoOnly: component.tobaccoOnly ?? null,
          sortOrder: index,
        })),
      });
    }

    return tx.offer.update({
      where: { id },
      data: {
        ...rest,
        ...(fixedPrice !== undefined
          ? { fixedPrice: new Prisma.Decimal(fixedPrice.toFixed(4)) }
          : {}),
        ...(startsAt !== undefined ? { startsAt: startsAt ? new Date(startsAt) : null } : {}),
        ...(endsAt !== undefined ? { endsAt: endsAt ? new Date(endsAt) : null } : {}),
      },
      include: { components: { orderBy: { sortOrder: 'asc' } } },
    });
  });

  await writeAudit({
    action: 'PRODUCT_UPDATED',
    entity: 'Offer',
    entityId: id,
    userId: session.sub,
    branchId,
    oldValue: { nameAr: existing.nameAr, isActive: existing.isActive },
    newValue: body,
    request,
  });

  return ok(offer);
});

/** DELETE /api/offers/:id — تعطيل العرض (لا يُحذف حفاظًا على سجل الفواتير) */
export const DELETE = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requirePermission('products.manage', request);
  const branchId = requireBranch(session);
  const { id } = await params;

  const existing = await prisma.offer.findFirst({ where: { id, branchId } });
  if (!existing) throw NotFound('العرض غير موجود');

  const offer = await prisma.offer.update({ where: { id }, data: { isActive: false } });

  await writeAudit({
    action: 'PRODUCT_UPDATED',
    entity: 'Offer',
    entityId: id,
    userId: session.sub,
    branchId,
    oldValue: { isActive: true },
    newValue: { isActive: false },
    request,
  });

  return ok(offer);
});
