import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { Prisma } from '@prisma/client';
import { created, ok, parseBody, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';
import { writeAudit } from '@/lib/audit';

/** GET /api/offers — قائمة العروض الترويجية للفرع */
export const GET = route(async (request: NextRequest) => {
  const session = await requirePermission('products.view', request);
  const branchId = requireBranch(session);

  const offers = await prisma.offer.findMany({
    where: { branchId },
    include: { components: { orderBy: { sortOrder: 'asc' } } },
    orderBy: [{ isActive: 'desc' }, { priority: 'desc' }, { nameAr: 'asc' }],
  });
  return ok(offers);
});

const componentSchema = z.object({
  nameAr: z.string().min(1),
  quantity: z.number().int().min(1).default(1),
  categoryIds: z.array(z.string().uuid()).default([]),
  productIds: z.array(z.string().uuid()).default([]),
  maxUnitPrice: z.number().min(0).optional().nullable(),
  minUnitPrice: z.number().min(0).optional().nullable(),
  tobaccoOnly: z.boolean().optional().nullable(),
});

const createSchema = z.object({
  nameAr: z.string().min(1),
  nameEn: z.string().optional().nullable(),
  description: z.string().optional().nullable(),
  fixedPrice: z.number().positive('سعر العرض يجب أن يكون أكبر من صفر'),
  isActive: z.boolean().default(true),
  priority: z.number().int().default(0),
  startsAt: z.string().datetime().optional().nullable(),
  endsAt: z.string().datetime().optional().nullable(),
  daysOfWeek: z.array(z.number().int().min(0).max(6)).default([]),
  startTime: z.string().regex(/^\d{2}:\d{2}$/).optional().nullable(),
  endTime: z.string().regex(/^\d{2}:\d{2}$/).optional().nullable(),
  maxPerOrder: z.number().int().min(0).default(0),
  components: z.array(componentSchema).min(2, 'العرض يحتاج مكوّنين على الأقل'),
});

/** POST /api/offers — إنشاء عرض ترويجي */
export const POST = route(async (request: NextRequest) => {
  const session = await requirePermission('products.manage', request);
  const branchId = requireBranch(session);
  const body = await parseBody(request, createSchema);

  const offer = await prisma.offer.create({
    data: {
      branchId,
      nameAr: body.nameAr,
      nameEn: body.nameEn ?? null,
      description: body.description ?? null,
      fixedPrice: new Prisma.Decimal(body.fixedPrice.toFixed(4)),
      isActive: body.isActive,
      priority: body.priority,
      startsAt: body.startsAt ? new Date(body.startsAt) : null,
      endsAt: body.endsAt ? new Date(body.endsAt) : null,
      daysOfWeek: body.daysOfWeek,
      startTime: body.startTime ?? null,
      endTime: body.endTime ?? null,
      maxPerOrder: body.maxPerOrder,
      components: {
        create: body.components.map((component, index) => ({
          nameAr: component.nameAr,
          quantity: component.quantity,
          categoryIds: component.categoryIds,
          productIds: component.productIds,
          maxUnitPrice:
            component.maxUnitPrice != null
              ? new Prisma.Decimal(component.maxUnitPrice.toFixed(4))
              : null,
          minUnitPrice:
            component.minUnitPrice != null
              ? new Prisma.Decimal(component.minUnitPrice.toFixed(4))
              : null,
          tobaccoOnly: component.tobaccoOnly ?? null,
          sortOrder: index,
        })),
      },
    },
    include: { components: true },
  });

  await writeAudit({
    action: 'PRODUCT_UPDATED',
    entity: 'Offer',
    entityId: offer.id,
    userId: session.sub,
    branchId,
    newValue: { nameAr: body.nameAr, fixedPrice: body.fixedPrice },
    request,
  });

  return created(offer);
});
