import { NextResponse, type NextRequest } from 'next/server';
import { route } from '@/lib/api/handler';
import { logout } from '@/lib/auth/auth-service';
import { ACCESS_COOKIE, REFRESH_COOKIE } from '@/lib/auth/tokens';
import { getSession } from '@/lib/api/session';
import { writeAudit } from '@/lib/audit';

/** POST /api/auth/logout — إنهاء الجلسة وإلغاء رمز التحديث */
export const POST = route(async (request: NextRequest) => {
  const session = await getSession(request);
  await logout(request.cookies.get(REFRESH_COOKIE)?.value ?? null);

  if (session) {
    await writeAudit({
      action: 'LOGOUT',
      entity: 'User',
      entityId: session.sub,
      userId: session.sub,
      branchId: session.branchId,
      request,
    });
  }

  const response = NextResponse.json({ success: true, data: { message: 'تم تسجيل الخروج' } });
  response.cookies.delete(ACCESS_COOKIE);
  response.cookies.delete(REFRESH_COOKIE);
  return response;
});
