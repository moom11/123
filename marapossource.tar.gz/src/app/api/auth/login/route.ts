import { z } from 'zod';
import { NextResponse, type NextRequest } from 'next/server';
import { route, parseBody, getClientIp } from '@/lib/api/handler';
import { login } from '@/lib/auth/auth-service';
import {
  ACCESS_COOKIE,
  REFRESH_COOKIE,
  accessTtlSeconds,
  cookieOptions,
  refreshTtlSeconds,
} from '@/lib/auth/tokens';
import { writeAudit } from '@/lib/audit';
import { ApiError } from '@/lib/api/errors';

const schema = z.object({
  identifier: z.string().min(1, 'أدخل رقم الموظف أو البريد الإلكتروني'),
  password: z.string().min(1, 'أدخل كلمة المرور'),
});

/**
 * POST /api/auth/login — تسجيل الدخول برقم الموظف أو البريد الإلكتروني
 */
export const POST = route(
  async (request: NextRequest) => {
    const body = await parseBody(request, schema);
    const ip = getClientIp(request);
    const userAgent = request.headers.get('user-agent');

    try {
      const result = await login(body.identifier, body.password, { ip, userAgent });

      const response = NextResponse.json({
        success: true,
        data: {
          user: result.user,
          accessToken: result.accessToken,
          refreshToken: result.refreshToken,
          expiresIn: accessTtlSeconds(),
        },
      });
      response.cookies.set(ACCESS_COOKIE, result.accessToken, cookieOptions(accessTtlSeconds()));
      response.cookies.set(REFRESH_COOKIE, result.refreshToken, cookieOptions(refreshTtlSeconds()));

      await writeAudit({
        action: 'LOGIN',
        entity: 'User',
        entityId: result.user.id,
        userId: result.user.id,
        branchId: result.user.branchId,
        newValue: { employeeNo: result.user.employeeNo },
        ip,
        userAgent,
      });

      return response;
    } catch (error) {
      if (error instanceof ApiError && error.status === 401) {
        await writeAudit({
          action: 'LOGIN_FAILED',
          entity: 'User',
          newValue: { identifier: body.identifier },
          ip,
          userAgent,
        });
      }
      throw error;
    }
  },
  { rateLimit: { max: Number(process.env.LOGIN_RATE_LIMIT_MAX ?? 10), scope: 'login' } },
);
