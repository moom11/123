import { z } from 'zod';
import { NextResponse, type NextRequest } from 'next/server';
import { route, getClientIp } from '@/lib/api/handler';
import { refreshSession } from '@/lib/auth/auth-service';
import {
  ACCESS_COOKIE,
  REFRESH_COOKIE,
  accessTtlSeconds,
  cookieOptions,
  refreshTtlSeconds,
} from '@/lib/auth/tokens';
import { Unauthorized } from '@/lib/api/errors';

const schema = z.object({ refreshToken: z.string().optional() });

/** POST /api/auth/refresh — تجديد رمز الدخول باستخدام رمز التحديث */
export const POST = route(async (request: NextRequest) => {
  const body = await request.json().catch(() => ({}));
  const parsed = schema.parse(body ?? {});
  const token = parsed.refreshToken ?? request.cookies.get(REFRESH_COOKIE)?.value;
  if (!token) throw Unauthorized('رمز التحديث غير موجود');

  const result = await refreshSession(token, {
    ip: getClientIp(request),
    userAgent: request.headers.get('user-agent'),
  });

  const response = NextResponse.json({
    success: true,
    data: {
      user: result.user,
      accessToken: result.accessToken,
      refreshToken: result.refreshToken,
      expiresIn: accessTtlSeconds(),
    },
  });
  response.cookies.set(ACCESS_COOKIE, result.accessToken, cookieOptions(accessTtlSeconds()));
  response.cookies.set(REFRESH_COOKIE, result.refreshToken, cookieOptions(refreshTtlSeconds()));
  return response;
});
