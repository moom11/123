import type { NextRequest } from 'next/server';
import { route, ok } from '@/lib/api/handler';
import { requireSession } from '@/lib/api/session';
import { loadUserContext } from '@/lib/auth/auth-service';
import { prisma } from '@/lib/prisma';

/** GET /api/auth/me — بيانات المستخدم الحالي وصلاحياته */
export const GET = route(async (request: NextRequest) => {
  const session = await requireSession(request);
  const { user, roles, permissions } = await loadUserContext(session.sub);

  const branch = user.branchId
    ? await prisma.branch.findUnique({
        where: { id: user.branchId },
        include: { settings: true, company: true },
      })
    : null;

  return ok({
    id: user.id,
    employeeNo: user.employeeNo,
    fullName: user.fullName,
    email: user.email,
    roles,
    permissions,
    branch: branch
      ? {
          id: branch.id,
          nameAr: branch.nameAr,
          companyName: branch.company.nameAr,
          settings: branch.settings,
        }
      : null,
  });
});
