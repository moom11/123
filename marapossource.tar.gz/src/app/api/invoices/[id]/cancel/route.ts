import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { ok, parseBody, route } from '@/lib/api/handler';
import { requireBranch, requireSession } from '@/lib/api/session';
import { cancelInvoice } from '@/lib/pos/checkout-service';
import { verifyManagerPin } from '@/lib/auth/auth-service';
import { hasPermission } from '@/lib/auth/permissions';
import { Forbidden } from '@/lib/api/errors';
import { writeAudit } from '@/lib/audit';

type Ctx = { params: Promise<{ id: string }> };

const schema = z.object({
  reason: z.string().min(1, 'سبب الإلغاء مطلوب'),
  managerPin: z.string().optional().nullable(),
});

/**
 * POST /api/invoices/:id/cancel — إلغاء فاتورة مكتملة.
 * الكاشير لا يستطيع الإلغاء إلا برمز المدير. الفاتورة لا تُحذف نهائيًا.
 */
export const POST = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requireSession(request);
  const branchId = requireBranch(session);
  const { id } = await params;
  const body = await parseBody(request, schema);

  let approvedBy = session.sub;
  if (!hasPermission(session.permissions, 'invoices.cancel')) {
    if (!body.managerPin) throw Forbidden('إلغاء الفاتورة يحتاج اعتماد المدير');
    const manager = await verifyManagerPin(branchId, body.managerPin, 'invoices.cancel');
    approvedBy = manager.id;
  }

  const invoice = await cancelInvoice(id, session.sub, body.reason);

  await writeAudit({
    action: 'INVOICE_CANCELLED',
    entity: 'Invoice',
    entityId: id,
    userId: session.sub,
    branchId,
    newValue: { reason: body.reason, approvedBy },
    request,
  });

  return ok(invoice);
});
