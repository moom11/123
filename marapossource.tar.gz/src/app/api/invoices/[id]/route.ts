import type { NextRequest } from 'next/server';
import { ok, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';
import { NotFound } from '@/lib/api/errors';

type Ctx = { params: Promise<{ id: string }> };

/** GET /api/invoices/:id — تفاصيل الفاتورة مع سجل التعديلات */
export const GET = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requirePermission('invoices.view', request);
  const branchId = requireBranch(session);
  const { id } = await params;

  const invoice = await prisma.invoice.findFirst({
    where: { id, branchId },
    include: {
      items: true,
      payments: { include: { paymentMethod: true } },
      refunds: { include: { items: { include: { invoiceItem: true } } } },
      user: { select: { fullName: true, employeeNo: true } },
      shift: { select: { shiftNumber: true } },
      order: { select: { orderNumber: true, type: true, guestCount: true } },
      changes: { orderBy: { createdAt: 'desc' } },
      branch: { include: { company: true } },
    },
  });
  if (!invoice) throw NotFound('الفاتورة غير موجودة');
  return ok(invoice);
});
