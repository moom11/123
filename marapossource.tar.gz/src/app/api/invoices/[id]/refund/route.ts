import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { created, parseBody, route } from '@/lib/api/handler';
import { requireBranch, requireSession } from '@/lib/api/session';
import { createRefund } from '@/lib/pos/refund-service';
import { verifyManagerPin } from '@/lib/auth/auth-service';
import { hasPermission } from '@/lib/auth/permissions';
import { Forbidden } from '@/lib/api/errors';
import { writeAudit } from '@/lib/audit';
import { toNumber } from '@/lib/money';

type Ctx = { params: Promise<{ id: string }> };

const schema = z.object({
  reason: z.string().min(1, 'سبب الإرجاع مطلوب'),
  /** فارغ = إرجاع كامل الفاتورة */
  items: z
    .array(
      z.object({
        invoiceItemId: z.string().uuid(),
        quantity: z.number().positive(),
      }),
    )
    .optional(),
  shiftId: z.string().uuid().optional().nullable(),
  managerPin: z.string().optional().nullable(),
  idempotencyKey: z.string().optional().nullable(),
});

/**
 * POST /api/invoices/:id/refund — إرجاع كامل أو جزئي.
 * يُعاد المبلغ بنفس طرق الدفع الأصلية ويُرحّل إلى Odoo كإشعار دائن.
 */
export const POST = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requireSession(request);
  const branchId = requireBranch(session);
  const { id } = await params;
  const body = await parseBody(request, schema);

  let approvedById: string | null = null;
  if (!hasPermission(session.permissions, 'refunds.create')) {
    if (!body.managerPin) throw Forbidden('المرتجع يحتاج اعتماد المدير');
    const manager = await verifyManagerPin(branchId, body.managerPin, 'refunds.create');
    approvedById = manager.id;
  } else if (body.managerPin) {
    const manager = await verifyManagerPin(branchId, body.managerPin, 'refunds.create');
    approvedById = manager.id;
  }

  const refund = await createRefund({
    invoiceId: id,
    userId: session.sub,
    shiftId: body.shiftId,
    reason: body.reason,
    items: body.items,
    approvedById,
    idempotencyKey: body.idempotencyKey,
  });

  await writeAudit({
    action: 'REFUND_CREATED',
    entity: 'Refund',
    entityId: refund.id,
    userId: session.sub,
    branchId,
    newValue: {
      refundNumber: refund.refundNumber,
      grandTotal: toNumber(refund.grandTotal),
      reason: body.reason,
      approvedById,
    },
    request,
  });

  return created(refund);
});
