import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { InvoiceStatus, Prisma, SyncStatus } from '@prisma/client';
import { ok, parseQuery, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';

const querySchema = z.object({
  status: z.string().optional(),
  from: z.string().optional(),
  to: z.string().optional(),
  search: z.string().optional(),
  shiftId: z.string().uuid().optional(),
  syncStatus: z.nativeEnum(SyncStatus).optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(25),
});

/** GET /api/invoices — سجل الفواتير مع فلاتر البحث */
export const GET = route(async (request: NextRequest) => {
  const session = await requirePermission('invoices.view', request);
  const branchId = requireBranch(session);
  const query = parseQuery(request, querySchema);

  const where: Prisma.InvoiceWhereInput = {
    branchId,
    ...(query.status
      ? { status: { in: query.status.split(',') as InvoiceStatus[] } }
      : {}),
    ...(query.shiftId ? { shiftId: query.shiftId } : {}),
    ...(query.syncStatus ? { syncStatus: query.syncStatus } : {}),
    ...(query.from || query.to
      ? {
          businessDay: {
            ...(query.from ? { gte: new Date(`${query.from}T00:00:00Z`) } : {}),
            ...(query.to ? { lte: new Date(`${query.to}T00:00:00Z`) } : {}),
          },
        }
      : {}),
    ...(query.search
      ? {
          OR: [
            { invoiceNumber: { contains: query.search, mode: 'insensitive' } },
            { customerName: { contains: query.search, mode: 'insensitive' } },
            { customerPhone: { contains: query.search } },
          ],
        }
      : {}),
  };

  const [items, total] = await Promise.all([
    prisma.invoice.findMany({
      where,
      include: {
        user: { select: { fullName: true, employeeNo: true } },
        payments: { include: { paymentMethod: { select: { nameAr: true, type: true } } } },
        _count: { select: { items: true, refunds: true } },
      },
      orderBy: { createdAt: 'desc' },
      skip: (query.page - 1) * query.pageSize,
      take: query.pageSize,
    }),
    prisma.invoice.count({ where }),
  ]);

  return ok(items, { total, page: query.page, pageSize: query.pageSize });
});
