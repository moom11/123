import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { PrepStation, Prisma, SyncEntity } from '@prisma/client';
import { ok, parseBody, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';
import { NotFound, Forbidden } from '@/lib/api/errors';
import { writeAudit } from '@/lib/audit';
import { hasPermission } from '@/lib/auth/permissions';
import { toNumber } from '@/lib/money';
import { enqueueSyncJob } from '@/lib/odoo/sync-queue';

type Ctx = { params: Promise<{ id: string }> };

/** GET /api/products/:id */
export const GET = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requirePermission('products.view', request);
  const branchId = requireBranch(session);
  const { id } = await params;

  const product = await prisma.product.findFirst({
    where: { id, branchId },
    include: {
      category: true,
      vatTax: true,
      tobaccoTax: true,
      variants: { orderBy: { sortOrder: 'asc' } },
      modifierGroups: {
        orderBy: { sortOrder: 'asc' },
        include: { modifiers: { orderBy: { sortOrder: 'asc' } } },
      },
    },
  });
  if (!product) throw NotFound('المنتج غير موجود');
  return ok(product);
});

const updateSchema = z.object({
  categoryId: z.string().uuid().optional(),
  nameAr: z.string().min(1).optional(),
  nameEn: z.string().optional().nullable(),
  barcode: z.string().optional().nullable(),
  price: z.number().nonnegative().optional(),
  priceIncludesVat: z.boolean().optional(),
  vatTaxId: z.string().uuid().optional().nullable(),
  isTobacco: z.boolean().optional(),
  tobaccoTaxId: z.string().uuid().optional().nullable(),
  imageUrl: z.string().optional().nullable(),
  unit: z.string().optional(),
  isActive: z.boolean().optional(),
  showInPos: z.boolean().optional(),
  prepStation: z.nativeEnum(PrepStation).optional(),
  sortOrder: z.number().int().optional(),
});

/** PATCH /api/products/:id — تعديل منتج (تغيير السعر يحتاج صلاحية مستقلة) */
export const PATCH = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requirePermission('products.manage', request);
  const branchId = requireBranch(session);
  const { id } = await params;
  const body = await parseBody(request, updateSchema);

  const existing = await prisma.product.findFirst({ where: { id, branchId } });
  if (!existing) throw NotFound('المنتج غير موجود');

  const priceChanged =
    body.price !== undefined && toNumber(existing.price) !== body.price;
  if (priceChanged && !hasPermission(session.permissions, 'products.change_price')) {
    throw Forbidden('لا تملك صلاحية تعديل الأسعار');
  }

  const product = await prisma.product.update({
    where: { id },
    data: {
      ...body,
      ...(body.price !== undefined
        ? { price: new Prisma.Decimal(body.price.toFixed(4)) }
        : {}),
    },
  });

  await writeAudit({
    action: priceChanged ? 'PRICE_CHANGE' : 'PRODUCT_UPDATED',
    entity: 'Product',
    entityId: id,
    userId: session.sub,
    branchId,
    oldValue: { price: toNumber(existing.price), nameAr: existing.nameAr },
    newValue: body,
    request,
  });

  const odoo = await prisma.odooSetting.findUnique({ where: { branchId } });
  if (odoo?.isEnabled && odoo.productSyncDirection !== 'ODOO_TO_POS') {
    await enqueueSyncJob(prisma, {
      branchId,
      entity: SyncEntity.PRODUCT,
      entityId: id,
      idempotencyKey: `product:${id}:${Date.now()}`,
    });
  }

  return ok(product);
});

/** DELETE /api/products/:id — تعطيل المنتج (لا يُحذف نهائيًا) */
export const DELETE = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requirePermission('products.manage', request);
  const branchId = requireBranch(session);
  const { id } = await params;

  const existing = await prisma.product.findFirst({ where: { id, branchId } });
  if (!existing) throw NotFound('المنتج غير موجود');

  const product = await prisma.product.update({
    where: { id },
    data: { isActive: false, showInPos: false },
  });

  await writeAudit({
    action: 'PRODUCT_UPDATED',
    entity: 'Product',
    entityId: id,
    userId: session.sub,
    branchId,
    oldValue: { isActive: true },
    newValue: { isActive: false },
    request,
  });

  return ok(product);
});
