import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { PrepStation, Prisma, SyncEntity } from '@prisma/client';
import { created, ok, parseBody, parseQuery, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';
import { writeAudit } from '@/lib/audit';
import { enqueueSyncJob } from '@/lib/odoo/sync-queue';

const querySchema = z.object({
  categoryId: z.string().uuid().optional(),
  search: z.string().optional(),
  posOnly: z.enum(['true', 'false']).optional(),
  includeInactive: z.enum(['true', 'false']).optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(200).default(100),
});

/** GET /api/products — قائمة المنتجات مع الخيارات والإضافات */
export const GET = route(async (request: NextRequest) => {
  const session = await requirePermission('products.view', request);
  const branchId = requireBranch(session);
  const query = parseQuery(request, querySchema);

  const where: Prisma.ProductWhereInput = {
    branchId,
    ...(query.categoryId ? { categoryId: query.categoryId } : {}),
    ...(query.posOnly === 'true' ? { showInPos: true } : {}),
    ...(query.includeInactive === 'true' ? {} : { isActive: true }),
    ...(query.search
      ? {
          OR: [
            { nameAr: { contains: query.search, mode: 'insensitive' } },
            { nameEn: { contains: query.search, mode: 'insensitive' } },
            { sku: { contains: query.search, mode: 'insensitive' } },
            { barcode: { contains: query.search, mode: 'insensitive' } },
          ],
        }
      : {}),
  };

  const [items, total] = await Promise.all([
    prisma.product.findMany({
      where,
      include: {
        category: { select: { id: true, nameAr: true, color: true } },
        vatTax: { select: { id: true, nameAr: true, rate: true } },
        tobaccoTax: { select: { id: true, nameAr: true, rate: true, tobaccoBase: true } },
        variants: { where: { isActive: true }, orderBy: { sortOrder: 'asc' } },
        modifierGroups: {
          orderBy: { sortOrder: 'asc' },
          include: {
            modifiers: { where: { isActive: true }, orderBy: { sortOrder: 'asc' } },
          },
        },
      },
      orderBy: [{ sortOrder: 'asc' }, { nameAr: 'asc' }],
      skip: (query.page - 1) * query.pageSize,
      take: query.pageSize,
    }),
    prisma.product.count({ where }),
  ]);

  return ok(items, { total, page: query.page, pageSize: query.pageSize });
});

const createSchema = z.object({
  categoryId: z.string().uuid(),
  nameAr: z.string().min(1),
  nameEn: z.string().optional().nullable(),
  sku: z.string().min(1),
  barcode: z.string().optional().nullable(),
  price: z.number().nonnegative(),
  priceIncludesVat: z.boolean().default(true),
  vatTaxId: z.string().uuid().optional().nullable(),
  isTobacco: z.boolean().default(false),
  tobaccoTaxId: z.string().uuid().optional().nullable(),
  imageUrl: z.string().optional().nullable(),
  unit: z.string().default('PCS'),
  isActive: z.boolean().default(true),
  showInPos: z.boolean().default(true),
  prepStation: z.nativeEnum(PrepStation).default(PrepStation.KITCHEN),
  sortOrder: z.number().int().default(0),
});

/** POST /api/products — إنشاء منتج جديد */
export const POST = route(async (request: NextRequest) => {
  const session = await requirePermission('products.manage', request);
  const branchId = requireBranch(session);
  const body = await parseBody(request, createSchema);

  const product = await prisma.product.create({
    data: { ...body, branchId, price: new Prisma.Decimal(body.price.toFixed(4)) },
  });

  await writeAudit({
    action: 'PRODUCT_CREATED',
    entity: 'Product',
    entityId: product.id,
    userId: session.sub,
    branchId,
    newValue: body,
    request,
  });

  // مزامنة المنتج مع Odoo عند تفعيل الاتجاه المناسب
  const odoo = await prisma.odooSetting.findUnique({ where: { branchId } });
  if (odoo?.isEnabled && odoo.productSyncDirection !== 'ODOO_TO_POS') {
    await enqueueSyncJob(prisma, {
      branchId,
      entity: SyncEntity.PRODUCT,
      entityId: product.id,
      idempotencyKey: `product:${product.id}:${Date.now()}`,
    });
  }

  return created(product);
});
