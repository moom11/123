import type { NextRequest } from 'next/server';
import { ok, route } from '@/lib/api/handler';
import { requirePermission } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';

/** GET /api/expense-categories — تصنيفات المصروفات */
export const GET = route(async (request: NextRequest) => {
  await requirePermission('cash.manage', request);
  return ok(
    await prisma.expenseCategory.findMany({
      where: { isActive: true },
      orderBy: { nameAr: 'asc' },
    }),
  );
});
