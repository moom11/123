import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { KitchenTicketStatus, PrepStation } from '@prisma/client';
import { ok, parseQuery, route } from '@/lib/api/handler';
import { requireBranch, requireSession } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';

const schema = z.object({
  station: z.nativeEnum(PrepStation).optional(),
  status: z.nativeEnum(KitchenTicketStatus).optional(),
});

/** GET /api/kitchen-tickets — تذاكر التحضير حسب المحطة (مطبخ/بار/شيشة) */
export const GET = route(async (request: NextRequest) => {
  const session = await requireSession(request);
  const branchId = requireBranch(session);
  const query = parseQuery(request, schema);

  const tickets = await prisma.kitchenTicket.findMany({
    where: {
      order: { branchId },
      ...(query.station ? { station: query.station } : {}),
      ...(query.status
        ? { status: query.status }
        : { status: { notIn: ['SERVED', 'CANCELLED'] } }),
    },
    include: {
      order: {
        select: { orderNumber: true, type: true, table: { select: { number: true } } },
      },
    },
    orderBy: { createdAt: 'asc' },
    take: 100,
  });

  return ok(tickets);
});
