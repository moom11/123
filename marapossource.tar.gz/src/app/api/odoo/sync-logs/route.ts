import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { ok, parseQuery, route } from '@/lib/api/handler';
import { requirePermission } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';

const schema = z.object({
  syncJobId: z.string().uuid().optional(),
  limit: z.coerce.number().int().min(1).max(200).default(50),
});

/** GET /api/odoo/sync-logs — السجل الفني للطلبات والردود (بدون بيانات اعتماد) */
export const GET = route(async (request: NextRequest) => {
  await requirePermission('odoo.view_sync', request);
  const query = parseQuery(request, schema);

  return ok(
    await prisma.syncLog.findMany({
      where: query.syncJobId ? { syncJobId: query.syncJobId } : {},
      orderBy: { createdAt: 'desc' },
      take: query.limit,
    }),
  );
});
