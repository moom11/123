import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { ok, parseBody, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { buildDailyClosing } from '@/lib/reports/report-service';
import { scheduleDailySummary } from '@/lib/odoo/integration-service';
import { currentBusinessDay } from '@/lib/settings';
import { parseBusinessDay } from '@/lib/business-day';
import { prisma } from '@/lib/prisma';
import { UnprocessableEntity } from '@/lib/api/errors';

const schema = z.object({
  businessDay: z.string().optional(),
  /** إغلاق اليوم نهائيًا بعد بناء الملخص */
  close: z.boolean().default(false),
});

/**
 * POST /api/odoo/daily-summary — بناء الملخص اليومي وجدولة ترحيله إلى Odoo.
 * هذا هو الوضع الافتراضي لتقليل عدد العمليات داخل Odoo.
 */
export const POST = route(async (request: NextRequest) => {
  const session = await requirePermission('odoo.retry_sync', request);
  const branchId = requireBranch(session);
  const body = await parseBody(request, schema);

  const businessDay = body.businessDay
    ? parseBusinessDay(body.businessDay)
    : await currentBusinessDay(branchId);

  const closing = await buildDailyClosing(branchId, businessDay);

  const settings = await prisma.odooSetting.findUnique({ where: { branchId } });
  if (!settings?.isEnabled) {
    throw UnprocessableEntity('الربط مع Odoo غير مفعل — تم بناء الملخص دون ترحيله');
  }
  if (settings.postingMode !== 'DAILY_SUMMARY') {
    throw UnprocessableEntity(
      'وضع الترحيل الحالي هو «إرسال كل فاتورة» — غيّره إلى الملخص اليومي أولًا',
    );
  }

  const job = await scheduleDailySummary(branchId, closing.id);

  if (body.close) {
    await prisma.dailyClosing.update({
      where: { id: closing.id },
      data: { isClosed: true, closedAt: new Date(), closedById: session.sub },
    });
  }

  return ok({ closing, job });
});

/** GET /api/odoo/daily-summary — عرض ملخص يوم تشغيلي دون ترحيله */
export const GET = route(async (request: NextRequest) => {
  const session = await requirePermission('reports.view', request);
  const branchId = requireBranch(session);
  const day = new URL(request.url).searchParams.get('businessDay');
  const businessDay = day ? parseBusinessDay(day) : await currentBusinessDay(branchId);
  return ok(await buildDailyClosing(branchId, businessDay));
});
