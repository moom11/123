import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { OdooPostingMode, OdooProtocol, ProductSyncDirection } from '@prisma/client';
import { ok, parseBody, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';
import { encryptSecret } from '@/lib/crypto';
import { writeAudit } from '@/lib/audit';

/** GET /api/odoo/settings — إعدادات الربط (مفتاح API لا يُعاد أبدًا) */
export const GET = route(async (request: NextRequest) => {
  const session = await requirePermission('odoo.configure', request);
  const branchId = requireBranch(session);

  const settings = await prisma.odooSetting.findUnique({ where: { branchId } });
  if (!settings) return ok(null);

  const { apiKeyEncrypted, ...safe } = settings;
  return ok({ ...safe, hasApiKey: Boolean(apiKeyEncrypted) });
});

const schema = z.object({
  isEnabled: z.boolean().optional(),
  url: z.string().url('رابط Odoo غير صالح').optional(),
  database: z.string().optional(),
  username: z.string().optional(),
  /** يُرسل فقط عند التغيير — يُخزن مشفرًا */
  apiKey: z.string().optional().nullable(),
  protocol: z.nativeEnum(OdooProtocol).optional(),
  odooCompanyId: z.number().int().optional().nullable(),
  analyticAccountId: z.number().int().optional().nullable(),
  salesJournalId: z.number().int().optional().nullable(),
  cashJournalId: z.number().int().optional().nullable(),
  bankJournalId: z.number().int().optional().nullable(),
  vatAccountId: z.number().int().optional().nullable(),
  tobaccoTaxAccountId: z.number().int().optional().nullable(),
  discountAccountId: z.number().int().optional().nullable(),
  refundAccountId: z.number().int().optional().nullable(),
  cashDiffAccountId: z.number().int().optional().nullable(),
  defaultPartnerId: z.number().int().optional().nullable(),
  postingMode: z.nativeEnum(OdooPostingMode).optional(),
  productSyncDirection: z.nativeEnum(ProductSyncDirection).optional(),
  odooIsMasterOnConflict: z.boolean().optional(),
  maxSyncAttempts: z.number().int().min(1).max(20).optional(),
});

/** PUT /api/odoo/settings — حفظ إعدادات الربط مع تشفير بيانات الاعتماد */
export const PUT = route(async (request: NextRequest) => {
  const session = await requirePermission('odoo.configure', request);
  const branchId = requireBranch(session);
  const body = await parseBody(request, schema);

  const { apiKey, odooCompanyId, ...rest } = body;
  const data = {
    ...rest,
    ...(odooCompanyId !== undefined ? { companyId: odooCompanyId } : {}),
    ...(apiKey ? { apiKeyEncrypted: encryptSecret(apiKey) } : {}),
  };

  const existing = await prisma.odooSetting.findUnique({ where: { branchId } });
  const settings = await prisma.odooSetting.upsert({
    where: { branchId },
    create: { branchId, ...data },
    update: data,
  });

  await writeAudit({
    action: 'ODOO_SETTINGS_UPDATED',
    entity: 'OdooSetting',
    entityId: settings.id,
    userId: session.sub,
    branchId,
    oldValue: existing
      ? { isEnabled: existing.isEnabled, url: existing.url, postingMode: existing.postingMode }
      : null,
    newValue: { ...data, apiKeyEncrypted: undefined, apiKeyChanged: Boolean(apiKey) },
    request,
  });

  const { apiKeyEncrypted, ...safe } = settings;
  return ok({ ...safe, hasApiKey: Boolean(apiKeyEncrypted) });
});
