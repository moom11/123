import type { NextRequest } from 'next/server';
import { ok, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { testOdooConnection } from '@/lib/odoo/integration-service';

/** POST /api/odoo/test — اختبار الاتصال بخادم Odoo */
export const POST = route(async (request: NextRequest) => {
  const session = await requirePermission('odoo.configure', request);
  const branchId = requireBranch(session);
  return ok(await testOdooConnection(branchId));
});
