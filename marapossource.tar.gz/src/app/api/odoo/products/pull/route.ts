import type { NextRequest } from 'next/server';
import { ok, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { pullProductsFromOdoo } from '@/lib/odoo/integration-service';
import { writeAudit } from '@/lib/audit';

/** POST /api/odoo/products/pull — جلب المنتجات والأسعار من Odoo */
export const POST = route(async (request: NextRequest) => {
  const session = await requirePermission('odoo.configure', request);
  const branchId = requireBranch(session);

  const result = await pullProductsFromOdoo(branchId);

  await writeAudit({
    action: 'SYNC_RETRY',
    entity: 'Product',
    userId: session.sub,
    branchId,
    newValue: result,
    request,
  });

  return ok(result);
});
