import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { SyncEntity, SyncStatus } from '@prisma/client';
import { ok, parseQuery, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';

const schema = z.object({
  status: z.string().optional(),
  entity: z.nativeEnum(SyncEntity).optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(25),
});

/** GET /api/odoo/sync-jobs — سجل مهام المزامنة مع إحصاء الحالات */
export const GET = route(async (request: NextRequest) => {
  const session = await requirePermission('odoo.view_sync', request);
  const branchId = requireBranch(session);
  const query = parseQuery(request, schema);

  const where = {
    branchId,
    ...(query.status
      ? { status: { in: query.status.split(',') as SyncStatus[] } }
      : {}),
    ...(query.entity ? { entity: query.entity } : {}),
  };

  const [items, total, grouped] = await Promise.all([
    prisma.syncJob.findMany({
      where,
      include: { logs: { orderBy: { createdAt: 'desc' }, take: 3 } },
      orderBy: { createdAt: 'desc' },
      skip: (query.page - 1) * query.pageSize,
      take: query.pageSize,
    }),
    prisma.syncJob.count({ where }),
    prisma.syncJob.groupBy({
      by: ['status'],
      where: { branchId },
      _count: { _all: true },
    }),
  ]);

  const counts = Object.fromEntries(
    grouped.map((g) => [g.status, g._count._all]),
  ) as Record<SyncStatus, number>;

  return ok(items, { total, page: query.page, pageSize: query.pageSize, counts });
});
