import type { NextRequest } from 'next/server';
import { ok, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { retryJob } from '@/lib/odoo/sync-queue';
import { NotFound } from '@/lib/api/errors';
import { writeAudit } from '@/lib/audit';

type Ctx = { params: Promise<{ id: string }> };

/** POST /api/odoo/sync-jobs/:id/retry — إعادة إرسال عملية فاشلة يدويًا */
export const POST = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requirePermission('odoo.retry_sync', request);
  const branchId = requireBranch(session);
  const { id } = await params;

  const job = await retryJob(id);
  if (!job) throw NotFound('مهمة المزامنة غير موجودة');

  await writeAudit({
    action: 'SYNC_RETRY',
    entity: 'SyncJob',
    entityId: id,
    userId: session.sub,
    branchId,
    newValue: { entity: job.entity, entityId: job.entityId },
    request,
  });

  return ok(job);
});
