import type { NextRequest } from 'next/server';
import { ok, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { retryAllFailed } from '@/lib/odoo/sync-queue';
import { writeAudit } from '@/lib/audit';

/** POST /api/odoo/sync-jobs/retry-all — إعادة جدولة جميع العمليات الفاشلة */
export const POST = route(async (request: NextRequest) => {
  const session = await requirePermission('odoo.retry_sync', request);
  const branchId = requireBranch(session);

  const count = await retryAllFailed(branchId);

  await writeAudit({
    action: 'SYNC_RETRY',
    entity: 'SyncJob',
    userId: session.sub,
    branchId,
    newValue: { retriedCount: count },
    request,
  });

  return ok({ retriedCount: count });
});
