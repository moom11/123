import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { Prisma, TobaccoTaxBase } from '@prisma/client';
import { ok, parseBody, route } from '@/lib/api/handler';
import { requirePermission } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';
import { NotFound } from '@/lib/api/errors';
import { writeAudit } from '@/lib/audit';
import { toNumber } from '@/lib/money';

type Ctx = { params: Promise<{ id: string }> };

const updateSchema = z.object({
  nameAr: z.string().min(1).optional(),
  rate: z.number().min(0).max(1000).optional(),
  tobaccoBase: z.nativeEnum(TobaccoTaxBase).optional().nullable(),
  fixedAmount: z.number().min(0).optional().nullable(),
  minAmountPerUnit: z.number().min(0).optional().nullable(),
  isDefault: z.boolean().optional(),
  isActive: z.boolean().optional(),
});

/**
 * PATCH /api/taxes/:id — تعديل نسبة ضريبة.
 * ملاحظة: الفواتير القديمة لا تتأثر لأن الضرائب مخزنة كنسخة ثابتة داخلها.
 */
export const PATCH = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requirePermission('taxes.manage', request);
  const { id } = await params;
  const body = await parseBody(request, updateSchema);

  const existing = await prisma.tax.findUnique({ where: { id } });
  if (!existing) throw NotFound('الضريبة غير موجودة');

  const tax = await prisma.tax.update({
    where: { id },
    data: {
      ...body,
      ...(body.rate !== undefined
        ? { rate: new Prisma.Decimal(body.rate.toFixed(4)) }
        : {}),
      ...(body.fixedAmount !== undefined
        ? {
            fixedAmount:
              body.fixedAmount != null
                ? new Prisma.Decimal(body.fixedAmount.toFixed(4))
                : null,
          }
        : {}),
      ...(body.minAmountPerUnit !== undefined
        ? {
            minAmountPerUnit:
              body.minAmountPerUnit != null
                ? new Prisma.Decimal(body.minAmountPerUnit.toFixed(4))
                : null,
          }
        : {}),
    },
  });

  await writeAudit({
    action: 'TAX_UPDATED',
    entity: 'Tax',
    entityId: id,
    userId: session.sub,
    branchId: session.branchId,
    oldValue: { rate: toNumber(existing.rate), isActive: existing.isActive },
    newValue: body,
    request,
  });

  return ok(tax);
});
