import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { Prisma, TaxType, TobaccoTaxBase } from '@prisma/client';
import { created, ok, parseBody, route } from '@/lib/api/handler';
import { requirePermission } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';
import { writeAudit } from '@/lib/audit';

/** GET /api/taxes — الضرائب المعرفة (القيمة المضافة والتبغ) */
export const GET = route(async (request: NextRequest) => {
  await requirePermission('taxes.view', request);
  return ok(await prisma.tax.findMany({ orderBy: [{ type: 'asc' }, { code: 'asc' }] }));
});

const createSchema = z.object({
  code: z.string().min(1),
  nameAr: z.string().min(1),
  nameEn: z.string().optional().nullable(),
  type: z.nativeEnum(TaxType),
  rate: z.number().min(0).max(1000),
  tobaccoBase: z.nativeEnum(TobaccoTaxBase).optional().nullable(),
  fixedAmount: z.number().min(0).optional().nullable(),
  minAmountPerUnit: z.number().min(0).optional().nullable(),
  isDefault: z.boolean().default(false),
  isActive: z.boolean().default(true),
});

/** POST /api/taxes — إنشاء ضريبة جديدة */
export const POST = route(async (request: NextRequest) => {
  const session = await requirePermission('taxes.manage', request);
  const body = await parseBody(request, createSchema);

  const tax = await prisma.tax.create({
    data: {
      ...body,
      rate: new Prisma.Decimal(body.rate.toFixed(4)),
      fixedAmount:
        body.fixedAmount != null ? new Prisma.Decimal(body.fixedAmount.toFixed(4)) : null,
      minAmountPerUnit:
        body.minAmountPerUnit != null
          ? new Prisma.Decimal(body.minAmountPerUnit.toFixed(4))
          : null,
    },
  });

  await writeAudit({
    action: 'TAX_UPDATED',
    entity: 'Tax',
    entityId: tax.id,
    userId: session.sub,
    branchId: session.branchId,
    newValue: body,
    request,
  });
  return created(tax);
});
