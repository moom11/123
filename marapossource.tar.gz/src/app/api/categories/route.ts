import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { created, ok, parseBody, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';

/** GET /api/categories — تصنيفات المنتجات مع عدد المنتجات النشطة */
export const GET = route(async (request: NextRequest) => {
  const session = await requirePermission('products.view', request);
  const branchId = requireBranch(session);

  const categories = await prisma.category.findMany({
    where: { branchId, isActive: true },
    orderBy: [{ sortOrder: 'asc' }, { nameAr: 'asc' }],
    include: {
      _count: { select: { products: { where: { isActive: true, showInPos: true } } } },
    },
  });
  return ok(categories);
});

const createSchema = z.object({
  nameAr: z.string().min(1),
  nameEn: z.string().optional().nullable(),
  color: z.string().default('#C8102E'),
  iconEmoji: z.string().optional().nullable(),
  sortOrder: z.number().int().default(0),
});

/** POST /api/categories */
export const POST = route(async (request: NextRequest) => {
  const session = await requirePermission('products.manage', request);
  const branchId = requireBranch(session);
  const body = await parseBody(request, createSchema);
  return created(await prisma.category.create({ data: { ...body, branchId } }));
});
