import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { ok, parseBody, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';
import { NotFound } from '@/lib/api/errors';

type Ctx = { params: Promise<{ id: string }> };

const updateSchema = z.object({
  nameAr: z.string().min(1).optional(),
  nameEn: z.string().optional().nullable(),
  color: z.string().optional(),
  iconEmoji: z.string().optional().nullable(),
  sortOrder: z.number().int().optional(),
  isActive: z.boolean().optional(),
});

/** PATCH /api/categories/:id */
export const PATCH = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requirePermission('products.manage', request);
  const branchId = requireBranch(session);
  const { id } = await params;
  const existing = await prisma.category.findFirst({ where: { id, branchId } });
  if (!existing) throw NotFound('التصنيف غير موجود');
  return ok(await prisma.category.update({ where: { id }, data: await parseBody(request, updateSchema) }));
});

/** DELETE /api/categories/:id — تعطيل التصنيف */
export const DELETE = route<Ctx>(async (request: NextRequest, { params }) => {
  const session = await requirePermission('products.manage', request);
  const branchId = requireBranch(session);
  const { id } = await params;
  const existing = await prisma.category.findFirst({ where: { id, branchId } });
  if (!existing) throw NotFound('التصنيف غير موجود');
  return ok(await prisma.category.update({ where: { id }, data: { isActive: false } }));
});
