import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { created, route } from '@/lib/api/handler';
import { BadRequest } from '@/lib/api/errors';
import { requirePermission } from '@/lib/api/session';
import type { PermissionCode } from '@/lib/auth/permissions';
import { storeUpload, type UploadKind } from '@/lib/uploads';
import { writeAudit } from '@/lib/audit';

export const dynamic = 'force-dynamic';

const kindSchema = z.enum(['products', 'expenses']);

/** الصلاحية المطلوبة لكل نوع رفع */
const PERMISSION_BY_KIND: Record<UploadKind, PermissionCode> = {
  products: 'products.manage',
  expenses: 'cash.manage',
};

/**
 * POST /api/uploads — رفع صورة (multipart/form-data)
 *   الحقول: file (الملف) · kind (products | expenses)
 * يعيد الرابط العام ليُحفظ في imageUrl للمنتج أو مستند المصروف.
 */
export const POST = route(
  async (request: NextRequest) => {
    let form: FormData;
    try {
      form = await request.formData();
    } catch {
      throw BadRequest('الطلب يجب أن يكون multipart/form-data');
    }

    const kind = kindSchema.parse(form.get('kind') ?? 'products');
    const session = await requirePermission(PERMISSION_BY_KIND[kind], request);

    const file = form.get('file');
    if (!(file instanceof File)) throw BadRequest('لم يُرفق أي ملف في الحقل file');

    const stored = await storeUpload(file, kind);

    await writeAudit({
      userId: session.sub,
      branchId: session.branchId ?? null,
      action: 'FILE_UPLOADED',
      entity: 'Upload',
      entityId: stored.url,
      newValue: { kind, mime: stored.mime, size: stored.size },
      request,
    });

    return created(stored);
  },
  // الرفع أثقل من طلب عادي — حد أقل لمنع إغراق القرص
  { rateLimit: { max: 30, windowMs: 60_000, scope: 'uploads' } },
);
