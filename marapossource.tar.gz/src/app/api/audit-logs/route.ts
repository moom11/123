import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { ok, parseQuery, route } from '@/lib/api/handler';
import { requireBranch, requirePermission } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';

const schema = z.object({
  action: z.string().optional(),
  entity: z.string().optional(),
  userId: z.string().uuid().optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(50),
});

/** GET /api/audit-logs — سجل التدقيق */
export const GET = route(async (request: NextRequest) => {
  const session = await requirePermission('audit.view', request);
  const branchId = requireBranch(session);
  const query = parseQuery(request, schema);

  const where = {
    branchId,
    ...(query.action ? { action: query.action } : {}),
    ...(query.entity ? { entity: query.entity } : {}),
    ...(query.userId ? { userId: query.userId } : {}),
  };

  const [items, total] = await Promise.all([
    prisma.auditLog.findMany({
      where,
      include: { user: { select: { fullName: true, employeeNo: true } } },
      orderBy: { createdAt: 'desc' },
      skip: (query.page - 1) * query.pageSize,
      take: query.pageSize,
    }),
    prisma.auditLog.count({ where }),
  ]);

  return ok(items, { total, page: query.page, pageSize: query.pageSize });
});
