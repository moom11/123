import type { NextRequest } from 'next/server';
import { ok, route } from '@/lib/api/handler';
import { requireBranch, requireSession } from '@/lib/api/session';
import { prisma } from '@/lib/prisma';

/** GET /api/floors — الأدوار والمناطق مع طاولاتها */
export const GET = route(async (request: NextRequest) => {
  const session = await requireSession(request);
  const branchId = requireBranch(session);

  const floors = await prisma.floor.findMany({
    where: { branchId, isActive: true },
    orderBy: { sortOrder: 'asc' },
    include: {
      areas: {
        where: { isActive: true },
        orderBy: { sortOrder: 'asc' },
        include: {
          tables: {
            where: { isActive: true },
            orderBy: { number: 'asc' },
          },
        },
      },
    },
  });
  return ok(floors);
});
