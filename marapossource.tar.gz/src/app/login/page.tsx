'use client';

import { useState, type FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { api, ApiClientError } from '@/lib/client/api';
import { ErrorAlert, Spinner } from '@/components/ui';

const DEMO_ACCOUNTS = [
  { role: 'مدير النظام', employeeNo: '1001', password: 'Admin@1234' },
  { role: 'مدير الفرع', employeeNo: '1002', password: 'Manager@1234' },
  { role: 'كاشير', employeeNo: '1003', password: 'Cashier@1234' },
  { role: 'مقدم الطلب', employeeNo: '1004', password: 'Waiter@1234' },
];

export default function LoginPage() {
  const router = useRouter();
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await api.post('/api/auth/login', { identifier, password });
      router.replace('/dashboard');
      router.refresh();
    } catch (err) {
      setError(
        err instanceof ApiClientError ? err.message : 'تعذر تسجيل الدخول، حاول مجددًا',
      );
    } finally {
      setBusy(false);
    }
  }

  function fillDemo(account: (typeof DEMO_ACCOUNTS)[number]) {
    setIdentifier(account.employeeNo);
    setPassword(account.password);
    setError(null);
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-gradient-to-bl from-ink via-neutral-900 to-[var(--brand-primary)] p-4">
      <div className="w-full max-w-md">
        <div className="mb-6 text-center text-white">
          <div className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-white/10 text-3xl backdrop-blur">
            ☕
          </div>
          <h1 className="text-2xl font-bold">مارا لاونج</h1>
          <p className="mt-1 text-sm text-white/70">نظام نقاط البيع والمحاسبة</p>
        </div>

        <form onSubmit={submit} className="card space-y-4 p-6">
          <div>
            <label className="label" htmlFor="identifier">
              رقم الموظف أو البريد الإلكتروني
            </label>
            <input
              id="identifier"
              className="input"
              value={identifier}
              onChange={(event) => setIdentifier(event.target.value)}
              autoComplete="username"
              autoFocus
              required
              placeholder="1003"
            />
          </div>

          <div>
            <label className="label" htmlFor="password">
              كلمة المرور
            </label>
            <input
              id="password"
              type="password"
              className="input"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              autoComplete="current-password"
              required
              placeholder="••••••••"
            />
          </div>

          <ErrorAlert message={error} />

          <button type="submit" className="btn-primary btn-touch w-full" disabled={busy}>
            {busy && <Spinner className="h-4 w-4" />}
            تسجيل الدخول
          </button>
        </form>

        <div className="mt-5 rounded-2xl bg-white/10 p-4 text-white backdrop-blur">
          <p className="mb-2 text-xs font-semibold text-white/80">
            الحسابات التجريبية — اضغط للتعبئة السريعة
          </p>
          <div className="grid grid-cols-2 gap-2">
            {DEMO_ACCOUNTS.map((account) => (
              <button
                key={account.employeeNo}
                type="button"
                onClick={() => fillDemo(account)}
                className="rounded-xl bg-white/10 px-3 py-2 text-right text-xs transition hover:bg-white/20"
              >
                <span className="block font-semibold">{account.role}</span>
                <span className="tabular block text-white/60">{account.employeeNo}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </main>
  );
}
