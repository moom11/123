/** أنواع مشتركة بين الواجهة والخادم */

export interface CategoryDto {
  id: string;
  nameAr: string;
  color: string;
  iconEmoji: string | null;
  sortOrder: number;
  _count?: { products: number };
}

export interface ModifierDto {
  id: string;
  nameAr: string;
  priceDelta: string | number;
  isDefault: boolean;
}

export interface ModifierGroupDto {
  id: string;
  nameAr: string;
  selectionType: 'SINGLE' | 'MULTIPLE';
  isRequired: boolean;
  minSelect: number;
  maxSelect: number;
  modifiers: ModifierDto[];
}

export interface VariantDto {
  id: string;
  nameAr: string;
  priceDelta: string | number;
  isDefault: boolean;
}

export interface ProductDto {
  id: string;
  nameAr: string;
  nameEn: string | null;
  sku: string;
  barcode: string | null;
  price: string | number;
  priceIncludesVat: boolean;
  isTobacco: boolean;
  imageUrl: string | null;
  unit: string;
  isActive: boolean;
  showInPos: boolean;
  prepStation: 'KITCHEN' | 'BAR' | 'SHISHA' | 'NONE';
  categoryId: string;
  sortOrder: number;
  odooProductId: number | null;
  syncStatus: string;
  lastSyncAt: string | null;
  category?: { id: string; nameAr: string; color: string };
  vatTax?: { id: string; nameAr: string; rate: string | number } | null;
  tobaccoTax?: { id: string; nameAr: string; rate: string | number } | null;
  variants?: VariantDto[];
  modifierGroups?: ModifierGroupDto[];
}

export interface OrderItemDto {
  id: string;
  productId: string;
  variantId: string | null;
  nameAr: string;
  sku: string;
  quantity: string | number;
  unitPrice: string | number;
  modifiersPrice: string | number;
  lineSubtotal: string | number;
  discountAmount: string | number;
  netBeforeTax: string | number;
  vatRate: string | number;
  vatAmount: string | number;
  isTobacco: boolean;
  tobaccoTaxAmount: string | number;
  lineTotal: string | number;
  prepStation: string;
  note: string | null;
  isVoided: boolean;
  modifiers: { name: string; priceDelta: number }[] | null;
}

export interface DiscountDto {
  id: string;
  type: string;
  scope: string;
  value: string | number;
  amount: string | number;
  reason: string | null;
  orderItemId: string | null;
  offerId?: string | null;
  offer?: { id: string; nameAr: string } | null;
}

export interface OfferComponentDto {
  id: string;
  nameAr: string;
  quantity: number;
  categoryIds: string[];
  productIds: string[];
  maxUnitPrice: string | number | null;
  minUnitPrice: string | number | null;
  tobaccoOnly: boolean | null;
  sortOrder: number;
}

export interface OfferDto {
  id: string;
  nameAr: string;
  description: string | null;
  fixedPrice: string | number;
  isActive: boolean;
  priority: number;
  startsAt: string | null;
  endsAt: string | null;
  daysOfWeek: number[];
  startTime: string | null;
  endTime: string | null;
  maxPerOrder: number;
  components: OfferComponentDto[];
}

export interface OrderDto {
  id: string;
  orderNumber: string;
  type: 'DINE_IN' | 'TAKEAWAY' | 'PICKUP' | 'DELIVERY';
  status: string;
  tableId: string | null;
  guestCount: number | null;
  businessDay: string;
  subtotal: string | number;
  discountTotal: string | number;
  vatTotal: string | number;
  tobaccoTaxTotal: string | number;
  grandTotal: string | number;
  note: string | null;
  createdAt: string;
  items: OrderItemDto[];
  discounts?: DiscountDto[];
  dismissedOfferIds?: string[];
  table?: { id: string; number: string; nameAr: string | null; status: string } | null;
  user?: { id: string; fullName: string; employeeNo: string };
}

export interface TableDto {
  id: string;
  number: string;
  nameAr: string | null;
  seats: number;
  status: 'AVAILABLE' | 'OCCUPIED' | 'AWAITING_PAYMENT' | 'RESERVED' | 'NEEDS_CLEANING';
  floorId: string;
  areaId: string | null;
  floor?: { id: string; nameAr: string };
  area?: { id: string; nameAr: string } | null;
  orders?: {
    id: string;
    orderNumber: string;
    status: string;
    grandTotal: string | number;
    guestCount: number | null;
    createdAt: string;
    user?: { fullName: string };
  }[];
}

export interface FloorDto {
  id: string;
  nameAr: string;
  areas: { id: string; nameAr: string; tables: TableDto[] }[];
}

export interface PaymentMethodDto {
  id: string;
  code: string;
  nameAr: string;
  type: string;
  affectsCashDrawer: boolean;
  isActive: boolean;
}

export interface InvoiceDto {
  id: string;
  invoiceNumber: string;
  reference: string;
  status: string;
  type: string;
  businessDay: string;
  tableNumber: string | null;
  customerName: string | null;
  subtotal: string | number;
  discountTotal: string | number;
  netBeforeTax: string | number;
  vatTotal: string | number;
  tobaccoTaxTotal: string | number;
  grandTotal: string | number;
  paidTotal: string | number;
  changeDue: string | number;
  refundedTotal: string | number;
  qrPayload: string | null;
  syncStatus: string;
  odooRecordId: number | null;
  createdAt: string;
  closedAt: string | null;
  items?: InvoiceItemDto[];
  payments?: {
    id: string;
    amount: string | number;
    paymentMethod: { nameAr: string; type: string };
  }[];
  user?: { fullName: string; employeeNo: string };
  _count?: { items: number; refunds: number };
}

export interface InvoiceItemDto {
  id: string;
  nameAr: string;
  sku: string;
  quantity: string | number;
  unitPrice: string | number;
  netBeforeTax: string | number;
  discountAmount: string | number;
  vatAmount: string | number;
  isTobacco: boolean;
  tobaccoTaxAmount: string | number;
  lineTotal: string | number;
  refundedQuantity: string | number;
  note: string | null;
}

export interface ShiftSummaryDto {
  shiftId: string;
  shiftNumber: string;
  status: string;
  openedAt: string;
  closedAt: string | null;
  cashierName: string;
  openingFloat: number;
  cashSales: number;
  cardSales: number;
  otherSales: number;
  totalSales: number;
  refunds: number;
  expenses: number;
  withdrawals: number;
  deposits: number;
  employeeAdvances: number;
  drawerOpenCount: number;
  invoiceCount: number;
  expectedCash: number;
  countedCash: number | null;
  cashDifference: number | null;
  vatTotal: number;
  tobaccoTaxTotal: number;
  discountTotal: number;
}

export interface ShiftDto {
  id: string;
  shiftNumber: string;
  status: 'OPEN' | 'CLOSED' | 'PENDING_APPROVAL';
  businessDay: string;
  openedAt: string;
  closedAt: string | null;
  openingFloat: string | number;
  expectedCash: string | number | null;
  countedCash: string | number | null;
  cashDifference: string | number | null;
  differenceReason: string | null;
  user?: { fullName: string; employeeNo: string };
  device?: { name: string } | null;
  summary?: ShiftSummaryDto;
  _count?: { invoices: number };
}
