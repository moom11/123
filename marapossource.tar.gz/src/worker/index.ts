/**
 * =============================================================================
 * عامل المزامنة الخلفي
 * =============================================================================
 * يعالج طابور المزامنة مع Odoo على فترات منتظمة.
 *
 * التشغيل:
 *   npm run worker
 * أو داخل Docker كخدمة مستقلة (راجع docker-compose.yml).
 *
 * بديل آخر: استدعاء POST /api/cron/sync من مجدول خارجي.
 */
import { runSyncCycle } from '@/lib/odoo/integration-service';
import { prisma } from '@/lib/prisma';

const INTERVAL_SECONDS = Number(process.env.SYNC_WORKER_INTERVAL_SECONDS ?? 30);
const BATCH_SIZE = Number(process.env.SYNC_WORKER_BATCH_SIZE ?? 20);
const WORKER_ID = `worker-${process.pid}`;

let running = true;
let cycleInProgress = false;

async function tick() {
  if (cycleInProgress) return;
  cycleInProgress = true;
  try {
    const result = await runSyncCycle(WORKER_ID, BATCH_SIZE);
    if (result.processed > 0) {
      console.log(
        `[worker] عولجت ${result.processed} مهمة — نجحت ${result.succeeded}، فشلت ${result.failed}`,
      );
    }
  } catch (error) {
    // العامل لا يتوقف بسبب خطأ في دورة واحدة
    console.error('[worker] خطأ في دورة المزامنة:', error);
  } finally {
    cycleInProgress = false;
  }
}

async function shutdown(signal: string) {
  console.log(`\n[worker] استلام ${signal} — إيقاف العامل بعد إنهاء الدورة الحالية…`);
  running = false;
  // ننتظر انتهاء الدورة الجارية حتى لا تبقى مهام مقفولة
  for (let i = 0; i < 30 && cycleInProgress; i += 1) {
    await new Promise((resolve) => setTimeout(resolve, 1000));
  }
  await prisma.$disconnect();
  process.exit(0);
}

process.on('SIGINT', () => void shutdown('SIGINT'));
process.on('SIGTERM', () => void shutdown('SIGTERM'));

async function main() {
  console.log(
    `[worker] بدء عامل المزامنة (${WORKER_ID}) — كل ${INTERVAL_SECONDS} ثانية، دفعة ${BATCH_SIZE}`,
  );
  while (running) {
    await tick();
    await new Promise((resolve) => setTimeout(resolve, INTERVAL_SECONDS * 1000));
  }
}

void main();
