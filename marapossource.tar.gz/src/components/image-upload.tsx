'use client';

/**
 * حقل صورة: يرفع ملفًا من الجهاز أو يقبل رابطًا خارجيًا.
 * القيمة النهائية دائمًا نص الرابط، فيتوافق مع حقل imageUrl كما هو.
 */
import { useRef, useState } from 'react';
import { api, ApiClientError } from '@/lib/client/api';

interface StoredFile {
  url: string;
  mime: string;
  size: number;
}

interface Props {
  label?: string;
  value: string;
  onChange: (url: string) => void;
  kind?: 'products' | 'expenses';
  disabled?: boolean;
}

export function ImageUpload({
  label = 'الصورة',
  value,
  onChange,
  kind = 'products',
  disabled,
}: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleFile(file: File | undefined) {
    if (!file) return;
    setError(null);
    setUploading(true);
    try {
      const form = new FormData();
      form.append('file', file);
      form.append('kind', kind);
      const { data } = await api.upload<StoredFile>('/api/uploads', form);
      onChange(data.url);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'تعذر رفع الصورة');
    } finally {
      setUploading(false);
      // نفرّغ الحقل حتى يمكن إعادة اختيار الملف نفسه بعد الحذف
      if (inputRef.current) inputRef.current.value = '';
    }
  }

  return (
    <div>
      <label className="label">{label}</label>

      <div className="flex items-start gap-3">
        <div className="grid h-20 w-20 shrink-0 place-items-center overflow-hidden rounded-xl border border-surface-border bg-surface-muted">
          {value ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={value} alt="" className="h-full w-full object-cover" />
          ) : (
            <span className="text-2xl opacity-40" aria-hidden>
              🖼️
            </span>
          )}
        </div>

        <div className="min-w-0 flex-1 space-y-2">
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              className="btn-ghost"
              disabled={disabled || uploading}
              onClick={() => inputRef.current?.click()}
            >
              {uploading ? 'جارٍ الرفع…' : value ? 'تغيير الصورة' : 'رفع صورة'}
            </button>
            {value && !uploading && (
              <button
                type="button"
                className="btn-ghost"
                disabled={disabled}
                onClick={() => {
                  setError(null);
                  onChange('');
                }}
              >
                إزالة
              </button>
            )}
          </div>

          <input
            ref={inputRef}
            type="file"
            accept="image/jpeg,image/png,image/webp,image/gif"
            className="hidden"
            onChange={(event) => void handleFile(event.target.files?.[0])}
          />

          <input
            className="input"
            placeholder="أو الصق رابط صورة"
            value={value}
            disabled={disabled || uploading}
            onChange={(event) => onChange(event.target.value)}
          />

          {error ? (
            <p className="text-sm text-red-600">{error}</p>
          ) : (
            <p className="text-xs opacity-60">JPG أو PNG أو WebP أو GIF — حتى 5 ميجابايت</p>
          )}
        </div>
      </div>
    </div>
  );
}
