'use client';

import { useEffect, useState } from 'react';
import { countPendingOperations, syncPendingOperations } from '@/lib/client/offline-queue';

/**
 * مؤشر حالة الاتصال.
 * يُظهر عدد العمليات غير المتزامنة ويحاول رفعها تلقائيًا عند عودة الاتصال.
 */
export function OfflineIndicator() {
  const [online, setOnline] = useState(true);
  const [pending, setPending] = useState(0);
  const [syncing, setSyncing] = useState(false);

  useEffect(() => {
    setOnline(navigator.onLine);

    const refreshCount = async () => setPending(await countPendingOperations());

    const handleOnline = async () => {
      setOnline(true);
      setSyncing(true);
      await syncPendingOperations().catch(() => undefined);
      setSyncing(false);
      await refreshCount();
    };
    const handleOffline = () => setOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    void refreshCount();
    const timer = setInterval(refreshCount, 15000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(timer);
    };
  }, []);

  if (online && pending === 0) {
    return (
      <span className="badge bg-emerald-100 text-emerald-800" title="متصل بالخادم">
        <span className="h-2 w-2 rounded-full bg-emerald-500" />
        متصل
      </span>
    );
  }

  if (!online) {
    return (
      <span className="badge bg-red-100 text-red-800" title="لا يوجد اتصال — يتم الحفظ محليًا">
        <span className="h-2 w-2 animate-pulse rounded-full bg-red-500" />
        غير متصل{pending > 0 ? ` · ${pending} بانتظار الرفع` : ''}
      </span>
    );
  }

  return (
    <span className="badge bg-amber-100 text-amber-800">
      <span className="h-2 w-2 animate-pulse rounded-full bg-amber-500" />
      {syncing ? 'جارٍ المزامنة…' : `${pending} عملية بانتظار الرفع`}
    </span>
  );
}
