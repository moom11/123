'use client';

import { useEffect, useState } from 'react';
import { api } from '@/lib/client/api';
import { ErrorAlert, Modal, Spinner } from '@/components/ui';
import { useSession } from '@/components/session-provider';
import { TABLE_STATUS_LABELS } from '@/lib/client/format';
import type { FloorDto, TableDto } from '@/types/pos';

/**
 * نافذة فتح طلب جديد.
 * لطلبات «داخل المطعم» يجب اختيار الدور والمنطقة والطاولة، وعدد الضيوف اختياري.
 */
export function OrderTypeModal({
  open,
  busy,
  onClose,
  onConfirm,
}: {
  open: boolean;
  busy: boolean;
  onClose: () => void;
  onConfirm: (payload: {
    type: string;
    tableId?: string | null;
    guestCount?: number | null;
    customerName?: string | null;
    customerPhone?: string | null;
  }) => void;
}) {
  const { user } = useSession();
  const deliveryEnabled = user.branch?.settings?.enableDelivery ?? false;

  const [type, setType] = useState('DINE_IN');
  const [floors, setFloors] = useState<FloorDto[]>([]);
  const [floorId, setFloorId] = useState<string | null>(null);
  const [areaId, setAreaId] = useState<string | null>(null);
  const [tableId, setTableId] = useState<string | null>(null);
  const [guestCount, setGuestCount] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    setError(null);
    setTableId(null);
    api
      .get<FloorDto[]>('/api/floors')
      .then(({ data }) => {
        setFloors(data);
        setFloorId(data[0]?.id ?? null);
        setAreaId(data[0]?.areas[0]?.id ?? null);
      })
      .catch((err) => setError(err instanceof Error ? err.message : 'تعذر تحميل الطاولات'));
  }, [open]);

  const floor = floors.find((f) => f.id === floorId);
  const area = floor?.areas.find((a) => a.id === areaId);
  const tables: TableDto[] = area?.tables ?? floor?.areas.flatMap((a) => a.tables) ?? [];

  const types = [
    { value: 'DINE_IN', label: 'داخل المطعم', icon: '🍽️', enabled: true },
    { value: 'TAKEAWAY', label: 'سفري', icon: '🥡', enabled: true },
    { value: 'PICKUP', label: 'استلام', icon: '🛍️', enabled: true },
    { value: 'DELIVERY', label: 'توصيل', icon: '🛵', enabled: deliveryEnabled },
  ];

  const canConfirm = type !== 'DINE_IN' || Boolean(tableId);

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="طلب جديد"
      size="lg"
      footer={
        <>
          <button type="button" className="btn-ghost" onClick={onClose} disabled={busy}>
            إلغاء
          </button>
          <button
            type="button"
            className="btn-primary"
            disabled={!canConfirm || busy}
            onClick={() =>
              onConfirm({
                type,
                tableId: type === 'DINE_IN' ? tableId : null,
                guestCount: guestCount ? Number(guestCount) : null,
                customerName: customerName.trim() || null,
                customerPhone: customerPhone.trim() || null,
              })
            }
          >
            {busy && <Spinner className="h-4 w-4" />}
            فتح الطلب
          </button>
        </>
      }
    >
      <div className="space-y-5">
        <ErrorAlert message={error} />

        <section>
          <p className="label">نوع الطلب</p>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {types.map((item) => (
              <button
                key={item.value}
                type="button"
                disabled={!item.enabled}
                onClick={() => setType(item.value)}
                className={`btn-touch flex-col gap-1 rounded-2xl border text-sm font-semibold transition ${
                  type === item.value
                    ? 'border-brand bg-brand/10 text-brand'
                    : 'border-surface-border bg-white hover:bg-surface-muted'
                } ${!item.enabled ? 'cursor-not-allowed opacity-40' : ''}`}
                title={!item.enabled ? 'معطل من إعدادات الفرع' : undefined}
              >
                <span className="text-xl">{item.icon}</span>
                {item.label}
              </button>
            ))}
          </div>
        </section>

        {type === 'DINE_IN' && (
          <>
            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <label className="label" htmlFor="floor">
                  الدور
                </label>
                <select
                  id="floor"
                  className="input"
                  value={floorId ?? ''}
                  onChange={(event) => {
                    setFloorId(event.target.value);
                    const next = floors.find((f) => f.id === event.target.value);
                    setAreaId(next?.areas[0]?.id ?? null);
                    setTableId(null);
                  }}
                >
                  {floors.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.nameAr}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label" htmlFor="area">
                  المنطقة
                </label>
                <select
                  id="area"
                  className="input"
                  value={areaId ?? ''}
                  onChange={(event) => {
                    setAreaId(event.target.value);
                    setTableId(null);
                  }}
                >
                  {floor?.areas.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.nameAr}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <section>
              <p className="label">
                الطاولة <span className="text-red-600">*</span>
              </p>
              <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
                {tables.map((table) => {
                  const available = table.status === 'AVAILABLE';
                  return (
                    <button
                      key={table.id}
                      type="button"
                      onClick={() => setTableId(table.id)}
                      className={`rounded-xl border p-2.5 text-center text-sm transition ${
                        tableId === table.id
                          ? 'border-brand bg-brand/10 font-bold text-brand'
                          : available
                            ? 'border-emerald-300 bg-emerald-50 hover:bg-emerald-100'
                            : 'border-surface-border bg-neutral-50 text-neutral-500'
                      }`}
                    >
                      <span className="tabular block font-bold">{table.number}</span>
                      <span className="block text-[10px]">
                        {TABLE_STATUS_LABELS[table.status]}
                      </span>
                    </button>
                  );
                })}
              </div>
            </section>

            <div>
              <label className="label" htmlFor="guests">
                عدد الضيوف (اختياري)
              </label>
              <input
                id="guests"
                type="number"
                min="1"
                className="input tabular w-32"
                value={guestCount}
                onChange={(event) => setGuestCount(event.target.value)}
              />
            </div>
          </>
        )}

        {type !== 'DINE_IN' && (
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <label className="label" htmlFor="customer">
                اسم العميل (اختياري)
              </label>
              <input
                id="customer"
                className="input"
                value={customerName}
                onChange={(event) => setCustomerName(event.target.value)}
              />
            </div>
            <div>
              <label className="label" htmlFor="phone">
                رقم الجوال (اختياري)
              </label>
              <input
                id="phone"
                className="input tabular"
                value={customerPhone}
                onChange={(event) => setCustomerPhone(event.target.value)}
                placeholder="05xxxxxxxx"
              />
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
}
