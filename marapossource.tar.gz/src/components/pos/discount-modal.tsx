'use client';

import { useEffect, useState } from 'react';
import { api, ApiClientError } from '@/lib/client/api';
import { money } from '@/lib/client/format';
import { ErrorAlert, Modal, Spinner } from '@/components/ui';
import { useSession } from '@/components/session-provider';
import type { OrderDto } from '@/types/pos';

/**
 * نافذة الخصم — تدعم النسبة والمبلغ الثابت والكوبون،
 * على مستوى صنف واحد أو على كامل الفاتورة، مع اعتماد المدير عند الحاجة.
 */
export function DiscountModal({
  open,
  order,
  onClose,
  onApplied,
}: {
  open: boolean;
  order: OrderDto;
  onClose: () => void;
  onApplied: (order: OrderDto) => void;
}) {
  const { user, can } = useSession();
  const requiresApproval =
    (user.branch?.settings?.requireManagerForDiscount ?? true) && !can('discounts.approve');
  const maxPercent = Number(user.branch?.settings?.maxDiscountPercent ?? 100);

  const [mode, setMode] = useState<'PERCENT' | 'AMOUNT' | 'COUPON'>('PERCENT');
  const [value, setValue] = useState('');
  const [couponCode, setCouponCode] = useState('');
  const [scope, setScope] = useState<string>('ORDER');
  const [reason, setReason] = useState('');
  const [managerPin, setManagerPin] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    setValue('');
    setCouponCode('');
    setReason('');
    setManagerPin('');
    setError(null);
    setScope('ORDER');
  }, [open]);

  const items = order.items.filter((item) => !item.isVoided);

  async function submit() {
    setBusy(true);
    setError(null);
    try {
      const { data } = await api.post<{ order: OrderDto }>(
        `/api/orders/${order.id}/discount`,
        {
          orderItemId: scope === 'ORDER' ? null : scope,
          type: mode === 'COUPON' ? 'COUPON' : mode,
          value: mode === 'COUPON' ? 1 : Number(value) || 0,
          couponCode: mode === 'COUPON' ? couponCode.trim() : null,
          reason: reason.trim() || null,
          managerPin: managerPin.trim() || null,
        },
      );
      onApplied(data.order);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'تعذر تطبيق الخصم');
    } finally {
      setBusy(false);
    }
  }

  const canSubmit =
    (mode === 'COUPON' ? couponCode.trim().length > 0 : Number(value) > 0) &&
    (!requiresApproval || managerPin.trim().length >= 4);

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="تطبيق خصم"
      size="md"
      footer={
        <>
          <button type="button" className="btn-ghost" onClick={onClose} disabled={busy}>
            إلغاء
          </button>
          <button
            type="button"
            className="btn-primary"
            disabled={!canSubmit || busy}
            onClick={() => void submit()}
          >
            {busy && <Spinner className="h-4 w-4" />}
            تطبيق
          </button>
        </>
      }
    >
      <div className="space-y-4">
        <ErrorAlert message={error} />

        <div className="flex items-center justify-between rounded-xl bg-surface-muted px-4 py-2.5 text-sm">
          <span className="text-neutral-600">إجمالي الطلب الحالي</span>
          <span className="tabular font-bold">{money(order.grandTotal)}</span>
        </div>

        <section>
          <p className="label">نوع الخصم</p>
          <div className="grid grid-cols-3 gap-2">
            {[
              { key: 'PERCENT', label: 'نسبة %' },
              { key: 'AMOUNT', label: 'مبلغ ثابت' },
              { key: 'COUPON', label: 'كوبون' },
            ].map((item) => (
              <button
                key={item.key}
                type="button"
                onClick={() => setMode(item.key as typeof mode)}
                className={`btn-touch rounded-xl border text-sm font-semibold ${
                  mode === item.key
                    ? 'border-brand bg-brand/10 text-brand'
                    : 'border-surface-border bg-white'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </section>

        {mode === 'COUPON' ? (
          <div>
            <label className="label" htmlFor="coupon">
              كود الكوبون
            </label>
            <input
              id="coupon"
              className="input uppercase"
              value={couponCode}
              onChange={(event) => setCouponCode(event.target.value)}
              placeholder="WELCOME10"
            />
          </div>
        ) : (
          <div>
            <label className="label" htmlFor="discount-value">
              {mode === 'PERCENT' ? `النسبة (الحد الأعلى ${maxPercent}%)` : 'المبلغ بالريال'}
            </label>
            <input
              id="discount-value"
              type="number"
              min="0"
              step="0.01"
              max={mode === 'PERCENT' ? maxPercent : undefined}
              className="input tabular text-lg"
              value={value}
              onChange={(event) => setValue(event.target.value)}
            />
          </div>
        )}

        <div>
          <label className="label" htmlFor="scope">
            نطاق الخصم
          </label>
          <select
            id="scope"
            className="input"
            value={scope}
            onChange={(event) => setScope(event.target.value)}
          >
            <option value="ORDER">كامل الفاتورة</option>
            {items.map((item) => (
              <option key={item.id} value={item.id}>
                {item.nameAr} — {money(item.lineTotal, false)}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="label" htmlFor="discount-reason">
            سبب الخصم
          </label>
          <input
            id="discount-reason"
            className="input"
            value={reason}
            onChange={(event) => setReason(event.target.value)}
            placeholder="مثال: عميل دائم، تعويض عن تأخير…"
          />
        </div>

        {requiresApproval && (
          <div>
            <label className="label" htmlFor="discount-pin">
              رمز المدير للاعتماد <span className="text-red-600">*</span>
            </label>
            <input
              id="discount-pin"
              type="password"
              inputMode="numeric"
              className="input tabular text-center text-lg tracking-[0.4em]"
              value={managerPin}
              onChange={(event) => setManagerPin(event.target.value)}
              placeholder="••••"
              maxLength={8}
            />
            <p className="mt-1 text-xs text-neutral-500">
              إعدادات الفرع تشترط اعتماد المدير على الخصومات.
            </p>
          </div>
        )}
      </div>
    </Modal>
  );
}
