'use client';

import { useEffect, useState } from 'react';
import { api } from '@/lib/client/api';
import { money, number, dateTime, ORDER_TYPE_LABELS } from '@/lib/client/format';
import { LoadingBlock, Modal } from '@/components/ui';
import { useSession } from '@/components/session-provider';
import type { InvoiceDto } from '@/types/pos';

/**
 * فاتورة العميل بمقاس الطابعة الحرارية 80 مم.
 * الطباعة تتم عبر متصفح الجهاز، ويمكن توجيهها إلى طابعة الشبكة المعرفة في الإعدادات.
 */
export function ReceiptModal({
  invoice: initial,
  onClose,
}: {
  invoice: InvoiceDto;
  onClose: () => void;
}) {
  const { user } = useSession();
  const [invoice, setInvoice] = useState<InvoiceDto | null>(
    initial.items ? initial : null,
  );

  useEffect(() => {
    if (invoice) return;
    api
      .get<InvoiceDto>(`/api/invoices/${initial.id}`)
      .then(({ data }) => setInvoice(data))
      .catch(() => setInvoice(initial));
  }, [invoice, initial]);

  return (
    <Modal
      open
      onClose={onClose}
      title={`فاتورة ${initial.invoiceNumber}`}
      size="sm"
      footer={
        <>
          <button type="button" className="btn-ghost no-print" onClick={onClose}>
            إغلاق
          </button>
          <button
            type="button"
            className="btn-primary no-print"
            onClick={() => window.print()}
          >
            🖨️ طباعة
          </button>
        </>
      }
    >
      {!invoice ? (
        <LoadingBlock />
      ) : (
        <div className="print-receipt mx-auto max-w-[300px] text-xs">
          <div className="text-center">
            <p className="text-base font-bold">{user.branch?.companyName}</p>
            <p className="font-semibold">{user.branch?.nameAr}</p>
            <p className="mt-1 text-[10px] text-neutral-600">فاتورة ضريبية مبسطة</p>
          </div>

          <div className="my-2 border-y border-dashed border-neutral-400 py-2">
            <ReceiptRow label="رقم الفاتورة" value={invoice.invoiceNumber} />
            <ReceiptRow label="التاريخ" value={dateTime(invoice.closedAt ?? invoice.createdAt)} />
            <ReceiptRow label="الكاشير" value={invoice.user?.fullName ?? user.fullName} />
            <ReceiptRow label="نوع الطلب" value={ORDER_TYPE_LABELS[invoice.type] ?? invoice.type} />
            {invoice.tableNumber && <ReceiptRow label="الطاولة" value={invoice.tableNumber} />}
          </div>

          <table className="w-full text-[11px]">
            <thead>
              <tr className="border-b border-neutral-400">
                <th className="py-1 text-right">الصنف</th>
                <th className="py-1 text-center">الكمية</th>
                <th className="py-1 text-left">المبلغ</th>
              </tr>
            </thead>
            <tbody>
              {invoice.items?.map((item) => (
                <tr key={item.id} className="align-top">
                  <td className="py-1">
                    {item.nameAr}
                    {item.isTobacco && <span className="text-[9px]"> (تبغ)</span>}
                  </td>
                  <td className="tabular py-1 text-center">{number(item.quantity)}</td>
                  <td className="tabular py-1 text-left">{money(item.lineTotal, false)}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="mt-2 border-t border-dashed border-neutral-400 pt-2">
            <ReceiptRow label="الإجمالي قبل الضريبة" value={money(invoice.netBeforeTax, false)} />
            {Number(invoice.discountTotal) > 0 && (
              <ReceiptRow label="الخصم" value={`- ${money(invoice.discountTotal, false)}`} />
            )}
            <ReceiptRow label="ضريبة القيمة المضافة" value={money(invoice.vatTotal, false)} />
            {Number(invoice.tobaccoTaxTotal) > 0 && (
              <ReceiptRow label="ضريبة التبغ" value={money(invoice.tobaccoTaxTotal, false)} />
            )}
            <div className="mt-1 flex justify-between border-t border-neutral-400 pt-1 text-sm font-bold">
              <span>الإجمالي</span>
              <span className="tabular">{money(invoice.grandTotal)}</span>
            </div>
          </div>

          {invoice.payments && invoice.payments.length > 0 && (
            <div className="mt-2 border-t border-dashed border-neutral-400 pt-2">
              {invoice.payments.map((payment) => (
                <ReceiptRow
                  key={payment.id}
                  label={payment.paymentMethod.nameAr}
                  value={money(payment.amount, false)}
                />
              ))}
              {Number(invoice.changeDue) > 0 && (
                <ReceiptRow label="الباقي" value={money(invoice.changeDue, false)} />
              )}
            </div>
          )}

          {invoice.qrPayload && (
            <div className="mt-3 text-center">
              <p className="text-[9px] text-neutral-500">رمز الاستجابة السريعة (ZATCA)</p>
              <p className="mt-1 break-all text-[7px] text-neutral-400">{invoice.qrPayload}</p>
            </div>
          )}

          <p className="mt-3 text-center text-[10px] text-neutral-600">
            شكرًا لزيارتكم — نتشرف بخدمتكم دائمًا
          </p>
        </div>
      )}
    </Modal>
  );
}

function ReceiptRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-2 py-0.5">
      <span className="text-neutral-600">{label}</span>
      <span className="tabular">{value}</span>
    </div>
  );
}
