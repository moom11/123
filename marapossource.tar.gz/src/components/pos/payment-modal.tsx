'use client';

import { useEffect, useMemo, useState } from 'react';
import { api, ApiClientError } from '@/lib/client/api';
import { money } from '@/lib/client/format';
import { ErrorAlert, Modal, Spinner } from '@/components/ui';
import { useSession } from '@/components/session-provider';
import type { InvoiceDto, OrderDto, PaymentMethodDto } from '@/types/pos';

interface SplitLine {
  paymentMethodId: string;
  amount: number;
}

/**
 * نافذة الدفع — تدعم الدفع بطريقة واحدة أو الدفع المختلط.
 * تمنع الإغلاق إذا لم يساوِ مجموع المدفوعات المبلغ المطلوب
 * (مع سماحية التقريب المسموح بها من إعدادات الفرع).
 */
export function PaymentModal({
  open,
  order,
  shiftId,
  onClose,
  onPaid,
}: {
  open: boolean;
  order: OrderDto;
  shiftId: string | null;
  onClose: () => void;
  onPaid: (invoice: InvoiceDto) => void;
}) {
  const { user } = useSession();
  const tolerance = Number(user.branch?.settings?.paymentRoundingTolerance ?? 0.05);

  const total = Number(order.grandTotal);
  const [methods, setMethods] = useState<PaymentMethodDto[]>([]);
  const [mixed, setMixed] = useState(false);
  const [lines, setLines] = useState<SplitLine[]>([]);
  const [received, setReceived] = useState<string>('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // مفتاح ثابت لمنع إغلاق نفس الفاتورة مرتين عند تكرار الضغط أو انقطاع الشبكة
  const [idempotencyKey] = useState(() => `checkout:${order.id}:${crypto.randomUUID()}`);

  useEffect(() => {
    if (!open) return;
    setError(null);
    setReceived('');
    api
      .get<PaymentMethodDto[]>('/api/payment-methods')
      .then(({ data }) => {
        setMethods(data);
        const cash = data.find((m) => m.affectsCashDrawer) ?? data[0];
        if (cash) setLines([{ paymentMethodId: cash.id, amount: total }]);
      })
      .catch((err) => setError(err instanceof Error ? err.message : 'تعذر تحميل طرق الدفع'));
  }, [open, total]);

  const paidTotal = useMemo(
    () => Math.round(lines.reduce((sum, line) => sum + (line.amount || 0), 0) * 100) / 100,
    [lines],
  );
  const remaining = Math.round((total - paidTotal) * 100) / 100;
  const balanced = Math.abs(remaining) <= tolerance + 1e-9;

  const cashLine = lines.find(
    (line) => methods.find((m) => m.id === line.paymentMethodId)?.affectsCashDrawer,
  );
  const receivedNumber = Number(received) || 0;
  const change =
    cashLine && receivedNumber > cashLine.amount
      ? Math.round((receivedNumber - cashLine.amount) * 100) / 100
      : 0;

  function selectSingle(methodId: string) {
    setLines([{ paymentMethodId: methodId, amount: total }]);
    setMixed(false);
  }

  function addLine() {
    const unused = methods.find((m) => !lines.some((l) => l.paymentMethodId === m.id));
    if (!unused) return;
    setLines((current) => [
      ...current,
      { paymentMethodId: unused.id, amount: Math.max(remaining, 0) },
    ]);
  }

  function updateLine(index: number, patch: Partial<SplitLine>) {
    setLines((current) =>
      current.map((line, i) => (i === index ? { ...line, ...patch } : line)),
    );
  }

  function removeLine(index: number) {
    setLines((current) => current.filter((_, i) => i !== index));
  }

  async function submit() {
    setBusy(true);
    setError(null);
    try {
      const { data } = await api.post<InvoiceDto>(`/api/orders/${order.id}/checkout`, {
        payments: lines
          .filter((line) => line.amount > 0)
          .map((line) => ({
            paymentMethodId: line.paymentMethodId,
            amount: Math.round(line.amount * 100) / 100,
            receivedAmount:
              cashLine?.paymentMethodId === line.paymentMethodId && receivedNumber > 0
                ? receivedNumber
                : null,
          })),
        shiftId,
        idempotencyKey,
      });
      onPaid(data);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'تعذر إتمام الدفع');
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={`الدفع — ${order.orderNumber}`}
      size="md"
      footer={
        <>
          <button type="button" className="btn-ghost" onClick={onClose} disabled={busy}>
            رجوع
          </button>
          <button
            type="button"
            className="btn-success btn-touch min-w-[180px]"
            disabled={!balanced || busy || lines.length === 0}
            onClick={() => void submit()}
          >
            {busy ? <Spinner className="h-5 w-5" /> : '✅'} تأكيد الدفع
          </button>
        </>
      }
    >
      <div className="space-y-4">
        <div className="rounded-2xl bg-brand px-4 py-4 text-center text-white">
          <p className="text-xs opacity-80">المبلغ المطلوب</p>
          <p className="tabular text-3xl font-bold">{money(total)}</p>
          <p className="mt-1 text-[11px] opacity-70">
            ضريبة القيمة المضافة {money(order.vatTotal, false)}
            {Number(order.tobaccoTaxTotal) > 0 &&
              ` · ضريبة التبغ ${money(order.tobaccoTaxTotal, false)}`}
          </p>
        </div>

        <ErrorAlert message={error} />

        {!mixed ? (
          <>
            <p className="label">اختر طريقة الدفع</p>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {methods.map((method) => (
                <button
                  key={method.id}
                  type="button"
                  onClick={() => selectSingle(method.id)}
                  className={`btn-touch rounded-2xl border text-sm font-semibold transition ${
                    lines.length === 1 && lines[0].paymentMethodId === method.id
                      ? 'border-brand bg-brand/10 text-brand'
                      : 'border-surface-border bg-white hover:bg-surface-muted'
                  }`}
                >
                  {method.nameAr}
                </button>
              ))}
            </div>
            <button
              type="button"
              className="btn-ghost w-full"
              onClick={() => {
                setMixed(true);
                if (lines.length === 1) {
                  updateLine(0, { amount: Math.round((total / 2) * 100) / 100 });
                }
              }}
            >
              ⇄ دفع مختلط (تقسيم المبلغ على أكثر من طريقة)
            </button>
          </>
        ) : (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <p className="label !mb-0">الدفع المختلط</p>
              <button
                type="button"
                className="text-xs text-neutral-500 underline"
                onClick={() => selectSingle(lines[0]?.paymentMethodId ?? methods[0]?.id)}
              >
                العودة للدفع بطريقة واحدة
              </button>
            </div>

            {lines.map((line, index) => (
              <div key={index} className="flex items-center gap-2">
                <select
                  className="input flex-1"
                  value={line.paymentMethodId}
                  onChange={(event) =>
                    updateLine(index, { paymentMethodId: event.target.value })
                  }
                >
                  {methods.map((method) => (
                    <option key={method.id} value={method.id}>
                      {method.nameAr}
                    </option>
                  ))}
                </select>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  className="input tabular w-32 text-center"
                  value={line.amount}
                  onChange={(event) =>
                    updateLine(index, { amount: Number(event.target.value) || 0 })
                  }
                />
                {lines.length > 1 && (
                  <button
                    type="button"
                    className="rounded-lg px-2 py-2 text-red-600 hover:bg-red-50"
                    onClick={() => removeLine(index)}
                    aria-label="حذف"
                  >
                    ✕
                  </button>
                )}
              </div>
            ))}

            <div className="flex gap-2">
              <button
                type="button"
                className="btn-ghost flex-1"
                onClick={addLine}
                disabled={lines.length >= methods.length}
              >
                ＋ إضافة طريقة دفع
              </button>
              {remaining !== 0 && lines.length > 0 && (
                <button
                  type="button"
                  className="btn-ghost flex-1"
                  onClick={() =>
                    updateLine(lines.length - 1, {
                      amount:
                        Math.round((lines[lines.length - 1].amount + remaining) * 100) / 100,
                    })
                  }
                >
                  إكمال المتبقي ({money(remaining, false)})
                </button>
              )}
            </div>
          </div>
        )}

        {cashLine && (
          <div>
            <label className="label" htmlFor="received">
              المبلغ المستلم نقدًا (اختياري — لحساب الباقي)
            </label>
            <input
              id="received"
              type="number"
              step="0.01"
              min="0"
              className="input tabular text-lg"
              value={received}
              onChange={(event) => setReceived(event.target.value)}
              placeholder={String(cashLine.amount)}
            />
            {change > 0 && (
              <p className="mt-2 rounded-xl bg-emerald-50 px-3 py-2 text-sm font-semibold text-emerald-800">
                الباقي للعميل: <span className="tabular">{money(change)}</span>
              </p>
            )}
          </div>
        )}

        <div
          className={`flex items-center justify-between rounded-xl px-4 py-3 text-sm ${
            balanced
              ? 'bg-emerald-50 text-emerald-800'
              : 'bg-amber-50 text-amber-900'
          }`}
        >
          <span>مجموع المدفوعات</span>
          <span className="tabular font-bold">{money(paidTotal)}</span>
        </div>
        {!balanced && (
          <p className="text-xs text-amber-700">
            {remaining > 0
              ? `متبقٍ ${money(remaining)} — لا يمكن إغلاق الفاتورة قبل اكتمال المبلغ.`
              : `المبلغ زائد بمقدار ${money(Math.abs(remaining))}.`}
          </p>
        )}
      </div>
    </Modal>
  );
}
