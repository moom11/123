'use client';

import { useMemo, useState } from 'react';
import { Modal, Spinner } from '@/components/ui';
import { money } from '@/lib/client/format';
import type { ProductDto } from '@/types/pos';

export interface SelectedOptions {
  variantId?: string | null;
  quantity: number;
  note?: string | null;
  modifiers: {
    groupId: string;
    groupName: string;
    modifierId: string;
    name: string;
    priceDelta: number;
  }[];
}

/**
 * نافذة خيارات المنتج: الحجم، الإضافات، النكهة، درجة السكر، الملاحظات، الكمية.
 * تظهر فقط عند وجود خيارات للمنتج — وإلا تُضاف المنتجات بضغطة واحدة.
 */
export function ProductOptionsModal({
  product,
  busy,
  onClose,
  onConfirm,
}: {
  product: ProductDto;
  busy: boolean;
  onClose: () => void;
  onConfirm: (options: SelectedOptions) => void;
}) {
  const variants = product.variants ?? [];
  const groups = product.modifierGroups ?? [];

  const [variantId, setVariantId] = useState<string | null>(
    variants.find((v) => v.isDefault)?.id ?? variants[0]?.id ?? null,
  );
  const [selected, setSelected] = useState<Record<string, string[]>>(() => {
    const initial: Record<string, string[]> = {};
    for (const group of groups) {
      const defaults = group.modifiers.filter((m) => m.isDefault).map((m) => m.id);
      initial[group.id] = group.selectionType === 'SINGLE' ? defaults.slice(0, 1) : defaults;
    }
    return initial;
  });
  const [quantity, setQuantity] = useState(1);
  const [note, setNote] = useState('');

  function toggle(groupId: string, modifierId: string, single: boolean, maxSelect: number) {
    setSelected((current) => {
      const list = current[groupId] ?? [];
      if (single) return { ...current, [groupId]: [modifierId] };
      if (list.includes(modifierId)) {
        return { ...current, [groupId]: list.filter((id) => id !== modifierId) };
      }
      if (list.length >= maxSelect) return current;
      return { ...current, [groupId]: [...list, modifierId] };
    });
  }

  const chosenModifiers = useMemo(() => {
    const result: SelectedOptions['modifiers'] = [];
    for (const group of groups) {
      for (const modifierId of selected[group.id] ?? []) {
        const modifier = group.modifiers.find((m) => m.id === modifierId);
        if (modifier) {
          result.push({
            groupId: group.id,
            groupName: group.nameAr,
            modifierId: modifier.id,
            name: modifier.nameAr,
            priceDelta: Number(modifier.priceDelta),
          });
        }
      }
    }
    return result;
  }, [groups, selected]);

  const unitPrice = useMemo(() => {
    const variantDelta = variants.find((v) => v.id === variantId)?.priceDelta ?? 0;
    const modifiersTotal = chosenModifiers.reduce((sum, m) => sum + m.priceDelta, 0);
    return Number(product.price) + Number(variantDelta) + modifiersTotal;
  }, [product.price, variants, variantId, chosenModifiers]);

  const missingRequired = groups.filter(
    (group) => group.isRequired && (selected[group.id]?.length ?? 0) < Math.max(group.minSelect, 1),
  );

  return (
    <Modal
      open
      onClose={onClose}
      title={product.nameAr}
      size="md"
      footer={
        <>
          <button type="button" className="btn-ghost" onClick={onClose} disabled={busy}>
            إلغاء
          </button>
          <button
            type="button"
            className="btn-primary"
            disabled={busy || missingRequired.length > 0}
            onClick={() =>
              onConfirm({
                variantId,
                quantity,
                note: note.trim() || null,
                modifiers: chosenModifiers,
              })
            }
          >
            {busy && <Spinner className="h-4 w-4" />}
            إضافة — {money(unitPrice * quantity)}
          </button>
        </>
      }
    >
      <div className="space-y-5">
        {variants.length > 0 && (
          <section>
            <p className="label">الحجم / الخيار</p>
            <div className="flex flex-wrap gap-2">
              {variants.map((variant) => (
                <OptionChip
                  key={variant.id}
                  label={variant.nameAr}
                  delta={Number(variant.priceDelta)}
                  active={variantId === variant.id}
                  onClick={() => setVariantId(variant.id)}
                />
              ))}
            </div>
          </section>
        )}

        {groups.map((group) => {
          const single = group.selectionType === 'SINGLE';
          const list = selected[group.id] ?? [];
          return (
            <section key={group.id}>
              <p className="label">
                {group.nameAr}
                {group.isRequired && <span className="text-red-600"> *</span>}
                {!single && (
                  <span className="mr-2 text-xs font-normal text-neutral-400">
                    (حتى {group.maxSelect})
                  </span>
                )}
              </p>
              <div className="flex flex-wrap gap-2">
                {group.modifiers.map((modifier) => (
                  <OptionChip
                    key={modifier.id}
                    label={modifier.nameAr}
                    delta={Number(modifier.priceDelta)}
                    active={list.includes(modifier.id)}
                    onClick={() =>
                      toggle(group.id, modifier.id, single, group.maxSelect)
                    }
                  />
                ))}
              </div>
            </section>
          );
        })}

        <section>
          <p className="label">الكمية</p>
          <div className="flex items-center gap-3">
            <button
              type="button"
              className="btn-ghost h-11 w-11 !px-0 text-xl"
              onClick={() => setQuantity((q) => Math.max(1, q - 1))}
            >
              −
            </button>
            <input
              type="number"
              min={1}
              className="input tabular w-24 text-center text-lg font-bold"
              value={quantity}
              onChange={(event) => setQuantity(Math.max(1, Number(event.target.value) || 1))}
            />
            <button
              type="button"
              className="btn-ghost h-11 w-11 !px-0 text-xl"
              onClick={() => setQuantity((q) => q + 1)}
            >
              +
            </button>
          </div>
        </section>

        <section>
          <label className="label" htmlFor="item-note">
            ملاحظات
          </label>
          <textarea
            id="item-note"
            className="input min-h-[68px]"
            placeholder="مثال: بدون ثلج، سكر خفيف…"
            value={note}
            onChange={(event) => setNote(event.target.value)}
          />
        </section>

        {missingRequired.length > 0 && (
          <p className="text-xs text-red-600">
            يجب اختيار: {missingRequired.map((g) => g.nameAr).join('، ')}
          </p>
        )}
      </div>
    </Modal>
  );
}

function OptionChip({
  label,
  delta,
  active,
  onClick,
}: {
  label: string;
  delta: number;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-xl border px-4 py-2.5 text-sm font-medium transition ${
        active
          ? 'border-brand bg-brand/10 text-brand'
          : 'border-surface-border bg-white hover:bg-surface-muted'
      }`}
    >
      {label}
      {delta !== 0 && (
        <span className="tabular mr-1.5 text-xs text-neutral-500">
          {delta > 0 ? '+' : ''}
          {delta}
        </span>
      )}
    </button>
  );
}
