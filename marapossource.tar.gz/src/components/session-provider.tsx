'use client';

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import { useRouter } from 'next/navigation';
import { api } from '@/lib/client/api';
import { LoadingBlock } from '@/components/ui';

export interface BranchSettings {
  businessDayStartHour: number;
  paymentRoundingTolerance: string | number;
  cashDiffTolerance: string | number;
  enableDelivery: boolean;
  enableCreditPayment: boolean;
  maxDiscountPercent: string | number;
  requireManagerForDiscount: boolean;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  showQrOnInvoice: boolean;
}

export interface CurrentUser {
  id: string;
  employeeNo: string;
  fullName: string;
  email: string | null;
  roles: string[];
  permissions: string[];
  branch: {
    id: string;
    nameAr: string;
    companyName: string;
    settings: BranchSettings | null;
  } | null;
}

interface SessionContextValue {
  user: CurrentUser;
  can: (permission: string | string[]) => boolean;
  canAny: (permissions: string[]) => boolean;
  refresh: () => Promise<void>;
  logout: () => Promise<void>;
}

const SessionContext = createContext<SessionContextValue | null>(null);

/**
 * يضبط لون الهوية كقنوات RGB (مثل «200 16 46») حتى تعمل معه
 * معدِّلات الشفافية في Tailwind مثل `bg-brand/10`.
 */
function applyBrandColor(root: HTMLElement, variable: string, hex: string) {
  const match = /^#?([0-9a-f]{6}|[0-9a-f]{3})$/i.exec(hex.trim());
  if (!match) return;
  const value = match[1].length === 3
    ? match[1].split('').map((char) => char + char).join('')
    : match[1];
  const r = parseInt(value.slice(0, 2), 16);
  const g = parseInt(value.slice(2, 4), 16);
  const b = parseInt(value.slice(4, 6), 16);
  root.style.setProperty(`${variable}-rgb`, `${r} ${g} ${b}`);
  root.style.setProperty(variable, `rgb(${r} ${g} ${b})`);
}

export function useSession(): SessionContextValue {
  const context = useContext(SessionContext);
  if (!context) {
    throw new Error('useSession يجب أن يُستخدم داخل SessionProvider');
  }
  return context;
}

export function SessionProvider({ children }: { children: ReactNode }) {
  const router = useRouter();
  const [user, setUser] = useState<CurrentUser | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      const { data } = await api.get<CurrentUser>('/api/auth/me');
      setUser(data);
    } catch {
      router.replace('/login');
    } finally {
      setLoading(false);
    }
  }, [router]);

  useEffect(() => {
    void load();
  }, [load]);

  // تطبيق الهوية اللونية المخزنة في إعدادات الفرع
  useEffect(() => {
    const settings = user?.branch?.settings;
    if (!settings) return;
    const root = document.documentElement;
    applyBrandColor(root, '--brand-primary', settings.primaryColor);
    applyBrandColor(root, '--brand-secondary', settings.secondaryColor);
    applyBrandColor(root, '--brand-accent', settings.accentColor);
  }, [user]);

  const value = useMemo<SessionContextValue | null>(() => {
    if (!user) return null;
    const permissions = new Set(user.permissions);
    return {
      user,
      can: (permission) =>
        (Array.isArray(permission) ? permission : [permission]).every((code) =>
          permissions.has(code),
        ),
      canAny: (list) => list.some((code) => permissions.has(code)),
      refresh: load,
      logout: async () => {
        await api.post('/api/auth/logout').catch(() => undefined);
        router.replace('/login');
      },
    };
  }, [user, load, router]);

  if (loading || !value) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <LoadingBlock label="جارٍ تحميل بيانات المستخدم…" />
      </div>
    );
  }

  return <SessionContext.Provider value={value}>{children}</SessionContext.Provider>;
}
