'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState, type ReactNode } from 'react';
import { useSession } from '@/components/session-provider';
import { ROLE_LABELS } from '@/lib/client/format';
import { OfflineIndicator } from '@/components/offline-indicator';

interface NavItem {
  href: string;
  label: string;
  icon: string;
  /** الصلاحيات المطلوبة لعرض العنصر */
  permissions?: string[];
}

const NAV_ITEMS: NavItem[] = [
  { href: '/dashboard', label: 'لوحة التحكم', icon: '📊' },
  { href: '/pos', label: 'نقاط البيع', icon: '🧾', permissions: ['pos.use'] },
  { href: '/tables', label: 'الطاولات', icon: '🪑', permissions: ['pos.use'] },
  { href: '/kitchen', label: 'شاشة التحضير', icon: '👨‍🍳', permissions: ['pos.use'] },
  { href: '/invoices', label: 'الفواتير', icon: '📄', permissions: ['invoices.view'] },
  { href: '/shifts', label: 'الورديات', icon: '🕔', permissions: ['shifts.open'] },
  { href: '/cash', label: 'الصندوق والمصروفات', icon: '💰', permissions: ['cash.manage'] },
  { href: '/reports', label: 'التقارير', icon: '📈', permissions: ['reports.view'] },
  { href: '/products', label: 'المنتجات', icon: '🍔', permissions: ['products.view'] },
  { href: '/offers', label: 'العروض', icon: '🎁', permissions: ['products.view'] },
  { href: '/users', label: 'المستخدمون', icon: '👥', permissions: ['users.view'] },
  { href: '/odoo', label: 'الربط مع Odoo', icon: '🔗', permissions: ['odoo.view_sync'] },
  { href: '/settings', label: 'الإعدادات', icon: '⚙️', permissions: ['settings.manage'] },
  { href: '/audit', label: 'سجل التدقيق', icon: '🛡️', permissions: ['audit.view'] },
];

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const { user, can, logout } = useSession();
  const [menuOpen, setMenuOpen] = useState(false);

  const items = NAV_ITEMS.filter((item) => !item.permissions || can(item.permissions));

  return (
    <div className="flex min-h-screen flex-col bg-surface-muted lg:flex-row">
      {/* الشريط الجانبي */}
      <aside
        className={`${
          menuOpen ? 'block' : 'hidden'
        } shrink-0 border-l border-surface-border bg-ink text-white lg:block lg:w-64`}
      >
        <div className="flex h-16 items-center gap-3 border-b border-white/10 px-5">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand text-lg">
            ☕
          </span>
          <div className="min-w-0">
            <p className="truncate text-sm font-bold">{user.branch?.nameAr ?? 'مارا'}</p>
            <p className="truncate text-[11px] text-white/50">
              {user.branch?.companyName ?? 'نظام نقاط البيع'}
            </p>
          </div>
        </div>

        <nav className="space-y-1 p-3">
          {items.map((item) => {
            const active = pathname === item.href || pathname.startsWith(`${item.href}/`);
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setMenuOpen(false)}
                className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors ${
                  active
                    ? 'bg-brand font-semibold text-white'
                    : 'text-white/70 hover:bg-white/10 hover:text-white'
                }`}
              >
                <span aria-hidden className="text-base">
                  {item.icon}
                </span>
                {item.label}
              </Link>
            );
          })}
        </nav>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        {/* الشريط العلوي */}
        <header className="no-print sticky top-0 z-30 flex h-16 items-center justify-between gap-3 border-b border-surface-border bg-white px-4 lg:px-6">
          <div className="flex items-center gap-3">
            <button
              type="button"
              className="btn-ghost !px-3 lg:hidden"
              onClick={() => setMenuOpen((value) => !value)}
              aria-label="القائمة"
            >
              ☰
            </button>
            <h1 className="text-base font-bold text-ink">
              {items.find(
                (item) => pathname === item.href || pathname.startsWith(`${item.href}/`),
              )?.label ?? 'مارا'}
            </h1>
          </div>

          <div className="flex items-center gap-3">
            <OfflineIndicator />
            <div className="hidden text-left sm:block">
              <p className="text-sm font-semibold text-ink">{user.fullName}</p>
              <p className="text-[11px] text-neutral-500">
                {user.roles.map((role) => ROLE_LABELS[role] ?? role).join('، ')} ·{' '}
                <span className="tabular">{user.employeeNo}</span>
              </p>
            </div>
            <button type="button" className="btn-ghost !px-3" onClick={() => void logout()}>
              خروج
            </button>
          </div>
        </header>

        <main className="flex-1 p-4 lg:p-6">{children}</main>
      </div>
    </div>
  );
}
