'use client';

import { useEffect, useRef, useState, type ReactNode } from 'react';

/** مكونات واجهة مشتركة: نوافذ، تنبيهات، حالات فارغة، شارات */

export function Spinner({ className = '' }: { className?: string }) {
  return (
    <span
      className={`inline-block h-5 w-5 animate-spin rounded-full border-2 border-current border-t-transparent ${className}`}
      role="status"
      aria-label="جارٍ التحميل"
    />
  );
}

export function LoadingBlock({ label = 'جارٍ التحميل…' }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-3 py-16 text-neutral-500">
      <Spinner />
      <span className="text-sm">{label}</span>
    </div>
  );
}

export function EmptyState({
  icon = '📭',
  title,
  description,
  action,
}: {
  icon?: string;
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 px-6 py-16 text-center">
      <span className="text-4xl">{icon}</span>
      <p className="text-base font-semibold text-neutral-700">{title}</p>
      {description && <p className="max-w-md text-sm text-neutral-500">{description}</p>}
      {action && <div className="mt-3">{action}</div>}
    </div>
  );
}

export function ErrorAlert({ message }: { message?: string | null }) {
  if (!message) return null;
  return (
    <div className="flex items-start gap-2 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
      <span aria-hidden>⚠️</span>
      <span className="flex-1">{message}</span>
    </div>
  );
}

export function SuccessAlert({ message }: { message?: string | null }) {
  if (!message) return null;
  return (
    <div className="flex items-start gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
      <span aria-hidden>✅</span>
      <span className="flex-1">{message}</span>
    </div>
  );
}

export function Badge({
  children,
  className = 'bg-neutral-100 text-neutral-700',
}: {
  children: ReactNode;
  className?: string;
}) {
  return <span className={`badge ${className}`}>{children}</span>;
}

/** نافذة منبثقة — تُغلق بمفتاح Escape */
export function Modal({
  open,
  onClose,
  title,
  children,
  footer,
  size = 'md',
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  footer?: ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handler = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [open, onClose]);

  if (!open) return null;

  const widths = {
    sm: 'max-w-sm',
    md: 'max-w-lg',
    lg: 'max-w-3xl',
    xl: 'max-w-5xl',
  } as const;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <div
        ref={ref}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={`flex max-h-[90vh] w-full ${widths[size]} flex-col overflow-hidden rounded-2xl bg-white shadow-pop`}
      >
        <header className="flex items-center justify-between border-b border-surface-border px-5 py-4">
          <h2 className="text-lg font-bold text-ink">{title}</h2>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg px-2 py-1 text-2xl leading-none text-neutral-400 hover:bg-surface-muted hover:text-neutral-700"
            aria-label="إغلاق"
          >
            ×
          </button>
        </header>
        <div className="flex-1 overflow-y-auto px-5 py-4">{children}</div>
        {footer && (
          <footer className="flex items-center justify-end gap-2 border-t border-surface-border bg-surface-muted px-5 py-3">
            {footer}
          </footer>
        )}
      </div>
    </div>
  );
}

/** نافذة تأكيد للعمليات الحساسة، مع إمكانية طلب سبب أو رمز مدير */
export function ConfirmDialog({
  open,
  title,
  message,
  confirmLabel = 'تأكيد',
  cancelLabel = 'إلغاء',
  danger = false,
  requireReason = false,
  reasonLabel = 'السبب',
  requireManagerPin = false,
  busy = false,
  error,
  onConfirm,
  onCancel,
}: {
  open: boolean;
  title: string;
  message?: string;
  confirmLabel?: string;
  cancelLabel?: string;
  danger?: boolean;
  requireReason?: boolean;
  reasonLabel?: string;
  requireManagerPin?: boolean;
  busy?: boolean;
  error?: string | null;
  onConfirm: (payload: { reason?: string; managerPin?: string }) => void;
  onCancel: () => void;
}) {
  const [reason, setReason] = useState('');
  const [pin, setPin] = useState('');

  useEffect(() => {
    if (open) {
      setReason('');
      setPin('');
    }
  }, [open]);

  const canConfirm =
    (!requireReason || reason.trim().length > 0) &&
    (!requireManagerPin || pin.trim().length >= 4);

  return (
    <Modal
      open={open}
      onClose={onCancel}
      title={title}
      size="sm"
      footer={
        <>
          <button type="button" className="btn-ghost" onClick={onCancel} disabled={busy}>
            {cancelLabel}
          </button>
          <button
            type="button"
            className={danger ? 'btn-danger' : 'btn-primary'}
            disabled={!canConfirm || busy}
            onClick={() =>
              onConfirm({
                reason: requireReason ? reason.trim() : undefined,
                managerPin: requireManagerPin ? pin.trim() : undefined,
              })
            }
          >
            {busy && <Spinner className="h-4 w-4" />}
            {confirmLabel}
          </button>
        </>
      }
    >
      <div className="space-y-3">
        {message && <p className="text-sm text-neutral-700">{message}</p>}
        <ErrorAlert message={error} />
        {requireReason && (
          <div>
            <label className="label" htmlFor="confirm-reason">
              {reasonLabel} <span className="text-red-600">*</span>
            </label>
            <textarea
              id="confirm-reason"
              className="input min-h-[76px]"
              value={reason}
              onChange={(event) => setReason(event.target.value)}
              placeholder="اكتب السبب…"
            />
          </div>
        )}
        {requireManagerPin && (
          <div>
            <label className="label" htmlFor="confirm-pin">
              رمز المدير <span className="text-red-600">*</span>
            </label>
            <input
              id="confirm-pin"
              type="password"
              inputMode="numeric"
              className="input tabular text-center text-lg tracking-[0.4em]"
              value={pin}
              onChange={(event) => setPin(event.target.value)}
              placeholder="••••"
              maxLength={8}
            />
          </div>
        )}
      </div>
    </Modal>
  );
}

/** بطاقة مؤشر لوحة التحكم */
export function StatCard({
  label,
  value,
  hint,
  tone = 'default',
  icon,
}: {
  label: string;
  value: string;
  hint?: string;
  tone?: 'default' | 'brand' | 'success' | 'warning' | 'danger';
  icon?: string;
}) {
  const tones = {
    default: 'border-surface-border bg-white',
    brand: 'border-brand/25 bg-brand/5',
    success: 'border-emerald-200 bg-emerald-50',
    warning: 'border-amber-200 bg-amber-50',
    danger: 'border-red-200 bg-red-50',
  } as const;

  return (
    <div className={`rounded-2xl border p-4 shadow-card ${tones[tone]}`}>
      <div className="flex items-start justify-between gap-2">
        <p className="text-xs font-medium text-neutral-600">{label}</p>
        {icon && <span aria-hidden className="text-lg">{icon}</span>}
      </div>
      <p className="tabular mt-2 text-2xl font-bold text-ink">{value}</p>
      {hint && <p className="mt-1 text-xs text-neutral-500">{hint}</p>}
    </div>
  );
}
