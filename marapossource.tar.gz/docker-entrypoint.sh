#!/bin/sh
# يطبق هجرات قاعدة البيانات قبل تشغيل التطبيق
set -e

echo "⏳ في انتظار قاعدة البيانات…"
for i in $(seq 1 30); do
  if npx prisma migrate deploy > /dev/null 2>&1; then
    echo "✅ تم تطبيق هجرات قاعدة البيانات"
    break
  fi
  if [ "$i" = "30" ]; then
    echo "❌ تعذر الاتصال بقاعدة البيانات بعد 30 محاولة"
    exit 1
  fi
  sleep 2
done

exec "$@"
